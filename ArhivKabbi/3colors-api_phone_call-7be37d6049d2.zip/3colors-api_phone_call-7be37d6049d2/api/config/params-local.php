<?php

return [
    'adminEmail'    => 'sup1@gootax.com',
    'pbxPort'       => '8088',
    'pbxHost'       => [
        'media1' => '192.168.99.133',
    ],
    'protokol'      => 'http',
    'notifyServers' => ['http://192.168.99.133:8088/call/notify'],
    'version' => require __DIR__ . '/version.php',
];

