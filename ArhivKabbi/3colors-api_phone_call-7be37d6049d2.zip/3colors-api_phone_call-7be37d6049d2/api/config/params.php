<?php

return [
    'adminEmail'    => 'sup1@gootax.com',
    'pbxPort'       => '8088',
    'pbxHost'       => [
        'media1' => '95.213.177.155',
        'media2' => '62.212.235.118',
        'media3' => '37.26.63.168',
    ],
    'protokol'      => 'http',
    'notifyServers' => ['http://95.213.177.155:8088/call/notify'],
    'version' => require __DIR__ . '/version.php',
];
