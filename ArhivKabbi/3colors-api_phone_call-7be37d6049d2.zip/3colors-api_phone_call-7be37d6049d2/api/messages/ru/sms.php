<?php

return [
    'Your password'  => 'Ваш пароль',
    
];

