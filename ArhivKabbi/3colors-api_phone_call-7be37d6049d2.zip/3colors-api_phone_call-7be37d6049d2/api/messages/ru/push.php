<?php

return [
    'Order rejected' => 'Заказ отменен',
    'From'           => 'Откуда',
    'New order'      => 'Новый заказ',
];

