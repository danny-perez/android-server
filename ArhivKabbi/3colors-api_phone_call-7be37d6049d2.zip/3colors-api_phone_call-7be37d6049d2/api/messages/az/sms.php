<?php

return [
    'Your password' => 'Parol',
];

