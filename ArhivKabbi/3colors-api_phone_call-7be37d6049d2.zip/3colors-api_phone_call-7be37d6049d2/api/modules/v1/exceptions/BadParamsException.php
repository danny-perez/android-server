<?php

namespace api\modules\v1\exceptions;

use yii\base\Exception;

class BadParamsException extends Exception
{

}