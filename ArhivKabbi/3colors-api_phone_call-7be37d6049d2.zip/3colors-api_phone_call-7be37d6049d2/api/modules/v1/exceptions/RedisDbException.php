<?php

namespace api\modules\v1\exceptions;

use yii\base\Exception;

class RedisDbException extends Exception
{

}