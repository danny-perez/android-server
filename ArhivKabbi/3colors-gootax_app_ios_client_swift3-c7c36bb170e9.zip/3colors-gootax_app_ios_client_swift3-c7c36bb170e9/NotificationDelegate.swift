//
//  NotificationDelegate.swift
//  Client
//
//  Created by  Andrew on 28.02.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import Foundation


protocol NotificationDelegate {
    func showNext()
    func dequeueValue() 
}
