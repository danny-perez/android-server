//
//  GootaxGeocoder.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import Foundation
import Alamofire





func getGxAddressByCoords(_ coords : CLLocationCoordinate2D, city : City, completion: @escaping (_ address: AddressTemp?, _ arr: [AddressTemp]) -> Void, failure: (_ error : NSError) -> Void)
{
    var lang = ""
    if let curLan = UserDefaults.standard.object(forKey: udefCurLan) {
        lang = curLan as! String
    } else {
       lang = "ru"
    }
    var params = [
        "point.lat" : String(coords.latitude),
        "point.lon" : String(coords.longitude),
        "format" : "gootax",
        "type_app" : type_app,
        "tenant_id" : curTenant(),
        "size" : "1",
        "sort" : "distance",
        "radius" : mapRadius,
        "lang" :  lang,
    ]
    if let city_id = curCity().cityID {
        params["city_id"] = city_id
    }
    params["hash"] = gxGenSignatureFromParams(params)
    print(params)
    gxGeocodeDoGet(params, completion: { (result) -> Void in
        
        if let res = result["results"] as? [Dictionary<String,AnyObject>] {
            let addresses = gxParseGeo(res)
            var addr = AddressTemp()
            if addresses.count > 0 {
                addr = addresses[0]
                addr.lat = coords.latitude
                addr.lon = coords.longitude
            }
            else {
                addr.lat = coords.latitude
                addr.lon = coords.longitude
            }
            completion(addr, addresses)
        }
        else {
            completion(AddressTemp(), [AddressTemp]())
        }
        
        
        }
    ) { (error) -> Void in
        print(error.description)
    }
}


func gxGetAddresses(_ location: CLLocationCoordinate2D, completion: @escaping (_ arr: [AddressTemp]) -> Void) {
    var params = [
        "point.lat" : String(location.latitude),
        "point.lon" : String(location.longitude),
        "format" : "gootax",
        "type_app" : type_app,
        "tenant_id" : curTenant(),
        "size" : "20",
        "radius" : listRadius
    ]
    if let city_id = curCity().cityID {
        params["city_id"] = city_id
    }
    params["hash"] = gxGenSignatureFromParams(params)
    gxGeocodeDoGet(params, completion: { (result) -> Void in
        
        if let res = result["results"] as? [Dictionary<String,AnyObject>] {
            completion(gxParseGeo(res))
        }
        else {
            completion([AddressTemp]())
        }
        
        
    }
    ) { (error) -> Void in
        print(error.description)
    }
}
