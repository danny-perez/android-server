//
//  ParallaxHeaderView.m
//  ParallaxTableViewHeader
//
//  Created by Vinodh  on 26/10/14.
//  Copyright (c) 2014 Daston~Rhadnojnainva. All rights reserved.

//

#import <QuartzCore/QuartzCore.h>

#import "ParallaxHeaderView.h"
//#import "UIImage+ImageEffects.h"

@interface ParallaxHeaderView ()
@property (weak, nonatomic) IBOutlet UIScrollView *imageScrollView;
@property (weak, nonatomic) IBOutlet UIView *subView;
@property (weak, nonatomic) IBOutlet UIView *botView;
@property (nonatomic) BOOL preorder;
@end
#define DEVICE_SIZE [[[[UIApplication sharedApplication] keyWindow] rootViewController].view convertRect:[[UIScreen mainScreen] bounds] fromView:nil].size
#define kDefaultHeaderFrame CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 44 - 55)

@implementation ParallaxHeaderView

+ (id)parallaxHeaderViewWithSubView:(UIView *)subView andPreOrder:(BOOL)preorder
{
    if (preorder == YES) {
        ParallaxHeaderView *headerView = [[ParallaxHeaderView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 100 - 55)];
        [headerView initialSetupForCustomSubView:subView];
        headerView.height.constant = 65;
        headerView.costLabel.hidden = true;
        headerView.statusLabel.hidden = false;
        return headerView;
        
    }
    else {
        ParallaxHeaderView *headerView = [[ParallaxHeaderView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 44 - 55)];
        [headerView initialSetupForCustomSubView:subView];
        headerView.height.constant = 130;
        headerView.costLabel.hidden = false;
        headerView.statusLabel.hidden = false;
        return headerView;
        
    }
}

- (void)awakeFromNib
{
    if (self.subView)
        [self initialSetupForCustomSubView:self.subView];
    CGRect frame = self.imageScrollView.frame;
    //frame.origin.y = MAX(300 *kParallaxDeltaFactor, 0);
    self.imageScrollView.frame = frame;
    self.frame = kDefaultHeaderFrame;
    self.bounds = kDefaultHeaderFrame;
    
}

#pragma mark -
#pragma mark Private


- (void)initialSetupForCustomSubView:(UIView *)subView
{
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    self.imageScrollView = scrollView;
    self.subView = subView;
    subView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self.imageScrollView addSubview:subView];
    [self addSubview:self.imageScrollView];
}

- (IBAction)setMark:(id)sender {
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center postNotificationName : @"callSetMark" object : nil];
}



#pragma mark - Setters

- (void)setConstr:(BOOL)preorder
{
    if (preorder == YES) {
        self.height.constant = 90;
        self.costLabel.hidden = true;
        self.statusLabel.hidden = false;
        self.frame = CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 100 - 55);
        self.bounds = CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 100 - 55);
        self.botSpace.constant = 0;
    }
    else {
        self.height.constant = 130;
        self.costLabel.hidden = false;
        self.statusLabel.hidden = false;
        self.frame = CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 44 - 55);
        self.bounds = CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height - 44 - 55);
        self.botSpace.constant = 13;
    }
}

- (void)setCost:(NSString *)cost
{
    self.costLabel.text = cost;
}

@end
