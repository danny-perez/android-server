//
//  UINotificationView.swift
//  Client
//
//  Created by  Andrew on 22.02.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit
import AudioToolbox

class UINotificationView: UIView {
    
    @IBOutlet var mainView: UIView!
    @IBOutlet weak var appIcon: UIImageView!
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var heightConstarint: NSLayoutConstraint!
    
    var originalFrame: CGFloat?
    var isShowing: Bool = false
    var isAttach: Bool = false
    var deleagte: NotificationDelegate?
    var timer: Timer?
    
    // DONT'T USE
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    // USE FOR INIT
    init(_ message: NSString) {
        let screen = UIScreen.main
        let frame = CGRect(x: 0, y: 0, width: screen.bounds.width, height: 70)
        
        super.init(frame: frame)
        self.initializeView(message)
    }
    
    fileprivate func initializeView(_ message: NSString) {
        // init frame
        Bundle.main.loadNibNamed("UINotificationView", owner: self, options: nil)
        guard let content = mainView else { return }
        content.frame = self.bounds
        
        // init common view
        self.appIcon.image = UIImage(named: "AppIcon40x40")
        let appName = Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as! String
        self.title.text = appName
        self.message.text = message as String
        
        // add pan gestures
        let gestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
        self.mainView.addGestureRecognizer(gestureRecognizer)
        
        // init over optinons
        self.setHighWindowLevel()
        self.playSong()
        
        self.addSubview(content)
    }
    
    
    func start() {
        self.isShowing = true
        timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.startAnimation), userInfo: nil, repeats: false)
    }
    
    // Hide view with dalay
    func startAnimation() {
        UIView.animate(withDuration: 0.2, delay: 0, options: [.curveEaseOut, .allowUserInteraction, .allowAnimatedContent], animations: {
            if (!self.isAttach) { self.mainView.alpha = 0 }
            }, completion: nil)
        deleagte!.dequeueValue()
    }
    
    func stop() {
        if timer != nil {
            timer?.invalidate()
            timer = nil
        }
    }
    
    // Hide notification now
    func disappear() {
        self.stop()
        self.removeFromSuperview()
    }
    
    // Vibrate phone when show notification
    fileprivate func playSong() {
        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
    }
    
    // Set high level to window for show over StatusBar
    fileprivate func setHighWindowLevel() {
        UIApplication.shared.delegate?.window??.windowLevel = UIWindowLevelStatusBar + 1
        self.mainView.window?.autoresizingMask = [.flexibleHeight, .flexibleHeight]
    }
    
    // Gesture listener
    func handlePan(_ gestureRecognizer: UIPanGestureRecognizer) {
        
        let translation = gestureRecognizer.translation(in: self.mainView)
        
        if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {
            if (self.heightConstarint.constant + translation.y < self.heightConstarint.constant) {
                gestureRecognizer.view!.center = CGPoint(x: gestureRecognizer.view!.center.x, y: gestureRecognizer.view!.center.y + translation.y)
                gestureRecognizer.setTranslation(CGPoint.zero, in: self.mainView)
            }
        }
        
        if self.message.bounds.height < self.message.intrinsicContentSize.height {
            if (gestureRecognizer.state == .began) {
                self.originalFrame = self.heightConstarint.constant
            }
            
            if (gestureRecognizer.state == .changed) {
                if (translation.y > 0) {
                    var newFrame: CGFloat = originalFrame!;
                    newFrame += translation.y;
                    self.heightConstarint.constant = newFrame;
                }
            }
        }
        
        if gestureRecognizer.state == .ended {
            if self.mainView.center.y > self.heightConstarint.constant/3 {
                self.mainView.center.y = self.mainView.bounds.height/2
            } else {
                self.mainView.center.y = -self.heightConstarint.constant
                self.mainView.window?.windowLevel = UIWindowLevelNormal
                self.startAnimation()
                if (isAttach) {
                    isAttach = false
                    deleagte?.showNext()
                }
            }
            
            if self.message.bounds.height < self.message.intrinsicContentSize.height {
                self.heightConstarint.constant = 70
            } else {
                self.stop()
                isAttach = true
            }
            
        }
    }
}
