//
//  ParallaxHeaderView.h
//  ParallaxTableViewHeader
//
//  Created by Vinodh  on 26/10/14.
//  Copyright (c) 2014 Daston~Rhadnojnainva. All rights reserved.

//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ParallaxHeaderView : UIView

+ (id)parallaxHeaderViewWithSubView:(UIView *)subView andPreOrder:(BOOL)preorder;
- (void)setCost : (NSString *)cost;
- (void)setConstr:(BOOL)preorder;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *botSpace;
@property (weak, nonatomic) IBOutlet UIImageView *star1;
@property (weak, nonatomic) IBOutlet UIImageView *star2;
@property (weak, nonatomic) IBOutlet UIImageView *star3;
@property (weak, nonatomic) IBOutlet UIImageView *star4;
@property (weak, nonatomic) IBOutlet UIImageView *star5;
@property (strong, nonatomic) IBOutlet UILabel *yourMark;
@property (weak, nonatomic) IBOutlet UILabel *costLabel;
@property (weak, nonatomic) IBOutlet UILabel *driverNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *carModelLabel;
@property (weak, nonatomic) IBOutlet UIImageView *driverPhoto;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewHeight;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *height;
@property (weak, nonatomic) IBOutlet UILabel *toOrderTitle;
@property (weak, nonatomic) IBOutlet UILabel *toOrderLabel;
@property (weak, nonatomic) IBOutlet UIView *setMarkView;
@property (weak, nonatomic) IBOutlet UILabel *setMarkLabel;
    @property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintReviewView;
    
@end
