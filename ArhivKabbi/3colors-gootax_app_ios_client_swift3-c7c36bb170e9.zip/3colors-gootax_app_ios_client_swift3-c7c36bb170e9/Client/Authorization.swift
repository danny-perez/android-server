//
//  Authorization.swift
//  Client
//
//  Created by Dmitriy Kudrin on 25.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation




public func authorization(_ phoneNumber : String, completion: @escaping (_ result: Bool) -> Void)
{
    gxAuth(phoneNumber, completion: { (res) -> Void in
        completion(res)
    })
}


public func login(_ referralCode: String, cityId: String, phoneNumber : String, code : String, completion: @escaping (_ result: Bool, _ code: Int) -> Void)
{
    gxLogin(referralCode, cityId: cityId , phoneNumber: phoneNumber, code: code, completion: { (res, code) -> Void in
        completion(res, code)
    })
}


//MARK: Gootax

func gxAuth(_ phoneNumber : String, completion: @escaping (_ res: Bool) -> Void) {
    let params = ["phone" : phoneNumber]
    gxDoPOST(kGxApiSendPassword, params: params, completion: { (result) -> Void in
//        print(result)
        if result is Dictionary<String, AnyObject> {
            completion(gxParseSendedCode(result as! Dictionary<String, AnyObject>))
        }
        else {
            completion(false)
        }
        }) { (error) -> Void in
            completion(false)
            print(error.description)
    }
}

func gxParseSendedCode(_ dict : Dictionary<String, AnyObject>) -> Bool {
    var result : Bool = false
    
    if (dict["result"] != nil) {
        if dict["result"] is Dictionary<String, AnyObject> {
            let res : Dictionary<String, AnyObject> = dict["result"] as! Dictionary<String, AnyObject>
            if (res["password_result"] != nil) {
                if res["password_result"] is String {
                    if res["password_result"] as! String == "1" {
                        result = true
                    }
                }
                if res["password_result"] is Double {
                    if res["password_result"] as! Double == 1 {
                        result = true
                    }
                }
            }
        }
    }
    return result
}


func gxParseLogin(_ dict : Dictionary<String, AnyObject>) -> Bool {
    var result : Bool = false
    
    if (dict["result"] != nil) {
        if dict["result"] is Dictionary<String, AnyObject> {
            let res : Dictionary<String, AnyObject> = dict["result"] as! Dictionary<String, AnyObject>
            if (res["accept_result"] != nil) {
                if res["accept_result"] is String {
                    if res["accept_result"] as! String == "1" {
                        result = true
                    }
                }
                if res["accept_result"] is Double {
                    if res["accept_result"] as! Double == 1 {
                        result = true
                    }
                }
                if res["accept_referral_system"] is Double {
                    if res["accept_referral_system"] as! Double == 1 {
                        showMessage("", message: strRefActivatedSuccess()) // TODO
                    }
                }
                if result {
                    if res["client_profile"] != nil {
                        if res["client_profile"] is Dictionary<String, AnyObject> {
                            gxParseProfile(res["client_profile"] as! Dictionary<String, AnyObject>)
                        }
                        if res["bonus_system"] != nil {
                            gxParseBonusSystem(res["bonus_system"] as! Dictionary<String, AnyObject>)
                        }
                    }
                }
            }
        }
    }
    return result
}


func gxLogin(_ referralCode: String, cityId: String, phoneNumber : String, code: String, completion: @escaping (_ res: Bool, _ code: Int) -> Void) {
    var params = [
        "phone" : phoneNumber,
        "password" : code
    ]
    
    
    if (!referralCode.isEmpty) {
        params["city_id"] = cityId
        params["referral_code"] = referralCode
    }
    
    /**
     0 - success
     1 - incorrect referral
     */
    gxDoPOST(kGxApiAcceptPassword, params: params, completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            // 18 - INCORRECTLY_REFERRAL_CODE
            if let code = result["code"] as? Int {
                if (code == 18) {
                    return completion(false, 1)
                }
            }
            completion(gxParseLogin(result as! Dictionary<String, AnyObject>), 0)
        }
        else {
            completion(false, 0)
        }
        }) { (error) -> Void in
            print(error.description)
            completion(false, 0)
    }
}
