//
//  Alert.swift
//  Client
//
//  Created by  Andrew on 05/12/2017.
//  Copyright © 2017 Gootax. All rights reserved.
//

import Foundation

class AlertLoading {
    
    var alert: UIAlertController? = nil
    
    private func show(message: String) {
        self.alert = UIAlertController(title: nil, message: show, preferredStyle: UIAlertControllerStyle.alert)
        
        let spinnerIndicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        spinnerIndicator.center = CGPoint(x: 135.0, y: 65.5)
        spinnerIndicator.color = UIColor.black
        spinnerIndicator.startAnimating()
        
        self.alert!.view.addSubview(spinnerIndicator)
    }
    
    
    private func dismiss() {
        
    }
    
    
}

