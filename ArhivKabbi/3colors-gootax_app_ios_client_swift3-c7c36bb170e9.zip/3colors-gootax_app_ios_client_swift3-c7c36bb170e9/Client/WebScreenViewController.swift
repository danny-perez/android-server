//
//  WebScreenViewController.swift
//  Client
//
//  Created by Andrew Chupin on 11.02.2018.
//  Copyright © 2018 Gootax. All rights reserved.
//

import UIKit

class WebScreenViewController: UIViewController {

    @IBOutlet weak var wvContent: UIWebView!
    @IBOutlet weak var indicatorLoading: UIActivityIndicatorView!
    @IBOutlet weak var closeButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        wvContent.delegate = self
        wvContent.isHidden = true
        indicatorLoading.isHidden = false
        indicatorLoading.startAnimating()
        
        localize()
        colorize()
        
        loadPage(url: webScreenUrl)
    }
    
    @IBAction func closeAction(_ sender: UIBarButtonItem) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    
    private func loadPage(url: String) {
        if let urlPath = URL(string: url) {
            wvContent.loadRequest(URLRequest(url: urlPath))
        }
    }
    
    
    func localize() {
        self.navigationItem.title = webScreenTitle
    }
    
    
    func colorize() {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
}

extension WebScreenViewController: UIWebViewDelegate {
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        wvContent.isHidden = false
        indicatorLoading.isHidden = true
        indicatorLoading.stopAnimating()
    }
    
}
