//
//  GoogleGeocoder.swift
//  Client
//
//  Created by Dmitriy Kudrin on 30.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import Alamofire

func getGoogleAddressByCoords(_ coords : CLLocationCoordinate2D, completion: (_ address: AddressTemp?, _ arr: [AddressTemp]) -> Void, failure: (_ error : NSError) -> Void)
{
    var params : Dictionary<String, String> = Dictionary()
    params["latlng"] = String(format: "%@,%@", String(coords.latitude), String(coords.longitude))
    params["language"] = lang()
    
//    Alamofire.request(.GET, googleGeocodingURL, parameters: params)
//        .responseJSON { (request, response, data) in
//            if (data.isSuccess) {
//                
////                let result = data.value as! Dictionary<String, AnyObject>
//
////                completion(parseGoogleAddress(result["results"] as! [Dictionary<String, AnyObject>]))
//                //completion(result: data as! AddressTemp)
//            }
//    }
}


func parseGoogleAddress(_ dicts : [Dictionary<String, AnyObject>]) -> (address: AddressTemp?, arr: [AddressTemp])
{
    
    var addresses : [AddressTemp] = [AddressTemp]()
    
    if dicts.count > 0 {
        for dict : Dictionary<String, AnyObject> in dicts {
            let newAddress = AddressTemp()
            for adcomps : Dictionary<String, AnyObject> in dict["address_components"] as! [Dictionary<String, AnyObject>] {
                for type : String in adcomps["types"] as! [String] {
                    if type == "route" {
                        newAddress.street = (adcomps["long_name"] as? String)!
                    }
                    if type == "street_number" {
                        newAddress.house = (adcomps["long_name"] as? String)!
                    }
                    if type == "administrative_area_level_2" {
                        newAddress.city = adcomps["long_name"] as? String
                    }
                }
            }
            if dict["geometry"] != nil {
                let geometry : Dictionary<String, AnyObject> = dict["geometry"] as! Dictionary<String, AnyObject>
                if geometry["location"] != nil {
                    let _ : Dictionary<String, AnyObject> = geometry["location"]! as! Dictionary<String, AnyObject>
                    //newAddress.lat = (location["lat"]?.doubleValue)!
                    //newAddress.lon = (location["lng"]?.doubleValue)!
                }
            }
            if newAddress.street != "" {
                addresses.append(newAddress)
            }
        }
    
    }
    
    if addresses.count > 0 {
        return (addresses[0], addresses)
    }
    else {
        return (AddressTemp(), addresses)
    }
    
    
    
}


