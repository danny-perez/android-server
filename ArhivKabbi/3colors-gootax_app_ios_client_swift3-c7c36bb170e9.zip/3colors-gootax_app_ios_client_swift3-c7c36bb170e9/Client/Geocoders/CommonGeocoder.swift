//
//  CommonGeocoder.swift
//  Client
//
//  Created by Dmitriy Kudrin on 30.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import MapKit
import GoogleMaps


class MapPin : NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}


class MapPinCar : NSObject, MKAnnotation {
    dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var car : Car?
    
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        self.car = nil
    }
}

class MapPinCarDriver : NSObject, MKAnnotation {
    dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}

class TimeAnnotation : NSObject, MKAnnotation {
    dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}

class PointAnnotation : NSObject, MKAnnotation {
    dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var point: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String, point: String) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        self.point = point
    }
}


func getAddressByCoords(_ coords : CLLocationCoordinate2D, city: City, completion: @escaping (_ address: AddressTemp?, _ arr: [AddressTemp]) -> Void, failure: (_ error : NSError) -> Void)
{
    getGxAddressByCoords(coords, city: city, completion: { (address, arr) -> Void in
        completion(address, arr)
        }, failure: { (error) -> Void in
            
    })
}


