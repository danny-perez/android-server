//
//  OsmGeocoder.swift
//  Client
//
//  Created by Dmitriy Kudrin on 30.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import Alamofire

func getOSMAddressByCoords(_ coords : CLLocationCoordinate2D, completion: @escaping (_ address: AddressTemp?, _ arr: [AddressTemp]) -> Void, failure: (_ error : NSError) -> Void)
{
    var params : Dictionary<String, String> = Dictionary()
    params["format"] = "json"
    params["lat"] = String(coords.latitude)
    params["lon"] = String(coords.longitude)
    params["accept-language"] = lang()
    
    Alamofire.request(osmGeocodingURL, parameters: params)
        .responseJSON { response in
            if let value =  response.result.value {
                if value is Dictionary<String, AnyObject> {
                    let val = parseOsmAddress(value as! Dictionary<String, AnyObject>)
                    completion(val.address, val.arr)
                }
            }
    }
}

func parseOsmAddress(_ dict : Dictionary<String, AnyObject>) -> (address: AddressTemp?, arr: [AddressTemp])
{
    let address : AddressTemp = AddressTemp()
    var addresses : [AddressTemp] = [AddressTemp]()
    
    if (dict["address"] != nil) {
        if ((dict["address"] as! Dictionary<String, String>)["city"] != nil) {
            address.city = (dict["address"] as! Dictionary<String, String>)["city"]!
        }
        if address.city == "" {
            if ((dict["address"] as! Dictionary<String, String>)["town"] != nil) {
                address.city = (dict["address"] as! Dictionary<String, String>)["town"]!
            }
        }
        if address.city == "" {
            if ((dict["address"] as! Dictionary<String, String>)["village"] != nil) {
                address.city = (dict["address"] as! Dictionary<String, String>)["village"]!
            }
        }
        if address.city == "" {
            if ((dict["address"] as! Dictionary<String, String>)["hamlet"] != nil) {
                address.city = (dict["address"] as! Dictionary<String, String>)["hamlet"]!
            }
        }
        if ((dict["address"] as! Dictionary<String, String>)["road"] != nil) {
            address.street = (dict["address"] as! Dictionary<String, String>)["road"]!
        }
        if (address.street == "") {
            if ((dict["address"] as! Dictionary<String, String>)["neighbourhood"] != nil) {
                address.street = (dict["address"] as! Dictionary<String, String>)["neighbourhood"]!
            }
            if (address.street == "") {
                if ((dict["address"] as! Dictionary<String, String>)["pedestrian"] != nil) {
                    address.street = (dict["address"] as! Dictionary<String, String>)["pedestrian"]!
                }
            }
            if (address.street == "") {
                if ((dict["address"] as! Dictionary<String, String>)["residential"] != nil) {
                    address.street = (dict["address"] as! Dictionary<String, String>)["residential"]!
                }
            }
        }
        if ((dict["address"] as! Dictionary<String, String>)["house_number"] != nil) {
            address.house = (dict["address"] as! Dictionary<String, String>)["house_number"]!
        }
    }
    if (dict["lat"] != nil) {
        address.lat = (dict["lat"]?.doubleValue)!
    }
    if (dict["lon"] != nil) {
        address.lon = (dict["lon"]?.doubleValue)!
    }
    
    addresses.append(address)
    
    return (address, addresses)
}



func getOSMCoordsByAddress(_ address : AddressTemp, completion: @escaping (_ coords: CLLocationCoordinate2D) -> Void, failure: @escaping () -> Void)
{
    var params : Dictionary<String, String> = Dictionary()
    params["format"] = "json"
    params["q"] = "\(address.city!) \(address.street!) \(address.house!)"
    Alamofire.request(osmGeocodingDir, parameters: params)
        .responseJSON { response in
            var finished = false
            if let value = response.result.value {
                if value is [Dictionary<String, AnyObject>] {
                    if (value as! [Dictionary<String, AnyObject>]).count > 0 {
                        finished = true
                        
                        parseOSMCoords(value as! [Dictionary<String, AnyObject>], completion: { (coord) -> Void in
                            completion(coord)
                        })
 
                    }
                }
            }
            if !finished {
                failure()
            }
    }
}


func parseOSMCoords(_ arr : [Dictionary<String, AnyObject>], completion: (_ coord: CLLocationCoordinate2D) -> Void){
    var coord = CLLocationCoordinate2D()
    if arr.count > 0 {
        let dict = arr[0]
        if dict["lat"] != nil {
            if dict["lat"] is String {
                coord.latitude = ((dict["lat"] as! String) as NSString).doubleValue
            }
            if dict["lat"] is Double {
                coord.latitude = dict["lat"] as! Double
            }
        }
        if dict["lon"] != nil {
            if dict["lon"] is String {
                coord.longitude = ((dict["lon"] as! String) as NSString).doubleValue
            }
            if dict["lon"] is Double {
                coord.longitude = dict["lon"] as! Double
            }
        }
    }
    completion(coord)
}
