//
//  PayTypeWithNoteTableViewCell.swift
//  Client
//
//  Created by  Andrew on 26.08.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PayTypeWithNoteTableViewCell: UITableViewCell {

    @IBOutlet weak var payTypelabel: UILabel!
    @IBOutlet weak var payTypeNoteLabel: UILabel!
    @IBOutlet weak var payTypeLogo: UIImageView!
    @IBOutlet weak var payTypeOk: UIImageView!
    @IBOutlet weak var BalanceLabel: UILabel!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var botSpace: NSLayoutConstraint!
    @IBOutlet weak var backView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func colorize()
    {
        self.tintColor = colorNewTint()
        self.applyCurvedShadow(self.backView)
    }
    
    
    func applyCurvedShadow(_ view: UIView) {
        let layer = self.backView.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }

}
