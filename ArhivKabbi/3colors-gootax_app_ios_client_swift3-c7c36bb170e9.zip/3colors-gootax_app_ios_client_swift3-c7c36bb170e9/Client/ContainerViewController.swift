//
//  ContainerViewController.swift
//  SlideOutNavigation
//
//  Created by James Frost on 03/08/2014.
//  Copyright (c) 2014 James Frost. All rights reserved.
//

import UIKit
import QuartzCore
import Foundation
import GoogleMaps
import RevealingSplashView

enum SlideOutState {
    case bothCollapsed
    case leftPanelExpanded
    case rightPanelExpanded
}



var centerPanelExpandedOffset: CGFloat = 62

class ContainerViewController: UIViewController {
    
    var centerNavigationController: UINavigationController!
    var centerViewController: MapViewController!
    
    var currentState: SlideOutState = .bothCollapsed {
        didSet {
            let shouldShowShadow = currentState != .bothCollapsed
            showShadowForCenterViewController(shouldShowShadow)
        }
    }
    
    var leftViewController: LeftSideViewController?
    
    var panGestureRecognizer : UIPanGestureRecognizer?
    
    var firstView : UIView?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if (profile().phone != ""){
            gxGetProfile(profile().phone!, completion: { (result) -> Void in
                
            })
        }
        
        gxGetShare()
        gxPingTime()
        
        centerViewController = UIStoryboard.centerViewController()
        centerViewController.delegate = self
        // wrap the centerViewController in a navigation controller, so we can push views to it
        // and display bar button items in the navigation bar
        let navCont = UINavigationController()
        navCont.viewControllers = [centerViewController]
        centerNavigationController = navCont
        //    centerNavigationController.navigationBar.fixedHeightWhenStatusBarHidden = true
        view.addSubview(centerNavigationController.view)
        addChildViewController(centerNavigationController)
        centerNavigationController.didMove(toParentViewController: self)
        
        self.panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(ContainerViewController.handlePanGesture(_:)))
        centerNavigationController.view.addGestureRecognizer(self.panGestureRecognizer!)
        self.panGestureRecognizer?.delegate = self
        self.addLeftPanelViewController()
        let revealingSplashView = RevealingSplashView(iconImage: UIImage(named: "logo_splash")!,iconInitialSize: CGSize(width: 270, height: 129), backgroundColor: colorSplash())
        
        
        /*self.view.addSubview(revealingSplashView)
        
        revealingSplashView.duration = 0.9
        
        revealingSplashView.animationType = SplashAnimationType.twitter
        
        revealingSplashView.startAnimation(){
            
        }*/
    }
    
}

// MARK: CenterViewController delegate

extension ContainerViewController: CenterViewControllerDelegate {
    
    func toggleLeftPanel() {
        let notAlreadyExpanded = (currentState != .leftPanelExpanded)
        
        if notAlreadyExpanded {
            addLeftPanelViewController()
        }
        
        animateLeftPanel(shouldExpand: notAlreadyExpanded)
    }
    
    func collapseSidePanels() {
        switch (currentState) {
        case .leftPanelExpanded:
            toggleLeftPanel()
        default:
            break
        }
    }
    
    func showForeground() {
        leftViewController?.showForeground()
    }
    
    func hideForeground() {
        leftViewController?.hideForeground()
    }
    
    func addLeftPanelViewController() {
        if (leftViewController == nil) {
            leftViewController = UIStoryboard.leftViewController()
            addChildSidePanelController(leftViewController!)
        }
    }
    
    func reloadLeftPanel() {
        if (leftViewController != nil) {
            leftViewController?.setProfile()
        }
    }
    
    func updateCityPhone(_ city: City?) {
        if (leftViewController != nil) {
            leftViewController?.updateLeftPhone(city)
        }
    }
    
    func updateCenterView(controller: UINavigationController) {
        self.centerNavigationController = controller
    }
    
    func addChildSidePanelController(_ sidePanelController: LeftSideViewController) {
        sidePanelController.delegate = centerViewController
        
        view.insertSubview(sidePanelController.view, at: 0)
        
        addChildViewController(sidePanelController)
        sidePanelController.didMove(toParentViewController: self)
    }
    
    
    func animateLeftPanel(shouldExpand: Bool) {
        if (shouldExpand) {
            leftViewController?.hideForeground()
            currentState = .leftPanelExpanded
            centerViewController.uieSpace.constant = 3000
            if UI_USER_INTERFACE_IDIOM() == .pad {
                animateCenterPanelXPosition(targetPosition: 300)
            }
            else {
                let position = centerNavigationController.view.frame.width - centerPanelExpandedOffset
                animateCenterPanelXPosition(targetPosition: position)
            }
        }
        else {
            animateCenterPanelXPosition(targetPosition: 0) { finished in
                self.currentState = .bothCollapsed
                self.centerViewController.uieSpace.constant = 15
            }
        }
        leftViewController?.tableView.reloadData()
    }
    
    func animateCenterPanelXPosition(targetPosition: CGFloat, completion: ((Bool) -> Void)! = nil) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: UIViewAnimationOptions(), animations: {
            if layoutDirection == .rightToLeft {
                self.centerNavigationController.view.frame.origin.x = -targetPosition
            } else {
                self.centerNavigationController.view.frame.origin.x = targetPosition
            }
            self.centerNavigationController.view.layoutIfNeeded()
            print(targetPosition)
        }, completion: completion)
    }
    
    
    func showShadowForCenterViewController(_ shouldShowShadow: Bool) {
        if (shouldShowShadow) {
            centerNavigationController.view.layer.shadowOpacity = 0.8
        } else {
            centerNavigationController.view.layer.shadowOpacity = 0.0
        }
        
    }
    
}


//func classNameAsString(obj: AnyObject) -> String {
//    return _stdlib_getDemangledTypeName(obj).componentsSeparatedByString(".").last!
//}

extension ContainerViewController: UIGestureRecognizerDelegate {
    // MARK: Gesture recognizer
    
    func handlePanGesture(_ recognizer: UIPanGestureRecognizer) {
        if recognizer == self.panGestureRecognizer {
            let gestureIsDraggingFromLeftToRight = (recognizer.velocity(in: view).x > 0)
            
            switch(recognizer.state) {
            case .began:
                let point = recognizer.location(in: recognizer.view)
                let viewTouched = recognizer.view?.hitTest(point, with: nil)
                var need = true
                if viewTouched != nil {
                    if point.x < 20 {
                        self.firstView = UIView()
                    }
                    else if classNameAsString((viewTouched!.superview?.superview?.superview)!) == "UINavigationTransitionView" {
                        self.firstView = viewTouched!.superview?.superview?.superview
                        need = false
                    }
                    else if viewTouched!.superview?.superview?.superview?.superview is UITableView {
                        self.firstView = viewTouched!.superview?.superview?.superview?.superview
                        need = false
                    }
                    else if viewTouched!.superview?.superview is MKMapView {
                        self.firstView = viewTouched!.superview?.superview
                        need = false
                    }
                    else if viewTouched!.superview is GMSMapView {
                        self.firstView = viewTouched!.superview
                        need = false
                    }
                    else if viewTouched!.superview?.superview is UICollectionViewCell {
                        self.firstView = viewTouched!.superview?.superview
                        need = false
                    }
                    else if viewTouched!.superview?.superview is UICollectionView {
                        self.firstView = viewTouched!.superview?.superview
                        need = false
                    }
                    else {
                        self.firstView = UIView()
                    }
                }
                else {
                    self.firstView = UIView()
                }
                if need {
                    if (currentState == .bothCollapsed) {
                        if (gestureIsDraggingFromLeftToRight) {
                            addLeftPanelViewController()
                        }
                        
                        showShadowForCenterViewController(true)
                        
                    }
                }
                if (currentState != .bothCollapsed) {
                    self.firstView = UIView()
                }
            case .changed:
                var need = true
                if self.firstView != nil {
                    if classNameAsString(self.firstView!) == "UINavigationTransitionView" {
                        need = false
                    }
                    else if self.firstView is UITableView {
                        need = false
                    }
                    else if self.firstView is MKMapView {
                        need = false
                    }
                    else if self.firstView is GMSMapView {
                        need = false
                    }
                    else if self.firstView is UICollectionViewCell {
                        need = false
                    }
                    else if self.firstView is UICollectionView {
                        need = false
                    }
                    
                }
                if need == true {
                    if (currentState == .bothCollapsed) {
                        if (gestureIsDraggingFromLeftToRight) {
                            addLeftPanelViewController()
                        }
                    }
                    if layoutDirection == .rightToLeft {
                        if recognizer.view!.center.x + recognizer.translation(in: view).x <= UIScreen.main.bounds.width / 2 {
                            recognizer.view!.center.x = recognizer.view!.center.x + recognizer.translation(in: view).x
                            recognizer.setTranslation(CGPoint.zero, in: view)
                        }
                    } else {
                        if recognizer.view!.center.x + recognizer.translation(in: view).x >= UIScreen.main.bounds.width / 2 {
                            recognizer.view!.center.x = recognizer.view!.center.x + recognizer.translation(in: view).x
                            recognizer.setTranslation(CGPoint.zero, in: view)
                        }
                    }
                }
            case .ended:
                var need = true
                if self.firstView != nil {
                    if classNameAsString(self.firstView!) == "UINavigationTransitionView" {
                        need = false
                    }
                    else if self.firstView is UITableView {
                        need = false
                    }
                    else if self.firstView is MKMapView {
                        need = false
                    }
                    else if self.firstView is GMSMapView {
                        need = false
                    }
                    else if self.firstView is UICollectionViewCell {
                        need = false
                    }
                    else if self.firstView is UICollectionView {
                        need = false
                    }
                }
                if need == true {
                    if (leftViewController != nil) {
                        if UI_USER_INTERFACE_IDIOM() == .pad {
                            var hasMovedGreaterThanHalfway = false
                            if layoutDirection == .rightToLeft {
                                hasMovedGreaterThanHalfway = recognizer.view!.center.x < (view.bounds.size.width - 300)
                            } else {
                               hasMovedGreaterThanHalfway = recognizer.view!.center.x > (view.bounds.size.width - 300)
                            }
                            animateLeftPanel(shouldExpand: hasMovedGreaterThanHalfway)
                        }
                        else {
                            var hasMovedGreaterThanHalfway = false
                            if layoutDirection == .rightToLeft {
                                hasMovedGreaterThanHalfway = recognizer.view!.center.x < view.bounds.size.width
                            } else {
                                hasMovedGreaterThanHalfway = recognizer.view!.center.x > view.bounds.size.width
                            }
                            animateLeftPanel(shouldExpand: hasMovedGreaterThanHalfway)
                        }
                        
                    }
                }
            default:
                break
            }
        }
        
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
}


extension UIStoryboard {
    class func mainStoryboard() -> UIStoryboard { return UIStoryboard(name: "Main", bundle: Bundle.main) }
    
    class func leftViewController() -> LeftSideViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "LeftViewController") as? LeftSideViewController
    }
    
    class func centerViewController() -> MapViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "CenterViewController") as? MapViewController
    }
    
    class func authViewController() -> UINavigationController? {
        return UINavigationController(rootViewController:mainStoryboard().instantiateViewController(withIdentifier: "auth"))
    }
    
    class func ordersListViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "listNavigation") as? UINavigationController
    }
    
    class func aboutUsViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "about") as? UINavigationController
    }
    
    class func profileViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "profileNavigationController") as? UINavigationController
    }
    
    class func referralCodeViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "referralCode") as? UINavigationController
    }
    
    class func referralSystemViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "referralSystem") as? UINavigationController
    }
    
    class func orderSummaryViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "ordSum") as? UINavigationController
    }
    
    class func timePicker() -> NewTimePickViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "timepick") as? NewTimePickViewController
    }
    
    class func mapPicker() -> MapPickViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "mapPick") as? MapPickViewController
    }
    
    class func finishedOrder() -> FinishedOrderViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "completed") as? FinishedOrderViewController
    }
    
    class func preoderViewController() -> FinishedOrderViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "completed") as? FinishedOrderViewController
    }
    
    class func wishesController() -> WishesViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "wishesN") as? WishesViewController
    }
    
    class func payTypeController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "paytype") as? UINavigationController
    }
    
    class func settingsController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "settings") as? UINavigationController
    }
    
    class func tenantSettingsController() -> TenantSettingsViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "tenSettings") as? TenantSettingsViewController
    }
    
    class func addressDetailController() -> AddressDetailViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "addressDetail") as? AddressDetailViewController
    }
    
    class func tariffPickerViewController() -> TariffPickViewController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "tariff") as? TariffPickViewController
    }
    
    class func editOrderViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "EditOrder") as? UINavigationController
    }
    
    class func webScreenViewController() -> UINavigationController? {
        return mainStoryboard().instantiateViewController(withIdentifier: "WebScreen") as? UINavigationController
    }
    
}
