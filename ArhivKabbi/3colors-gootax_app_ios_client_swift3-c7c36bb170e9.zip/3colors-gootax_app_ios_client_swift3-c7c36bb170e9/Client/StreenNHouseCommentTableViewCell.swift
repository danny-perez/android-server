//
//  StreenNHouseCommentTableViewCell.swift
//  Client
//
//  Created by  Andrew on 25.06.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class StreenNHouseCommentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var snhTitle: UILabel!
    @IBOutlet weak var snhField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        colorize()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // если выбрали - сделать поле для редактирования адреса
        if selected {
            self.snhField.becomeFirstResponder()
        }
        
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        //        self.flatTitle.textColor = colorMainText()
        //        self.flatField.textColor = colorMainFieldText()
    }
    
    func localize()
    {
        self.snhTitle.text = strComStreetNHouseComment()
    }


}
