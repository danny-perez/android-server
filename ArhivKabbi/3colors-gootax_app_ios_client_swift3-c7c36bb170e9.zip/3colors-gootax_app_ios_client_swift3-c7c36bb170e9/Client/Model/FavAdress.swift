//
//  FavAdress.swift
//  Client
//
//  Created by Dmitriy Kudrin on 13.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import CoreData

@objc(FavAdress)
class FavAdress: NSManagedObject {
    @NSManaged
    var addressID : NSNumber
    
    @NSManaged
    var building : String
    
    @NSManaged
    var city : String
    
    @NSManaged
    var cityID : String
    
    @NSManaged
    var corp : String
    
    @NSManaged
    var house : String
    
    @NSManaged
    var housing : String
    
    @NSManaged
    var lat : NSNumber
    
    @NSManaged
    var lon : NSNumber
    
    @NSManaged
    var porch : NSNumber
    
    @NSManaged
    var publicPlace : NSNumber
    
    @NSManaged
    var street : String
    
    @NSManaged
    var favorite : NSNumber
}
