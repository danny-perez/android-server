//
//  Driver.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import CoreData
@objc(Driver)
class Driver: NSManagedObject {
    @NSManaged
    var carModel : String
    
    @NSManaged
    var carNum : String
    
    @NSManaged
    var name : String
    
    @NSManaged
    var phone : String
    
    @NSManaged
    var photo : String? // тут будет ссылка на фотку
    
    @NSManaged
    var rate : NSNumber? // рейтинг водилы
    
    @NSManaged
    var lat : NSNumber?
    
    @NSManaged
    var lon : NSNumber?
    
    @NSManaged
    var angle : NSNumber?
    
    @NSManaged
    var loadedPhoto : Data?
    
    @NSManaged
    var order : Order // заказ, к которому он привязан. к каждому заказу будет создан свой водила
    
}
