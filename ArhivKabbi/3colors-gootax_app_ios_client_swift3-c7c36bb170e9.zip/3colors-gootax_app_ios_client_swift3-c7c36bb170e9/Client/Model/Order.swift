//
//  Order.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import CoreData
@objc(Order)
open class Order: NSManagedObject {
    
    @NSManaged
    var driver : Driver?
    
    @NSManaged
    var pointA : Address?
    
    @NSManaged
    var pointB : Address?
    
    @NSManaged
    var pointC : Address?
    
    @NSManaged
    var pointD : Address?
    
    @NSManaged
    var pointE : Address?
    
    @NSManaged
    var accrualCity : String
    
    @NSManaged
    var accrualOutCity : String
    
    @NSManaged
    var carAssigningDateTime : Date?
    
    @NSManaged
    var carAtPlaceDateTime : Date?
    
    @NSManaged
    var createDateTime : Date
    
    @NSManaged
    var carDateTime : Date?
    
    @NSManaged
    var comment : String
    
    @NSManaged
    var cardNum : String
    
    @NSManaged
    var cost_adds : NSNumber?
    
    @NSManaged
    var cost_clientWait : NSNumber?
    
    @NSManaged
    var time_clientWait : NSNumber?
    
    @NSManaged
    var cost_car_assigning : NSNumber
    
    @NSManaged
    var cost_city : NSNumber
    
    @NSManaged
    var cost_order : NSNumber
    
    @NSManaged
    var cost_outCity : NSNumber?
    
    @NSManaged
    var cost_prostCity : NSNumber?
    
    @NSManaged
    var time_city : NSNumber?
    
    @NSManaged
    var time_outCity : NSNumber?
    
    @NSManaged
    var cost_prostOutCity : NSNumber?
    
    @NSManaged
    var currency : String
    
    @NSManaged
    var dist_city : NSNumber?
    
    @NSManaged
    var dist_cityProst : NSNumber?
    
    @NSManaged
    var dist_included : NSNumber?
    
    @NSManaged
    var dist_outCity : NSNumber?
    
    @NSManaged
    var carTime : NSNumber?
    
    @NSManaged
    var dist_outCityProst : NSNumber?
    
    @NSManaged
    var dist_sum : NSNumber?
    
    @NSManaged
    var feedback : String
    
    @NSManaged
    var routeEncoded : String?
    
    @NSManaged
    var orderID : String?
    
    @NSManaged
    var companyId : String?
    
    @NSManaged
    var orderNumber : String!
    
    @NSManaged
    var payType : String?
    
    @NSManaged
    var statusID : String
    
    @NSManaged
    var statusLabel : String
    
    @NSManaged
    var preorder : NSNumber
    
    @NSManaged
    var rate : NSNumber?
    
    @NSManaged
    var route : Data?
    
    @NSManaged
    var routeCoords : Data?
    
    @NSManaged
    var tariff : Data?
    
    @NSManaged
    var wishes : Data
    
    @NSManaged
    var uuid : String
    
    @NSManaged
    var isFix : NSNumber
    
    @NSManaged
    var fixPrice : NSNumber?
    
    func needShowDriverPhoto() -> Bool {
        if self.driver?.photo == "" {
            return false
        }
        if self.driver?.photo != nil {
            let imageData : Data? = Data(base64Encoded: (self.driver?.photo)!, options: NSData.Base64DecodingOptions(rawValue: 0))
            if imageData == nil {
                return false
            }
            else {
                return true
            }
        }
        else {
            return  false
        }
    }
    
    
    
}
