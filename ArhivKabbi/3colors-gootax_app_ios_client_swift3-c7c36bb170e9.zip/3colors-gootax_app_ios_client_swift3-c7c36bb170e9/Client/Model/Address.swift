//
//  Address.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import CoreData
@objc(Address)
class Address: NSManagedObject {
    @NSManaged
    var addressID : NSNumber
    
    @NSManaged
    var building : String
    
    @NSManaged
    var city : String
    
    @NSManaged
    var cityID : String
    
    @NSManaged
    var corp : String
    
    @NSManaged
    var house : String
    
    @NSManaged
    var housing : String
    
    @NSManaged
    var lat : NSNumber
    
    @NSManaged
    var lon : NSNumber
    
    @NSManaged
    var porch : String
    
    @NSManaged
    var publicPlace : NSNumber
    
    @NSManaged
    var street : String
    
    func strFromAddress() -> String
    {
        var str : String = ""
        if (self.street != "") {
           
            str = self.street
            
            if (self.house != "") {
                str = String(format: "%@, %@", str, self.house)
                if self.corp != "" {
                    str = String(format: "%@/%@", str, self.corp)
                }
                if self.porch != "" {
                    str = String(format: "%@, %@ %@", str, strComPorch().lowercased(), self.porch)
                }
            }
        }
        if self.lat.doubleValue != 0 {
            if str == "" {
                str = strComOrdByCoords()
            }
        }
        if str == "" {
            str = strComNoAddrs()
        }
        return str
    }
    
    
}

