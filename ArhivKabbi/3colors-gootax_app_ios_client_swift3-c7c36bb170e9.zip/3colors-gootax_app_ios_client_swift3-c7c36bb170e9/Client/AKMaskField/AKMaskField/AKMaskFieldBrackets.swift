//
//  AKMaskFieldBrackets.swift
//  AKMaskField
//
//  Created by Artem Krachulov on 12/3/16.
//  Copyright © 2016 Artem Krachulov. All rights reserved.
//

import Foundation

public struct AKMaskFieldBrackets {
    
    let left, right: Character
}
    
