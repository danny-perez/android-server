//
//  OfferTableViewCell.swift
//  Client
//
//  Created by  Andrew on 27.03.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class OfferTableViewCell: UITableViewCell {
    @IBOutlet weak var offerInfo: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(OfferTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func localize()
    {
        self.offerInfo.text = strInfoOffer()
    }
    
    func colorize()
    {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.offerInfo.textColor = colorGrayLabelText()
    }
}
