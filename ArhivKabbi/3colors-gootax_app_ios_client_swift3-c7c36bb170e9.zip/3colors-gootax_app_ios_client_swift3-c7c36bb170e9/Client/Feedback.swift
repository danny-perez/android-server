//
//  Feedback.swift
//  Client
//
//  Created by Dmitriy Kudrin on 03.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import Foundation

public func sendFeedBack(_ grade : String, text : String, order : Order, completion: @escaping (_ result: Bool) -> Void)
{
    gxSendFeedBack(grade, text: text, order: order, completion: { (res) -> Void in
        completion(res)
    })
}


func gxSendFeedBack(_ grade : String, text: String, order: Order, completion: @escaping (_ res: Bool) -> Void) {
    let params = ["order_id" : (order.orderID)!,
        "grade" : grade,
        "text" : text]
    gxDoPOST(kGxApiSendFeedback, params: params, completion: { (result) -> Void in
        
        if result is Dictionary<String, AnyObject> {
            if let res = result["result"] as? Dictionary<String, AnyObject> {
                if res["response_result"] != nil {
                    if res["response_result"] is String {
                        if (res["response_result"] as! String) == "1" {
                            completion(true)
                        }
                    }
                    else {
                        if (res["response_result"] as! Double) == 1 {
                            completion(true)
                        }
                    }
                }
            }
        }
        else {
            completion(false)
        }
        }) { (error) -> Void in
            print(error.description)
            completion(false)
    }
}
