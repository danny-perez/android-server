//
//  Common.swift
//  Client
//
//  Created by Dmitriy Kudrin on 23.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

enum AddressKind {
    case common
    case autocomplete
}


// Класс для временных адресов
class AddressTemp : NSObject, NSCoding{
    var street: String?
    var label: String?
    var lat: Double?
    var lon: Double?
    var cityID: String?
    var house: String?
    var name: String?
    var corp: String?
    var housing: String?
    var porch: String?
    var publicPlace: Bool?
    var publicPlaceType: String?
    var city: String?
    var flat: String?
    var type: AddressKind?
    
    
    override init () {
        label = ""
        street = ""
        lat = 0
        lon = 0
        cityID = ""
        house = ""
        corp = ""
        housing = ""
        porch = ""
        name = ""
        publicPlace = false
        publicPlaceType = ""
        city = ""
        flat = ""
        type = .common
    }
    
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.street = decoder.decodeObject(forKey: "street") as? String
        self.label = decoder.decodeObject(forKey: "label") as? String
        self.lat = decoder.decodeObject(forKey: "lat") as? Double
        self.lon = decoder.decodeObject(forKey: "lon") as? Double
        self.cityID = decoder.decodeObject(forKey: "cityID") as? String
        self.house = decoder.decodeObject(forKey: "house") as? String
        self.corp = decoder.decodeObject(forKey: "corp") as? String
        self.housing = decoder.decodeObject(forKey: "housing") as? String
        self.name = decoder.decodeObject(forKey: "name") as? String
        self.porch = decoder.decodeObject(forKey: "porch") as? String
        self.publicPlaceType = decoder.decodeObject(forKey: "publicPlaceType") as? String
        self.publicPlace = decoder.decodeObject(forKey: "publicPlace") as? Bool
        self.city = decoder.decodeObject(forKey: "city") as? String
        self.flat = decoder.decodeObject(forKey: "flat") as? String
    }
    func encode(with coder: NSCoder) {
        coder.encode(self.street, forKey: "street")
        coder.encode(self.label, forKey: "label")
        coder.encode(self.lat, forKey: "lat")
        coder.encode(self.lon, forKey: "lon")
        coder.encode(self.cityID, forKey: "cityID")
        coder.encode(self.house, forKey: "house")
        coder.encode(self.corp, forKey: "corp")
        coder.encode(self.housing, forKey: "housing")
        coder.encode(self.porch, forKey: "porch")
        coder.encode(self.name, forKey: "name")
        coder.encode(self.publicPlaceType, forKey: "publicPlaceType")
        coder.encode(self.publicPlace, forKey: "publicPlace")
        coder.encode(self.city, forKey: "city")
        coder.encode(self.flat, forKey: "flat")
    }
    
    override func isEqual(_ object: Any?) -> Bool {
        if let address = object as? AddressTemp {
            return
                address.street == self.street &&
                address.label == self.label &&
                address.lat == self.lat &&
                address.lon == self.lon &&
                address.cityID == self.cityID &&
                address.house == self.house &&
                address.name == self.name &&
                address.corp == self.corp &&
                address.housing == self.housing &&
                address.porch == self.porch &&
                address.publicPlace == self.publicPlace &&
                address.publicPlaceType == self.publicPlaceType &&
                address.city == self.city &&
                address.flat == self.flat
        } else {
            return false
        }
    }
    
    func gxDict() -> Dictionary<String, String>
    {
        var dict : Dictionary<String, String> = Dictionary<String, String>()
        
        if self.cityID != nil {
            if self.cityID != "" {
                dict["city_id"] = self.cityID
            }
        }
        if self.city != nil {
            if self.city != "" {
                dict["city"] = self.city
            }
        }
        if self.street != nil {
            if self.street != "" {
                if self.publicPlace == true {
                    dict["street"] = self.shortStrFromTempAddress()
                }
                else {
                    dict["street"] = self.street
                }
            }
        }
        if self.house != nil {
            if self.house != "" {
                dict["house"] = self.house
            }
        }
        if self.housing != nil {
            if self.housing != "" {
                dict["housing"] = self.housing
            }
        }
        if self.porch != nil {
            if self.porch != "" {
                dict["porch"] = self.porch
            }
        }
        if self.flat != nil {
            if self.flat != "" {
                dict["apt"] = self.flat
            }
        }
        if self.lat != nil {
            if self.lat != 0 {
                dict["lat"] = String(format: "%f", self.lat!)
            }
        }
        if self.lon != nil {
            if self.lon != 0 {
                dict["lon"] = String(format: "%f", self.lon!)
            }
        }
        return dict
    }
    
    func shortStrFromTempAddress() -> String
    {
        var str : String = ""
        if self.label != nil {
            if self.label != "" {
                return self.label!
            }
        }
        if self.publicPlace == true {
            if (self.name != "") {
                str = self.name!
            }
        }
        if (self.street != "") {
            if (str != "") {
                str = String(format: "%@ | %@", str, (self.street)!)
            }
            else {
                str = self.street!
            }
            if (self.house != "") {
                str = String(format: "%@, %@", str, self.house!)
            }
        }
        if self.lat != 0 {
            if self.lon != 0 {
                if str == "" {
                    str = strComOrdByCoords()
                }
            }
        }
        if str == "" {
            str = strComNoAddrs()
        }
        return str
    }
    
    func strFromTempAddress() -> String
    {
        var str : String = ""
        if (self.city != "") {
            str = self.city!
        }
        if (self.street != "") {
            if (str != "") {
                str = String(format: "%@, %@", str, (self.street)!)
            }
            else {
                str = self.street!
            }
            if (self.house != "") {
                str = String(format: "%@, %@", str, self.house!)
                if self.corp != nil {
                    if self.corp != "" {
                        str = String(format: "%@/%@", str, self.corp!)
                    }
                }
            }
        }
        if str == "" {
            NSLog("Logos common2 not")
            str = strComNoAddrs()
        }
        return str
    }
    
    func getCoordsByAddress(_ completion: @escaping (_ coords: CLLocationCoordinate2D) -> Void, failure: @escaping () -> Void)
    {
        let map = curMap()
        if map == 0 || map == 2 {
            getOSMCoordsByAddress(self, completion: { (coordss) -> Void in
                completion(coordss)
                }, failure: { () -> Void in
                    failure()
            })
        }
        else if map == 1 {
            getOSMCoordsByAddress(self, completion: { (coordss) -> Void in
                completion(coordss)
                }, failure: { () -> Void in
                    failure()
            })
        }
    }
}

func ==(lhs: AddressTemp, rhs: AddressTemp) -> Bool
{
    return
        lhs.street == rhs.street &&
        lhs.label == rhs.label &&
        lhs.lat == rhs.lat &&
        lhs.lon == rhs.lon &&
        lhs.cityID == rhs.cityID &&
        lhs.house == rhs.house &&
        lhs.name == rhs.name &&
        lhs.corp == rhs.corp &&
        lhs.housing == rhs.housing &&
        lhs.porch == rhs.porch &&
        lhs.publicPlace == rhs.publicPlace &&
        lhs.publicPlaceType == rhs.publicPlaceType &&
        lhs.city == rhs.city &&
        lhs.flat == rhs.flat
}

open class AddressType {
    var label : String?
    var logo : UIImage?
    var type : String?
    init(fromLogo logol : UIImage, labell : String, typel : String) {
        label = labell
        logo = logol
        type = typel
    }
}

// класс временного заказа
open class OrderTemp {
    var orderTime : Date?
    var payBonus : Bool?
    var promoCode: String?
    var orderTariff : Tariff?
    var pathA : AddressTemp?
    var pathB : AddressTemp?
    var pathC : AddressTemp?
    var pathD : AddressTemp?
    var pathE : AddressTemp?
    var orderWishes : [Additional]?
    var payType : String?
    var payPan : String?
    var payCompanyId : String?
    var comment : String?
    
    init() {
        orderTime = nil
        orderTariff = nil
        payBonus = false
        promoCode = ""
        pathA = AddressTemp()
        pathB = nil
        pathC = nil
        pathD = nil
        pathE = nil
        orderWishes = [Additional]()
        let payment = defaultPayType()
        payType = payment.payID
        payPan = payment.payLabel
        payCompanyId = payment.payCompanyID
        comment = ""
    }
}

func defaultPayType() -> ClientPayment {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: "defPayType") == nil || NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: "defPayType") as! Data) == nil {
        let cash = ClientPayment()
        cash.payLabel = allowPaymentInCash ? strPayCash() : strPayUndefined()
        cash.payID = allowPaymentInCash ? "CASH" : "UNDEFINED"
        cash.payCompanyID = ""
        setDefaultPayment(cash)
    }
    return NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: "defPayType") as! Data) as! ClientPayment
}

func setDefaultPayment(_ pay : ClientPayment) {
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: pay), forKey: "defPayType")
}

public func saveCit(_ cit : City) {
    var cts = [City]()
    for city in cities() {
        
        if city.cityID == cit.cityID {
            cts.append(cit)
        }
        else {
            cts.append(city)
        }
    }
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: cts), forKey: udefCities)
}



func searchRecentAddresses(phone: String, cityId: String, completion: @escaping (_ arr: [AddressTemp]) -> Void) {
    let requestParams = [
        "city_id": cityId,
        "phone": phone
    ]
    
    
    gxDoGet(kGxApiGetClientHistory, params: requestParams, completion: { (response)in
        var addresses = [AddressTemp]()
        
        if response is Dictionary<String, AnyObject> {
            if let result = response["result"] as? [Dictionary<String, AnyObject>] {
                for address in result {
                    let addressTemp = AddressTemp()
                    
                    if let parsedAddress = address["address"] as? Dictionary<String, AnyObject> {
                        addressTemp.city = parsedAddress["city"] as? String ?? ""
                        addressTemp.house = parsedAddress["house"] as? String ?? ""
                        addressTemp.housing = parsedAddress["housing"] as? String ?? ""
                        addressTemp.porch = parsedAddress["porch"] as? String ?? ""
                        addressTemp.street = parsedAddress["label"] as? String ?? ""
                        if let lat = parsedAddress["lat"] as? String {
                            addressTemp.lat = Double(lat) ?? 0.0
                        }
                        if let lat = parsedAddress["lat"] as? Double {
                            addressTemp.lat = lat
                        }
                        
                        if let lon = parsedAddress["lon"] as? String {
                            addressTemp.lon = Double(lon) ?? 0.0
                        }
                        if let lon = parsedAddress["lon"] as? Double {
                            addressTemp.lon = lon
                        }
                    }
                    
                    addressTemp.label = address["label"] as? String ?? ""
                    
                    
                    addresses.append(addressTemp)
                }
            }
        }
        
        completion(addresses)
    }) { (error) in
        print(error)
    }
}

func getRecentAdresses() -> [AddressTemp]
{
    var addresses : [AddressTemp]?
    let defaults = UserDefaults.standard
    
    let addressesData = defaults.object(forKey: udefRecentAddresses) as? NSData
    if addressesData != nil {
        NSKeyedUnarchiver.setClass(AddressTemp.self, forClassName: "Utap.AddressTemp")
        addresses = NSKeyedUnarchiver.unarchiveObject(with: addressesData! as Data) as? [AddressTemp]
        
        if addresses == nil {
            addresses = [AddressTemp]()
        }
    }
    return addresses!
    
}

func saveRecentAddresses(addresses: [AddressTemp]) {
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: addresses), forKey: udefRecentAddresses)
}


private let characterEntities : [ String : Character ] = [
    // XML predefined entities:
    "&quot;"    : "\"",
    "&amp;"     : "&",
    "&apos;"    : "'",
    "&lt;"      : "<",
    "&gt;"      : ">",
    
    // HTML character entity references:
    "&nbsp;"    : "\u{00a0}",
    // ...
    "&diams;"   : "♦",
]

extension String {
    
    /// Returns a new string made by replacing in the `String`
    /// all HTML character entity references with the corresponding
    /// character.
    var stringByDecodingHTMLEntities : String {
        
        // ===== Utility functions =====
        
        // Convert the number in the string to the corresponding
        // Unicode character, e.g.
        //    decodeNumeric("64", 10)   --> "@"
        //    decodeNumeric("20ac", 16) --> "€"
        func decodeNumeric(_ string : String, base : Int32) -> Character? {
            let code = UInt32(strtoul(string, nil, base))
            return Character(UnicodeScalar(code)!)
        }
        
        // Decode the HTML character entity to the corresponding
        // Unicode character, return `nil` for invalid input.
        //     decode("&#64;")    --> "@"
        //     decode("&#x20ac;") --> "€"
        //     decode("&lt;")     --> "<"
        //     decode("&foo;")    --> nil
        func decode(_ entity : String) -> Character? {
            
            if entity.hasPrefix("&#x") || entity.hasPrefix("&#X"){
                return decodeNumeric(entity.substring(from: entity.characters.index(entity.startIndex, offsetBy: 3)), base: 16)
            } else if entity.hasPrefix("&#") {
                return decodeNumeric(entity.substring(from: entity.characters.index(entity.startIndex, offsetBy: 2)), base: 10)
            } else {
                return characterEntities[entity]
            }
        }
        
        // ===== Method starts here =====
        
        var result = ""
        var position = startIndex
        
        // Find the next '&' and copy the characters preceding it to `result`:
        while let ampRange = self.range(of: "&", range: position ..< endIndex) {
            result.append(self[position ..< ampRange.lowerBound])
            position = ampRange.lowerBound
            
            // Find the next ';' and copy everything from '&' to ';' into `entity`
            if let semiRange = self.range(of: ";", range: position ..< endIndex) {
                let entity = self[position ..< semiRange.upperBound]
                position = semiRange.upperBound
                
                if let decoded = decode(entity) {
                    // Replace by decoded character:
                    result.append(decoded)
                } else {
                    // Invalid entity, copy verbatim:
                    result.append(entity)
                }
            } else {
                // No matching ';'.
                break
            }
        }
        // Copy remaining characters to `result`:
        result.append(self[position ..< endIndex])
        return result
    }
}


public func pointOnPolygon(_ polygon: [PolygonPoint], test: CGPoint) -> Bool {
    if polygon.count <= 1 {
        return false //or if first point = test -> return true
    }
    let p = UIBezierPath()
    let firstPoint = CGPoint(x: CGFloat(polygon[0].lat!), y: CGFloat(polygon[0].lon!))
 
    p.move(to: firstPoint)
    
    for index in 1...polygon.count-1 {
        p.addLine(to: CGPoint(x: CGFloat(polygon[index].lat!), y: CGFloat(polygon[index].lon!)) as CGPoint)
    }
    
    p.close()
    return p.contains(test)
}

public func curTenant() -> String
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefCurTenID) == nil) {
        defaults.set(gxDefTenantID, forKey: udefCurTenID)
    }
    return defaults.string(forKey: udefCurTenID)!
}

public func curMap() -> Int
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefCurMap) == nil) {
        defaults.set(defaultMap, forKey: udefCurMap)
    }
    if defaults.integer(forKey: udefCurMap) == 0 {
        if !needOSMMap {
            defaults.set(1, forKey: udefCurMap)
        }
    }
    if defaults.integer(forKey: udefCurMap) == 1 {
        if !needGoogleMapHybrid && !needGoogleMapNormal {
            defaults.set(0, forKey: udefCurMap)
        }
    }
    return defaults.integer(forKey: udefCurMap)
}

public func curGoogleMapType() -> Bool { // true - обычная. false = гибрид
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefGoogleMapType) == nil) {
        defaults.set(defaultGoogleType, forKey: udefGoogleMapType)
    }
    if defaults.bool(forKey: udefGoogleMapType) == true {
        if !needGoogleMapNormal {
            defaults.set(false, forKey: udefGoogleMapType)
        }
    }
    else {
        if !needGoogleMapHybrid {
            defaults.set(true, forKey: udefGoogleMapType)
        }
    }
    return defaults.bool(forKey: udefGoogleMapType)
}

public func curMapTitle() -> String {
    if curMap() == 0 {
        return strMapOsm()
    }
    else if curMap() == 1 {
        return strMapGoogle()
    } else if curMap() == 2 {
        return strMapGis()
    }
    return ""
}


public let layoutDirection: UIUserInterfaceLayoutDirection = {
    return UIApplication.shared.userInterfaceLayoutDirection
}()

public func deviceToken() -> String
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefDevToken) == nil) {
        defaults.set("emptyDeviceId", forKey: udefDevToken)
    }
    return defaults.string(forKey: udefDevToken)!
}


//получить список адресов рядом
func lastAddresses() -> [AddressTemp]
{
    let defaults : UserDefaults = UserDefaults.standard
    
    var arr : [AddressTemp] = Array()
    
    if (defaults.object(forKey: udefLastAddresses) == nil) {
        defaults.set(arr, forKey: udefLastAddresses)
    }
    arr = defaults.object(forKey: udefLastAddresses) as! [AddressTemp]
    return arr
}


// Получить нужную валюту
public func currency() -> String
{
    if let curr = curCity().currency {
        return curr
    }
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefCurrency) == nil) {
        defaults.set(defCurrency, forKey: udefCurrency)
    }
    return defaults.string(forKey: udefCurrency)!
}

public func dispPhone() -> String
{
    if curCity().dispTel != nil {
        if curCity().dispTel != "" {
            return curCity().dispTel!
        }
    }
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefDispPhone) == nil) {
        return ""
    }
    return defaults.string(forKey: udefDispPhone)!

}


// 0 - часов, 1 - час, 2 - часа
public func getEndingFromInt(_ num : Int) -> Int {
    let str = String(num)
    let lastCh : String = (str as NSString).substring(with: NSRange(location: str.characters.count-1, length: 1))
    if num > 10 && num < 20 {
        return 0
    }
    else {
        let lastNum = Int(lastCh)
        if lastNum == 0 || (lastNum > 4 && lastNum < 10) {
            return 0
        }
        else if lastNum == 1 {
            return 1
        }
        else {
            return 2
        }
    }
}


// Получить секретный ключ
public func secretKey() -> String
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefSecretKey) == nil) {
        defaults.set(gxSecretKey, forKey: udefSecretKey)
    }
    return defaults.string(forKey: udefSecretKey)!
}

public func timestamp() -> String
{
    return String(format: "%i", Int(Date.timeIntervalSinceReferenceDate))
}


public func lang() -> String
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefCurLan) == nil) {
        defaults.set(defaultLanguage, forKey: udefCurLan)
    }
    
    let myNSString = defaults.string(forKey: udefCurLan)! as NSString
    let str = myNSString.substring(with: NSRange(location: 0, length: 2)) as String
    return str
}

public func curScheme() -> Int
{
    let defaults : UserDefaults = UserDefaults.standard;
    if (defaults.object(forKey: udefCurColorScheme) == nil) {
        defaults.set(1, forKey: udefCurColorScheme)
    }
    
    return defaults.integer(forKey: udefCurColorScheme)
}

public func photo() -> String
{
    return photoType
}

extension String  {
    var md5: String! {
        let str = self.cString(using: String.Encoding.utf8)
        let strLen = CC_LONG(self.lengthOfBytes(using: String.Encoding.utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
        
        CC_MD5(str!, strLen, result)
        
        let hash = NSMutableString()
        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }
        
        result.deallocate(capacity: digestLen)
        
        return String(format: hash as String)
    }
}

extension UIImage {
    public func imageRotatedByDegrees(_ degrees: CGFloat, flip: Bool) -> UIImage {
        let degreesToRadians: (CGFloat) -> CGFloat = {
            return $0 / 180.0 * CGFloat(Double.pi)
        }
        
        let rotatedViewBox = UIView(frame: CGRect(origin: CGPoint.zero, size: size))
        let t = CGAffineTransform(rotationAngle: degreesToRadians(degrees));
        rotatedViewBox.transform = t
        let rotatedSize = rotatedViewBox.frame.size
        
        UIGraphicsBeginImageContextWithOptions(rotatedSize, false, 0)
        let bitmap = UIGraphicsGetCurrentContext()
        
        bitmap!.translateBy(x: rotatedSize.width / 2.0, y: rotatedSize.height / 2.0);
        
        bitmap!.rotate(by: degreesToRadians(degrees));
        
        var yFlip: CGFloat
        
        if(flip){
            yFlip = CGFloat(-1.0)
        } else {
            yFlip = CGFloat(1.0)
        }
        
        bitmap!.scaleBy(x: yFlip, y: -1.0)
        bitmap!.draw(cgImage!, in: CGRect(x: -size.width / 2, y: -size.height / 2, width: size.width, height: size.height))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
}

public func dictToJSON(_ dict : Dictionary<String, String>) -> String
{
    do {
        // Try parsing some valid JSON
        let parsed = try JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        let arr : String = NSString(data: parsed, encoding: String.Encoding.utf8.rawValue)! as String
        return arr
    }
    catch let error as NSError {
        print("A JSON parsing error occurred, here are the details:\n \(error)")
    }
    
    return ""
    
}

public func classNameAsString(_ obj: AnyObject) -> String {
    return String(describing: obj).components(separatedBy: ".").last!
}

public func secondsToNextSendCode() -> Int
{
    return intervalFromLastSMS()
}

public func secsToNextSend() -> String
{
    return String(format: "%@ %i %@", strInfoResendSMS(), secondsToNextSendCode(), strComSec())
}

public func intervalFromLastSMS() -> Int
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefLastSendSMS) == nil) {
        return -1;
    }
    let date : Date = defaults.object(forKey: udefLastSendSMS) as! Date
    let now = Date()
    if (date.timeIntervalSince(now) < 0) {
        return -1
    }
    else {
        return Int(date.timeIntervalSince(now))
    }
}

public func imageWithColor(_ color : UIColor) -> UIImage
{
    let rect = CGRect(x: 0, y: 0, width: 1, height: 1)
    UIGraphicsBeginImageContextWithOptions(CGSize(width: 1, height: 1), false, 0)
    color.setFill()
    UIRectFill(rect)
    let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()
    return image
    
}


public func selectedCountry() -> Dictionary<String, AnyObject>
{
    let defaults : UserDefaults = UserDefaults.standard
    if (defaults.object(forKey: udefCurCountry) == nil) {
        defaults.set(defaultCountry(), forKey: udefCurCountry)
    }
    return defaults.object(forKey: udefCurCountry) as! Dictionary<String, AnyObject>

}


public func strSelectedCountry() -> String
{
    return  selectedCountry()["label"] as! String
}


public func parseString(_ object: Any) -> String {
    switch object {
    case is String:
        return object as! String
    case is Int:
        return String(describing: object)
    case is Bool:
        return String(describing: object)
    default:
        return ""
    }
}

public func parseBool(_ object: Any) -> Bool {
    switch object {
    case is String:
        return (object as! NSString).boolValue
    case is Int:
        return Bool(object as! NSNumber)
    case is Bool:
        return object as! Bool
    default:
        return false
    }
}

extension UIImage {
    func imageWithColor(_ tintColor: UIColor) -> UIImage {
        let drawRect = CGRect(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        let context = UIGraphicsGetCurrentContext()
        context!.clip(to: drawRect, mask: cgImage!)
        tintColor.setFill()
        UIRectFill(drawRect)
        draw(in: drawRect, blendMode: .normal, alpha: 1.0)
        let tintedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return tintedImage!
    }
}


func heightForView(_ text:String, font:UIFont, width:CGFloat) -> CGFloat{
    let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
    label.numberOfLines = 0
    label.lineBreakMode = NSLineBreakMode.byWordWrapping
    label.font = font
    label.text = text
    
    label.sizeToFit()
    return label.frame.height
}

func widthForView(_ text:String, font:UIFont, width:CGFloat) -> CGFloat{
    let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
    label.numberOfLines = 0
    label.lineBreakMode = NSLineBreakMode.byWordWrapping
    label.font = font
    label.text = text
    
    label.sizeToFit()
    return label.frame.width
}


func printFullDate(_ date : Date) -> String
{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM.yyyy \(strComAt()) HH:mm"
    return dateFormatter.string(from: date)
}

func printFullDate(_ date : Date, locale: Int?) -> String
{
    if locale == nil { return printFullDate(date) }
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM.yyyy \(strComAt()) HH:mm"
    if (locale == persian) {
        let calendar = Calendar(identifier: Calendar.Identifier.persian)
        dateFormatter.calendar = calendar
    }
    return dateFormatter.string(from: date)
}

func printShortDate(_ date : Date) -> String
{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM HH:mm"
    return dateFormatter.string(from: date)
}

func printShortDate(_ date : Date, locale: Int?) -> String
{
    if locale == nil { return printShortDate(date) }
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM HH:mm"
    if (locale == persian) {
        let calendar = Calendar(identifier: Calendar.Identifier.persian)
        dateFormatter.calendar = calendar
    }
    return dateFormatter.string(from: date)
}

func printFullsDate(_ date : Date) -> String
{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM.yyyy HH:mm:ss"
    return dateFormatter.string(from: date)
}

func costStringFromDouble(_ val : Double, currency : String) -> String
{
    switch currency {
    case "RUB" :
        if layoutDirection == .rightToLeft {
            return String(format: "₽ %.0f", val)
        } else {
            return String(format: "%.0f ₽", val)
        }
    case "USD" :
        return String(format: "$%.2f", val)
    default :
        if layoutDirection == .rightToLeft {
            return String(format: "%@ %.2f", val, currency)
        } else {
            return String(format: "%.2f %@", val, currency)
        }
    }
}

func costStringFromDouble(_ val : Double) -> String
{
    switch currency() {
    case "RUB" :
        if layoutDirection == .rightToLeft {
            return String(format: "₽ %.0f", val)
        } else {
            return String(format: "%.0f ₽", val)
        }
    case "USD" :
        return String(format: "$%.2f", val)
    default :
        if layoutDirection == .rightToLeft {
            return String(format: "%@ %.2f", val, currency())
        } else {
            return String(format: "%.2f %@", val, currency())
        }
    }
}

func costStringFromDoubleWithCurProfile(_ val : Double) -> String
{
    switch profile().currency! {
    case "RUB" :
        if layoutDirection == .rightToLeft {
            return String(format: "₽ %.0f", val)
        } else {
            return String(format: "%.0f ₽", val)
        }
    case "USD" :
        return String(format: "$%.2f", val)
    default :
        if layoutDirection == .rightToLeft {
            return String(format: "%@ %.2f", val, profile().currency!)
        } else {
            return String(format: "%.2f %@", val, profile().currency!)
        }
    }
}


func currencyLoc() -> String {
    switch currency() {
    case "RUB" :
        return "₽"
    case "USD" :
        return "$"
    default :
        return currency()
    }
}

func delay(_ delay:Double, closure:@escaping ()->()) {
    DispatchQueue.main.asyncAfter(
        deadline: DispatchTime.now() + Double(Int64(delay * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: closure)
}


extension String {
    func contains(_ find: String) -> Bool{
        return self.range(of: find) != nil
    }
}

func imageFromView(_ aView:UIView) -> UIImage {
    if(UIScreen.main.responds(to: #selector(NSDecimalNumberBehaviors.scale))) {
        UIGraphicsBeginImageContextWithOptions(aView.frame.size, false, UIScreen.main.scale)
    }
    else {
        UIGraphicsBeginImageContext(aView.frame.size)
    }
    aView.layer.render(in: UIGraphicsGetCurrentContext()!)
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return image!
}

extension UIView {
    func roundCorners(_ corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}

extension String {
    
    subscript (i: Int) -> Character {
        return self[self.characters.index(self.startIndex, offsetBy: i)]
    }
    
    subscript (i: Int) -> String {
        return String(self[i] as Character)
    }
}



extension Array where Element:Equatable {
    func removeDuplicates() -> [Element] {
        var result = [Element]()
        
        for value in self {
            if result.contains(value) == false {
                result.append(value)
            }
        }
        
        return result
    }
}
