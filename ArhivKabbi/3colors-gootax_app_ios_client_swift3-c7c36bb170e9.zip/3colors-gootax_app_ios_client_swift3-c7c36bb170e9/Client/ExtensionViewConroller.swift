//
//  ExtensionViewConroller.swift
//  Client
//
//  Created by  Andrew on 11/01/2018.
//  Copyright © 2018 Gootax. All rights reserved.
//

import Foundation

public extension UIViewController {
    
    func showToast(message: String, duration: Double) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        self.present(alert, animated: true)
        
        // duration in seconds
        let duration: Double = duration
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
            alert.dismiss(animated: true)
        }
    }
    
}

