//
//  AppDelegate.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import GoogleMaps
import MagicalRecord
import Fabric
import Crashlytics
import YandexMobileMetrica
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?
    var notificationQueue: NotificationQueue?
    
    func resetDefaults()
    {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: "udefTariffs") == nil {
            defaults.set(Data(), forKey: udefTariffs)
        }
    }
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        //Инициализация AppMetrica SDK
        YMMYandexMetrica.activate(withApiKey: yandexMetricaAPIkey)
        //YMMYandexMetrica.setLoggingEnabled(true)
        YMMYandexMetrica.setReportCrashesEnabled(true)
        
        GMSServices.provideAPIKey(googleMapKey);
        
        setLoc()
        
        MagicalRecord.setupCoreDataStack(withAutoMigratingSqliteStoreNamed: "storeUTAP.sqlite")

        let types: UIUserNotificationType = [.alert, .sound]
        
        let settings: UIUserNotificationSettings = UIUserNotificationSettings(types: types, categories: nil )
        
        application.registerUserNotificationSettings( settings )
        application.registerForRemoteNotifications()
        
        resetDefaults()

        Fabric.with([Crashlytics.self()])
        window = UIWindow(frame: UIScreen.main.bounds)
        
        let containerViewController = ContainerViewController()
        
        window!.rootViewController = containerViewController
        window!.makeKeyAndVisible()
        notificationQueue = NotificationQueue(window: self.window!)
        
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.dayChanged(_:)), name: NSNotification.Name.UIApplicationSignificantTimeChange, object: nil)
        
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
        }

        application.registerForRemoteNotifications()
        if launchOptions != nil {
            let data = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification]
            if let userInfo = data as? [String: Any] {
                if let command = userInfo["command"] as? String {
                    switch command {
                    case "update_order":
                        if let commandParams = userInfo["command_params"] as? [String: Any] {
                            let orderId = parseString(commandParams["order_id"] ?? "")
                            if let ord = Order.mr_findFirst(byAttribute: "orderID", withValue: orderId) {
                                updOrder(ord, completion: { (order) -> Void in
                                    NotificationCenter.default.post(name: Notification.Name(rawValue: "updOrd"), object: order)
                                })
                            }
                        }
                    case "new_balance":
                        if let commandParams = userInfo["command_params"] as? [String: Any] {
                            let curProfile = profile()
                            curProfile.balanceMoney = commandParams["balance"] as? Double ?? 0.0
                            curProfile.balanceBonus = commandParams["bonus_balance"] as? Double ?? 0.0
                            updateProfile(curProfile)
                        }
                    default:
                        break
                    }
                }
            }
        }
        return true
    }
    


    func showNotification(_ message: NSString) {
        let notificationView = UINotificationView(message)
        notificationQueue?.append(notificationView)
    }

    
    @available(iOS 10, *)
    internal func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .sound, .badge])
    }

    
    @objc func dayChanged(_ notification: Notification){
        gxPingTime()
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
    // implemented in your application delegate
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenChars = (deviceToken as NSData).bytes.bindMemory(to: CChar.self, capacity: deviceToken.count)
        var tokenString = ""
        
        for i in 0 ..< deviceToken.count {
            tokenString += String(format: "%02.2hhx", arguments: [tokenChars[i]])
        }
        print(tokenString)
        
        UserDefaults.standard.set(tokenString, forKey: udefDevToken)
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
//        print("Couldn't register: \(error)", terminator: "")
        UserDefaults.standard.set("tokenString", forKey: udefDevToken)
    }
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        
        if UIApplication.shared.applicationState == .active {
            if let aps = userInfo["aps"] as? NSDictionary {
                if let alert = aps["alert"] as? NSDictionary {
                    if let message = alert["body"] as? NSString {
                        showNotification(message as NSString)
                    }
                }
            }
        }
        
//        print(userInfo)
        if userInfo["command"] != nil {
            if userInfo["command"] is String {
                if (userInfo["command"] as! String) == "update_order" {
                    if let commandParams = (userInfo["command_params"] as? Dictionary<String, AnyObject>) {
                        if commandParams["order_id"] != nil {
                            if commandParams["order_id"] is String {
                                if let ord = Order.mr_findFirst(byAttribute: "orderID", withValue: (commandParams["order_id"] as! String)) {
                                    updOrder(ord, completion: { (order) -> Void in
                                        NotificationCenter.default.post(name: Notification.Name(rawValue: "updOrd"), object: order)
                                    })
                                }
                            }
                        }
                    }
                }
                else if (userInfo["command"] as! String) == "new_balance" {
                    if let commandParams = (userInfo["command_params"] as? Dictionary<String, AnyObject>) {
                        let curProfile = profile()
                        if commandParams["balance"] != nil {
                            if commandParams["balance"] is String {
                                curProfile.balanceMoney = Double(commandParams["balance"] as! String)
                            }
                            else if commandParams["balance"] is Double {
                                curProfile.balanceMoney = commandParams["balance"] as? Double
                            }
                        }
                        if commandParams["bonus_balance"] != nil {
                            if commandParams["bonus_balance"] is String {
                                curProfile.balanceBonus = Double(commandParams["bonus_balance"] as! String)
                            }
                            else if commandParams["bonus_balance"] is Double {
                                curProfile.balanceBonus = commandParams["bonus_balance"] as? Double
                            }
                        }
                        updateProfile(curProfile)
                    }
                }
            }
        }
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
    
        if let aps = userInfo["aps"] as? NSDictionary {
            if let alert = aps["alert"] as? NSDictionary {
                if let message = alert["body"] as? NSString {
                    showNotification(message as NSString)
                }
            }
        }
        
        if userInfo["command"] != nil {
            if userInfo["command"] is String {
                if (userInfo["command"] as! String) == "update_order" {
                    if let commandParams = (userInfo["command_params"] as? Dictionary<String, AnyObject>) {
                        if commandParams["order_id"] != nil {
                            if commandParams["order_id"] is String {
                                if let ord = Order.mr_findFirst(byAttribute: "orderID", withValue: (commandParams["order_id"] as! String)) {
                                    updOrder(ord, completion: { (order) -> Void in
                                        NotificationCenter.default.post(name: Notification.Name(rawValue: "updOrd"), object: order)
                                        completionHandler(UIBackgroundFetchResult.newData)
                                    })
                                }
                            }
                        }
                    }
                }
                else if (userInfo["command"] as! String) == "new_balance" {
                    if let commandParams = (userInfo["command_params"] as? Dictionary<String, AnyObject>) {
                        let curProfile = profile()
                        if commandParams["balance"] != nil {
                            if commandParams["balance"] is String {
                                curProfile.balanceMoney = Double(commandParams["balance"] as! String)
                            }
                            else if commandParams["balance"] is Double {
                                curProfile.balanceMoney = commandParams["balance"] as? Double
                            }
                        }
                        if commandParams["bonus_balance"] != nil {
                            if commandParams["bonus_balance"] is String {
                                curProfile.balanceBonus = Double(commandParams["bonus_balance"] as! String)
                            }
                            else if commandParams["bonus_balance"] is Double {
                                curProfile.balanceBonus = commandParams["bonus_balance"] as? Double
                            }
                        }
                        updateProfile(curProfile)
                        completionHandler(UIBackgroundFetchResult.newData)
                    }
                }
            }
        }
    }
    
    
    
    func setLoc() {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: udefCurLan) == nil {
            let pre = (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!
            let str = (pre as AnyObject).substring(with: NSRange(location: 0, length: 2)) as String
            var setted = false
            for dic in languagesArray() {
                if dic["code"] == str {
                    defaults.set(str, forKey: udefCurLan)
                    setted = true
                }
            }
            if setted == false {
                defaults.set(defaultLanguage, forKey: udefCurLan)
            }
        }
        
    }

}

