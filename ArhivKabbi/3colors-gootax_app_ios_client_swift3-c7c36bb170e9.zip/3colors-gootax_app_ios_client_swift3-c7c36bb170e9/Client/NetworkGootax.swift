//
//  Network.swift
//  Client
//
//  Created by Dmitriy Kudrin on 23.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import Alamofire

public func gxDoPing(_ tenantId : String, completion: @escaping (_ result : Bool) -> Void, failure: (_ error : NSError) -> Void) {
    
    var newParam = Dictionary<String, String>()
    
    let configuration = URLSessionConfiguration.default
    
    newParam["current_time"] = timestamp()
    
    // добавить заголовке
    configuration.httpAdditionalHeaders = gxAddHeaders(Alamofire.SessionManager.default, params: newParam, tenant: tenantId)
    
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    let fullPath : String = String(format: "%@%@", arguments: [baseUrl,kGxApiPing])
    
    manager.request(URL(string: fullPath)!, parameters: newParam)
        .responseJSON { response in
            
            print(fullPath)
            var compl = false
            if let value =  response.result.value as? [String: Any] {
                if value["code"] != nil {
                    if value["code"] is String {
                        if value["code"] as! String == "0" {
                            compl = true
                        }
                    }
                    else if value["code"] is Double {
                        if value["code"] as! Double == 0 {
                            compl = true
                        }
                    }
                }
                print(value)
            }
            completion(compl)
            manager.session.invalidateAndCancel()
    }
}


public func gxDoGet(_ path : String, params : [String: String], completion: @escaping (_ result : AnyObject) -> Void, failure: (_ error : NSError) -> Void)
{
    var newParam = params
    
    let configuration = URLSessionConfiguration.default
    
    newParam["current_time"] = timestamp()
    
    // добавить заголовке
    configuration.httpAdditionalHeaders = gxAddHeaders(Alamofire.SessionManager.default, params: newParam, tenant: curTenant())
    print(path + " | \(String(describing: configuration.httpAdditionalHeaders))")
    print(path + " | \(newParam)")
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    let fullPath : String = String(format: "%@%@", arguments: [baseUrl,path])
    
    manager.request(URL(string: fullPath)!, parameters: newParam)
        .responseJSON { response in
            print(fullPath)
            print(response)
            print(response.response?.allHeaderFields ?? "Headers Error")
            if let value =  response.result.value as? [String : Any] {
                if !parsResult(value) {
                    completion(value as AnyObject)
                }
            }
            else {
//                print(response)
            }
            manager.session.invalidateAndCancel()
    }
}

public func gxDoPOST(_ path : String, params : Dictionary<String, String>, completion: @escaping (_ result : AnyObject) -> Void, failure: (_ error : NSError) -> Void)
{
    var newParam = params
    let configuration = URLSessionConfiguration.default
    newParam["current_time"] = timestamp()
    
    // добавить заголовке
    configuration.httpAdditionalHeaders = gxAddHeaders(Alamofire.SessionManager.default, params: newParam, tenant: curTenant())
    print(path + " | \(String(describing: configuration.httpAdditionalHeaders))")
    print(path + " | \(newParam)")
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    if newParam["Request-Id"] != nil {
        newParam.removeValue(forKey: "Request-Id")
        
    }
    
    let fullPath : String = String(format: "%@%@", arguments: [baseUrl,path])
    manager.request(URL(string: fullPath)!, method: .post,  parameters: newParam)
        .responseJSON { response in
            print(response.result.value ?? "default")
            if let value = response.result.value as? [String: Any] {
                if !parsResult(value) {
                    completion(value as AnyObject)
                }
            }
            else {
                print(response)
            }
            manager.session.invalidateAndCancel()
    }
}

func gxAddHeaders (_ manager : SessionManager, params : [String: String], tenant: String) -> [AnyHashable: Any]?
{
    var defaultHeaders = manager.session.configuration.httpAdditionalHeaders ?? [:]
    var validParams: Dictionary<String, String>
    
    defaultHeaders["typeclient"] = "ios"
    
    defaultHeaders["deviceid"] = deviceToken()
    
    defaultHeaders["lang"] = lang()
    
    defaultHeaders["tenantid"] = tenant
    
    defaultHeaders["versionclient"] = versionClient
    
    defaultHeaders["appid"] = appId
    
    if params["Request-Id"] != nil {
        print("Logos params[Request-Id] \(String(describing: params["Request-Id"]))")
        defaultHeaders["Request-Id"] = params["Request-Id"]
        validParams = params
        validParams.removeValue(forKey: "Request-Id")
        print("Logos validParams[Request-Id] \(String(describing: validParams["Request-Id"]))")
        defaultHeaders["signature"] = gxGenSignatureFromParams(validParams)
    }
    else {
        defaultHeaders["signature"] = gxGenSignatureFromParams(params)
    }
    print("Singnature \(defaultHeaders["signature"])")
//    defaultHeaders["User-Agent"] = "\(UIDevice.currentDevice().modelName) \(defaultHeaders["User-Agent"]!)"
    return defaultHeaders;
}


public func gxAutoCompleteDoGet(_ params : [String: String], completion: @escaping (_ result : AnyObject) -> Void, failure: (_ error : NSError) -> Void)
{
    
    let configuration = URLSessionConfiguration.default
    
    // добавить заголовке
    
    var defaultHeaders = Alamofire.SessionManager.default.session.configuration.httpAdditionalHeaders ?? [:]
    defaultHeaders["User-Agent"] = "\(UIDevice.current.modelName) \(defaultHeaders["User-Agent"]!)"
    configuration.httpAdditionalHeaders = defaultHeaders
    
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    let url : String?
    if useSearch {
        url = searchGxURL
    }
    else {
        url = autocomplGxURL
    }
    
    manager.request(URL(string: url!)!, parameters: params)
        .responseJSON { response in
            print(response.result.value ?? "Empty body autocomplete")
            if let value = response.result.value as? [String: Any] {
                if !parsResult(value) {
                    completion(value as AnyObject)
                }
            }
            manager.session.invalidateAndCancel()
    }
}

public func gxRejectDoGet(_ path : String, params : Dictionary<String, String>, completion: @escaping (_ result : AnyObject) -> Void, failure: (_ error : NSError) -> Void)
{
    var newParam = params
    
    let configuration = URLSessionConfiguration.default
    
    newParam["current_time"] = timestamp()
    
    // добавить заголовке
    configuration.httpAdditionalHeaders = gxAddHeaders(Alamofire.SessionManager.default, params: newParam, tenant: curTenant())
    
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    let fullPath : String = String(format: "%@%@", arguments: [baseUrl,path])
    
    manager.request(URL(string: fullPath)!, parameters: newParam)
        .responseJSON { response in
            print(response.result.value ?? "Reject body is empty")
            if let value = response.result.value as? [String: Any] {
                if !parsResult(value) {
                    completion(value as AnyObject)
                }
            }
            else {
                //                print(response)
            }
            manager.session.invalidateAndCancel()
    }
}

public func gxGeocodeDoGet(_ params : Dictionary<String, String>, completion: @escaping (_ result : AnyObject) -> Void, failure: (_ error : NSError) -> Void)
{
    
    let configuration = URLSessionConfiguration.default
    
    // добавить заголовке
    
    var defaultHeaders = Alamofire.SessionManager.default.session.configuration.httpAdditionalHeaders ?? [:]
    defaultHeaders["User-Agent"] = "\(UIDevice.current.modelName) \(defaultHeaders["User-Agent"]!)"
    configuration.httpAdditionalHeaders = defaultHeaders
    
    let manager = Alamofire.SessionManager(configuration: configuration)
    
    
    manager.request(URL(string: geocodeGxURL)!, parameters: params)
        .responseJSON { response in
            print(response.result.value ?? "Geocoder has not body")
            print(response)
            print(response.response?.allHeaderFields ?? "Not geocode headers")
            if let value = response.result.value {
                if value is Dictionary<String, AnyObject> {
                    if parsResult(value as! Dictionary<String, AnyObject>) == false {
                        completion(value as AnyObject)
                    }
                }
                
            }
        manager.session.invalidateAndCancel()
    }
}


public extension UIDevice {
    
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro"
        case "AppleTV5,3":                              return "Apple TV"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
    
}

func needBlur() -> Bool {
    let device = UIDevice.current.modelName
    return device != "iPhone 4s" && device != "iPad 2" && device != "iPad 3"
}

extension Dictionary {
    func valuesForKeys(_ keys: [Key]) -> [Value?] {
        var result = [Value?]()
        result.reserveCapacity(keys.count)
        for key in keys {
            result.append(self[key])
        }
        return result
    }
    
    func removeNullsFromDictionary(_ origin:[String:AnyObject]) -> [String:AnyObject] {
        var destination:[String:AnyObject] = [:]
        for key in origin.keys {
            if origin[key] != nil && !(origin[key] is NSNull){
                if origin[key] is [String:AnyObject] {
                    destination[key] = self.removeNullsFromDictionary(origin[key] as! [String:AnyObject]) as AnyObject?
                } else if origin[key] is [AnyObject] {
                    let orgArray = origin[key] as! [AnyObject]
                    var destArray: [AnyObject] = []
                    for item in orgArray {
                        if item is [String:AnyObject] {
                            destArray.append(self.removeNullsFromDictionary(item as! [String:AnyObject]) as AnyObject)
                        } else {
                            destArray.append(item)
                        }
                    }
                } else {
                    destination[key] = origin[key]
                }
            } else {
                destination[key] = "" as AnyObject?
            }
        }
        return destination
    }
}


func gxGenSignatureFromParams(_ params : Dictionary<String, String>) -> String
{
    var signature : String = ""

    let sorteda = params.keys.sorted()
    let objects = params.valuesForKeys(sorteda)

    for i in 0...sorteda.count-1 {
        let keyString = sorteda[i];
        let valueString = objects[i];
        
        if (signature == "") {
            if keyString != "address" {
                signature = String(format: "%@=%@", urlEscapeString(keyString) , urlEscapeString(valueString!))
            }
            else {
                
                signature = String(format: "%@=%@", urlEscapeString(keyString) , (valueString?.replacingOccurrences(of: "%5C", with: "%2F"))!)
            }
        }
        else {
            if keyString != "address" {
                signature = String(format: "%@&%@=%@", signature, urlEscapeString(keyString) , urlEscapeString(valueString!))
            }
            else {
                signature = String(format: "%@&%@=%@", signature, urlEscapeString(keyString) , (valueString?.replacingOccurrences(of: "%5C", with: "%2F"))!)
            }
        }
    }
    
    let trimmed = signature.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
//    trimmed = trimmed.stringByReplacingOccurrencesOfString("%2F", withString: "%5C")
//    trimmed = trimmed.stringByReplacingOccurrencesOfString("%5C%5C", withString: "%2F%2F")
    signature = String(format: "%@%@", trimmed , secretKey())
    print("Signature | \(signature)")
    return signature.md5
}

func urlEscapeString(_ sourceS : String) -> String
{
    var str = sourceS
    let customAllowedSet =  CharacterSet(charactersIn:":/?#[]@!$&'()*,;={}^%+\" ").inverted // тут список символов которые надо эскейпить. редкая ебола
    str = str.addingPercentEncoding(withAllowedCharacters: customAllowedSet)!
    let symbs = ["!", "*", "'", "(", ")", ";", ":", "@","&", "+", "$", ",", "/", "?", "#", "[", "]", "%5C", "|"];
    let escas = ["%21", "%2A", "%27", "%28", "%29", "%3B", "%3A", "%40", "%3D", "%2B", "%24", "%2C", "%2F", "%3F", "%23", "%5B", "%5D", "%2F", "%7C"];
    for i in (0..<symbs.count) {
        str = str.replacingOccurrences(of: symbs[i], with: escas[i])
    }
    
    return str;
}

//MARK: - Gootax Errors

func parsResult(_ dict : [String: Any]) -> Bool {
    print(dict)
    if dict["code"] != nil {
        let code = parseString(dict["code"] ?? "")
        return parseError(code)
    }
    return false
}

func parseError(_ code : String) -> Bool  {
    var res = false
    if code != "0"  && code != "7" && code != "20" {
        let aView = UIAlertView()
        aView.title = strErrTitle()
        switch code {
        case "1":
            aView.message = strErrInternal()
        case "2" :
            aView.message = strErrSignature()
        case "3" :
            aView.message = strErrUnknownReq()
        case "4" :
            aView.message = strErrBadParam()
        case "5" :
            aView.message = strErrMissingParam()
        case "6" :
            aView.message = strErrEmptyValue()
        case "7" :
            aView.message = strErrEmptyDataInDB()
        case "8" :
            aView.message = strErrEmptyTenantId()
        case "9" :
            aView.message = strErrBlackList()
        case "10" :
            aView.message = strErrNeedReauth()
        case "11" :
            aView.message = strErrBadPayType()
        case "12" :
            aView.message = strErrNoMoney()
        case "13" :
            aView.message = strErrBadBonus()
        case "14" :
            aView.message = strErrGate()
        case "15" :
            aView.message = strErrBadPan()
        case "18" :
            aView.message = strErrReferralCode()
            return false
        case "40":
            aView.message = strErrBadPromoCode()
        case "104":
            showMessageWithAction(strErrTitle(), message: strErrVersion(), action: strComUpdate(), actionHandler: {
                if let sharedLink = UserDefaults.standard.url(forKey: udefShareUrl) {
                    let url  = URL(string: "itms-apps://\((sharedLink.host)! + (sharedLink.path))")
                    if UIApplication.shared.canOpenURL(url!) {
                        UIApplication.shared.openURL(url!)
                    }
                }
            })
            return false
        default :
            aView.message = strErrInternal()
        }
        res = true
        aView.addButton(withTitle: strComClose())
        aView.cancelButtonIndex = 0
        aView.show()
    }
    else {
        res = false
    }
    return res
}

