//
//  PayTypeViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}


class PayTypeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var closeButton: UIBarButtonItem!
    
    var curPayments : [ClientPayment]?
    var isReferralInCity = false
    
    var visualEffectView : UIVisualEffectView?
    var curOrder : OrderTemp?
    
    var isOrderCreated: Bool = false
    
    lazy var currentPayment: ClientPayment = {
        return self.initDefaultPayment()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        NotificationCenter.default.addObserver(self, selector: #selector(PayTypeViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        let footerView = UIView(frame: CGRect(x: 0,y: 0,width: 30,height: 70))
        footerView.backgroundColor = UIColor.clear
        self.tableView.tableFooterView = footerView
    
        localize()
        colorize()
        
        if isOrderCreated {
            self.closeButton.isEnabled = false
            self.closeButton.tintColor = UIColor.clear
        }
        
        let mReferrals = getReferrals()
        let cityId = curCity().cityID
        
        if (mReferrals.count > 0) {
            for ref in mReferrals {
                if (ref.cityID == cityId) {
                    isReferralInCity = true
                }
            }
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.curPayments = nil
        if !profile().phone!.isEmpty {
            gxGetClientBalances(profile().phone!, cityId: curCity().cityID!, completion: { result in
                if result == true {
                    self.curPayments = nil
                    self.tableView.reloadData()
                    self.validatePaymentTypes()
                }
            })
        }
        self.tableView.reloadData()
    }
    
    
    //MARK: - UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return payments().count + NSNumber(value: allowPaymentInCash as Bool).intValue
        }
        else {
            return 3
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            if indexPath.row < payments().count {
                
                var payText = ""
                var hideCheckmark = false
                var topSpaceConstant = 0.0
                var botSpaceConstant = 0.0
                var cellImage = UIImage(named: "cash")
                
                if indexPath.row == 0 {
                    topSpaceConstant = 10
                } else {
                    topSpaceConstant = 0.5
                }
                
                if indexPath.row == payments().count - 1 {
                   botSpaceConstant = 5
                } else {
                    botSpaceConstant = 0.5
                }
                
                if self.currentPayment.payID == payments()[indexPath.row].payID {
                    if payments()[indexPath.row].payID != "CARD" {
                        if payments()[indexPath.row].payCompanyID == currentPayment.payCompanyID || payments()[indexPath.row].payLabel == currentPayment.payLabel {
                            hideCheckmark = false
                        } else {
                            hideCheckmark = true
                        }
                    } else {
                        if self.currentPayment.payLabel == payments()[indexPath.row].payLabel {
                            hideCheckmark = false
                        } else {
                            hideCheckmark = true
                        }
                    }
                } else {
                    hideCheckmark = true
                }
                
                switch payments()[indexPath.row].payID! {
                case "CASH" :
                    cellImage = UIImage(named: "cash")
                    payText = payments()[indexPath.row].payLabel!
                    let cell : PayTypeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payType", for: indexPath) as! PayTypeTableViewCell
                    cell.payTypeLogo.image = cellImage
                    cell.payTypeLabel.text = payText
                    cell.payTypeOk.isHidden = hideCheckmark
                    cell.botSpace.constant = CGFloat(botSpaceConstant)
                    cell.topSpace.constant = CGFloat(topSpaceConstant)
                    return cell

                case "PERSONAL_ACCOUNT" :
                    let cell : PayTypeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payType", for: indexPath) as! PayTypeTableViewCell
                    if profile().balanceMoney != nil {
                        cell.balanceLabel.text = costStringFromDoubleWithCurProfile(profile().balanceMoney!)
                    }
                    else {
                        cell.balanceLabel.text = ""
                    }
                    cell.payTypeLogo.image = UIImage(named: "pers")
                    cell.payTypeLabel.text = payments()[indexPath.row].payLabel
                    cell.payTypeOk.isHidden = hideCheckmark
                    cell.botSpace.constant = CGFloat(botSpaceConstant)
                    cell.topSpace.constant = CGFloat(topSpaceConstant)
                    return cell
                case "CORP_BALANCE" :
                    let cell : PayTypeWithNoteTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payTypeWithNote", for: indexPath) as! PayTypeWithNoteTableViewCell
                    cell.payTypeLogo.image = UIImage(named: "comp")
                    cell.payTypelabel.text = strPayCorpBal()
                    cell.payTypeNoteLabel.text = payments()[indexPath.row].payLabel
                    cell.payTypeOk.isHidden = hideCheckmark
                    cell.botSpace.constant = CGFloat(botSpaceConstant)
                    cell.topSpace.constant = CGFloat(topSpaceConstant)
                    return cell
                case "CARD" :
                    let cell : PayTypeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payType", for: indexPath) as! PayTypeTableViewCell
                    cell.payTypeLogo.image = UIImage(named: "visa")
                    cell.payTypeLabel.text = payments()[indexPath.row].payLabel
                    cell.payTypeOk.isHidden = hideCheckmark
                    cell.botSpace.constant = CGFloat(botSpaceConstant)
                    cell.topSpace.constant = CGFloat(topSpaceConstant)
                    return cell
                default :
                    let cell : PayTypeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payType", for: indexPath) as! PayTypeTableViewCell
                    cell.payTypeLogo.image = UIImage(named: "cash")
                    cell.payTypeLabel.text = strPayCash()
                    cell.payTypeOk.isHidden = hideCheckmark
                    cell.botSpace.constant = CGFloat(botSpaceConstant)
                    cell.topSpace.constant = CGFloat(topSpaceConstant)
                    return cell
                }
            } else {
                let cell : PayTypeInfoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payInfo", for: indexPath) as! PayTypeInfoTableViewCell
                return cell
            }
        }
        else {
            if indexPath.row == 0 {
                let cell : PayTypeAddTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payAdd", for: indexPath) as! PayTypeAddTableViewCell
                if !allowAddingCreditCard {
                    cell.isHidden = true
                }
                return cell
            }
            else if indexPath.row == 1 {
                let cell : PayTypeBonusTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payBonus", for: indexPath) as! PayTypeBonusTableViewCell
                cell.payBonusSwitch.isOn = (self.curOrder?.payBonus)!
                cell.payBonusBalanceLabel.text = profile().balanceBonus > 0.0 ? costStringFromDouble(profile().balanceBonus!, currency: "B") : "0 B"
                return cell
            } else {
                let cell : PayTypeAddTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payAdd", for: indexPath) as! PayTypeAddTableViewCell
                cell.payAddLabel.text = strInputCode()
                if !allowReferralSystem {
                    cell.isHidden = true
                }
                return cell
            }
        }
    }
    
    
    fileprivate func initDefaultPayment() -> ClientPayment {
        if isOrderCreated {
            let payment = ClientPayment()
            payment.payID = curOrder?.payType
            payment.payCompanyID = curOrder?.payCompanyId
            
            switch (self.curOrder?.payType)! {
            case "CASH" :
                payment.payLabel = strPayCash()
            case "PERSONAL_ACCOUNT" :
                payment.payLabel = strPayPersBal()
            case "CORP_BALANCE" :
                for company in profile().companies! {
                    if company.companyID == curOrder?.payCompanyId {
                        payment.payLabel = company.companyName
                    }
                }
            case "CARD" :
                payment.payLabel = curOrder?.payPan
            default :
                self.curOrder?.payPan = strPayUndefined()
            }
            return payment
        } else {
            return defaultPayType()
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if indexPath.row < payments().count {
                if indexPath.row == 0 {
                    return 61
                }
                else {
                    if indexPath.row == payments().count-1 {
                        return 56
                    }
                    return 51
                }
            }
            else {
                return 45
            }
        }
        else {
            if isOrderCreated {
                return 0
            } else {
                if indexPath.row == 0 {
                    return 65
                } else if indexPath.row == 1 && allowPaymentInBonus {
                    return 65
                } else if indexPath.row == 1 && !allowPaymentInBonus {
                    return 0
                } else {
                    if (allowReferralSystem && profile().phone != "" && isReferralInCity) { return 65 }
                    else { return 0 }
                }
            }
        }
    }

    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        if (indexPath.section == 0) {
            if (indexPath.row < payments().count && payments()[indexPath.row].payID! == "CARD") {
                return .delete
            }
        }
        return .none
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            gxDeleteCard(profile().clientID!, clientPhone: profile().phone!, pan: payments()[indexPath.row].payLabel!, completion: { res in
                if (res) {
                    if !profile().phone!.isEmpty {
                        gxGetClientBalances(profile().phone!, cityId: curCity().cityID!, completion: { result in
                            if result == true {
                                self.curPayments = nil
                                self.tableView.reloadData()
                                self.validatePaymentTypes()
                            }
                        })
                    }
                }
            })
        }
    }
    
    
    //MARK: - UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            if indexPath.row < self.payments().count {
                self.currentPayment = self.payments()[indexPath.row]
                self.tableView.reloadData()
            }
        } else {
            if indexPath.row == 0 {
                if self.authorized() {
                    self.performSegue(withIdentifier: "addCard", sender: self)
                } else {
                    self.showNeedAuth()
                }
            } else if (indexPath.row == 2) {
                let listController = UIStoryboard.referralCodeViewController()!
                listController.modalPresentationStyle = .overCurrentContext
                self.navigationController?.present(listController, animated: true, completion: nil)
            }
        }
    }
    
    
    //MARK: - Commons
    func authorized() -> Bool {
        if profile().phone != "" {
            return true
        }
        return false
    }
    
    
    func payments() -> [ClientPayment] {
        if self.curPayments != nil {
            return curPayments!
        }
        else {
            var pments = [ClientPayment]()
            
            if allowPaymentInCash {
                let cash = ClientPayment()
                cash.payLabel = strPayCash()
                cash.payID = "CASH"
                pments.append(cash)
            }
            
            let userProfile = profile()
            if userProfile.balanceMoney != nil && allowPaymentInPerosnal {
                let perBalance = ClientPayment()
                perBalance.payLabel = strPayPersBal()
                perBalance.payID = "PERSONAL_ACCOUNT"
                pments.append(perBalance)
            }
            if userProfile.companies?.count > 0 && allowPaymentInCompany {
                //
                for company in userProfile.companies! {
                    let accBalance = ClientPayment()
                    accBalance.payLabel = "\((company.companyName)!)"
                    accBalance.payID = "CORP_BALANCE"
                    accBalance.payCompanyID = company.companyID!
                    print("Company \(String(describing: accBalance.payCompanyID))")
                    pments.append(accBalance)
                }
            }
            if userProfile.payments?.count > 0 && allowAddingCreditCard {
                for pay in userProfile.payments! {
                    let newCard = ClientPayment()
                    newCard.payLabel = pay.payLabel
                    newCard.payID = "CARD"
                    pments.append(newCard)
                }
            }
            self.curPayments = pments
            return pments
        }
    }
    
    
    func validatePaymentTypes() {
        var count = 0
        for payment in payments() {
            if (payment.payID == curOrder!.payType) {
                switch payment.payID! {
                case "CARD":
                    if (curOrder!.payPan == payment.payLabel) {
                        count += 1
                    }
                case "CORP_BALANCE":
                    if (currentPayment.payCompanyID == payment.payCompanyID) {
                        count += 1
                    }
                default:
                    count += 1
                }
            }
        }
        if count == 0 && self.payments().count > 0 {
            self.curOrder?.payType = self.payments()[0].payID
            self.curOrder?.payPan = self.payments()[0].payLabel
            setDefaultPayment(self.payments()[0])
            self.tableView.reloadData()
        }
    }
    
    
    func colorize() {
        self.approveButton.layer.cornerRadius = 4;
        self.approveButton.layer.masksToBounds = true
        self.approveButton.setColors()
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
    
    func localize() {
        self.navigationItem.title = strPayTitleType()
        self.approveButton.setTitle(strComButApprove().uppercased(), for: UIControlState())
    }
    
    
    func showNeedAuth() {
        let aView = UIAlertView(title: strComNotificationTitle(), message: strAuthNeed(), delegate: nil, cancelButtonTitle: strComClose())
        aView.show()
    }
    
    
    func showNotEnoughB() {
        let aView = UIAlertView(title: strComNotificationTitle(), message: strBonusLow(), delegate: nil, cancelButtonTitle: strComClose())
        aView.show()
    }
    
    
    //MARK: - Actions
    func enterCode(_ code: String, sender: UISwitch) {
        
        let clientPhone = profile().phone
        gxActivateBonusSystem(clientPhone!, code: code, completion: { (result) -> Void in
            sender.setOn(result, animated: true)
            self.curOrder?.payBonus = sender.isOn
           
            let currentBonusSystem = bonus_system()
            currentBonusSystem.isActive = sender.isOn
            updateBonusSystem(currentBonusSystem)
            
            }
        )

    }
    
    
    @IBAction func turnBonus(_ sender: UISwitch) {
        if self.authorized() {
            if sender.isOn {
                if !(bonus_system().isActive)! && (bonus_system().systemID == "2") {
                    let alertController = UIAlertController(title: nil, message: strNoteEnterPromoCode(), preferredStyle: .alert)
                    
                    let checkCodeAction = UIAlertAction(title: strAlertButtonCheckCode(), style: .default) { (_) in
                        let codeField = alertController.textFields![0] as UITextField
                        codeField.keyboardType = .numberPad
                        self.enterCode(codeField.text!,sender: sender)
                    }
                    checkCodeAction.isEnabled = false
                    
                    let cancelAction = UIAlertAction(title: strComCancel(), style: .cancel) { (_) in }
                    
                    alertController.addAction(cancelAction)
                    
                    alertController.addTextField { (textField) in
                        textField.placeholder = strComPromoCode()
                        NotificationCenter.default.addObserver(forName: NSNotification.Name.UITextFieldTextDidChange, object: textField, queue: OperationQueue.main) { (notification) in
                            checkCodeAction.isEnabled = textField.text != ""
                        }
                    }
                    alertController.addAction(checkCodeAction)
                    self.present(alertController, animated: true) {
                        // ...
                    }
                    
                }else {
                    if profile().balanceBonus != nil {
                        if profile().balanceBonus <= 0.0 {
                            sender.setOn(false, animated: true)
                            self.showNotEnoughB()
                        }
                        else {
                            self.curOrder?.payBonus = sender.isOn
                        }
                        
                    }else {
                        sender.setOn(false, animated: true)
                        self.showNotEnoughB()
                    }

                }
            }else {
                sender.setOn(false, animated: true)
                self.curOrder?.payBonus = false
                self.curOrder?.promoCode = ""
                
            }
        }
        else {
            sender.setOn(false, animated: true)
            self.showNeedAuth()
        }
    }
    
    
    @IBAction func approveAction(_ sender: UIButton) {
        let curProfile = profile()
        self.curOrder?.payType = self.currentPayment.payID
        if self.currentPayment.payID == "CORP_BALANCE" {
            curProfile.clientType = "company"
        } else {
            curProfile.clientType = "base"
        }
        self.curOrder?.payPan = self.currentPayment.payLabel
        self.curOrder?.payCompanyId = self.currentPayment.payCompanyID
        setDefaultPayment(self.currentPayment)
        updateProfile(curProfile)
        if !isOrderCreated {
            (self.navigationController!.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
            self.navigationController!.dismiss(animated: true, completion: nil)
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    @IBAction func closeAction(_ sender: UIBarButtonItem) {
        (self.navigationController!.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.navigationController!.dismiss(animated: true, completion: nil)
    }
    
}
