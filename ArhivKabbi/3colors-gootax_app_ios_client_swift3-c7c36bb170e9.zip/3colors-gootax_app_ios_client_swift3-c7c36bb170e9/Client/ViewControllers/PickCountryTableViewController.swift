//
//  PickCountryTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 26.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class PickCountryTableViewController: UITableViewController, UISearchBarDelegate, UISearchControllerDelegate, UISearchResultsUpdating {

    
    let countrList: [String: [[String: Any]]] = countryByIndexes()
    let keys : [String] = indexes()
    var keysIndexes : [String] = []
    
    var findStr = ""
    
    var searchController = UISearchController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let searchResultsControllerr : UINavigationController = self.storyboard?.instantiateViewController(withIdentifier: "searchCountry") as! UINavigationController
        
        searchController  = UISearchController(searchResultsController: searchResultsControllerr)
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.hidesNavigationBarDuringPresentation = false
        self.definesPresentationContext = true
        
        searchController.searchBar.delegate = self
        searchController.searchBar.searchBarStyle = UISearchBarStyle.minimal
        
        self.navigationItem.titleView = searchController.searchBar
        
        for s : String in keys {
            keysIndexes.append(s)
            keysIndexes.append("")
        }
        
        localize()
        colorize()
        
        self.searchController.searchBar.placeholder = strComSearchCountry()
        
        self.searchController.searchBar.setValue(strComCancel(), forKey: "_cancelButtonText")
        
        self.navigationController!.navigationBar.topItem!.title = "";
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return keysIndexes.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (keysIndexes[section] == "")
        {
            return 0
        }
        let val = keys.index(of: keysIndexes[section])!
        let value = countrList[keys[val]]!
        return value.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : CountryTableViewCell = tableView.dequeueReusableCell(withIdentifier: "country", for: indexPath) as! CountryTableViewCell
        let val = keys.index(of: keysIndexes[indexPath.section])!
        let value = countrList[keys[val]]!
        let cntry = value[indexPath.row]
        cell.accessoryType = .none
        if cntry["code"] as! String == selectedCountry()["code"] as! String {
            cell.countryLabel.font = UIFont.boldSystemFont(ofSize: 17)
            cell.countryShortCode.font = UIFont.boldSystemFont(ofSize: 17)
            cell.shortWidth.constant = widthForView(value[indexPath.row]["shortMask"] as! String, font: UIFont.boldSystemFont(ofSize: 17), width: UIScreen.main.bounds.width)
        }
        else {
            cell.countryLabel.font = UIFont.systemFont(ofSize: 17)
            cell.countryShortCode.font = UIFont.systemFont(ofSize: 17)
            cell.shortWidth.constant = widthForView(value[indexPath.row]["shortMask"] as! String, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width)
        }
        
        cell.countryLabel.text = value[indexPath.row]["label"] as? String
        cell.countryShortCode.text = value[indexPath.row]["shortMask"] as? String
        // Configure the cell...
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if (keysIndexes[section] == "")
        {
            return 0
        }
        return 25
    }
    
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return keysIndexes[section]
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let val = keys.index(of: keysIndexes[indexPath.section])!
        let value = countrList[keys[val]]!
        let rightView = widthForView(value[indexPath.row]["shortMask"] as! String, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width)
        return heightForView(value[indexPath.row]["label"] as! String, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - rightView - 40) + 21;
    }
    
    override func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        if title == "" {
            return -1
        }
        else {
            return keysIndexes.index(of: title)!
        }
    }
    
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return keysIndexes
    }
    
    //MARK: TableView Delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let defaults : UserDefaults = UserDefaults.standard
        let val = keys.index(of: keysIndexes[indexPath.section])!
        let value = countrList[keys[val]]!
        defaults.set(value[indexPath.row], forKey: udefCurCountry)
        let controller : AuthorizationTableViewController = self.navigationController?.viewControllers[0] as! AuthorizationTableViewController
        controller.curPhone = ""
        controller.tableView.reloadData()
        self.navigationController?.popViewController(animated: true)
        
    }

    
    //MARK: Search Results updating
    func updateSearchResults(for searchController: UISearchController) {
        self.findStr = searchController.searchBar.text!
        
        let navController : UINavigationController = searchController.searchResultsController as! UINavigationController
        
        let vc : SearchCountryTableViewController = navController.topViewController as! SearchCountryTableViewController
        vc.cntries = genArrayForString(findStr)
        vc.tableView.reloadData()
    }
    
    //MARK: SearchController Delegate
    
    func didPresentSearchController(_ searchController: UISearchController) {
        
    }
    
    //MARK: Commons
    
    func localize()
    {
        self.navigationItem.title = strComCountry()
    }
    
    func colorize()
    {
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.tableView.backgroundColor = colorMain()
    }
    
    
    func genArrayForString(_ str : String) -> [[String: Any]]
    {
        var arrRet = [[String: Any]]()
        let cntries = countryList()
        for dict in cntries {
            
            if let label = dict["label"] as? String {
                if label.lowercased().range(of: str.lowercased()) != nil {
                    arrRet.append(dict)
                }
            }
            
        }
        return arrRet
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
