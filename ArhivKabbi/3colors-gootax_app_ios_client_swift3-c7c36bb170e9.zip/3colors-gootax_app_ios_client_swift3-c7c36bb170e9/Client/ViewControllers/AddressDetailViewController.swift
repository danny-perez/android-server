//
//  AddressDetailViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 29.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AddressDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {

    
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var navItem: UINavigationItem!
    var point: String?
    
    var address: AddressTemp?
    
    var curOrder : OrderTemp?
    
    @IBOutlet weak var constraintBottomTableView: NSLayoutConstraint!
    var redactFavorite : Bool = false
    
    var favAddress : FavAdress?
    
    var srcHouse : String?
    
    var houseField : UITextField?
    var corpField : UITextField?
    var flatField : UITextField?
    var porchField : UITextField?
    
    var commentField : UITextField?
    
    var streetNHouseCommentField: UITextField?
    
    var visualEffectView : UIVisualEffectView?
    
    var rootCont : MapViewController?

    @IBOutlet weak var botConstraint: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    
    var curCell : UITableViewCell?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(sender:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(sender:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(AddressDetailViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)

        if self.point != nil {
            if self.address == nil {
                switch self.point! {
                case "a":
                    self.address = curOrder?.pathA
                case "b":
                    self.address = curOrder?.pathB
                case "c":
                    self.address = curOrder?.pathC
                case "d":
                    self.address = curOrder?.pathD
                case "e":
                    self.address = curOrder?.pathE
                default:
                    self.address = curOrder?.pathA
                }
            }
        }
        self.srcHouse = self.address?.house
        self.tableView.delaysContentTouches = false
        self.tableView.setNeedsLayout()
        self.tableView.layoutIfNeeded()
        
        for view in self.tableView.subviews {
            if (classNameAsString(view) == "UITableViewWrapperView") {
                if view.isKind(of: UIScrollView.self) {
                    let scroll = (view as! UIScrollView)
                    scroll.delaysContentTouches = false
                }
                break
            }
        }
        
        self.tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 73))
        colorize()
        localize()
    }
    
    
    func keyboardWillShow(sender: NSNotification) {
        if let userInfo = sender.userInfo {
            let kFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as AnyObject).cgRectValue.size.height
            self.constraintBottomTableView.constant = kFrame
        }
    }
    
    func keyboardWillHide(sender: NSNotification) {
        self.constraintBottomTableView.constant = 0
    }
    
    // MARK: - keyboard
    
    func keybShow(_ notification: Notification) {
        
        let kboard : NSValue = (notification.userInfo!)[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let kboardFrame : CGRect? = kboard.cgRectValue
        if kboardFrame != nil {
            if self.tabBarController?.tabBar.frame != nil {
                self.botConstraint.constant = kboardFrame!.size.height - (self.tabBarController?.tabBar.frame.size.height)!
            }
            else {
                self.botConstraint.constant = kboardFrame!.size.height
            }
            
            let userInfo = notification.userInfo
            let animationCurveRawNSN = (userInfo!)[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions().rawValue
            let animationCurve:UIViewKeyframeAnimationOptions = UIViewKeyframeAnimationOptions(rawValue: animationCurveRaw)
            
            UIView.animateKeyframes(withDuration: (notification.userInfo!)[UIKeyboardAnimationDurationUserInfoKey] as! Double,
                delay: 0,
                options: animationCurve,
                animations: { () -> Void in
                    self.view.layoutIfNeeded()
                    if self.curCell != nil {
                        self.tableView.scrollToRow(at: self.tableView.indexPath(for: self.curCell!)!, at: UITableViewScrollPosition.middle, animated: false)
                    }
                }) { (finished) -> Void in
                    if finished {
                        if self.curCell != nil {
                            
                        }
                    }
            }
        }
    }
    
    func keybHide(_ notification: Notification) {
    }
    

    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.redactFavorite {
            return 5
        } else {
            return 9
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell : StreenNHouseCommentTableViewCell = tableView.dequeueReusableCell(withIdentifier: "streetnhouse", for: indexPath) as! StreenNHouseCommentTableViewCell
            self.streetNHouseCommentField = cell.snhField
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            let defaults = UserDefaults.standard
            var matchedAddresses = false
            var collectedStreet = ""
            if defaults.object(forKey: udefEditedAddr) != nil {
                if let storedAddress = NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefEditedAddr) as! Data) as? AddressTemp {
                    matchedAddresses = storedAddress.street == self.address!.street ||  storedAddress.label == self.address!.label
                    if matchedAddresses {
                        collectedStreet = storedAddress.street!
                    }
                }
            }
            
            let edited = UserDefaults.standard.object(forKey: udefEditedAddr) != nil && matchedAddresses

            if edited {
                cell.snhField.text = collectedStreet
            }
            
            if self.point == "a" && (self.address?.shortStrFromTempAddress() == strComNoAddrs() || self.address?.shortStrFromTempAddress() == strComOrdByCoords() || edited) {
                cell.isHidden = false
            } else {
                cell.isHidden = true
            }

            self.streetNHouseCommentField?.text = self.curOrder?.pathA?.label!
            return cell
                    }
        else if indexPath.row == 1 {
            let cell : HouseTableViewCell = tableView.dequeueReusableCell(withIdentifier: "house", for: indexPath) as! HouseTableViewCell
            cell.houseField.text = self.address?.house
            cell.isHidden = true
            return cell
        }
        else if indexPath.row == 2 {
            let cell : CorpTableViewCell = tableView.dequeueReusableCell(withIdentifier: "corp", for: indexPath) as! CorpTableViewCell
            
            cell.corpField.text = self.address?.corp
            self.corpField = cell.corpField
            cell.isHidden = true
            return cell
        }
        else if indexPath.row == 3 {
            let cell : PorchTableViewCell = tableView.dequeueReusableCell(withIdentifier: "porch", for: indexPath) as! PorchTableViewCell
            cell.porchField.text = self.address?.porch
            self.porchField = cell.porchField
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            return cell
        }
        else if indexPath.row == 4 {
            let cell : FlatTableViewCell = tableView.dequeueReusableCell(withIdentifier: "flat", for: indexPath) as! FlatTableViewCell
            cell.flatField.text = self.address?.flat
            if !needFlat {
                cell.isHidden = true
            }
            else {
                cell.isHidden = false
            }
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            self.flatField = cell.flatField
            return cell
        }
        else if indexPath.row == 5 {
            let cell : NoticeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "notice", for: indexPath) as! NoticeTableViewCell
            let str : String = strComQual()
            
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            cell.noticeLabel.text = str.uppercased()
            cell.isHidden = true
            return cell
        }
        else if indexPath.row == 6 {
            let cell : CommentTableViewCell = tableView.dequeueReusableCell(withIdentifier: "comment", for: indexPath) as! CommentTableViewCell
            self.commentField = cell.commentText
            cell.commentText.text = self.curOrder?.comment
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            return cell
        } else if indexPath.row == 7 {
            let cell : ApproveAddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "approve", for: indexPath) as! ApproveAddressTableViewCell
            cell.approveButton.setTitle(strComButApprove().uppercased(), for: UIControlState())
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            cell.onApproveClick = {
                self.approveAddress(cell.approveButton)
            }
            return cell
        }
        else {
            let cell : NoticeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "notice", for: indexPath) as! NoticeTableViewCell
            cell.noticeLabel.text = strInfoComExample()
            cell.isHidden = true
            cell.separatorInset = UIEdgeInsets(top: 0, left: 10000, bottom: 0, right: 0)
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            let defaults = UserDefaults.standard
            var matchedAddresses = false
            if defaults.object(forKey: udefEditedAddr) != nil {
                if let storedAddress = NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefEditedAddr) as! Data) as? AddressTemp {
                    matchedAddresses =  storedAddress.street == self.address!.street || storedAddress.label == self.address!.label
                }
            }
            let edited = UserDefaults.standard.object(forKey: udefEditedAddr) != nil && matchedAddresses
            return self.point == "a" && (
                self.address?.shortStrFromTempAddress() == strComNoAddrs() ||
                self.address?.shortStrFromTempAddress() == strComOrdByCoords() ||
                edited) ? 60 : 0
        }
        else if indexPath.row == 1 {
            return 0;
        }
        else if indexPath.row == 2 {
            return 0;
        }
        else if indexPath.row == 3 {
            if needPorch {
                return 60;
            } else {
                return 0;
            }
        }
        else if indexPath.row == 4 {
            if !needFlat {
                return 0
            }
            else {
                return 60
            }
        }
        else if indexPath.row == 5 {
            return 0
        }
        else if indexPath.row == 6 {
            return 60
        }
        else if indexPath.row == 7 {
            return 60
        }
        else {
            return 0
        }
    }
    
    //MARK: - Actions
    
    
    @IBAction func approveAddress(_ sender: UIButton) {
        if var newPorch = self.porchField?.text {
            if newPorch.characters.count > 100 {
                let index: String.Index = newPorch.characters.index(newPorch.startIndex, offsetBy: 100)
                newPorch = newPorch.substring(to: index)
            }
            self.address?.porch = newPorch
        }
        
        
        if var newFlat = self.flatField?.text {
            if newFlat.characters.count > 100 {
                let index: String.Index = newFlat.characters.index(newFlat.startIndex, offsetBy: 100)
                newFlat = newFlat.substring(to: index)
            }
            self.address?.flat = newFlat
        }
        
        let defaults = UserDefaults.standard
        var matchedAddresses = false
        if defaults.object(forKey: udefEditedAddr) != nil {
            if let storedAddress = NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefEditedAddr) as! Data) as? AddressTemp {
                matchedAddresses =  storedAddress.street == self.address!.street
            }
        }

        
        let edited = UserDefaults.standard.object(forKey: udefEditedAddr) != nil && matchedAddresses
        
        if self.point == "a" && (self.address?.shortStrFromTempAddress() == strComNoAddrs() || self.address?.shortStrFromTempAddress() == strComOrdByCoords() || edited) {
            var streetnhousecomment = (self.streetNHouseCommentField?.text)!
            if streetnhousecomment.characters.count > 100 {
                let index: String.Index = streetnhousecomment.characters.index(streetnhousecomment.startIndex, offsetBy: 100)
                streetnhousecomment = streetnhousecomment.substring(to: index)
            }
            self.address?.label = streetnhousecomment.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            UserDefaults.standard.set(NSKeyedArchiver.archivedData(withRootObject: self.address!), forKey: udefEditedAddr)
        }
        self.rootCont?.curOrder?.pathA = self.address
        self.curOrder?.comment = self.commentField?.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        self.view.endEditing(true)
        (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeAction(_ sender: AnyObject) {
        self.view.endEditing(true)
        (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    //MARK: commons
    func colorize() {
        self.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationBar.tintColor = colorNewHamButton()
        self.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
        self.tableView.backgroundColor = UIColor.clear
        self.view.backgroundColor = UIColor.clear
        self.tableView.tableFooterView?.backgroundColor = UIColor.clear

    }

    
    func localize() {
        self.navItem.title = strComQual()
    }

}
