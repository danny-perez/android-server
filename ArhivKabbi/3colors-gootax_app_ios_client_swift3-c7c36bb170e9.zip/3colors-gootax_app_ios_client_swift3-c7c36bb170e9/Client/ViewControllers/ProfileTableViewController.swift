//
//  ProfileTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ProfileTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate, AKMaskFieldDelegate, UIAlertViewDelegate {

    var edit = false
    
    let baseCount : Int = 2
    
    lazy var addEdit: Int = {
        if (isShowClientId) {
            return 4
        } else {
            return 3
        }
    }()
    
    var editButton : UIBarButtonItem = UIBarButtonItem(title: strComSave(), style: UIBarButtonItemStyle.plain, target: nil, action: #selector(ProfileTableViewController.setEdit))
//    
    var cancelButton : UIBarButtonItem = UIBarButtonItem(title: strComCancel(), style: UIBarButtonItemStyle.plain, target: nil, action: #selector(ProfileTableViewController.editCancel))
    
    var closeButton : UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .stop, target: nil, action: #selector(ProfileTableViewController.closeAction))
    
    let imagePicker : UIImagePickerController = UIImagePickerController()
    
    var imagePickerActionSheet : UIActionSheet = UIActionSheet()
    
    var tempProfile : Profile?
    
    var visualEffectView : UIVisualEffectView?
    
    var firstName : UITextField = UITextField()
    var lastName : UITextField = UITextField()
    var middleName : UITextField = UITextField()
    var email : UITextField = UITextField()
    var phone : AKMaskField?
    
    var isChangedPhoto = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imagePicker.allowsEditing = true
        self.imagePicker.delegate = self
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        self.navigationItem.rightBarButtonItem = self.closeButton
        
        self.closeButton.target = self
        
        self.closeButton.action = #selector(ProfileTableViewController.closeAction)
        
//        self.navigationItem.leftBarButtonItem = self.logoutButton
        
        self.editButton.target = self
        
        self.editButton.action = #selector(ProfileTableViewController.setEdit)
        
        self.cancelButton.target = self
        
        self.cancelButton.action = #selector(ProfileTableViewController.editCancel)
        
        self.tempProfile = profile()
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileTableViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        self.colorize()
        self.localize()
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    let view = UIView(frame: self.view.bounds)
                    view.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.5)
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    view.addSubview(self.visualEffectView!)
                    self.tableView.backgroundView = view
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.tableView.backgroundView = view
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if !self.edit {
            return self.baseCount
        }
        else {
            return self.baseCount + self.addEdit
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if !self.edit {
            if indexPath.row == 0 {
                let cell : ProfileUserTableViewCell = tableView.dequeueReusableCell(withIdentifier: "commonInfo", for: indexPath) as! ProfileUserTableViewCell
                
                cell.setProfile(self.tempProfile!)
                
                return cell
            }
            else if indexPath.row == 1 {
                let cell : ProfileLogoutTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileLogout", for: indexPath) as! ProfileLogoutTableViewCell
                
                return cell
            }
            else {
                let cell : OfferTableViewCell = tableView.dequeueReusableCell(withIdentifier: "offerInfo", for: indexPath) as! OfferTableViewCell
                cell.offerInfo.attributedText = NSAttributedString(string: strInfoOffer(), attributes:
                    [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
                cell.offerInfo.text = strInfoPublicOffer()
                return cell
            }
        }
        else {
            if indexPath.row == 0 {
                let cell : ProfileUploadPhotoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileUploadPhoto", for: indexPath) as! ProfileUploadPhotoTableViewCell
                cell.setProfile(self.tempProfile!)
                return cell
            }
            else if indexPath.row == 1 {
                let cell : ProfileFirstNameTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileFirstName", for: indexPath) as! ProfileFirstNameTableViewCell
                cell.firstNameLabel.text = self.tempProfile!.firstName
                self.firstName = cell.firstNameLabel
                return cell
            }
            if indexPath.row == 2 {
                let cell : ProfileLastNameTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileLastName", for: indexPath) as! ProfileLastNameTableViewCell
                cell.lastNameField.text = self.tempProfile!.lastName
                self.lastName = cell.lastNameField
                return cell
            }
            else if indexPath.row == 3 {
                let cell : ProfileEmailTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileEmail", for: indexPath) as! ProfileEmailTableViewCell
                
                if self.tempProfile!.email != nil {
                    cell.emailField.text = self.tempProfile!.email!
                }
                
                if self.edit {
                    cell.emailField.isEnabled = true
                }
                else {
                    cell.emailField.isEnabled = false
                }
                
                self.email = cell.emailField
                
                return cell
            } else if indexPath.row == 5 {
                // Cell client ID
                let cell : ProfileEmailTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profileEmail", for: indexPath) as! ProfileEmailTableViewCell
                cell.emailField.text = self.tempProfile!.clientID
                cell.emailLabel.text = strComId()
                cell.emailField.isEnabled = false
                return cell
            }
            else {
                let cell : ProfilePhoneTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profilePhone", for: indexPath) as! ProfilePhoneTableViewCell
                cell.phoneField.maskExpression = selectedCountry()["mask"] as? String
                cell.phoneField.placeholder = selectedCountry()["placeholder"] as? String
                cell.phoneField.maskDelegate = self
                cell.phoneField.isEnabled = false
                
                if (self.tempProfile!.phone != nil) {
                    let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
                    let phone1 = (selectedCountry()["shortMask"])?.components(separatedBy: numbersSet) as AnyObject as! NSArray
                    let str = phone1.componentsJoined(by: "")
                    if self.tempProfile!.phone!.characters.count > 0 {
                        let phone = (self.tempProfile!.phone! as NSString).substring(from: str.characters.count)
                        cell.phoneField.text = phone
                    }
                    else {
                        cell.phoneField.text = ""
                    }
                }
                else {
                    cell.phoneField.text = ""
                }

                self.phone = cell.phoneField
                
                return cell
            }

        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if !self.edit {
            if indexPath.row == 0 { //  ячейка с фото
                return 205
            }
            else if indexPath.row == 1 { // ячейка выйти
                return 58
            }
        }
        else {
            if indexPath.row == 0 { //редактировать фото
                return 86
            }
            else if indexPath.row == 1 { // фамилия
                return 58
            }
            else if indexPath.row == 2 { // имя
                return 58
            }
            else if indexPath.row == 3 { // отчество
                return 58
            }
            else if indexPath.row == 4 { // отступ
                return 58
            }
            else if indexPath.row == 5 { // загрузить фото
                return 58
            }
            else if indexPath.row == 6 { // отступ
                return 58
            }
        }
        return 44
    }
    
    //MARK: - UITableViewDelegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.view.endEditing(true)
        if self.edit {
            if indexPath.row == 0 {
                setPhoto()
            }
        }
        else {
            if indexPath.row == 1 {
                self.logout(true)
            }
        }
    }
    
    
    
    //MARK: - Actions
    
    @IBAction func goEdit(_ sender: UIButton) {
        self.setEdit()
        self.editButton.isEnabled = true
    }
    
    func setEdit() {
        var editIndexPaths = [IndexPath]()
        for i in self.baseCount...(self.baseCount + self.addEdit - 1) {
            let ip = IndexPath(row: i, section: 0)
            editIndexPaths.append(ip)
        }
        self.edit = !self.edit
        
        var reloadPaths = [IndexPath]()
        for i in 0...self.baseCount-1 {
            let ip = IndexPath(row: i, section: 0)
            reloadPaths.append(ip)
        }
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.tableView.beginUpdates()
            self.tableView.reloadRows(at: reloadPaths, with: .fade)
            if !self.edit {
                self.tableView.deleteRows(at: editIndexPaths, with: .fade)
            }
            else {
                self.tableView.insertRows(at: editIndexPaths, with: .fade);
            }
            
            self.tableView.endUpdates()
            }, completion: { (finished) -> Void in
                UIView.animate(withDuration: 0.2, animations: { () -> Void in
                    
                    }, completion: { (finished) -> Void in
                })
        }) 
        
        if !self.edit {
            self.updProfile()
        }
        self.setTitleLeftBut()
        self.setTitleRightButton()
    }
    
    func setPhoto() {
        self.imagePickerActionSheet = UIActionSheet(title: strComUploadPhoto(), delegate: self, cancelButtonTitle: strComCancel(), destructiveButtonTitle: nil, otherButtonTitles: strComTakePhoto(), strComChoosePhoto())
        self.imagePickerActionSheet.show(in: self.tableView)
    }
    
    func updProfile() {
        self.tempProfile?.middleName = self.middleName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        self.tempProfile?.lastName = self.lastName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        self.tempProfile?.firstName = self.firstName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        self.tempProfile?.email = self.email.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
        let phone1 = self.phone!.text!.components(separatedBy: numbersSet) as AnyObject as! NSArray
        self.tempProfile?.phone = phone1.componentsJoined(by: "")
        gxUpdateProfile(self.tempProfile!, isChangedPhoto: self.isChangedPhoto) { (finished) -> Void in
            self.tempProfile = profile()
            self.isChangedPhoto = false
            
            if profile().companies?.count == 0 {
                if allowPaymentInCash {
                    let cash = ClientPayment()
                    cash.payLabel = strPayCash()
                    cash.payID = "CASH"
                    cash.payCompanyID = ""
                    setDefaultPayment(cash)
                }
            } else {
                let accBalance = ClientPayment()
                accBalance.payLabel = "\(strPayCorpBal()) \((profile().companies![0].companyName)!)"
                accBalance.payID = "CORP_BALANCE"
                accBalance.payCompanyID = profile().companies![0].companyID!
                setDefaultPayment(accBalance)
                
            }

            
            self.tableView.reloadData()
        }
    }
    
    func closeAction() {
        self.navigationController?.dismiss(animated: true, completion: nil)
        
        if self.navigationController?.presentingViewController is UINavigationController {
            let navContr = self.navigationController?.presentingViewController as! UINavigationController
            if navContr.viewControllers[0] is MapViewController {
                let mapViewController = navContr.viewControllers[0] as! MapViewController
                mapViewController.setPayment()
            }
        }
    }
    
    func editCancel() {
        if self.edit {
            self.edit = false
            var editIndexPaths = [IndexPath]()
            for i in self.baseCount...(self.baseCount + self.addEdit - 1) {
                let ip = IndexPath(row: i, section: 0)
                editIndexPaths.append(ip)
            }
            
            var reloadPaths = [IndexPath]()
            for i in 0...self.baseCount-1 {
                let ip = IndexPath(row: i, section: 0)
                reloadPaths.append(ip)
            }
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.tableView.beginUpdates()
                
                if !self.edit {
                    self.tableView.deleteRows(at: editIndexPaths, with: .fade)
                }
                else {
                    self.tableView.insertRows(at: editIndexPaths, with: .fade);
                }
                self.tableView.endUpdates()
                }, completion: { (finished) -> Void in
                    UIView.animate(withDuration: 0.2, animations: { () -> Void in
                        self.tableView.reloadRows(at: reloadPaths, with: .none)
                        }, completion: { (finished) -> Void in
//                            self.editButton.enabled = true
                    })
            }) 
            self.tempProfile = profile()
            self.tableView.reloadData()
            self.setTitleLeftBut()
            self.setTitleRightButton()
        }
        else {
            self.logout(true)
        }
        
    }
    
    func logout(_ appr : Bool) {
        if appr {
            let approveAlertView = UIAlertView(title: strComLogout(), message: strComLogoutApprove(), delegate: self, cancelButtonTitle: strComCancel(), otherButtonTitles: strComYes())
            approveAlertView.show()
        }
        else {
            updateProfile(Profile())
            let defaults = UserDefaults.standard
            defaults.set("", forKey: udefBrowserKey)
            defaults.set("", forKey: udefToken)
            defaults.set(nil, forKey: "defPayType")
            let autController : AuthorizationTableViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "auth") as! AuthorizationTableViewController
            self.navigationController!.setViewControllers([autController], animated: true)
        }
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 1 {
            self.logout(false)
        }
    }
    
    
    //MARK: - AKMaskField Delegate
    
    func maskField(_ maskField: AKMaskField, madeEvent: String, withText oldText: String, inRange oldTextRange: NSRange, withText newText: String) {
        let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
        let phone1 = maskField.text!.components(separatedBy: numbersSet) as AnyObject as! NSArray
        self.tempProfile?.phone = phone1.componentsJoined(by: "")
    }
    
    //MARK: - UIActionSheet Delegate
    
    func actionSheet(_ actionSheet: UIActionSheet, didDismissWithButtonIndex buttonIndex: Int) {
        if buttonIndex == 1 {
            self.imagePicker.sourceType = .camera
            self.imagePicker.cameraDevice = .front
            self.present(self.imagePicker, animated: true, completion: nil)
        }
        else if buttonIndex == 2 {
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
        }
        
    }
    
    
    //MARK: - UIImagePickerController Delegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        picker.dismiss(animated: true, completion: nil)
        self.tempProfile?.photoImage = image
        
        let cell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! ProfileUploadPhotoTableViewCell
        cell.photoView.image = image
        isChangedPhoto = true
    }
    
    
    //MARK: - Commons
    
    func authrorized() -> Bool {
        if profile().phone != "" {
            return true
        }
        return false
    }
    
    
    func colorize()
    {
        self.tableView.backgroundColor = UIColor.clear
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
        self.editButton.tintColor = colorNewHamButton()
        self.cancelButton.tintColor = colorNewHamButton()
    }
    
    func localize()
    {
        self.navigationItem.title = strComProfile()
        self.setTitleLeftBut()
        self.setTitleRightButton()
    }
    
    func setTitleLeftBut() {
        if self.edit {
            
            self.navigationItem.setLeftBarButton(self.cancelButton, animated: true)
            self.cancelButton.tintColor = colorNewHamButton()
        }
        else {
            self.navigationItem.setLeftBarButton(nil, animated: true)
        }
        
        
    }
    
    func setTitleRightButton() {
        if self.edit {
            self.navigationItem.setRightBarButton(self.editButton, animated: true)
            
        }
        else {
            self.navigationItem.setRightBarButton(self.closeButton, animated: true)
        }
    }
    
    func checkPhone() -> Bool
    {
        if self.tempProfile?.phone == nil {
            self.tempProfile?.phone = ""
        }
        if (self.tempProfile!.phone!.characters.count < selectedCountry()["minLength"] as! Int) {
            return false
        }
        else {
            return true
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
