//
//  WishesViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 04.01.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class WishesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var tableView: UITableView!
    var curOrder : OrderTemp?
    var validOptions: [Additional]?
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var noTarrsImage: UIImageView!
    @IBOutlet weak var noTarrsLabel: UILabel!
    var cur : String?
    
    var visualEffectView : UIVisualEffectView?
    let endEffect = UIBlurEffect(style: .light)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.estimatedRowHeight = 80
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        self.tableView.setNeedsLayout()
        self.tableView.layoutIfNeeded()
        
        NotificationCenter.default.addObserver(self, selector: #selector(WishesViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        localize()
        colorize()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if self.curOrder?.orderTariff?.tariffType != nil && self.curOrder?.orderTariff?.options?.count > 0 {
            validOptions = [Additional]()
            for option in (self.curOrder?.orderTariff?.options)! {
                if (option.optionType == self.curOrder?.orderTariff?.tariffType) {
                    self.validOptions?.append(option)
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.validOptions != nil {
            if self.validOptions?.count == 0 {
                self.noTarrsImage.isHidden = false
                self.noTarrsLabel.isHidden = false
                self.tableView.isHidden = true
            }
            else {
                self.noTarrsImage.isHidden = true
                self.noTarrsLabel.isHidden = true
                self.tableView.isHidden = false
            }
        }
        else {
            self.noTarrsImage.isHidden = false
            self.noTarrsLabel.isHidden = false
            self.tableView.isHidden = true
        }
        if self.validOptions != nil {
            return (self.validOptions?.count)!
        }
        else {
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : WishTableViewCell = tableView.dequeueReusableCell(withIdentifier: "wish", for: indexPath) as! WishTableViewCell
        let curOption = (self.validOptions)![indexPath.row]
        
        if indexPath.row == 0 {
            cell.topSpace.constant = 10
        }
        else {
            cell.topSpace.constant = 0
        }
        
        if indexPath.row + 1 == (self.validOptions?.count)! {
            cell.botSpace.constant = 10
        }
        else {
            cell.botSpace.constant = 0
        }
        
        cell.checkedImage.isHidden = true
        
        for wish in (self.curOrder?.orderWishes)!{
            if wish.mainId! == (self.validOptions)![indexPath.row].mainId! {
                (self.validOptions)![indexPath.row].isChecked = true
                cell.checkedImage.isHidden = false
            }
        }
        
        cell.wishTitle.text = (self.validOptions)![indexPath.row].optionName
        cell.wishLogo.isHidden = true
        if curOption.cost != nil {
            if self.cur == nil {
                self.cur = currency()
            }
            cell.wishCost.text = costStringFromDouble(curOption.cost!, currency: self.cur!)
        }
        
        return cell
    }

    
    //MARK: UITableview delegate
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (self.validOptions)![indexPath.row].isChecked {
            for (index, wish) in (self.curOrder?.orderWishes)!.enumerated() {
                if wish.mainId! == (self.validOptions)![indexPath.row].mainId! {
                    (self.validOptions)![indexPath.row].isChecked = false
                    self.curOrder?.orderWishes?.remove(at: index)
                }
            }
        }
        else {
            (self.validOptions)![indexPath.row].isChecked = true
            self.curOrder?.orderWishes?.append((self.validOptions)![indexPath.row])
        }
        
        tableView.reloadRows(at: [indexPath], with: .none)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    //MARK: - Actions
    
    @IBAction func closeAction(_ sender: AnyObject) {
        (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func colorize() {
        self.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationBar.tintColor = colorNewHamButton()
        self.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
    //MARK: commons
    
    func localize()
    {
        self.navigationBar.topItem?.title = strComWishes()
        self.noTarrsLabel.text = strNoAddsForTariff()
    }
    
}
