//
//  LeftSideViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import Kingfisher

protocol SidePanelViewControllerDelegate {
    func profileSelected()
    func paySelected()
    func ordersSelected()
    func preOrdersSelected()
    func myAddrsSelected()
    func newsSelected()
    func settingsSelected()
    func referralSelected()
    func webScreenSelected()
    func aboutSelected()
    func login()
    func register()
}

enum UIUserInterfaceIdiom : Int
{
    case unspecified
    case phone
    case pad
}

struct ScreenSize
{
    static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
    static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
    static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
}

struct DeviceType
{
    static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
}

class LeftSideViewController: UIViewController{
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var botHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonView: UIView!

    @IBOutlet weak var botWidth: NSLayoutConstraint!

    @IBOutlet weak var leftPhone: UIButton!
    @IBOutlet weak var leftLogo: UIImageView!
    @IBOutlet weak var viewEmptyContainer: UIView!
    
    var delegate: SidePanelViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        colorize()
        localize()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftSideViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LeftSideViewController.colorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        // Do any additional setup after loading the view.
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        }
    }
  
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
        self.setProfile()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setProfile() {
        let profileSetted = profile().phone != ""
        self.tableView.reloadData()
        if profileSetted {
            let cell : LeftProfileTableViewCell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! LeftProfileTableViewCell
            cell.setProfile(profile())
        }
        else {
            let cell : LeftSignTableViewCell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! LeftSignTableViewCell
            cell.listener = {
                self.delegate?.register()
            }
            self.botHeight.constant = 109
        }
    }
    
    
    func updateLeftPhone(_ city: City?) {
        if city != nil && !(city?.dispTel?.isEmpty)! {
            var phone = city?.dispTel
            if phone![0] != "+" {
                phone = "+\(String(describing: phone))"
            }
            self.leftPhone.setTitle(phone, for: UIControlState())
        } else {
            self.leftPhone.setTitle("", for: UIControlState())
        }
    }
    
    
    func showForeground() {
        self.viewEmptyContainer.isHidden = false
    }
    
    
    func hideForeground() {
       self.viewEmptyContainer.isHidden = true
    }
    
    //MARK: - Commons
    func localize() {
        self.botWidth.constant = (UIScreen.main.bounds.width - 150 - centerPanelExpandedOffset)/2
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.botWidth.constant = CGFloat((300 - 150)/2)
        }
        self.tableView.reloadData()
    }
    
    func colorize() {
        self.tableView.reloadData()
        self.view.backgroundColor = colorNewHamBack()
        self.tableView.backgroundColor = colorNewHamBack()
        self.leftPhone.tintColor = colorNewHamText()
        self.buttonView.backgroundColor = colorNewHamBack()
        if colorNewHamBack().isLightColor() {
            leftPhone.setTitleColor(.black, for: .normal)
        } else {
            leftPhone.setTitleColor(.white, for: .normal)
        }
    }
    
    
    @IBAction func leftPhoneAction(_ sender: AnyObject) {
        if dispPhone() != "" {
            var phone = dispPhone().replacingOccurrences(of: " ", with: "")
            if phone[0] != "+" {
                phone = "+\(phone)"
            }
            UIApplication.shared.openURL(URL(string: "tel://\(phone)")!)
        }
    }
    
    func numberOfSectionsInTableView(_ tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            if profile().phone != "" {
                let cell : LeftProfileTableViewCell = tableView.dequeueReusableCell(withIdentifier: "profile", for: indexPath) as! LeftProfileTableViewCell
                cell.setProfile(profile())
                return cell
            } else {
                let cell : LeftSignTableViewCell = tableView.dequeueReusableCell(withIdentifier: "sign", for: indexPath) as! LeftSignTableViewCell
                let offests = 39 + cell.signUp.frame.width
                cell.signInfoConstraint.constant = UIScreen.main.bounds.width - offests - centerPanelExpandedOffset
                if UI_USER_INTERFACE_IDIOM() == .pad {
                    cell.signInfoConstraint.constant = 300 - offests
                }
                return cell
            }
        }
        else if indexPath.row > 0 && indexPath.row < 8 {
            let cell : LeftItemTableViewCell = tableView.dequeueReusableCell(withIdentifier: "leftCell", for: indexPath) as! LeftItemTableViewCell
            switch indexPath.row {
            case 1 :
                cell.label.text = strLeftPay()
            case 2:
                cell.label.text = strLeftOrders()
            case 3:
                cell.label.text = strLeftPreOrders()
            case 4:
                cell.label.text = strFreeTrip()
            case 5:
                cell.label.text = strLeftMyAddresses()
                cell.isHidden = true
            case 6:
                cell.label.text = strLeftNews()
                cell.isHidden = true
            default:
                cell.label.text = strLeftSettings()
            }
            return cell
        } else if indexPath.row == 9 {
            let cell : LeftAboutTableViewCell = tableView.dequeueReusableCell(withIdentifier: "about", for: indexPath) as! LeftAboutTableViewCell
            cell.aboutLabel.text = webScreenTitle
            return cell
        }
        else {
            let cell : LeftAboutTableViewCell = tableView.dequeueReusableCell(withIdentifier: "about", for: indexPath) as! LeftAboutTableViewCell
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let currentProfile = profile()
        if indexPath.row == 0 {
            if currentProfile.phone != "" {
                return 86
            } else {
                return 109
            }
        }
        if indexPath.row == 6 {
            return 0
        }
        if indexPath.row == 5 {
            return 0
        }
        if indexPath.row == 9 && !useWebScreen {
            return 0
        }
        if indexPath.row == 4 && (!allowReferralSystem  || currentProfile.phone == "" || !checkReferralByCity()) {
            return 0
        }
        if DeviceType.IS_IPHONE_4_OR_LESS {
            return 44
        }
        else if DeviceType.IS_IPHONE_5 {
            return 50
        }
        else {
            return 60
        }
    }
    
}

func checkReferralByCity() -> Bool {
    let referrals = getReferrals()
    let cityId = curCity().cityID
    
    if (referrals.count > 0) {
        for ref in referrals {
            if (ref.cityID == cityId) {
                return true;
            }
        }
    }
    return false
}


//MARK: - UITableViewDelegate
extension LeftSideViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.row {
        case 0:
            if profile().phone != "" {
                delegate?.profileSelected()
            }
        case 1:
            delegate?.paySelected()
        case 2:
            delegate?.ordersSelected()
        case 3:
            delegate?.preOrdersSelected()
        case 4:
            delegate?.referralSelected()
        case 5:
            delegate?.myAddrsSelected()
        case 6:
            delegate?.newsSelected()
        case 7:
            delegate?.settingsSelected()
        case 9:
            delegate?.webScreenSelected()
        default:
            delegate?.aboutSelected()
        }
    }
}

