//
//  ReferralViewController.swift
//  Client
//
//  Created by  Andrew on 19.04.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class ReferralViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    fileprivate lazy var mProfile: Profile? = nil
    fileprivate lazy var mReferral: Referral? = nil
    fileprivate lazy var mReferrals: [Referral]? = nil
    
    @IBOutlet weak var mTableView: UITableView!
    
    var visualEffectView : UIVisualEffectView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        
        mProfile = profile()
        mReferrals = getReferrals()
        let cityId = curCity().cityID
        
        if (mReferrals?.count > 0) {
            mReferral = findReferral(by: mReferrals!, and: cityId!)
        }
        
        mTableView.delegate = self
        mTableView.dataSource = self
        
        self.mTableView.estimatedRowHeight = 80
        self.mTableView.rowHeight = UITableViewAutomaticDimension
        
        self.mTableView.setNeedsLayout()
        self.mTableView.layoutIfNeeded()
        
        if (mReferral != nil) {
            if (self.mReferral!.isActive!) {
                self.mTableView.reloadData()
            } else {
                onActivateReferralSystem(profile().phone!)
            }
        } else if (mProfile?.phone != nil && mProfile?.phone != "") {
            dismiss(animated: true, completion: {
                showMessage(strErrTitle(), message: strRefNotFound())
            })
        }
        
        localize();
        colorize();
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func onReferralShare(_ sender: AnyObject) {
        if (self.mReferral != nil) {
            shareByReferral(self.mReferral!)
        }
    }
    
    func authorized() -> Bool {
        if profile().phone != "" {
            return true
        }
        return false
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (authorized()) {
            return 4
        } else {
            return 2
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (authorized()) {
            if (indexPath.row == 0) {
                let cell = tableView.dequeueReusableCell(withIdentifier: "referralContent", for: indexPath) as! ReferralContentTableViewCell
                if (mReferral?.content != "") { cell.content.text = mReferral?.content }
                else { cell.content.text = strRefInfo() }
                return cell
            }
            if (indexPath.row == 1) {
                let cell = tableView.dequeueReusableCell(withIdentifier: "referralContent", for: indexPath) as! ReferralContentTableViewCell
                cell.content.text = strYourCode()
                return cell
            } else if (indexPath.row == 2) {
                let cell = tableView.dequeueReusableCell(withIdentifier: "referralCode", for: indexPath) as! ReferralCodeTableViewCell
                cell.codeLabel.text = mReferral?.code
                cell.copyButton.setTitle(strRefCopy(), for: .normal)
                return cell
            } else {
                let cell : AuthSendCodeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "sendCode", for: indexPath) as! AuthSendCodeTableViewCell
                cell.sendButton.setTitle(strRefShare(), for: UIControlState())
                cell.sendButton.isEnabled = true
                return cell
            }
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "referralContent", for: indexPath) as! ReferralContentTableViewCell
            cell.content.text = strRefferalRegistration()
            return cell
        }
    }
    
    
    func shareByReferral(_ referral: Referral) {
        let textToShare = referral.text!
        let objectsToShare = [textToShare]
        let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        activityVC.setValue(referral.title, forKey: "subject")
        activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList, UIActivityType.print, UIActivityType.copyToPasteboard, UIActivityType.assignToContact, UIActivityType.postToVimeo]
        if UI_USER_INTERFACE_IDIOM() == .phone {
            self.present(activityVC, animated: true, completion: nil)
        } else {
            let popup: UIPopoverController = UIPopoverController(contentViewController: activityVC)
            popup.present(from: CGRect(x: self.view.frame.size.width / 2, y: self.view.frame.size.height / 4, width: 0, height: 0), in: self.view, permittedArrowDirections: .any, animated: true)
        }
    }
    
    
    func onActivateReferralSystem(_ phone: String?) {
        if phone != nil && phone != "" {
            getReferralSystemActivate(phone!, referralId: (mReferral?.referralId)!) { (code) in
                if (!code.isEmpty) {
                    getReferralList(self.mProfile?.phone!) { (referrals) in
                        self.mReferrals = referrals
                        let cityId = curCity().cityID
                        if (self.mReferrals?.count > 0) {
                            self.mReferral = self.findReferral(by: self.mReferrals!, and: cityId!)
                        }
                        self.mTableView.reloadData()
                    }
                }
            }
        }
    }

    fileprivate func findReferral(by referrals: [Referral], and city: String) -> Referral? {
        for ref in referrals {
            if (ref.cityID == city) {
                return ref
            }
        }
        return nil
    }
    
    @IBAction func onCloseWindow(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func localize()
    {
        self.navigationItem.title = strFreeTrip()
    }
    
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
    }
    
}
