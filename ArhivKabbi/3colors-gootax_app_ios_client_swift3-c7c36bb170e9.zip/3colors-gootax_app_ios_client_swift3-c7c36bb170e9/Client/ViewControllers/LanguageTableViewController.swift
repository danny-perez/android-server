//
//  LanguageTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LanguageTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(LanguageTableViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return languagesArray().count
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : LanguageTableViewCell = tableView.dequeueReusableCell(withIdentifier: "lan", for: indexPath) as! LanguageTableViewCell

        cell.lanTitle.text = languagesArray()[indexPath.row]["title"]
        
        let defaults = UserDefaults.standard
        if defaults.object(forKey: udefCurLan) as! String? == languagesArray()[indexPath.row]["code"] {
            cell.accessoryType = .checkmark
        }
        else {
            cell.accessoryType = .none
        }

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let defaults = UserDefaults.standard
        
        defaults.set(languagesArray()[indexPath.row]["code"], forKey: udefCurLan)
         NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeLan), object: nil)
        self.tableView.reloadData()
    }
    
    
    //MARK: - Commons
    func colorize()
    {
        self.tableView.backgroundColor = colorMain()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorStatusBar()
        self.navigationController?.navigationBar.addSubview(view)
        UIApplication.shared.statusBarStyle = colorStatusBarStyle()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = colorNavigationBar()
    }
    
    func localize()
    {
        self.navigationItem.title = strComLanguage()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
