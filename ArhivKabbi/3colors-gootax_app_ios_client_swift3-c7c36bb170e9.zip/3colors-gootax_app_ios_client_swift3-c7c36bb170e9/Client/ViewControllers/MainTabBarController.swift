//
//  MainTabBarController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController, UIActionSheetDelegate {
    var loaded = false // тестовый флаг на время
    
    var pickCitySheet : UIActionSheet?
    
    var cits : [City]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "localize", name: notifChangeLan, object: nil)
        localize()
        
        colorize()
        
        print(curTariffs())
        
        
        getCity({ (cities) -> Void in
            print(cities)
            self.cits = cities
            self.showDialogPickCity(cities)
            }) { (str) -> Void in
                getTariffs { (arr) -> Void in
                    print("tariffs loaded")
                }
        }
        
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        if authFirst {
            if !loaded {
                if (profile().phone == "") || (profile().phone == nil) {
                    self.performSegueWithIdentifier("showAuth", sender: self)
                }
                self.loaded = true
            }
        }
    }
    
    
    //MARK: Pick City
    
    func showDialogPickCity(cities : [City]) {
        if cities.count > 0 {
            self.setCity(cities[0])
        }
    }
    
    
    func setCity(city : City) {
        let defaults = NSUserDefaults.standardUserDefaults()
        if city.cityID != nil {
            defaults.setObject(city.cityID!, forKey: udefCurCity)
            getTariffs { (arr) -> Void in
                city.tariffs = arr
                saveCit(city)
                print("tariffs loaded")
            }
        }
    }
    
    //MARK: - UIActionSheetDelegate
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        self.setCity(self.cits![buttonIndex])
    }
    
    
    //MARK : Commons
    func localize()
    {
        let item1 : UITabBarItem = self.tabBar.items![0]
        item1.title = strTabBarNewOrder()
        let item2 : UITabBarItem = self.tabBar.items![1]
        item2.title = strTabBarMyOrders()
        let item3 : UITabBarItem = self.tabBar.items![2]
        item3.title = strTabBarProfile()
        let item4 : UITabBarItem = self.tabBar.items![3]
        item4.title = strTabBarAboutUs()
    }
    
    func colorize()
    {
        let item1 : UITabBarItem = self.tabBar.items![0]
        item1.image = UIImage(named: imageTabBar1())
        let item2 : UITabBarItem = self.tabBar.items![1]
        item2.image = UIImage(named: imageTabBar2())
        let item3 : UITabBarItem = self.tabBar.items![2]
        item3.image = UIImage(named: imageTabBar3())
        let item4 : UITabBarItem = self.tabBar.items![3]
        item4.image = UIImage(named: imageTabBar4())
        
        self.tabBar.tintColor = colorMainTint()
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
