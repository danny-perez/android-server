//
//  AuthorizationTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import YandexMobileMetrica

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class AuthorizationTableViewController: UITableViewController, AKMaskFieldDelegate, UITextFieldDelegate {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var curPhone : String?
    var curCode = ""
    var timer : Timer = Timer()
    var timerActive = false
    var fadeAnimation = false
    var visualEffectView : UIVisualEffectView?
    
    var isReferall = false
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    var curProfile : Profile?
    var curCountry : Dictionary<String, AnyObject>?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        colorize()
        localize()
        NotificationCenter.default.addObserver(self, selector: #selector(AuthorizationTableViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        self.clearsSelectionOnViewWillAppear = true
        
        self.tableView.delaysContentTouches = false
        
        for view in self.tableView.subviews {
            if (classNameAsString(view) == "UITableViewWrapperView") {
                if view.isKind(of: UIScrollView.self) {
                    let scroll = (view as! UIScrollView)
                    scroll.delaysContentTouches = false
                }
                break
            }
        }
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    let view = UIView(frame: self.view.bounds)
                    view.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.5)
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    view.addSubview(self.visualEffectView!)
                    self.tableView.backgroundView = view
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.tableView.backgroundView = view
        }
        
        if (allowReferralSystem) {
            let mReferrals: [Referral]? = getReferrals()
            let cityId = curCity().cityID
            if (mReferrals?.count > 0) {
                for ref in mReferrals! {
                    if (ref.cityID == cityId) {
                        isReferall = true
                    }
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.curCountry = nil
        self.curProfile = nil
        self.tableView.reloadData()
        self.startTimer()
    }
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.segmentedControl.selectedSegmentIndex == 0) {
            return 6
        }
        else {
            return 7
        }
    }
    
    
    struct AbstractPhone {
        let mask: String
        let placeholder: String
    }
    
    func getShortestGermanyMask(phoneNumber: String) -> AbstractPhone {
        let maskList = [
            AbstractPhone(mask: "+49({ddd}){dd}-{dd}", placeholder: "+49(___)__-__"),
            AbstractPhone(mask: "+49({ddd}){dd}-{ddd}", placeholder: "+49(___)__-___"),
            AbstractPhone(mask: "+49({ddd}){dd}-{dddd}", placeholder: "+49(___)__-____"),
            AbstractPhone(mask: "+49({ddd}){ddd}-{dddd}", placeholder: "+49(___)___-____"),
            AbstractPhone(mask: "+49({ddd}){dddd}-{dddd}", placeholder: "+49(___)____-____")
        ]
        
        for phone in maskList {
            let charsCount = phone.placeholder.characters.filter{$0 == "_"}.count + 2
            print(charsCount)
            if charsCount >= phoneNumber.count {
                return phone
            }
        }
        
        return maskList[maskList.count - 1]
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath.row == 0) {
            let cell : AuthLogoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "logo", for: indexPath) as! AuthLogoTableViewCell
            cell.isHidden = true
            return cell
        }
        else if (indexPath.row == 1) {
            let cell : AuthCountryPickedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "country", for: indexPath) as! AuthCountryPickedTableViewCell
//            cell.separatorInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
            cell.countryLabel.text = strSelectedCountry()
            return cell
        }
        else if (indexPath.row == 2) {
            let cell : AuthPhoneTableViewCell = tableView.dequeueReusableCell(withIdentifier: "phone", for: indexPath) as! AuthPhoneTableViewCell
            
            let mask = self.currCountry()["mask"] as? String
            let placeholder = self.currCountry()["placeholder"] as? String
            cell.phoneField.setMask(mask!, withMaskTemplate: placeholder)
            cell.phoneField.maskDelegate = self
            
            if self.curPhone != nil {
                
                let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
                let phone1 = (self.currCountry()["shortMask"])?.components(separatedBy: numbersSet) as AnyObject as! NSArray
                let str = phone1.componentsJoined(by: "")
                if self.curPhone == "" {
                    cell.phoneField.text = ""
                }
                else {
                    let currenPhone = (self.curPhone! as NSString).substring(from: str.characters.count)
                    if (self.curPhone?.starts(with: "49"))! {
                        let abstractPhone = getShortestGermanyMask(phoneNumber: self.curPhone!)
                        cell.phoneField.setMask(abstractPhone.mask, withMaskTemplate: abstractPhone.placeholder)
                    }
                    cell.phoneField.text = currenPhone
                }
            }
            else {
                if (self.currProfile().phone != nil) {
                    let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
                    let phone1 = (self.currCountry()["shortMask"])?.components(separatedBy: numbersSet) as AnyObject as! NSArray
                    let str = phone1.componentsJoined(by: "")
                    if self.currProfile().phone!.characters.count > 0 {
                        let currentPhone = (self.currProfile().phone! as NSString).substring(from: str.characters.count)
                        if (self.currProfile().phone?.starts(with: "49"))! {
                            let abstractPhone = getShortestGermanyMask(phoneNumber: self.curPhone!)
                            cell.phoneField.setMask(abstractPhone.mask, withMaskTemplate: abstractPhone.placeholder)
                        }
                        cell.phoneField.text = currentPhone
                    }
                    else {
                        cell.phoneField.text = ""
                    }
                }
                else {
                    cell.phoneField.text = ""
                }
            }
            
            cell.phoneField.becomeFirstResponder()
            return cell
        }
        else if (indexPath.row == 3) {
            if (self.segmentedControl.selectedSegmentIndex == 0) {
                let cell : AuthSMSInfoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "smsInfo", for: indexPath) as! AuthSMSInfoTableViewCell
                return cell
            }
            else {
                let cell : AuthCodeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "code", for: indexPath) as! AuthCodeTableViewCell
                cell.codeField.delegate = self
                return cell
            }
        }
        else if (indexPath.row == 4) {
            if (secondsToNextSendCode() > 0) {
                let cell : AuthResendSMSInfoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "smsResendInfo", for: indexPath) as! AuthResendSMSInfoTableViewCell
                cell.resendInfoLabel.text = secsToNextSend()
                if self.segmentedControl.selectedSegmentIndex == 1 {
                    cell.isHidden = true
                }
                else {
                    cell.isHidden = false
                }
                return cell
            }
            else {
                let cell : AuthSendCodeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "sendCode", for: indexPath) as! AuthSendCodeTableViewCell
                cell.sendButton.isEnabled = checkPhone()
                for view in cell.subviews {
                    if (classNameAsString(view) == "UITableViewCellScrollView") {
                        if view.isKind(of: UIScrollView.self) {
                            let scroll = (view as! UIScrollView)
                            scroll.delaysContentTouches = false
                            break
                        }
                    }
                }
                if self.segmentedControl.selectedSegmentIndex == 1 {
                    cell.isHidden = true
                }
                else {
                    cell.isHidden = false
                }
                return cell
            }
        } else if (indexPath.row == 5) {
            if self.segmentedControl.selectedSegmentIndex == 1 {
                let cell : AuthReferralCodeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "referralCode", for: indexPath) as! AuthReferralCodeTableViewCell
                return cell
            } else {
                let cell : OfferTableViewCell = tableView.dequeueReusableCell(withIdentifier: "offerInfo", for: indexPath) as! OfferTableViewCell
                cell.offerInfo.attributedText = NSAttributedString(string: strInfoOffer(), attributes:
                    [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
                return cell
            }
        } else if (indexPath.row == 6 && self.segmentedControl.selectedSegmentIndex == 1) {
            let cell : AuthEnterTableViewCell = tableView.dequeueReusableCell(withIdentifier: "enter", for: indexPath) as! AuthEnterTableViewCell
            
            for view in cell.subviews {
                if (classNameAsString(view) == "UITableViewCellScrollView") {
                    if view.isKind(of: UIScrollView.self) {
                        let scroll = (view as! UIScrollView)
                        scroll.delaysContentTouches = false
                        break
                    }
                }
            }
            
            return cell
        }
        else {
            let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "logo", for: indexPath)
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath.row == 0) { // ячейка с лого
            return 0
        }
        else if (indexPath.row == 1) { // ячейка со страной
            if withCountry {
                return 68
            } else {
                return 0
            }
        }
        else if (indexPath.row == 2) { // ячейка с телефоном
            return 58
        }
        else if (indexPath.row == 3) {
            if (self.segmentedControl.selectedSegmentIndex == 0) { // ячейка с инфо о смс
                return heightForView(strInfoAboutSMS(), font: UIFont.systemFont(ofSize: 12), width: UIScreen.main.bounds.width - 30) + 20;
//                return 63
            }
            else {
                return 63 // ячейка с полем для ввода кода
            }
        }
        else if (indexPath.row == 4) {
            if (secondsToNextSendCode() > 0) {
                if self.segmentedControl.selectedSegmentIndex == 1 {
                    return 0
                }
                else {
                    return heightForView(secsToNextSend(), font: UIFont.systemFont(ofSize: 12), width: UIScreen.main.bounds.width - 30) + 20;
//                    return 63
                }
                
            }
            else {
                if self.segmentedControl.selectedSegmentIndex == 1 {
                    return 0
                }
                else {
                    return 50
                }
            }
        }
        else if (indexPath.row == 5) {
            if self.segmentedControl.selectedSegmentIndex == 1 {
                if (isReferall)
                { return 63
                }
                return 0
            }
            return 50
        }
        else if (indexPath.row == 6) {
            return 50
        }
        else {
            return 0
        }
    }
    
    //MARK:Actions
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl)
    {
        self.tableView.reloadData()
        self.startTimer()
    }
    
    
    @IBAction func sendCodeAction(_ sender: UIButton)
    {
        sender.isEnabled = false
        let defaults : UserDefaults = UserDefaults.standard
        defaults.set(Date().addingTimeInterval(Double(smsTimeout)), forKey: udefLastSendSMS)
        if self.curPhone == nil {
            self.curPhone = ""
        }
        authorization(self.curPhone!) { (result) -> Void in
            sender.isEnabled = true
            if result == true {
                if (self.segmentedControl.selectedSegmentIndex == 0) {
                    self.segmentedControl.selectedSegmentIndex = 1
                    self.tableView.reloadData()
                }
                let codeField : UITextField = (self.tableView.cellForRow(at: IndexPath(row: 3, section: 0)) as! AuthCodeTableViewCell).codeField
                codeField.becomeFirstResponder()
                self.startTimer()
            }
        }
        
    }
    
    
    @IBAction func checkCodeAction(_ sender: AnyObject)
    {
        var referralCode = ""
        if (isReferall) {
            if let cell : AuthReferralCodeTableViewCell = self.tableView.cellForRow(at: IndexPath(row: 5, section: 0)) as? AuthReferralCodeTableViewCell {
                if (!(cell.codeField.text?.isEmpty)!) {
                    referralCode = cell.codeField.text!
                }
            }
        }
        
        if let cell : AuthCodeTableViewCell = self.tableView.cellForRow(at: IndexPath(row: 3, section: 0)) as? AuthCodeTableViewCell {
            if cell.codeField.text != nil {
                self.curCode = cell.codeField.text!
                if self.curPhone == nil {
                    self.curPhone = ""
                }
                
                let cityId = curCity().cityID! 
                
                login(referralCode, cityId: cityId, phoneNumber: self.curPhone!, code: self.curCode, completion: { (result, code) -> Void in
                    cell.wrongCode = !result
                    if !result {
                        if code == 1 {
                            if let referralCell = self.tableView.cellForRow(at: IndexPath(row: 5, section: 0)) as? AuthReferralCodeTableViewCell {
                                referralCell.flashRed()
                                cell.unflash()
                            }
                        } else {
                            cell.flashRed()
                            if let referralCell = self.tableView.cellForRow(at: IndexPath(row: 5, section: 0)) as? AuthReferralCodeTableViewCell {
                                referralCell.unflash()
                            }
                        }
                    }
                    else {
                        if (referralCode != "") {
                            showMessage(strRefActivatedSuccess(), message: "")
                        }
                        
                        gxGetProfile(self.curPhone!, completion: { (result) -> Void in
                            let curProfile : Profile = self.currProfile()
                            let metricaParams = ["userPhone" : curProfile.phone!]
                            let metricaMessage = "Logged in"
                            YMMYandexMetrica.reportEvent(metricaMessage, parameters: metricaParams, onFailure: {error in
                                NSLog("error: %@", error.localizedDescription);
                            })
//                            updateProfile(curProfile)
                            }
                        )
                        
                        if (allowReferralSystem) {  getReferralList(self.curPhone!) { (referrals) in } }
                        
                        getTariffs(completion: { arr in
                            if let city: City = curCity() {
                                city.tariffs = arr
                                saveCit(city)
                                if self.tabBarController != nil {
                                    let profileController : ProfileTableViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profile") as! ProfileTableViewController
                                    self.navigationController!.setViewControllers([profileController], animated: true)
                                }
                                else {
                                    self.closeAction("" as AnyObject)
                                }
                            }
                        })
                        
                        
                    }
                })
            }
        }
    }
    
    @IBAction func changeCode(_ sender: UITextField)
    {
        self.curCode = sender.text!
        if let cell : AuthCodeTableViewCell = self.tableView.cellForRow(at: IndexPath(row: 3, section: 0)) as? AuthCodeTableViewCell {
            if cell.wrongCode {
                cell.wrongCode = false
                cell.unflash()
            }
        }
    }
    
    
    @IBAction func closeAction(_ sender: AnyObject) {
        if self.presentingViewController is UINavigationController {
            (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func changeLang(_ sender: AnyObject)
    {
        let defaults : UserDefaults = UserDefaults.standard
        if defaults.string(forKey: udefCurLan) == "en" {
            defaults.set("ru", forKey: udefCurLan)
        }
        else {
            defaults.set("ru", forKey: udefCurLan)
        }
        NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeLan), object: nil)
    }
    
    //MARK: -mask Field Delegate
    
    func maskField(_ maskField: AKMaskField, madeEvent: String, withText oldText: String, inRange oldTextRange: NSRange, withText newText: String) {
        let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
        let phone1 = maskField.text!.components(separatedBy: numbersSet) as AnyObject as! NSArray
        self.curPhone = phone1.componentsJoined(by: "")
        self.tableView.reloadRows(at: [IndexPath(row: 4, section: 0)], with: UITableViewRowAnimation.none)
    }
    
    func maskField(_ maskField: AKMaskField, didChangedWithEvent event: AKMaskFieldEvent) {
        let numbersSet = CharacterSet(charactersIn: "0123456789").inverted
        let phone1 = maskField.text!.components(separatedBy: numbersSet) as AnyObject as! NSArray
        self.curPhone = phone1.componentsJoined(by: "")
        self.tableView.reloadRows(at: [IndexPath(row: 4, section: 0)], with: UITableViewRowAnimation.none)
        
    }
    
    //MARK: Timer
    func startTimer()
    {
        if ((secondsToNextSendCode() > 0) && !timerActive) {
            timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(AuthorizationTableViewController.updateCell), userInfo: nil, repeats: true)
            timerActive = true
            self.fadeAnimation = true
            CATransaction.begin()
            CATransaction.setCompletionBlock({ () -> Void in
                self.fadeAnimation = false
            })
            self.tableView.reloadRows(at: [IndexPath(row: 4, section: 0)], with: UITableViewRowAnimation.fade)
            CATransaction.commit()
        }
    }
    
    func updateCell()
    {
        if (secondsToNextSendCode() > 0) {
            if (!self.fadeAnimation) {
                self.tableView.reloadRows(at: [IndexPath(row: 4, section: 0)], with: UITableViewRowAnimation.none)
            }
        }
        else {
            stopTimer()
        }
    }
    
    func stopTimer()
    {
        self.timer.invalidate()
        timerActive = false
        self.tableView.reloadRows(at: [IndexPath(row: 4, section: 0)], with: UITableViewRowAnimation.fade)
    }
    
    //MARK: Commons
    
    func currProfile() -> Profile {
        return profile()
    }
    
    func currCountry() -> Dictionary<String, AnyObject> {
        if self.curCountry != nil {
            return self.curCountry!
        }
        self.curCountry = selectedCountry()
        return self.curCountry!
    }
    
    func colorize()
    {
        self.segmentedControl.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
    func localize()
    {
        self.segmentedControl.setTitle(strAuthGetCode(), forSegmentAt: 0)
        self.segmentedControl.setTitle(strAuthLogin(), forSegmentAt: 1)
        self.tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
    }
    
    func checkPhone() -> Bool
    {
        if self.curPhone == nil {
            self.curPhone = ""
        }
        if (self.curPhone!.characters.count < self.currCountry()["minLength"] as! Int) {
            return false
        }
        else {
            return true
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
