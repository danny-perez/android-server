//
//  ScrollViewContainer.swift
//  Client
//
//  Created by Dmitriy Kudrin on 13.01.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class ScrollViewContainer: UIView {

     @IBOutlet var scrollView: UIScrollView!
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.scrollView = self.viewWithTag(228) as! UIScrollView
    }
    override func hitTest(_ point: CGPoint, with event: UIEvent!) -> UIView? {
        let view = super.hitTest(point, with: event)
        if let theView = view {
            if theView == self {
                return scrollView
            }
        }
        
        return view
    }

}
