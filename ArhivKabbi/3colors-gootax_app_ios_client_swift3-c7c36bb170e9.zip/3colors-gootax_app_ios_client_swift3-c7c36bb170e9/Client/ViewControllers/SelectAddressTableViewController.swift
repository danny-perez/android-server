//
//  SelectAddressTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 02.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class SelectAddressTableViewController: UIViewController, UISearchBarDelegate, UISearchControllerDelegate, UISearchResultsUpdating, UITableViewDelegate, UITableViewDataSource {
    
    var collectionView : UICollectionView?
    var mainViewController : MapViewController?
    
    var addressesAutocomplete : [AddressTemp] = Array()
    var addresses : [AddressTemp] = Array()
    var addressesNearly : [AddressTemp] = Array()
    var addressesAirsAndTrains : [AddressTemp] = Array()
    
    @IBOutlet weak var contraintBottomSpace: NSLayoutConstraint!
    
    var searchController = UISearchController()
    
    var point : String?
    
    var searchStr : String?
    
    var searchTimer : Timer?
    
    var kFrame : CGFloat?
    
    var curOrder : OrderTemp?
    
    var loading : Bool = true
    
    var isOrderCreated: Bool = false
    
    
    @IBOutlet weak var constraintChoiceOnMap: NSLayoutConstraint!
    @IBOutlet weak var labelChoiceOnMap: UIButton!
    @IBOutlet weak var viewChoiceOnMapContainer: UIView!
    @IBOutlet weak var segmentsAddresses: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var nbiCancel: UIBarButtonItem!
    
    @IBOutlet weak var viewBaseTableViewContainer: UIView!
    @IBOutlet weak var viewNotFoundedBase: UIView!
    @IBOutlet weak var labelNotFoundedBase: UILabel!
    @IBOutlet weak var indicatorBase: UIActivityIndicatorView!
    
    @IBOutlet weak var autocompleteTableView: UITableView!
    @IBOutlet weak var viewAutocompleteComtainer: UIView!
    @IBOutlet weak var indicatorAutocompleteLoading: UIActivityIndicatorView!
    @IBOutlet weak var viewAutocompleteNotFounded: UIView!
    @IBOutlet weak var labelAddressNotFounded: UILabel!
    
    var centerCol : CLLocationCoordinate2D?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        if point == nil {
            point = "b"
        }
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.autocompleteTableView.delegate = self
        self.autocompleteTableView.dataSource = self
        
        self.searchController = UISearchController(searchResultsController: nil)
        self.searchController.searchResultsUpdater = self
        self.searchController.delegate = self
        self.searchController.searchBar.delegate = self
        self.searchController.dimsBackgroundDuringPresentation = false
        self.searchController.searchBar.placeholder = strComSearch()
        
        if #available(iOS 11.0, *) {
            navigationItem.searchController = searchController
        } else {
            navigationItem.titleView = searchController.searchBar
        }
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(SelectAddressTableViewController.keyboardWillShow(sender:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(SelectAddressTableViewController.keyboardWillHide(sender:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        if point != "a"  {
            
        } else {
            constraintChoiceOnMap.constant = 0
        }
        
        localize()
        initAdresses()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let text = self.searchController.searchBar.text {
            if (text.count > 0) {
                setEditing(true, animated: true)
            }
        }
        
        segmentsAddresses.isHidden = false
        tableView.isHidden = false
        showBaseLoading()
        self.updateTableView()
        
        if #available(iOS 11.0, *) {
            navigationItem.searchController?.searchBar.becomeFirstResponder()
        } else {
            self.searchController.searchBar.becomeFirstResponder()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mainViewController?.delegate?.showForeground!()
        colorize()
        
        if isOrderCreated {
            self.nbiCancel.isEnabled = false
            self.nbiCancel.tintColor = UIColor.clear
        }
        
        if #available(iOS 11.0, *) {
            self.searchController.isActive = false
            self.searchController.definesPresentationContext = true
            self.searchController.hidesNavigationBarDuringPresentation = true
        } else {
            self.searchController.definesPresentationContext = false
            self.searchController.hidesNavigationBarDuringPresentation = false
        }
    }

    
    func initAdresses() {
        let userProfile = profile()
        
        self.loading = true
        gxGetAddresses(centerCol!, completion: { (arr) in
            self.addressesNearly = arr
            self.loading = false
            self.updateTableView()
            self.viewBaseTableViewContainer.isHidden = false
        })
        
        if !(userProfile.phone?.isEmpty)! {
            searchRecentAddresses(phone: userProfile.phone!, cityId: curCity().cityID!, completion: { addressesRecent in
                self.addresses = addressesRecent
                self.updateTableView()
            })
        }
    }
    
    func keyboardWillShow(sender: NSNotification) {
        if let userInfo = sender.userInfo {
            self.kFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as AnyObject).cgRectValue.size.height
            self.contraintBottomSpace.constant = self.kFrame!
        }
    }
    
    func keyboardWillHide(sender: NSNotification) {
        self.contraintBottomSpace.constant = 0
    }
    
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.autocompleteTableView {
            return self.addressesAutocomplete.count
        } else {
            switch segmentsAddresses.selectedSegmentIndex {
            case 0:
                return (self.addresses.count)
            case 1:
                return (self.addressesNearly.count)
            case 2:
                return (self.addressesAirsAndTrains.count)
            default:
                return (self.addresses.count)
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var tempAddress: AddressTemp
        
        if tableView == self.autocompleteTableView {
            tempAddress = self.addressesAutocomplete[indexPath.row]
        } else {
            switch segmentsAddresses.selectedSegmentIndex {
            case 0:
                tempAddress = self.addresses[indexPath.row]
            case 1:
                tempAddress = self.addressesNearly[indexPath.row]
            case 2:
                tempAddress = self.addressesAirsAndTrains[indexPath.row]
            default:
                tempAddress = self.addresses[indexPath.row]
            }
        }
        
        
        let cell : AddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "address", for: indexPath as IndexPath) as! AddressTableViewCell
        cell.addressStreet.text = tempAddress.shortStrFromTempAddress()
        cell.addressCity.text = tempAddress.city
        
        if tempAddress.shortStrFromTempAddress() == strComNoAddrs() {
            cell.isHidden = true
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var tempAddress: AddressTemp
        
        if tableView == self.autocompleteTableView {
            tempAddress = self.addressesAutocomplete[indexPath.row]
        } else {
            switch segmentsAddresses.selectedSegmentIndex {
            case 0:
                tempAddress = self.addresses[indexPath.row]
            case 1:
                tempAddress = self.addressesNearly[indexPath.row]
            case 2:
                tempAddress = self.addressesAirsAndTrains[indexPath.row]
            default:
                tempAddress = self.addresses[indexPath.row]
            }
        }
        
        return tempAddress.shortStrFromTempAddress() == strComNoAddrs() ? 0 : heightForView(tempAddress.shortStrFromTempAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 40) + 27;
    }
    
    
    //MARK: Table View Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var tempAddress: AddressTemp
        
        if tableView == self.autocompleteTableView {
            tempAddress = self.addressesAutocomplete[indexPath.row]
        } else {
            switch segmentsAddresses.selectedSegmentIndex {
            case 0:
                tempAddress = self.addresses[indexPath.row]
            case 1:
                tempAddress = self.addressesNearly[indexPath.row]
            case 2:
                tempAddress = self.addressesAirsAndTrains[indexPath.row]
            default:
                tempAddress = self.addresses[indexPath.row]
            }
        }
        if indexPath.section == 0 {
            
            switch self.point! {
            case "a":
                self.curOrder?.pathA = tempAddress
                tempAddress.type = .autocomplete
            case "b":
                self.curOrder?.pathB = tempAddress
            case "c":
                self.curOrder?.pathC = tempAddress
            case "d":
                self.curOrder?.pathD = tempAddress
            case "e":
                self.curOrder?.pathE = tempAddress
            default:
                self.curOrder?.pathA = tempAddress
            }
            
            if isOrderCreated {
                self.navigationController?.popViewController(animated: true)
            } else {
                if searchController.isActive {
                    searchController.dismiss(animated: true, completion: {
                        self.dismiss(animated: true, completion: nil)
                    })
                } else {
                    dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    //MARK: search
    func willPresentSearchController(_ searchController: UISearchController) {
        self.searchController.searchBar.setValue(strComCancel(), forKey: "_cancelButtonText")
        self.searchController.searchBar.placeholder = strComSearch()
    }
    
    func didPresentSearchController(_ searchController: UISearchController) {
        showAutocompleteTableViewEmpty()
        self.labelAddressNotFounded.text = strComSearch()
        
        if #available(iOS 11.0, *) {
        } else {
            self.searchController.isActive = true
            self.searchController.searchBar.becomeFirstResponder()
        }
    }
    
    func willDismissSearchController(_ searchController: UISearchController) {
        view.endEditing(true)
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        if let text = searchController.searchBar.text {
            self.searchStr = text
            if self.searchController.isActive {
                if text.count > 2 {
                    loadingAutocompleteTableView()
                    self.searchTimer?.invalidate()
                    self.searchTimer = nil
                    self.searchTimer = Timer.scheduledTimer(
                        timeInterval: 0.5,
                        target : self,
                        selector : #selector(SelectAddressTableViewController.loadStreets),
                        userInfo : nil,
                        repeats : false)
                } else {
                    showAutocompleteTableViewEmpty()
                    self.labelAddressNotFounded.text = strComSearch()
                }
            } else {
                self.viewAutocompleteComtainer.isHidden = true
            }
        }
    }
    
    
    func loadStreets() {
        searchGeo(self.searchStr!, loc: self.centerCol!) { (arr) -> Void in
            if (self.searchController.isActive && (self.searchStr?.characters.count)! > 2) {
                self.addressesAutocomplete = arr
                self.autocompleteTableView.reloadData()
                if (arr.count > 0) {
                    self.showAutocompleteTableViewComplete()
                } else {
                    self.showAutocompleteTableViewEmpty()
                    self.labelAddressNotFounded.text = strComNotFound()
                }
            }
        }
    }
    
    
    private func loadingAutocompleteTableView() {
        self.viewAutocompleteComtainer.isHidden = false
        self.autocompleteTableView.isHidden = true
        self.indicatorAutocompleteLoading.isHidden = false
        self.viewAutocompleteNotFounded.isHidden = true
        self.indicatorAutocompleteLoading.startAnimating()
    }
    
    
    private func showAutocompleteTableViewComplete() {
        self.viewAutocompleteComtainer.isHidden = false
        self.autocompleteTableView.isHidden = false
        self.indicatorAutocompleteLoading.isHidden = true
        self.viewAutocompleteNotFounded.isHidden = true
        self.indicatorAutocompleteLoading.stopAnimating()
    }
    
    
    private func showAutocompleteTableViewEmpty() {
        self.viewAutocompleteComtainer.isHidden = false
        self.autocompleteTableView.isHidden = true
        self.indicatorAutocompleteLoading.isHidden = true
        self.viewAutocompleteNotFounded.isHidden = false
        self.indicatorAutocompleteLoading.stopAnimating()
    }
    
    
    //MARK: Commons
    func localize() {
        self.labelNotFoundedBase.text = strComNotFound()
        self.labelAddressNotFounded.text = strComNotFound()
        self.labelChoiceOnMap.setTitle(strTypesMap(), for: .normal)
        if point == "a" {
            self.navigationItem.title = strComFrom()
        }
        else {
            self.navigationItem.title = strComTo()
        }
        self.segmentsAddresses.setTitle(strComRecent(), forSegmentAt: 0)
        self.segmentsAddresses.setTitle(strComNearly(), forSegmentAt: 1)
    }
    
    func colorize() {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.isTranslucent = false
        self.searchController.searchBar.tintColor = colorNewNavBarText()
        self.segmentsAddresses.tintColor = UIColor(hexString: "727373")
        self.nbiCancel.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.sizeToFit()

        if let textfield = searchController.searchBar.value(forKey: "searchField") as? UITextField {
            textfield.textColor = .black
            textfield.tintColor = .black
            if let backgroundview = textfield.subviews.first {
                backgroundview.backgroundColor = UIColor.white
                backgroundview.layer.cornerRadius = 10;
                backgroundview.clipsToBounds = true;
            }
        }
    }
    
    
    @IBAction func onMapSelection(sender: AnyObject) {
        let controller = UIStoryboard.mapPicker()
        controller?.path = self.point
        self.navigationController?.pushViewController(controller!, animated: true)
    }
    // MARK: - Navigation
    
    @IBAction func onCloseView(_ sender: UIBarButtonItem) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    
    func selectOnMap() {
        self.mainViewController?.curOrder = self.curOrder
        self.mainViewController?.point = self.point
        if isOrderCreated {
            self.navigationController?.popToRootViewController(animated: true)
        } else {
            self.navigationController?.dismiss(animated: true, completion: nil)
            self.navigationController?.pushViewController(
                self.mainViewController!, animated: true)
        }
    }
    
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "approveAddress" {
            switch self.point! {
            case "a":
                self.curOrder?.pathA = addresses[(sender as! NSIndexPath).row]
            case "b":
                self.curOrder?.pathB = addresses[(sender as! NSIndexPath).row]
            case "c":
                self.curOrder?.pathC = addresses[(sender as! NSIndexPath).row]
            case "d":
                self.curOrder?.pathD = addresses[(sender as! NSIndexPath).row]
            case "e":
                self.curOrder?.pathE = addresses[(sender as! NSIndexPath).row]
            default:
                self.curOrder?.pathA = addresses[(sender as! NSIndexPath).row]
            }
            let controller : AddressDetailViewController = segue.destination as!  AddressDetailViewController
            controller.point = self.point
            controller.curOrder = self.curOrder
        }
    }
    
    @IBAction func onSegmentChanged(_ sender: UISegmentedControl) {
        updateTableView()
    }
    
    
    private func updateTableView() {
        switch (segmentsAddresses.selectedSegmentIndex) {
        case 0:
            setBaseTableViewState(addresses: self.addresses)
        case 1:
            setBaseTableViewState(addresses: self.addressesNearly)
        case 2:
            setBaseTableViewState(addresses: self.addressesAirsAndTrains)
        default:
            break
        }
        self.tableView.reloadData()
    }
    
    private func setBaseTableViewState(addresses: [AddressTemp]) {
        if addresses.count > 0 {
            showBaseTableViewComplete()
        } else {
            showBaseTableViewEmpty()
        }
    }

    private func showBaseLoading() {
        self.tableView.isHidden = true
        self.viewNotFoundedBase.isHidden = true
        self.indicatorBase.isHidden = false
        self.indicatorBase.startAnimating()
    }
    
    private func showBaseTableViewComplete() {
        self.tableView.isHidden = false
        self.viewNotFoundedBase.isHidden = true
        self.indicatorBase.stopAnimating()
        self.indicatorBase.isHidden = true
    }
    
    private func showBaseTableViewEmpty() {
        self.tableView.isHidden = true
        self.viewNotFoundedBase.isHidden = false
        self.indicatorBase.stopAnimating()
        self.indicatorBase.isHidden = true
    }
    
}
