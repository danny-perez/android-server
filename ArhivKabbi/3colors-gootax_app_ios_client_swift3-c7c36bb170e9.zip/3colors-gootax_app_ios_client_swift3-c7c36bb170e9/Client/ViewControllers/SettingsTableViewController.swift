//
//  SettingsTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class SettingsTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        NotificationCenter.default.addObserver(self, selector: #selector(SettingsTableViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        self.colorize()
        self.localize()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 6
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell : LanTitleTableViewCell = tableView.dequeueReusableCell(withIdentifier: "lanTitle", for: indexPath) as! LanTitleTableViewCell
            
            return cell
        }
        else if indexPath.row == 1 {
            let cell : LanSelectedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "lanPicked", for: indexPath) as! LanSelectedTableViewCell
            
             
            
            return cell
        }
        else if indexPath.row == 2 {
            let cell : ColorTitleTableViewCell = tableView.dequeueReusableCell(withIdentifier: "colTitle", for: indexPath) as! ColorTitleTableViewCell
            
            return cell
        }
        else if indexPath.row == 3 {
            let cell : ColorSelectedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "colPicked", for: indexPath) as! ColorSelectedTableViewCell
            
            
            return cell
        }
        else if indexPath.row == 4 {
            let cell : MapTitleTableViewCell = tableView.dequeueReusableCell(withIdentifier: "mapTitle", for: indexPath) as! MapTitleTableViewCell
            
            return cell
        }
        else if indexPath.row == 5 {
            let cell : MapSelectedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "mapPicked", for: indexPath) as! MapSelectedTableViewCell
            
            cell.mapSelectedTitle.text = curMapTitle()
            
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44.0
    }
    

    //MARK: - Commons
    func colorize()
    {
        self.tableView.backgroundColor = colorGrayBackground()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorStatusBar()
        self.navigationController?.navigationBar.addSubview(view)
        UIApplication.shared.statusBarStyle = colorStatusBarStyle()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = colorNavigationBar()
    }
    
    
    func localize()
    {
        self.navigationItem.title = strComSettings()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
