//
//  ActivateCodeViewController.swift
//  Client
//
//  Created by  Andrew on 20.04.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class ActivateCodeViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var inputCodeLabel: UILabel!
    
    fileprivate lazy var mProfile: Profile? = nil
    fileprivate lazy var mReferral: Referral? = nil
    @IBOutlet weak var backView: UIView!
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var codeField: UITextField!
    
     var visualEffectView : UIVisualEffectView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        
        
        mProfile = profile()
        let referrals: [Referral] = getReferrals()
        let cityId = curCity().cityID
        
        if (referrals.count > 0) {
            for ref in referrals {
                if (ref.cityID == cityId) {
                    mReferral = ref
                }
            }
        }
      
        codeField.delegate = self
        
        localize();
        colorize();
        
      
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onCheckCode(_ sender: AnyObject) {
        onActivateReferralCode()
    }
    
    @IBAction func onCloseWindow(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentCharacterCount = textField.text?.characters.count ?? 0
        
        if (range.length + range.location > currentCharacterCount){
            return false
        }
        
        let newLength = currentCharacterCount + string.characters.count - range.length
        return newLength <= 6
    }
    
    
    func onActivateReferralCode() {
        
        guard codeField.text!.count > 0 else {
            showMessage(strErrTitle(), message: "Введите промо-код")
            return
        }
        
        getReferralCodeActivate(codeField.text! , phone: mProfile!.phone!) { (isActivated) in
            if (isActivated) {
                showMessage(strRefActivatedSuccess() , message: "")
            } else {
                showMessage(strErrTitle() , message: strRefErrActivated())
            }
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    
    
    func localize()
    {
        self.navigationItem.title = strReferralCodeTitle()
        
        let layer = self.backView.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }
    
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        
        self.saveButton.setColors()
        self.saveButton.setTitle(strRateSend(), for: UIControlState())
    }
    
}
