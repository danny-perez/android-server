//
//  FeedbackViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 28.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class FeedbackViewController: UIViewController {

    @IBOutlet weak var starsView: UIView!
    @IBOutlet weak var star3: UIButton!
    @IBOutlet weak var star2: UIButton!
    @IBOutlet weak var star1: UIButton!
    @IBOutlet weak var star4: UIButton!
    @IBOutlet weak var star5: UIButton!
    @IBOutlet weak var feedbackLabel: UILabel!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var feedBackTextField: UITextField!
    
    
    var curValue : Double?
    
    var order : Order?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var setted = false
        if order != nil {
            if order?.rate != nil {
                if order?.rate != NSNumber(value: 0 as Double) {
                    self.setStar((order?.rate?.doubleValue)!)
                    self.disableButtons()
                    setted = true
                }
            }
        }
        if !setted {
            self.setStar(0)
            self.feedBackTextField.becomeFirstResponder()
        }
        self.feedBackTextField.text = self.order?.feedback
        self.colorize()
        
        self.localize()
       
        let gesture = UITapGestureRecognizer(target: self, action: #selector(FeedbackViewController.tapped))
        self.view.addGestureRecognizer(gesture)
    
        // Do any additional setup after loading the view.
    }
    
    func tapped() {
        self.view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func resizeImage(_ image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    @IBAction func sendFeedback(_ sender: UIButton)
    {
        sender.isEnabled = false
        let trimmedFeedback = self.feedBackTextField.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        if (useReviewBlock && self.curValue != nil && (Int(self.curValue!)) < 5 && trimmedFeedback!.isEmpty) {
            showMessage(strErrTitle(), message: strReviewStarCount())
            sender.isEnabled = true
        } else {
            sendFeedBack(String(Int(self.curValue!)), text: trimmedFeedback!, order: self.order!) { (result) -> Void in
                self.order?.rate = self.curValue! as NSNumber?
                self.order?.feedback = self.feedBackTextField.text!
                saveDefaultContext()
                self.navigationController?.popViewController(animated: true)
                sender.isEnabled = true
            }
        }
        
    }
    
    
    @IBAction func newRate(_ sender: UIButton) {
        self.setStar(Double(sender.tag))
    }
    
    
    func setStar(_ val: Double) {
        if val > 0 {
            self.star1.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
            self.sendButton.isEnabled = true
        }
        else {
            self.star1.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
            self.sendButton.isEnabled = false
        }
        if val > 1 {
            self.star2.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star2.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 2 {
            self.star3.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star3.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 3 {
            self.star4.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star4.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 4 {
            self.star5.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star5.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        self.curValue = val
    }
    
    func disableButtons() {
        self.star1.isEnabled = false
        self.star2.isEnabled = false
        self.star3.isEnabled = false
        self.star4.isEnabled = false
        self.star5.isEnabled = false
        self.feedBackTextField.isEnabled = false
        self.sendButton.isEnabled = false
    }
    
    
    func localize() {
        self.feedbackLabel.text = strRateFeedback()
        self.sendButton.setTitle(strRateSend(), for: UIControlState())
        var setted = false
        if order != nil {
            if order?.rate != nil {
                self.navigationItem.title = strRateYour()
                setted = true
            }
        }
        if !setted {
            self.navigationItem.title = strRateSet()
        }
    }
    
    func colorize() {
        self.sendButton.setColors()
    }

}
