//
//  SettingsViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    //    @IBOutlet weak var navBar: UINavigationBar!
    
    var visualEffectView : UIVisualEffectView?
    let endEffect = UIBlurEffect(style: .light)
    
    var activeText: UITextField?
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    
    var tenText: UITextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        NotificationCenter.default.addObserver(self, selector: #selector(SettingsViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        localize()
        
        colorize()
        
        NotificationCenter.default.addObserver(self,
                                                         selector: #selector(SettingsViewController.keyboardWillShow(_:)),
                                                         name: NSNotification.Name.UIKeyboardWillShow,
                                                         object: nil)
        NotificationCenter.default.addObserver(self,
                                                         selector: #selector(SettingsViewController.keyboardWillHide(_:)),
                                                         name: NSNotification.Name.UIKeyboardWillHide,
                                                         object: nil)
        
        // Do any additional setup after loading the view.
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeText = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeText = nil
    }
    
    func keyboardWillShow(_ note: Notification) {
        if let keyboardSize = (note.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            var frame = tableView.frame
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationBeginsFromCurrentState(true)
            UIView.setAnimationDuration(0.3)
            frame.size.height -= keyboardSize.height
            tableView.frame = frame
            if activeText != nil {
                let rect = tableView.convert(activeText!.bounds, from: activeText)
                tableView.scrollRectToVisible(rect, animated: false)
            }
            UIView.commitAnimations()
        }
    }
    
    func keyboardWillHide(_ note: Notification) {
        if let keyboardSize = (note.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            var frame = tableView.frame
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationBeginsFromCurrentState(true)
            UIView.setAnimationDuration(0.3)
            frame.size.height += keyboardSize.height
            tableView.frame = frame
            UIView.commitAnimations()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if isDemo {
            if countMaps() > 0 {
                return 5
            }
            else {
                return 3
            }
        }
        else {
            if countMaps() > 0 {
                return 4
            }
            return 2
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            if !isDemo {
                return 0
            }
            return 1
        }
        else if section == 1 {
            return languagesArray().count + 1
        }
        else if section == 2 {
            if countMaps() > 0 {
                return countMaps() + 1
            }
            else {
                return schemes.count + 1
            }
        }
        else if section == 3 {
            if countMaps() > 0 {
                return 3
            }
            else {
                return 3
            }
        }
        else {
            return schemes.count + 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                let cell : HeaderSetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "setHead", for: indexPath) as! HeaderSetTableViewCell
                cell.titleLabel.text = strSetLan().uppercased()
                return cell
            }
            let cell : LanguageTableViewCell = tableView.dequeueReusableCell(withIdentifier: "set", for: indexPath) as! LanguageTableViewCell
            let index = indexPath.row - 1
            cell.lanTitle.text = languagesArray()[index]["title"]
            if selectedLan() == languagesArray()[index]["title"] {
                cell.lanChecked.isHidden = false
            }
            else {
                cell.lanChecked.isHidden = true
            }
            if index == 0 {
                cell.topSpace.constant = 8
            }
            else {
                cell.topSpace.constant = 0
            }
            if index == languagesArray().count-1 {
                cell.botSpace.constant = 3
            }
            else {
                cell.botSpace.constant = 0
            }
            return cell
        }
        if countMaps() > 0 {
            if indexPath.section == 2 {
                if indexPath.row == 0 {
                    let cell : HeaderSetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "setHead", for: indexPath) as! HeaderSetTableViewCell
                    cell.titleLabel.text = strSetMap().uppercased()
                    return cell
                }
                let cell : LanguageTableViewCell = tableView.dequeueReusableCell(withIdentifier: "set", for: indexPath) as! LanguageTableViewCell
                let index = indexPath.row - 1
                if index == 0 {
                    if needOSMMap {
                        cell.lanTitle.text = mapsArray()[0]["title"] as? String
                        
                        if curMap() == 0 {
                            cell.lanChecked.isHidden = false
                        }
                        else {
                            cell.lanChecked.isHidden = true
                        }
                        
                        
                    }
                    else if needGoogleMapNormal {
                        cell.lanTitle.text = mapsArray()[1]["title"] as? String
                        if curGoogleMapType() {
                            cell.lanChecked.isHidden = false
                        }
                        else {
                            cell.lanChecked.isHidden = true
                        }
                    }
                    else {
                        cell.lanTitle.text = "\(mapsArray()[1]["title"] as! String) Hybrid"
                        if !curGoogleMapType() {
                            cell.lanChecked.isHidden = false
                        }
                        else {
                            cell.lanChecked.isHidden = true
                        }
                    }
                }
                else if index == 1 {
                    cell.lanTitle.text = mapsArray()[1]["title"] as? String
                    if curGoogleMapType() {
                        
                        if curMap() == 1 {
                            cell.lanChecked.isHidden = false
                        }
                        else {
                            cell.lanChecked.isHidden = true
                        }
                    }
                    else {
                        cell.lanChecked.isHidden = true
                    }
                } else if index == 2 {
                    cell.lanTitle.text = "\(mapsArray()[1]["title"] as! String) Hybrid"
                    if curMap() == 1 {
                        if !curGoogleMapType() {
                            cell.lanChecked.isHidden = false
                        }
                        else {
                            cell.lanChecked.isHidden = true
                        }
                    }
                    else {
                        cell.lanChecked.isHidden = true
                    }
                }  else if index == 3 {
                    cell.lanTitle.text = "\(mapsArray()[2]["title"] as! String)"
                    if curMap() == 2 {
                        cell.lanChecked.isHidden = false
                    } else {
                        cell.lanChecked.isHidden = true
                    }
                }
                if index == 0 {
                    cell.topSpace.constant = 8
                }
                else {
                    cell.topSpace.constant = 0
                }
                if index == countMaps()-1 {
                    cell.botSpace.constant = 3
                }
                else {
                    cell.botSpace.constant = 0
                }
                return cell
            } else if indexPath.section == 3 {
                if indexPath.row == 0 {
                    let cell : HeaderSetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "setHead", for: indexPath) as! HeaderSetTableViewCell
                    cell.titleLabel.text = strCalndarTitle()
                    return cell
                }  else {
                    let cell : LanguageTableViewCell = tableView.dequeueReusableCell(withIdentifier: "set", for: indexPath) as! LanguageTableViewCell
                    let index = indexPath.row - 1
                    cell.lanTitle.text = calendarArray()[index]
                    if profile().calendar! == index {
                        cell.lanChecked.isHidden = false
                    }
                    else {
                        cell.lanChecked.isHidden = true
                    }
                    if index == 0 {
                        cell.topSpace.constant = 8
                    }
                    else {
                        cell.topSpace.constant = 0
                    }
                    if index == calendarArray().count-1 {
                        cell.botSpace.constant = 3
                    }
                    else {
                        cell.botSpace.constant = 0
                    }
                    return cell
                }
            }
        }
        if indexPath.section == 0 {
            let cell : TenSetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "tenSet", for: indexPath) as! TenSetTableViewCell
            return cell
        }
        else {
            if indexPath.row == 0 {
                let cell : HeaderSetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "setHead", for: indexPath) as! HeaderSetTableViewCell
                cell.titleLabel.text = strSetSelectColor().uppercased()
                return cell
            }
            let cell : LanguageTableViewCell = tableView.dequeueReusableCell(withIdentifier: "set", for: indexPath) as! LanguageTableViewCell
            let index = indexPath.row - 1
            cell.lanTitle.text = String(index)
            if currentSch() == index {
                cell.lanChecked.isHidden = false
            }
            else {
                cell.lanChecked.isHidden = true
            }
            if index == 0 {
                cell.topSpace.constant = 8
            }
            else {
                cell.topSpace.constant = 0
            }
            if index == schemes.count-1 {
                cell.botSpace.constant = 3
            }
            else {
                cell.botSpace.constant = 0
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (!useCalendarExtensions && indexPath.section == 3) {
            return 0
        }
        if indexPath.row == 0 {
            if indexPath.section == 0 {
                return 57
            }
            return 35
        }
        let index = indexPath.row - 1
        if indexPath.section == 1 {
            if index == 0 {
                return 55
            }
            else if index == languagesArray().count-1 {
                return 50
            }
            else {
                return 47
            }
        }
        if countMaps() > 0 {
            if indexPath.section == 2 {
                if index == 1 {
                    if countMaps() == 1 {
                        return 58
                    }
                    return 47
                }
                else if index == 0 {
                    var height : CGFloat = 3
                    if needGoogleMapHybrid {
                        if countMaps() == 2 {
                            height += 50
                        }
                        else {
                            height += 47
                        }
                    }
                    return height
                }
                else {
                    if !needGoogleMapNormal {
                        return 0
                    }
                    return 47
                }
            }
        }
        else {
            if indexPath.section == 2 {
                if index == 0 {
                    return 55
                }
                else if index == schemes.count-1 {
                    return 50
                }
                else {
                    return 47
                }
            }
            
        }
        if indexPath.section == 3 {
            if index == 0 {
                return 55
            }
            else if index == schemes.count-1 {
                return 50
            }
            else {
                return 47
            }
        }
        if indexPath.section == 0 {
            return 52
        }
        if indexPath.row == 0 {
            return 65
        }
        else {
            return 47
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let index = indexPath.row - 1
        if indexPath.section == 1 {
            let defaults = UserDefaults.standard
            defaults.set(languagesArray()[index]["code"], forKey: udefCurLan)
            defaults.synchronize()
            delay(0.1, closure: {
                print(defaultCountry)
                defaults.set(defaultCountry(), forKey: udefCurCountry)
            })
            NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeLan), object: nil)
            self.tableView.reloadData()
        }
        else if indexPath.section == 2 {
            if countMaps() > 0 {
                let defaults = UserDefaults.standard
                if index == 0 {
                    if needOSMMap {
                        defaults.set(mapsArray()[0]["code"], forKey: udefCurMap)
                    }
                    else if needGoogleMapNormal {
                        defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                        defaults.set(true, forKey: udefGoogleMapType)
                    }
                    else {
                        defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                        defaults.set(false, forKey: udefGoogleMapType)
                    }
                }
                else if index == 1 {
                    if needOSMMap {
                        if needGoogleMapNormal {
                            defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                            defaults.set(true, forKey: udefGoogleMapType)
                        }
                        else {
                            defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                            defaults.set(false, forKey: udefGoogleMapType)
                        }
                    }
                    else {
                        defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                        defaults.set(false, forKey: udefGoogleMapType)
                    }
                } else if index == 2 {
                    defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                    defaults.set(false, forKey: udefGoogleMapType)
                } else if index == 3 {
                    defaults.set(mapsArray()[2]["code"], forKey: udefCurMap)
                }
                else {
                    defaults.set(mapsArray()[1]["code"], forKey: udefCurMap)
                    defaults.set(false, forKey: udefGoogleMapType)
                }
                let mapCont = (self.presentingViewController as! UINavigationController).viewControllers[0] as! MapViewController
                
                mapCont.viewDidLoad()
                mapCont.viewWillAppear(true)
                
                self.tableView.reloadData()
            } else {
                let defaults = UserDefaults.standard
                defaults.set(index, forKey: udefSch)
                NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeCol), object: nil)
                self.tableView.reloadData()
                self.colorize()
            }
        } else if indexPath.section == 3 {
            let curProfile = profile()
            curProfile.calendar = index
            updateProfile(curProfile)
            NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeCalendar), object: nil)
            self.tableView.reloadData()
        }
        else if indexPath.section == 4 {
            let defaults = UserDefaults.standard
            defaults.set(index, forKey: udefSch)
            NotificationCenter.default.post(name: Notification.Name(rawValue: notifChangeCol), object: nil)
            self.tableView.reloadData()
            self.colorize()
        }
        else if indexPath.section == 0 {
            self.navigationController!.pushViewController(UIStoryboard.tenantSettingsController()!, animated: true)
        }
    }
    
    @IBAction func closeAction(_ sender: AnyObject) {
        self.navigationController!.dismiss(animated: true, completion: nil)
    }
    func localize()
    {
        self.navigationItem.title = strComSettings()
    }
    
    func colorize() {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        //        self.closeButton.tintColor = colorNewHamButton()
    }
    
}
