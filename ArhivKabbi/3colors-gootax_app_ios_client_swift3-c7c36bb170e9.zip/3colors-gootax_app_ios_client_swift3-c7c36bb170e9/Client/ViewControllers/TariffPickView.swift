//
//  TariffPickView.swift
//  Client
//
//  Created by Dmitriy Kudrin on 13.01.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class TariffPickView: UIView {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var tariffName: UILabel!
    @IBOutlet weak var carPhoto: UIImageView!
    @IBOutlet weak var pickButton: UIButton!
    @IBOutlet weak var tariffDescr: UITextView!
    @IBOutlet weak var shadowView: UIView!
    var tariff : Tariff?
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.pickButton.backgroundColor = colorNewTint()
        self.pickButton.setColors()
        self.backView.layer.shouldRasterize = true
        self.backView.layer.rasterizationScale = UIScreen.main.scale
        self.backView.layer.shadowRadius = 3;
        self.backView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backView.layer.masksToBounds = false
        self.backView.layer.shadowOpacity = 0.3;
        self.backView.layer.cornerRadius = 4
        self.tariffDescr.setContentOffset(CGPoint.zero, animated: false)
        
        self.shadowView.layer.shouldRasterize = true
        self.shadowView.layer.rasterizationScale = UIScreen.main.scale
        self.shadowView.layer.shadowRadius = 1;
        self.shadowView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.shadowView.layer.masksToBounds = false
        self.shadowView.layer.shadowOpacity = 0.2;
        self.colorize()
        self.localize()
    }
    
    @IBAction func selectTariff(_ sender: UIButton) {
        var responder : UIResponder = self
        while !(responder is TariffPickViewController) {
            if responder.next != nil {
                responder = responder.next!
            }
            else {
                break
            }
        }
        let tariffPickViewController : TariffPickViewController = responder as! TariffPickViewController
        tariffPickViewController.curOrder?.orderTariff = self.tariff
        tariffPickViewController.closeAction("" as AnyObject)
    }
    
    @IBAction func close(_ sender: UIButton) {
        var responder : UIResponder = self
        while !(responder is TariffPickViewController) {
            if responder.next != nil {
                responder = responder.next!
            }
            else {
                break
            }
        }
        let tariffPickViewController : TariffPickViewController = responder as! TariffPickViewController
        tariffPickViewController.closeAction("" as AnyObject)
    }
    
    
    func colorize() {
        
    }
    
    func localize() {
        self.pickButton.setTitle(strComPickC().uppercased(), for: UIControlState())
    }
    

}
