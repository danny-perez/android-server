//
//  SearchCountryTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 26.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class SearchCountryTableViewController: UITableViewController {
    
    
    var cntries : [[String: Any]] = [[String: Any]]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        colorize()
        
        self.navigationController?.isNavigationBarHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cntries.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : CountryTableViewCell = tableView.dequeueReusableCell(withIdentifier: "country", for: indexPath) as! CountryTableViewCell
        cell.countryShortCode.text = cntries[indexPath.row]["shortMask"] as? String
        cell.countryLabel.text = cntries[indexPath.row]["label"] as? String

        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let rightView = widthForView(cntries[indexPath.row]["shortMask"] as! String, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width)
        return heightForView(cntries[indexPath.row]["label"] as! String, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - rightView - 40) + 21;
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let defaults : UserDefaults = UserDefaults.standard
        defaults.set(cntries[indexPath.row], forKey: udefCurCountry)
        let controller : AuthorizationTableViewController = self.presentingViewController!.navigationController?.viewControllers[0] as! AuthorizationTableViewController
        controller.curPhone = ""
        controller.tableView.reloadData()
        self.presentingViewController?.navigationController?.popViewController(animated: true)
    }
    
    
    
    func colorize()
    {
        self.tableView.backgroundColor = colorMain()
    }

}
