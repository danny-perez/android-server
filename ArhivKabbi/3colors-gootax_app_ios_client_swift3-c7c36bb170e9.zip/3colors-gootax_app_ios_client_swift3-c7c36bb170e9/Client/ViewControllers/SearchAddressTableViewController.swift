//
//  SearchAddressTableViewController.swift
//  
//
//  Created by Dmitriy Kudrin on 06.07.15.
//
//

import UIKit

class SearchAddressTableViewController: UITableViewController {

    
    
    var addresses : [AddressTemp] = Array()
    
    var loading : Bool = true
    
    var kFrame : CGFloat?
    
    var resized : Bool = false
    
    var path : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
//        print(self.presentingViewController?.navigationController)
        if let presentedController = self.presentingViewController as? SelectAddressTableViewController {
            self.path = presentedController.point
        }

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        if self.path != "a" {
            return 2
        }
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.path != "a" {
            if section == 0 {
                return 1
            }
            else {
                if loading {
                    return 1
                }
                else {
                    if addresses.count == 0 {
                        return 1
                    }
                    return addresses.count
                }
            }
        }
        if loading {
            return 1
        }
        else {
            if addresses.count == 0 {
                return 1
            }
            return addresses.count
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.path != "a" {
            if indexPath.section == 0 {
                let cell : SelectMapTableViewCell = tableView.dequeueReusableCell(withIdentifier: "searchOnMap", for: indexPath) as! SelectMapTableViewCell
                
                return cell
            }
            else {
                if loading {
                    
                    let cell : LoadingAddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "loading", for: indexPath) as! LoadingAddressTableViewCell
                    
                    cell.loadingIndicator.startAnimating()
                    
                    return cell
                }
                else {
                    if addresses.count > 0 {
                        let cell : AddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "address", for: indexPath) as! AddressTableViewCell
                        cell.addressStreet.text = (self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress()
                        cell.addressCity.text = (self.addresses[indexPath.row] as AddressTemp).city
                        return cell
                    }
                    else {
                        let cell : NoResTableViewCell = tableView.dequeueReusableCell(withIdentifier: "noResults", for: indexPath) as! NoResTableViewCell
                        cell.notFoundLabel.text = strComNotFound()
                        return cell
                    }
                }
            }
        }
        else {
            if loading {
                
                let cell : LoadingAddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "loading", for: indexPath) as! LoadingAddressTableViewCell
                
                cell.loadingIndicator.startAnimating()
                
                return cell
            }
            else {
                if addresses.count > 0 {
                    let cell : AddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "address", for: indexPath) as! AddressTableViewCell
                    cell.addressStreet.text = (self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress()
                    cell.addressCity.text = (self.addresses[indexPath.row] as AddressTemp).city
                    return cell
                }
                else {
                    let cell : NoResTableViewCell = tableView.dequeueReusableCell(withIdentifier: "noResults", for: indexPath) as! NoResTableViewCell
                    cell.notFoundLabel.text = strComNotFound()
                    return cell
                }
            }
        }
        
    }
    

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.path != "a" {
            if indexPath.section == 0 {
                return 50
            }
            else {
                if loading {
                    return 44
                }
                else {
                    if addresses.count > 0 {
                        return heightForView((self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 40) + 23;
                    }
                    else {
                        return 250
                    }
                }
            }
        }
        if loading {
            return 44
        }
        else {
            if addresses.count > 0 {
                return heightForView((self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 40) + 23;
            }
            else {
                return 250
            }
        }
    }

    @IBAction func selectMap(_ sender: AnyObject) {
        let presentingController : SelectAddressTableViewController = self.presentingViewController as! SelectAddressTableViewController
        presentingController.selectOnMap()
    }
    
    // MARK: - UITableView Delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.path != "a" {
            if indexPath.section != 0 {
                if self.loading == false {
                    if addresses.count > 0 {
                        let presentingController : SelectAddressTableViewController = self.presentingViewController as! SelectAddressTableViewController
                        
                        let tempAddress = self.addresses[indexPath.row]
                        switch presentingController.point! {
                        case "a" :
                            presentingController.curOrder?.pathA = tempAddress
                        case "b" :
                            presentingController.curOrder?.pathB = tempAddress
                        case "c" :
                            presentingController.curOrder?.pathC = tempAddress
                        case "d" :
                            presentingController.curOrder?.pathD = tempAddress
                        case "e" :
                            presentingController.curOrder?.pathE = tempAddress
                        default :
                            print("default")
                        }
                        presentingController.navigationController?.dismiss(animated: true, completion: nil)
                    }
                }
            }
        }
        else {
            if self.loading == false {
                if addresses.count > 0 {
                    let presentingController : SelectAddressTableViewController = self.presentingViewController as! SelectAddressTableViewController
                    switch presentingController.point! {
                    case "a" :
                        presentingController.curOrder?.pathA = self.addresses[indexPath.row]
                    case "b" :
                        presentingController.curOrder?.pathB = self.addresses[indexPath.row]
                    case "c" :
                        presentingController.curOrder?.pathC = self.addresses[indexPath.row]
                    case "d" :
                        presentingController.curOrder?.pathD = self.addresses[indexPath.row]
                    case "e" :
                        presentingController.curOrder?.pathE = self.addresses[indexPath.row]
                    default :
                        print("default")
                    }
                    presentingController.navigationController?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
