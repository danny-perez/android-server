//
//  SelectMapTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 04.04.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class SelectMapTableViewCell: UITableViewCell {

    @IBOutlet weak var approveButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        colorize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.approveButton.backgroundColor = colorNewTint()
        self.approveButton.setColors()
        
    }
    
    func localize()
    {

        self.approveButton.setTitle(strTypesMap().uppercased(), for: UIControlState())
        self.approveButton.layer.cornerRadius = 4;
    }

}
