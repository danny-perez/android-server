//
//  WishesFinishedTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 08.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class WishesFinishedTableViewCell: UITableViewCell {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var costAdditionals: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
