//
//  ProfilePayBonusTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ProfilePayBonusTableViewCell: UITableViewCell {

    @IBOutlet weak var payBonus: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ProfilePayBonusTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = colorMain()
        self.backgroundColor = colorMain()
        self.payBonus.textColor = colorMainText()
    }
    
    func localize()
    {
        self.payBonus.text = strComPayBonus()
    }
}
