//
//  DeleteOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 29.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class DeleteOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var deleteLogo: UIImageView!
    @IBOutlet weak var deleteLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(DeleteOrderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func colorize() {
        self.backgroundColor = colorMain()
        self.backgroundView?.backgroundColor = colorMain()
        self.deleteLabel.textColor = colorRedText()
    }
    
    func localize() {
        self.deleteLabel.text = strComDeleteOrder()
    }

}
