//
//  ReorderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 28.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ReorderTableViewCell: UITableViewCell {

    @IBOutlet weak var reorderTitle: UILabel!
    @IBOutlet weak var shareTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ReorderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)

        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize() {
//        self.backgroundColor = colorMain()
//        self.backgroundView?.backgroundColor = colorMain()
//        self.reorderTitle.textColor = colorMainText()
    }
    
    func localize() {
        self.reorderTitle.text = strComRetry()
        self.shareTitle.text = strShareTitle()
    }
}
