//
//  CommentTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class CommentTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var commentLabel: UILabel!
    @IBOutlet weak var commentText: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        commentText.delegate = self
        localize()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        if selected {
            self.commentText.becomeFirstResponder()
        }
        // Configure the view for the selected state
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentCharacterCount = textField.text?.characters.count ?? 0
        if (range.length + range.location > currentCharacterCount){
            return false
        }
        let newLength = currentCharacterCount + string.characters.count - range.length
        return newLength <= 100
    }

    func colorize() {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.commentText.textColor = colorMainText()
    }
    
    func localize() {
        self.commentLabel.text = strComComment()
    }
    
    
}
