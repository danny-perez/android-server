//
//  AboutOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AboutOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var aboutOrderTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AboutOrderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = colorGrayBackground()
        self.backgroundColor = colorGrayBackground()
        self.aboutOrderTitle.textColor = colorGrayLabelText()
    }
    
    func localize()
    {
        self.aboutOrderTitle.text = strComAboutOrder().uppercased()
    }
}
