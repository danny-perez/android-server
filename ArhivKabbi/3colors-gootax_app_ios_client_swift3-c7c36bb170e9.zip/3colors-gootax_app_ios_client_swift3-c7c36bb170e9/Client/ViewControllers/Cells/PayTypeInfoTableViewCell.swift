//
//  PayTypeInfoTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PayTypeInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var payInfoLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(PayTypeInfoTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func localize() {
        self.payInfoLabel.text = strPayInfoPay()
    }

}
