//
//  ReverseOrderTableViewCell.swift
//  Client
//
//  Created by  Andrew on 11/01/2018.
//  Copyright © 2018 Gootax. All rights reserved.
//

import UIKit

class ReverseOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var labelReorderTitle: UILabel!
    @IBOutlet weak var labelReverseTitle: UILabel!
    @IBOutlet weak var labelShareTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        localizationResourse()
        NotificationCenter.default.addObserver(self, selector: #selector(ReorderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func localizationResourse() {
        self.labelReorderTitle.text = strComRetry()
        self.labelShareTitle.text = strShareTitle()
        self.labelReverseTitle.text = strComReverse()
    }

}
