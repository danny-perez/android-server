//
//  CostListTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class CostListTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    private func localize() {
        if layoutDirection == .rightToLeft {
            titleLabel.textAlignment = .right
            costLabel.textAlignment = .left
        } else {
            titleLabel.textAlignment = .left
            costLabel.textAlignment = .right
        }
        
    }
    
}
