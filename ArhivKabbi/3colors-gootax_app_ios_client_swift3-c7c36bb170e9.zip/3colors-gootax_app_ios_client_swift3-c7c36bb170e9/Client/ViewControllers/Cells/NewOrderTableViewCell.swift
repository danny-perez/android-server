//
//  NewOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 26.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
import Kingfisher

class NewOrderTableViewCell: UITableViewCell, MKMapViewDelegate {

    @IBOutlet weak var centerConstraint: NSLayoutConstraint!
    @IBOutlet weak var rejectedLabel: UILabel!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var carLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var sepView: UIView!
    @IBOutlet weak var driverPhoto: UIImageView!
    @IBOutlet weak var botView: UIView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var preOrderTimeTitle: UILabel!
    @IBOutlet weak var preOrderTimeLabel: UILabel!
    var updateDelay : Double = 30
    var quered = false
    var curOrder : Order?
    var timer : Timer?
    
    func curMap() -> Int {
        return 0
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.applyCurvedShadow(self.backView)
        self.applyCurvedShadow(self.driverPhoto)
        localize()
        colorize()
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.blue
            polylineRenderer.lineWidth = 5
            return polylineRenderer
        }
        return MKTileOverlayRenderer(overlay: overlay)
    }
    
    func diealloc() {
        if self.timer != nil {
            self.timer?.invalidate()
            self.timer = nil
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is PointAnnotation {
            let ann = annotation as! PointAnnotation
            let annView = SmallPointAnnView(annotation: ann, reuseIdentifier: "", point: ann.point)
            return annView
        }
        else {
            return nil
        }
    }

    
    func setOrder(_ order : Order, cur: String) {
        let curProfile = profile()
        self.curOrder = order
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy, HH:mm"
        if (curProfile.calendar == persian) { dateFormatter.calendar = Calendar(identifier: Calendar.Identifier.persian) }
        dateFormatter.locale = Locale(identifier: selLan())
        if (curOrder?.carDateTime != nil) {
            self.dateLabel.text = dateFormatter.string(from: getFakeOrderDate((curOrder?.carDateTime)!))
        }
        else {
            self.dateLabel.text = dateFormatter.string(from: (curOrder?.createDateTime)! as Date)
        }
        self.contentView.setNeedsLayout()
        if order.driver == nil {
            self.carLabel.isHidden = false
            self.driverPhoto.image = UIImage(named: "driver")
            if order.statusID == "new" || order.statusID == "New" || order.statusID == "pre_order" {
                self.carLabel.text = strComDriverNotSettedYet()
            }
            else {
                self.carLabel.text = strComDriverNotWasSetted()
            }
        }
        else {
            self.carLabel.isHidden = false
            self.carLabel.text = order.driver?.carModel
        }
        
        if order.statusID == "new" || order.statusID == "New" || order.statusID == "pre_order"{
            self.setTime()
            self.timer = Timer.scheduledTimer(timeInterval: updateDelay, target: self, selector: #selector(NewOrderTableViewCell.setTime), userInfo: "", repeats: true)
            self.rejectedLabel.isHidden = true
            self.costLabel.isHidden = true
            self.preOrderTimeLabel.isHidden = false
            self.preOrderTimeTitle.isHidden = false
        }
        else {
            self.rejectedLabel.isHidden = false
            self.costLabel.isHidden = false
            self.preOrderTimeLabel.isHidden = true
            self.preOrderTimeTitle.isHidden = true
        }
        
        if self.curMap() == 0 || self.curMap() == 2 {
            self.mapView!.removeAnnotations(self.mapView!.annotations)
            self.mapView!.addAnnotation(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointA?.lat.doubleValue)!, (order.pointA?.lon.doubleValue)!), title: "", subtitle: "", point: "A"))
        }
        
        var pointsArray = [PointAnnotation]()
        pointsArray.append(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointA?.lat.doubleValue)!, (order.pointA?.lon.doubleValue)!), title: "", subtitle: "", point: "A"))
        
        if order.pointB != nil {
            if order.pointB?.lat != nil {
                if order.pointB?.lat.doubleValue != 0 {
                    if order.pointB?.lon != nil {
                        if order.pointB?.lon.doubleValue != 0 {
                            if self.curMap() == 0 || self.curMap() == 2 {
                                pointsArray.append(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointB?.lat.doubleValue)!, (order.pointB?.lon.doubleValue)!), title: "", subtitle: "", point: "B"))
                                self.mapView!.addAnnotation(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointB?.lat.doubleValue)!, (order.pointB?.lon.doubleValue)!), title: "", subtitle: "", point: "B"))
                            }
                        }
                    }
                }
            }
        }
        if order.pointC != nil {
            if order.pointC?.lat != nil {
                if order.pointC?.lat.doubleValue != 0 {
                    if order.pointC?.lon != nil {
                        if order.pointC?.lon.doubleValue != 0 {
                            if self.curMap() == 0 || self.curMap() == 2  {
                                pointsArray.append(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointC?.lat.doubleValue)!, (order.pointC?.lon.doubleValue)!), title: "", subtitle: "", point: "C"))
                                self.mapView!.addAnnotation(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointC?.lat.doubleValue)!, (order.pointC?.lon.doubleValue)!), title: "", subtitle: "", point: "C"))
                            }
                        }
                    }
                }
            }
        }
        if order.pointD != nil {
            if order.pointD?.lat != nil {
                if order.pointD?.lat.doubleValue != 0 {
                    if order.pointD?.lon != nil {
                        if order.pointD?.lon.doubleValue != 0 {
                            if self.curMap() == 0 || self.curMap() == 2  {
                                pointsArray.append(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointD?.lat.doubleValue)!, (order.pointD?.lon.doubleValue)!), title: "", subtitle: "", point: "D"))
                                self.mapView!.addAnnotation(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointD?.lat.doubleValue)!, (order.pointD?.lon.doubleValue)!), title: "", subtitle: "", point: "D"))
                            }
                        }
                    }
                }
            }
        }
        if order.pointE != nil {
            if order.pointE?.lat != nil {
                if order.pointE?.lat.doubleValue != 0 {
                    if order.pointE?.lon != nil {
                        if order.pointE?.lon.doubleValue != 0 {
                            if self.curMap() == 0 || self.curMap() == 2  {
                                pointsArray.append(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointE?.lat.doubleValue)!, (order.pointE?.lon.doubleValue)!), title: "", subtitle: "", point: "E"))
                                self.mapView!.addAnnotation(PointAnnotation(coordinate: CLLocationCoordinate2DMake((order.pointE?.lat.doubleValue)!, (order.pointE?.lon.doubleValue)!), title: "", subtitle: "", point: "E"))
                            }
                        }
                    }
                }
            }
        }
        if self.curMap() == 0 || self.curMap() == 2  {
            if pointsArray.count > 1 {
                var zoomRect = MKMapRectNull
                for annotation in pointsArray {
                    let annotationPoint = MKMapPointForCoordinate(annotation.coordinate)
                    let pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0.1, 0.1)
                    zoomRect = MKMapRectUnion(zoomRect, pointRect)
                }
                let insetWidth = -zoomRect.size.width * 0.1
                let insetHeight = -zoomRect.size.height * 0.1
                self.mapView!.setVisibleMapRect(MKMapRectInset(zoomRect, insetWidth, insetHeight), animated: false)
            } else {
                let span = MKCoordinateSpanMake(0.001, 0.001)
                let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: pointsArray[0].coordinate.latitude, longitude: pointsArray[0].coordinate.longitude), span: span)
                mapView.setRegion(region, animated: false)
            }
        }

        
        if order.statusID == "rejected" {
            self.centerConstraint.constant = -10
            self.rejectedLabel.isHidden = false
            self.rejectedLabel.textColor = colorRedText()
        }
        else {
            self.centerConstraint.constant = 0
            self.rejectedLabel.isHidden = true
        }
        self.costLabel.text = costStringFromDouble(order.cost_order.doubleValue, currency: cur)
        
        
        var setted = false
        
        if order.driver != nil {
            if order.driver?.photo != nil {
                if order.driver?.loadedPhoto != nil {
                    self.driverPhoto.image = UIImage(data: (order.driver?.loadedPhoto)! as Data)
                    setted = true
                }
            }
        }
        
        if order.driver?.photo != nil {
            if setted == false {
                let url = URL(string: (order.driver?.photo!)!)

                self.driverPhoto.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    if image == nil {
                        order.driver?.loadedPhoto = UIImageJPEGRepresentation(UIImage(named: "driver")!, 1.0)
                        self.driverPhoto.image = UIImage(named: "driver")
                    } else {
                        order.driver?.loadedPhoto = UIImageJPEGRepresentation(image!, 1.0)
                    }
                    saveDefaultContext()
                })
            }
        }
        
        
        if self.curOrder?.route == nil {
            getRoute(self.curOrder!, completion: { (ord) in
                self.curOrder = ord
                self.setRoute()
                
                
                }, failure: { 
                    
            })
        }
        else {
            self.setRoute()
        }
        
        
    }
    
    func setRoute() {
        if self.curOrder!.routeCoords != nil {
            if self.curOrder?.route != nil {
                if self.curOrder?.routeEncoded == nil {
                    let route = NSKeyedUnarchiver.unarchiveObject(with: (self.curOrder!.route)! as Data) as! Dictionary<String, AnyObject>
                    var line = [CLLocation]()
                    
                    if route["result"] != nil {
                        if route["result"] is Dictionary<String, AnyObject> {
                            if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] != nil {
                                if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] is [Dictionary<String, AnyObject>] {
                                    for rt in (route["result"] as! Dictionary<String, AnyObject>)["route_data"] as! [Dictionary<String, AnyObject>] {
                                        if rt["status_id"] != nil {
                                            var status = ""
                                            if rt["status_id"] is String {
                                                status = rt["status_id"] as! String
                                            }
                                            else if rt["status_id"] is Int {
                                                status = String(rt["status_id"] as! Int)
                                            }
                                            
                                            if status != "17" && status != "55" {
                                                if rt["lat"] != nil {
                                                    var loc = CLLocationCoordinate2D()
                                                    if rt["lat"] is String {
                                                        loc.latitude = (rt["lat"] as! NSString).doubleValue
                                                    }
                                                    else if rt["lat"] is Double {
                                                        loc.latitude = rt["lat"] as! Double
                                                    }
                                                    if rt["lon"] != nil {
                                                        if rt["lon"] is String {
                                                            loc.longitude = (rt["lon"] as! NSString).doubleValue
                                                        }
                                                        else if rt["lon"] is Double {
                                                            loc.longitude = rt["lon"] as! Double
                                                        }
                                                        let location = CLLocation(latitude: loc.latitude, longitude: loc.longitude)
                                                        line.append(location)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            let line = NSKeyedUnarchiver.unarchiveObject(with: (self.curOrder!.routeCoords)! as Data) as! [CLLocation]
            if line.count > 0 {
                if self.curMap() == 0 || self.curMap() == 2  {
                    self.mapView!.setCenter(line[0].coordinate, animated: false)
                    var coordinates = line.map({(location: CLLocation) -> CLLocationCoordinate2D in return location.coordinate})
                    let mkPoly = MKPolyline(coordinates: &coordinates, count: line.count)
                    self.mapView!.add(mkPoly)
                    self.mapView!.setVisibleMapRect(mkPoly.boundingMapRect, edgePadding: UIEdgeInsetsMake(10,10,10,10), animated: false)
                }
            }
            else {
                getRoute(self.curOrder!, completion: { (ord) in
                    self.curOrder = ord
                    self.setRoute()
                    
                    
                    }, failure: {
                        
                })
            }
            
        }
        else {
            
            let route = NSKeyedUnarchiver.unarchiveObject(with: (self.curOrder!.route)! as Data) as! Dictionary<String, AnyObject>
            var line = [CLLocation]()
            if route["result"] != nil {
                if route["result"] is Dictionary<String, AnyObject> {
                    if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] != nil {
                        if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] is [Dictionary<String, AnyObject>] {
                            for rt in (route["result"] as! Dictionary<String, AnyObject>)["route_data"] as! [Dictionary<String, AnyObject>] {
                                if rt["status_id"] != nil {
                                    var status = ""
                                    if rt["status_id"] is String {
                                        status = rt["status_id"] as! String
                                    }
                                    else if rt["status_id"] is Int {
                                        status = String(rt["status_id"] as! Int)
                                    }
                                    
                                    if status != "17" && status != "55" {
                                        if rt["lat"] != nil {
                                            var loc = CLLocationCoordinate2D()
                                            if rt["lat"] is String {
                                                loc.latitude = (rt["lat"] as! NSString).doubleValue
                                            }
                                            else if rt["lat"] is Double {
                                                loc.latitude = rt["lat"] as! Double
                                            }
                                            if rt["lon"] != nil {
                                                if rt["lon"] is String {
                                                    loc.longitude = (rt["lon"] as! NSString).doubleValue
                                                }
                                                else if rt["lon"] is Double {
                                                    loc.longitude = rt["lon"] as! Double
                                                }
                                                let location = CLLocation(latitude: loc.latitude, longitude: loc.longitude)
                                                line.append(location)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            if line.count > 0 {
                if self.curMap() == 0 || self.curMap() == 2  {
                    var coordinates = line.map({(location: CLLocation) -> CLLocationCoordinate2D in return location.coordinate})
                    let mkPoly = MKPolyline(coordinates: &coordinates, count: line.count)
                    self.curOrder?.routeCoords = NSKeyedArchiver.archivedData(withRootObject: line)
                    saveDefaultContext()
                    self.mapView!.add(mkPoly)
                    self.mapView!.setVisibleMapRect(mkPoly.boundingMapRect, edgePadding: UIEdgeInsetsMake(10,10,10,10), animated: false)
                }
            }
            else {
                if self.quered == false {
                    self.quered = true
                    getRoute(self.curOrder!, completion: { (ord) in
                        self.curOrder = ord
                        self.setRoute()
                        
                        
                        }, failure: {
                            
                    })
                }
            }
        }
        
    }
    
    func setTime() {
        let ord = self.curOrder!
        let startDate = Date()
        var strDate = ""
        if ord.carDateTime != nil {
            let calendar = Calendar.current
            let components = (calendar as NSCalendar).components([.day, .hour, .minute], from: startDate,
                                                 to: getFakeOrderDate(ord.carDateTime!), options: [])
            if components.day! > 0 {
                strDate = "\(String(describing: components.day!)) \(strTimeD())."
            }
            if components.hour! > 0 {
                if strDate == "" {
                    strDate = "\(String(describing: components.hour!)) \(strTimeH())."
                }
                else {
                    strDate = "\(strDate) \(String(describing: components.hour!)) \(strTimeH())."
                }
            }
            if components.minute! > 0 {
                if strDate == "" {
                    strDate = "\(String(describing: components.minute!)) \(strTimeM())."
                }
                else {
                    strDate = "\(strDate) \(String(describing: components.minute!)) \(strTimeM())."
                }
            }
            self.preOrderTimeLabel.text = strDate
        }
        else {
            self.preOrderTimeLabel.text = ""
        }
    }


    
    
    
//    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
//        if overlay is MKPolyline {
//            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
//            polylineRenderer.strokeColor = UIColor.blueColor()
//            polylineRenderer.lineWidth = 3
//            return polylineRenderer
//        }
//        return MKTileOverlayRenderer(overlay: overlay)
//    }

    
    func localize() {
        self.rejectedLabel.text = strComOrderRejected()
        self.preOrderTimeTitle.text = strComToOrder()
    }
    
    func colorize() {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
    }
    
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
    
    
    
}
