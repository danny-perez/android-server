//
//  ProfileLastNameTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ProfileLastNameTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var lastNameField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileLastNameTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.lastNameLabel.textColor = colorMainText()
        self.lastNameField.textColor = colorMainFieldText()
        self.backView.backgroundColor = colorMain()
        self.applyCurvedShadow(self.backView)
    }
    
    func localize()
    {
        if layoutDirection == .rightToLeft {
            self.lastNameField.textAlignment = .left
        } else {
            self.lastNameField.textAlignment = .right
        }
        self.lastNameLabel.text = strComLastName()
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
}
