//
//  ProfileLogoutTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 28.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class ProfileLogoutTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var logoutTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileLogoutTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.backView.backgroundColor = colorMain()
        self.logoutTitle.textColor = colorMainText()
        self.applyCurvedShadow(self.backView)
    }
    
    func localize()
    {
        self.logoutTitle.text = strComLogout()
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
}
