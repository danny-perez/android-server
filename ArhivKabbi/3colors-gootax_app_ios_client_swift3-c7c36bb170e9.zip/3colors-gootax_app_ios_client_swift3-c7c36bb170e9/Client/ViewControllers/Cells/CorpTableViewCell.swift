//
//  CorpTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 02.10.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class CorpTableViewCell: UITableViewCell {

    @IBOutlet weak var corpTitle: UILabel!
    @IBOutlet weak var corpField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        colorize()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // если выбрали - сделать поле для редактирования адреса
        if selected {
            self.corpField.becomeFirstResponder()
        }
        
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.corpTitle.textColor = colorMainText()
        self.corpField.textColor = colorMainFieldText()
    }
    
    func localize()
    {
        self.corpTitle.text = strComCorp()
    }

}
