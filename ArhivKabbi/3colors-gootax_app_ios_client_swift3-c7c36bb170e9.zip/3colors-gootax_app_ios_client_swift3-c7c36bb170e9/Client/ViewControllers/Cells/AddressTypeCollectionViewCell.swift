//
//  AddressTypeCollectionViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 02.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AddressTypeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeLogo: UIImageView!
    
}
