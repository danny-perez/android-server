//
//  AddressesTypesTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 02.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AddressesTypesTableViewCell: UITableViewCell {

    @IBOutlet weak var addressesTypesCollectionView: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
