//
//  AuthSMSInfoTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthSMSInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var smsInfoLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AuthSMSInfoTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func localize()
    {
        self.smsInfoLabel.text = strInfoAboutSMS()
    }
    
    func colorize()
    {
//        self.backgroundColor = colorGrayBackground()
//        self.contentView.backgroundColor = colorGrayBackground()
        self.smsInfoLabel.textColor = colorGrayLabelText()
    }
    
}
