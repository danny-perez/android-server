//
//  PayOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 18.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PayOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var payLogo: UIImageView!
    @IBOutlet weak var payTitle: UILabel!
    @IBOutlet weak var payCost: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setOrder(_ ord: Order) {
        if ord.payType != nil {
            switch ord.payType! {
            case "CASH" :
                self.payLogo.image = UIImage(named: "cash")
                self.payTitle.text = strPayCash()
            case "PERSONAL_ACCOUNT" :
                self.payLogo.image = UIImage(named: "pers")
                self.payTitle.text = strPayPersBal()
            case "CORP_BALANCE" :
                self.payLogo.image = UIImage(named: "comp")
                self.payTitle.text = ord.cardNum
            case "CARD" :
                self.payLogo.image = UIImage(named: "visa")
                self.payTitle.text = ord.cardNum
            default :
                self.payLogo.image = UIImage(named: "cash")
                self.payTitle.text = strPayCash()
            }
        }
        else {
            self.payLogo.image = UIImage(named: "cash")
            self.payTitle.text = strPayCash()
        }
        self.payCost.text = costStringFromDouble(ord.cost_order.doubleValue, currency: ord.currency)
    }

}
