//
//  ProfileUploadPhotoTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import Kingfisher

class ProfileUploadPhotoTableViewCell: UITableViewCell {

    @IBOutlet weak var photoView: UIImageView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var uploadPhotoTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileUploadPhotoTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.uploadPhotoTitle.textColor = colorNewTint()
        self.backView.backgroundColor = colorMain()
        self.applyCurvedShadow(self.backView)
    }
    
    func setProfile(_ profile : Profile) {
        
        if profile.photo != nil {
            let url = URL(string: profile.photo!)
            
            self.photoView.kf.setImage(with: url, completionHandler: {
                (image, error, cacheType, imageUrl) in
                if image == nil {
                    self.photoView.image = UIImage(named: "driver")
                }
            })
            
        }
    }
    
    func localize()
    {
        self.uploadPhotoTitle.text = strComUploadPhoto()
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
}
