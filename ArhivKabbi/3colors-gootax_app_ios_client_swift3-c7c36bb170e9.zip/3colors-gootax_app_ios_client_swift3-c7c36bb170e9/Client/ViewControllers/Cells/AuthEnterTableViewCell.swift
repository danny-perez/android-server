//
//  AuthEnterTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthEnterTableViewCell: UITableViewCell {

    @IBOutlet weak var enterButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AuthEnterTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
//        self.backgroundColor = colorGrayBackground()
//        self.contentView.backgroundColor = colorGrayBackground()
        self.enterButton.setColors()
    }
    
    func localize()
    {
        self.enterButton.setTitle(strAuthEnter(), for: UIControlState())
        self.enterButton.layer.cornerRadius = 4;
    }

}
