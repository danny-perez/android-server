
//  ReferralCodeTableViewCell.swift
//  Client
//
//  Created by  Andrew on 20.04.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class ReferralCodeTableViewCell: UITableViewCell {

    @IBOutlet weak var codeLabel: UILabel!
    @IBOutlet weak var copyButton: UIButton!
    
    @IBOutlet weak var codeView: UIView!

    @IBAction func onCopyCode(_ sender: AnyObject) {
        UIPasteboard.general.string = codeLabel.text
        showMessage(strRefCopyBuffer(), message: "")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        applyCurvedShadow(codeView)
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
    func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }

}
