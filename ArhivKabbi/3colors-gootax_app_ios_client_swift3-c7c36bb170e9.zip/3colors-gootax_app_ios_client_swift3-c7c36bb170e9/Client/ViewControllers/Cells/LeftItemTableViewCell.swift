//
//  LeftItemTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 25.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LeftItemTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var width: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        width.constant = UIScreen.main.bounds.width - centerPanelExpandedOffset - 30
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftItemTableViewCell.colorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

    func colorize() {
        self.backgroundColor = colorNewHamBack()
        self.contentView.backgroundColor = colorNewHamBack()
        self.label.textColor = colorNewHamText()
        self.selectionStyle = .blue;
        let backView = UIView()
        backView.backgroundColor = colorNewHamSelectedBack()
        self.selectedBackgroundView = backView
    }
    
    
}
