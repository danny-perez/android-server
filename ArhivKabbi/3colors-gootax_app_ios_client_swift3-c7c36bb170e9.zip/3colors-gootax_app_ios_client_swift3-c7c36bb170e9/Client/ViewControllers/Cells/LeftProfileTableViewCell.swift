//
//  LeftProfileTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 25.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import Kingfisher

class LeftProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var labelSize: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftProfileTableViewCell.colorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        localize()
        self.labelSize.constant = UIScreen.main.bounds.width - centerPanelExpandedOffset - 90
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        photo.layer.cornerRadius = photo.frame.size.width / 2
        photo.clipsToBounds = true
    }
    
    func setProfile(_ profile : Profile) {
        self.name.text = profile.fullName()
        if profile.photo != nil {
            print("photoParse0 \(String(describing: profile.photo))")
            let url = URL(string: profile.photo!)
            self.photo.kf.setImage(with: url, completionHandler: {
                (image, error, cacheType, imageUrl) in
                if image == nil {
                    self.photo.image = UIImage(named: "photoPlaceholder")
                }
            })
        } else {
            self.photo.image = UIImage(named: "photoPlaceholder")
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func colorize() {
        self.name.textColor = colorNewHamText()
        self.selectionStyle = .blue;
        self.backView.backgroundColor = colorNewHamBack().withAlphaComponent(0.9)
    }
    
    func localize() {
        
    }

}
