//
//  BackOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 29.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class BackOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var backLogo: UIImageView!
    @IBOutlet weak var backLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(BackOrderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize() {
        self.backgroundColor = colorMain()
        self.backgroundView?.backgroundColor = colorMain()
        self.backLabel.textColor = colorMainText()
    }
    
    func localize() {
        self.backLabel.text = strComReverse()
    }
}
