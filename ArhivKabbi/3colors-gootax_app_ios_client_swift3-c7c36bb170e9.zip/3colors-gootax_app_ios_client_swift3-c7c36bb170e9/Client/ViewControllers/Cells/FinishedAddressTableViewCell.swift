//
//  FinishedAddressTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 25.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class FinishedAddressTableViewCell: UITableViewCell {

    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var addressLogo: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
//    @IBOutlet weak var botView: UIView!
//    @IBOutlet weak var topView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
 
    
    func colorize() {
//        self.backgroundColor = UIColor.clearColor()
//        self.contentView.backgroundColor = UIColor.clearColor()
//        self.addressLabel.textColor = colorMain()
//        self.botView.backgroundColor = colorGrayLabelText()
//        self.topView.backgroundColor = colorGrayLabelText()
    }
    
}
