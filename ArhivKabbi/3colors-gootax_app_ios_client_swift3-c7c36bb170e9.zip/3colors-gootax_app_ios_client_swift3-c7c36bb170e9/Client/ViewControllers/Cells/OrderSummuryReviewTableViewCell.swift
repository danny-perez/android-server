//
//  OrderSummuryReviewTableViewCell.swift
//  Client
//
//  Created by  Andrew on 11/01/2018.
//  Copyright © 2018 Gootax. All rights reserved.
//

import UIKit

class OrderSummuryReviewTableViewCell: UITableViewCell {

    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var starsView: UIView!
    @IBOutlet weak var star3: UIButton!
    @IBOutlet weak var star2: UIButton!
    @IBOutlet weak var star1: UIButton!
    @IBOutlet weak var star4: UIButton!
    @IBOutlet weak var star5: UIButton!
    var currentValue: Double = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        localize()
        self.setStar(currentValue)
        // Configure the view for the selected state
    }

    
    @IBAction func newRate(_ sender: UIButton) {
        self.setStar(Double(sender.tag))
    }
    
    
    func setStar(_ val: Double) {
        if val > 0 {
            self.star1.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star1.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 1 {
            self.star2.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star2.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 2 {
            self.star3.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star3.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 3 {
            self.star4.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star4.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        if val > 4 {
            self.star5.setImage(UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint()), for: UIControlState())
        }
        else {
            self.star5.setImage(UIImage(named: imageRateBigStroke()), for: UIControlState())
        }
        self.currentValue = val
    }

    func localize() {
        self.titleLabel.text = strRateSet().uppercased()
    }
    
}
