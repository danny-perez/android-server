//
//  CallRejectTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 12.05.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class CallRejectTableViewCell: UITableViewCell {

    @IBOutlet weak var rejectLabel: UILabel!
    @IBOutlet weak var callLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ReorderTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func localize() {
        self.rejectLabel.text = strComRejectOrder()
        self.callLabel.text = strComDoCall()
    }

}
