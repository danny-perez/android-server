//
//  OrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class OrderTableViewCell: UITableViewCell, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var driverName: UILabel!
    @IBOutlet weak var carModel: UILabel!
    @IBOutlet weak var carNomer: UILabel!
    @IBOutlet weak var driverPhoto: UIImageView!
    @IBOutlet weak var driverRating: UIView!
    @IBOutlet weak var ratingStar: UIImageView!
    @IBOutlet weak var ratingValue: UILabel!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var backViewHeight: NSLayoutConstraint!
    var ord : Order?
    override func awakeFromNib() {
        super.awakeFromNib()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.colorize()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setOrder(_ order : Order) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy, HH:mm"
        self.timeLabel.text = dateFormatter.string(from: order.createDateTime as Date)
        self.ord = order
        self.tableView.reloadData()
        self.tableViewHeight.constant = self.tableView.contentSize.height
        self.contentView.setNeedsLayout()
        var addHeight : Double = 10
        if order.driver == nil {
            self.driverName.isHidden = true
            self.carModel.isHidden = true
            self.driverPhoto.isHidden = true
            self.carNomer.isHidden = true
            self.driverRating.isHidden = true
        }
        else {
            self.driverName.isHidden = false
            self.carModel.isHidden = false
            self.driverPhoto.isHidden = false
            self.carNomer.isHidden = false
            self.driverRating.isHidden = true
            self.driverName.text = order.driver?.name
            self.carModel.text = order.driver?.carModel.uppercased()
            self.carNomer.text = order.driver?.carNum.uppercased()
            if order.driver != nil {
                if order.driver?.photo != nil {
                    let imageData : Data? = Data(base64Encoded: (order.driver?.photo)!, options: NSData.Base64DecodingOptions(rawValue: 0))
                    if imageData != nil {
                        let image = UIImage(data: imageData!)
                        self.driverPhoto.image = image
                        self.driverPhoto.isHidden = false
                    }
                }
            }
            
            self.contentView.setNeedsLayout()
            addHeight += 10
            addHeight += Double(self.driverName.frame.height)
            addHeight += 24
            if self.carModel.frame.height > self.carNomer.frame.height {
                addHeight += Double(self.carModel.frame.height)
            }
            else {
                addHeight += Double(self.carNomer.frame.height)
            }
        }
        
        self.statusLabel.text = order.statusLabel
        
        if getStatus(order) != .rejected {
            self.statusLabel.textColor = colorGreenText()
        }
        else {
            self.statusLabel.textColor = colorRedText()
        }
        
        self.backViewHeight.constant = CGFloat(40 + Double(self.tableViewHeight.constant) + addHeight)
    }
    
    
    func getStatus(_ ord : Order) -> OrderStatus {
        switch (ord.statusID) {
        case "new", "New" :
            return .new
        case "car_assigned", "carAssigned" :
            return .carAssigned
        case "car_at_place" :
            return .carAtPlace
        case "rejected" :
            return .rejected
        case "executing" :
            return .executing
        case "completed" :
            return .completed
        default :
            return .new
        }
    }
    
    func hightlight() {
        UIView.animate(withDuration: 0.2, animations: { () -> Void in
            self.backView.backgroundColor = colorGrayBackground()
            }, completion: { (finished) -> Void in
                
        }) 
    }
    
    func unhighlight() {
        UIView.animate(withDuration: 0.2, animations: { () -> Void in
            self.backView.backgroundColor = colorMain()
        }) 
    }
    
    //MARK: -UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.numOfPoints()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : PathListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "path", for: indexPath) as! PathListTableViewCell
        
        if indexPath.row == 0 {
            cell.topView.isHidden = true
            cell.addressLogo.image = UIImage(named: imageListA())
            if self.numOfPoints() == 1 {
                cell.botView.isHidden = true
            }
            else {
                cell.botView.isHidden = false
            }
            cell.addressLabel.text = (self.ord?.pointA)!.strFromAddress()
        }
        else if indexPath.row == 1 {
            if self.numOfPoints() == 2 {
                cell.botView.isHidden = true
            }
            else {
                cell.botView.isHidden = false
            }
            cell.addressLogo.image = UIImage(named: imageListB())
            cell.topView.isHidden = false
            cell.addressLabel.text = (self.ord?.pointB)!.strFromAddress()
        }
        else if indexPath.row == 2 {
            if self.numOfPoints() == 3 {
                cell.botView.isHidden = true
            }
            else {
                cell.botView.isHidden = false
            }
            cell.addressLogo.image = UIImage(named: imageListC())
            cell.topView.isHidden = false
            cell.addressLabel.text = (self.ord?.pointC)!.strFromAddress()
        }
        else if indexPath.row == 3 {
            if self.numOfPoints() == 4 {
                cell.botView.isHidden = true
            }
            else {
                cell.botView.isHidden = false
            }
            cell.addressLogo.image = UIImage(named: imageListD())
            cell.topView.isHidden = false
            cell.addressLabel.text = (self.ord?.pointD)!.strFromAddress()
        }
        else if indexPath.row == 4 {
            cell.topView.isHidden = false
            cell.addressLogo.image = UIImage(named: imageListE())
            cell.botView.isHidden = true
            cell.addressLabel.text = (self.ord?.pointE)!.strFromAddress()
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return heightForView((self.ord?.pointA)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8
        }
        else if indexPath.row == 1 {
            return heightForView((self.ord?.pointB)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8
        }
        else if indexPath.row == 2 {
            return heightForView((self.ord?.pointC)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8
        }
        else if indexPath.row == 3 {
            return heightForView((self.ord?.pointD)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8
        }
        else if indexPath.row == 4 {
            return heightForView((self.ord?.pointE)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8
        }
        return 0
    }
    
    
    func numOfPoints() -> Int {
        if self.ord != nil {
            var i = 0
            if self.ord?.pointA != nil {
                if self.ord?.pointA?.street != nil {
                    if self.ord?.pointA?.street != "" {
                        i += 1
                    }
                }
                if self.ord?.pointB != nil {
                    if self.ord?.pointB?.street != nil {
                        if self.ord?.pointB?.street != "" {
                            i += 1
                        }
                    }
                    if self.ord?.pointC != nil {
                        if self.ord?.pointC?.street != nil {
                            if self.ord?.pointC?.street != "" {
                                i += 1
                            }
                        }
                        if self.ord?.pointD != nil {
                            if self.ord?.pointD?.street != nil {
                                if self.ord?.pointD?.street != "" {
                                    i += 1
                                }
                            }
                            if self.ord?.pointE != nil {
                                if self.ord?.pointE?.street != nil {
                                    if self.ord?.pointE?.street != "" {
                                        i += 1
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return i
        }
        return 0
    }
    
    
    func colorize() {
        self.contentView.backgroundColor = colorGrayBackground()
        self.backgroundColor = colorGrayBackground()
        self.backView.backgroundColor = colorMain()
        self.timeLabel.textColor = colorMainText()
        self.tableView.backgroundColor = UIColor.clear
        self.driverName.textColor = colorMainText()
        self.carModel.textColor = colorMainText()
        self.carNomer.textColor = colorMainText()
        self.ratingValue.textColor = colorMainText()
        
        self.backView.layer.cornerRadius = 6
        self.backView.layer.masksToBounds = true
        self.backView.layer.borderWidth = 1
        self.backView.layer.borderColor = colorGrayLabelText().cgColor
        
        self.driverPhoto.layer.cornerRadius = 40
        self.driverPhoto.layer.masksToBounds = true
        self.driverPhoto.layer.borderWidth = 1
        self.driverPhoto.layer.borderColor = colorHighlightedColCell().cgColor
        
        self.driverRating.backgroundColor = colorMain()
        self.driverRating.layer.cornerRadius = 4
        self.driverRating.layer.borderWidth = 1
        self.driverRating.layer.borderColor = colorHighlightedColCell().cgColor
    }
    
    
}
