//
//  AuthPhoneTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthPhoneTableViewCell: UITableViewCell {
    
    @IBOutlet weak var phoneTitle: UILabel!
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var phoneField: AKMaskField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AuthPhoneTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        self.backView.backgroundColor = colorMain()
    }
    
    func colorize()
    {
        self.phoneTitle.textColor = colorMainText()
        self.phoneField.textColor = colorMainFieldText()
        self.backView.layer.shouldRasterize = true
        self.backView.layer.rasterizationScale = UIScreen.main.scale
        self.backView.layer.shadowRadius = 1;
        self.backView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backView.layer.masksToBounds = false
        self.backView.layer.shadowOpacity = 0.3;
    }
    
    func localize()
    {
        if layoutDirection == .rightToLeft {
            self.phoneField.textAlignment = .left
        } else {
            self.phoneField.textAlignment = .right
        }
        self.phoneTitle.text = strComPhoneTitle()
    }

}
