//
//  LanguageTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LanguageTableViewCell: UITableViewCell {

    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var lanTitle: UILabel!
    @IBOutlet weak var lanChecked: UIImageView!
    @IBOutlet weak var botSpace: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.lanTitle.textColor = colorMainText()
        self.tintColor = colorNewTint()
        self.applyCurvedShadow(self.backView)
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
}
