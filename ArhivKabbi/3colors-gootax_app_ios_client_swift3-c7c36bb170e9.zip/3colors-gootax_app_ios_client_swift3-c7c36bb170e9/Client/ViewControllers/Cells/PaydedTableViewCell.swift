//
//  PaydedTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 18.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PaydedTableViewCell: UITableViewCell {

    @IBOutlet weak var paydedTitle: UILabel!
    var payded : Bool?
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(PaydedTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
//        self.contentView.backgroundColor = colorGrayBackground()
//        self.backgroundColor = colorGrayBackground()
        self.paydedTitle.textColor = colorGrayLabelText()
    }
    
    func localize()
    {
        if self.payded != false {
            self.paydedTitle.text = strComPayded().uppercased()
        }
        else {
            self.paydedTitle.text = strComNotPayded().uppercased()
        }
    }


}
