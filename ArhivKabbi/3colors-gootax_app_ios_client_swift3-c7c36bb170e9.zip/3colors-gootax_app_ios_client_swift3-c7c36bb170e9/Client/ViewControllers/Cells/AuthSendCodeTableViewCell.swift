//
//  AuthSendCodeTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthSendCodeTableViewCell: UITableViewCell {

    @IBOutlet weak var sendButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AuthSendCodeTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    
    func colorize()
    {
        self.sendButton.setColors()
    }
    
    func localize()
    {

        self.sendButton.setTitle(strAuthSendCode(), for: UIControlState())
        self.sendButton.layer.cornerRadius = 4;
    }
    
    
    
    
}
