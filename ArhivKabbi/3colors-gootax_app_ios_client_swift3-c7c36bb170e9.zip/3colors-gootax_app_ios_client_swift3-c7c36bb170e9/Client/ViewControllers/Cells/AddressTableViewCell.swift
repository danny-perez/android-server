//
//  AddressTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 03.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AddressTableViewCell: UITableViewCell {
    
    @IBOutlet weak var addressLogo: UIImageView!
    @IBOutlet weak var addressCity: UILabel!
    @IBOutlet weak var addressStreet: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func colorize()
    {
        if self.addressCity != nil {
            self.addressCity.textColor = colorGrayLabelText()
        }
        self.addressStreet.textColor = colorMainText()
    }
    
    
    
}
