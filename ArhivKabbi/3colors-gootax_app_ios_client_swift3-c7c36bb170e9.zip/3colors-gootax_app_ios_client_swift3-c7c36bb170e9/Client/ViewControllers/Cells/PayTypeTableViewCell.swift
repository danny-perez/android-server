//
//  PayTypeTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PayTypeTableViewCell: UITableViewCell {

    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var botSpace: NSLayoutConstraint!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var payTypeLabel: UILabel!
    @IBOutlet weak var payTypeNoteLabel: UILabel!
    @IBOutlet weak var payTypeLogo: UIImageView!
    @IBOutlet weak var payTypeOk: UIImageView!
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    @IBOutlet weak var top2Constraint: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.tintColor = colorNewTint()
        self.applyCurvedShadow(self.backView)
    }
    
    
    func applyCurvedShadow(_ view: UIView) {
        let layer = self.backView.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }

}
