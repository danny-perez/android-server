//
//  LeftAboutTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 25.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LeftAboutTableViewCell: UITableViewCell {

    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var aboutLabel: UILabel!
    @IBOutlet weak var labelWidth: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.labelWidth.constant = UIScreen.main.bounds.width - centerPanelExpandedOffset - 30
        localize()
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftAboutTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LeftAboutTableViewCell.colorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    func colorize() {
        self.backgroundColor = colorNewHamBack()
        self.contentView.backgroundColor = colorNewHamBack()
        self.aboutLabel.textColor = colorNewHamText()
        self.aboutLabel.alpha = 0.8
        self.selectionStyle = .blue;
        let backView = UIView()
        backView.backgroundColor = colorNewHamSelectedBack()
        self.selectedBackgroundView = backView
    }
    
    func localize() {
        if aboutLabel.text != webScreenTitle {
            self.aboutLabel.text = strLeftAbout()
        }
    }

}
