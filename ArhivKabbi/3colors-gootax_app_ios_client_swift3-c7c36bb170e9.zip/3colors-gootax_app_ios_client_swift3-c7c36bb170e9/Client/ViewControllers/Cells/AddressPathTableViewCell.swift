//
//  AddressPathTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 17.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class AddressPathTableViewCell: UITableViewCell {

    @IBOutlet weak var pathImage: UIImageView!
    @IBOutlet weak var pathStreet: UILabel!
    @IBOutlet weak var pathCity: UILabel!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var addPathButton: UIButton!
    @IBOutlet weak var topSpace: NSLayoutConstraint!
    @IBOutlet weak var deletePathButton: UIButton!
    
    
    @IBOutlet weak var porchLabel: UILabel!
    @IBOutlet weak var viewPorchLabelContainer: UIView!
    @IBOutlet weak var viewPorchContainer: UIView!
    
    
    var pointPath: String?
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let porchContainerLayer = viewPorchLabelContainer.layer
        porchContainerLayer.borderWidth = 1
        porchContainerLayer.borderColor = UIColor.gray.cgColor
        // Initialization code
    }

    @IBOutlet weak var topView: UIView!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        if self.pathCity.text == strNotePickSecondAddr(){
            self.deletePathButton.isHidden = true
            self.viewPorchLabelContainer.isHidden = true
        }
        else {
            self.deletePathButton.isHidden = self.pointPath == "a"
            self.viewPorchLabelContainer.isHidden = !(self.pointPath == "a")
        }

        // Configure the view for the selected state
    }
    
    func setAddress(_ addr : AddressTemp, inCity : Bool) {
        if inCity == true {
            if addr.city != nil {
                self.pathCity.text = addr.city
            } else {
                self.pathCity.text = ""
            }
            self.pathStreet.text = addr.shortStrFromTempAddress()
            if addr.shortStrFromTempAddress() == strComNoAddrs() {
                self.deletePathButton.isHidden = true
            }
            
            if self.pointPath == "a" {
                
                if !needPorch {
                    self.viewPorchContainer.isHidden = true
                } else {
                    self.viewPorchContainer.isHidden = false
                }
                
                if pathStreet.text == strComLoading() {
                    self.viewPorchContainer.isHidden = true
                    self.pathCity.text = ""
                } else if pathStreet.text == strComOrdByCoords() {
                    porchLabel.text = strComPickAddress()
                } else if let porch = addr.porch, !porch.isEmpty {
                    porchLabel.text = strComPorchNumber() + porch
                } else {
                    porchLabel.text = strComPickPorch()
                }
            } else {
                self.viewPorchContainer.isHidden = true
            }
            
            self.pathStreet.textColor = colorMainText()
        } else {
            self.viewPorchContainer.isHidden = true
            self.addPathButton?.isHidden = true
            self.pathCity.text = ""
            if addr.city == "" {
                addr.city = strComThisRegion()
            }
            self.pathStreet.text = "\((addr.city)!) \(strComNotSupported())"
            self.pathStreet.textColor = colorRedText()
        }
        self.backView.layoutIfNeeded()
    }

    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
    
}
