//
//  LeftSignTableViewCell.swift
//  Client
//
//  Created by  Andrew on 17.05.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class LeftSignTableViewCell: UITableViewCell {

    @IBOutlet weak var signInfoConstraint: NSLayoutConstraint!
    @IBOutlet weak var signInfo: UILabel!
    @IBOutlet weak var signUp: UIButton!
    
    
    var listener: () -> Void = { }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftSignTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LeftSignTableViewCell.colorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }


    @IBAction func singUpAction(_ sender: AnyObject) {
        listener()
    }
    
    func localize() {
        self.signUp.setTitle(strLeftRegister(), for: UIControlState())
        self.signUp.layer.cornerRadius = 4
        self.signUp.clipsToBounds = true
        self.signInfo.text = strLeftInfo()
    }
    
    func colorize() {
        signUp.setColors()
    }
}
