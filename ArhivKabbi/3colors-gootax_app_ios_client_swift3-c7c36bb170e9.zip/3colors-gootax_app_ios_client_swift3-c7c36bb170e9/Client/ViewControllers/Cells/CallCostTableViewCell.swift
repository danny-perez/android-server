//
//  CallCostTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 12.05.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class CallCostTableViewCell: UITableViewCell {

    @IBOutlet weak var callCostLabel: UILabel!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    /*func doCallCost(order : OrderTemp) {
        callCostForOrder(order) { (ccost) in
            if ccost.isFixed == true {
                self.callCostLabel.text = "\(strCCostFixPrice()) \(costStringFromDouble(ccost.cost!))"
            }
            else {
                self.callCostLabel.text = "~ \(costStringFromDouble(ccost.cost!)), \(String(format: "%.1f", ccost.distance!)) \(strCCostKm()), \(String(format: "%.0f", ccost.time!)) \(strCCostMin())"
            }
            self.callCostLabel.hidden = false
            self.loadingIndicator.hidden = true
        }
    }*/

}
