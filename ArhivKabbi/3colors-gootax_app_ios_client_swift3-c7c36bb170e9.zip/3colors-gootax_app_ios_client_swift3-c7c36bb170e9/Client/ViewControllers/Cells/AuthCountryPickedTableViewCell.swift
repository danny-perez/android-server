//
//  AuthCountryPickedTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 26.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthCountryPickedTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var countryLabel: UILabel!
    override func awakeFromNib() {
        
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(AuthCountryPickedTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
//        self.contentView.backgroundColor = colorMain()
//        self.backgroundColor = colorMain()
//        self.countryTitle.textColor = colorMainText()
        self.countryLabel.textColor = colorMainText()
        self.countryLabel.textAlignment = .natural
        self.backView.layer.shouldRasterize = true
        self.backView.layer.rasterizationScale = UIScreen.main.scale
        self.backView.layer.shadowRadius = 1;
        self.backView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backView.layer.masksToBounds = false
        self.backView.layer.shadowOpacity = 0.3;
    }
    
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        
        UIView.animate(withDuration: 0.2, animations: { () -> Void in
            if highlighted {
                self.backView.backgroundColor = colorHighlightedColCell()
            }
            else {
                self.backView.backgroundColor = colorMain()
            }
        }) 
    }
    
    
    
    func localize()
    {
//        self.countryTitle.text = strComCountry()
        self.countryLabel.text = strSelectedCountry()
    }

}
