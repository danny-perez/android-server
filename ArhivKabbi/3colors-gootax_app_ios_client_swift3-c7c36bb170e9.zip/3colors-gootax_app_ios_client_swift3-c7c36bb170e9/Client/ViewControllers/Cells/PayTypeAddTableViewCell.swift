//
//  PayTypeAddTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PayTypeAddTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var disclIndicator: UIImageView!
    @IBOutlet weak var payAddLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(PayTypeAddTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.tintColor = colorNewTint()
        self.applyCurvedShadow(self.backView)
    }
    
    func localize() {
        self.payAddLabel.text = strPayAddCard()
    }
    
    func applyCurvedShadow(_ view: UIView) {
        let layer = self.backView.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }

}
