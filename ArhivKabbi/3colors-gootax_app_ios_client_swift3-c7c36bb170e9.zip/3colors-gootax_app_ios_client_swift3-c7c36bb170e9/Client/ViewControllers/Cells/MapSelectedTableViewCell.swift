//
//  MapSelectedTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class MapSelectedTableViewCell: UITableViewCell {

    @IBOutlet weak var mapSelectedTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = colorMain()
        self.backgroundColor = colorMain()
        self.mapSelectedTitle.textColor = colorMainText()
    }

}
