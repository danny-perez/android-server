//
//  OrdMarkTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class OrdMarkTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        localize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setStar(_ val: Double) {
        if val > 0 {
            self.star1.image = UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint())
        }
        else {
            self.star1.image = UIImage(named: imageRateBigStroke())
        }
        if val > 1 {
            self.star2.image = UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint())
        }
        else {
            self.star2.image = UIImage(named: imageRateBigStroke())
        }
        if val > 2 {
            self.star3.image = UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint())
        }
        else {
            self.star3.image = UIImage(named: imageRateBigStroke())
        }
        if val > 3 {
            self.star4.image = UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint())
        }
        else {
            self.star4.image = UIImage(named: imageRateBigStroke())
        }
        if val > 4 {
            self.star5.image = UIImage(named: imageRateBigFill())?.imageWithColorz(colorNewTint())
        }
        else {
            self.star5.image = UIImage(named: imageRateBigStroke())
        }
    }

    
    func localize() {
        self.titleLabel.text = strRateSet().uppercased()
    }
}
