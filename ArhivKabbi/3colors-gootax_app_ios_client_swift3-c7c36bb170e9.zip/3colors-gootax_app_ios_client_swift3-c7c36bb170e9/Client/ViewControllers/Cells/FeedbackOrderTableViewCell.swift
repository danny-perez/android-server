//
//  FeedBackOrderTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 28.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class FeedbackOrderTableViewCell: UITableViewCell {

    @IBOutlet weak var leftStarImage: UIImageView!
    @IBOutlet weak var feedLabel: UILabel!
    @IBOutlet weak var starsView: UIView!
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    @IBOutlet weak var rightSpace: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setOrder(_ ord : Order) {
        var rated = false
        if ord.rate != nil {
            if ord.rate != NSNumber(value: 0 as Double) {
                rated = true
                self.feedLabel.text = strRateYour()
                self.rightSpace.constant = 130
                self.starsView.isHidden = false
                self.star1.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
                if ord.rate?.doubleValue > 1 {
                    self.star2.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
                }
                else {
                    self.star2.image = UIImage(named: imageRateSmallStroke())
                }
                if ord.rate?.doubleValue > 2 {
                    self.star3.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
                }
                else {
                    self.star3.image = UIImage(named: imageRateSmallStroke())
                }
                if ord.rate?.doubleValue > 3 {
                    self.star4.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
                }
                else {
                    self.star4.image = UIImage(named: imageRateSmallStroke())
                }
                if ord.rate?.doubleValue > 4 {
                    self.star5.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
                }
                else {
                    self.star5.image = UIImage(named: imageRateSmallStroke())
                }
            }
        }
        if !rated {
            self.feedLabel.text = ord.statusID == "Rejected" ? strWriteFeedback() : strRateSet()
            self.rightSpace.constant = 15
            self.starsView.isHidden = true
        }
    }
}
