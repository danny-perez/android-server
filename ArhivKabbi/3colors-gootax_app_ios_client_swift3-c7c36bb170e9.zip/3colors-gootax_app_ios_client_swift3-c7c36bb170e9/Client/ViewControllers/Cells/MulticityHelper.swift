//
//  MulticityHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 18.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

open class PolygonPoint : NSObject, NSCoding {
    var lat : Double?
    var lon : Double?
    override init() {
        lat = 0
        lon = 0
    }
    required convenience public init(coder decoder: NSCoder) {
        self.init()
        self.lat = decoder.decodeObject(forKey: "lat") as? Double
        self.lon = decoder.decodeObject(forKey: "lon") as? Double
    }
    open func encode(with coder: NSCoder) {
        coder.encode(self.lon, forKey: "lon")
        coder.encode(self.lat, forKey: "lat")
    }
}

open class City : NSObject, NSCoding {
    var cityName : String?
    var cityID : String?
    var dispTel : String?
    var currency : String?
    var centerCoord : CLLocation?
    var stations : [AddressTemp]?
    var airports : [AddressTemp]?
    var tariffs : [Tariff]?
    var polygon : [PolygonPoint]?
    var lat : Double?
    var lon : Double?
    
    override init () {
        cityName = ""
        cityID = ""
        dispTel = ""
        currency = defCurrency
        centerCoord = CLLocation()
        stations = [AddressTemp]()
        airports = [AddressTemp]()
        polygon = [PolygonPoint]()
        lat = 0
        lon = 0
        tariffs = [Tariff]()
    }
    required convenience public init(coder decoder: NSCoder) {
        self.init()
        self.cityName = decoder.decodeObject(forKey: "cityName") as? String
        self.cityID = decoder.decodeObject(forKey: "cityID") as? String
        self.dispTel = decoder.decodeObject(forKey: "dispTel") as? String
        self.currency = decoder.decodeObject(forKey: "currency") as? String
        self.centerCoord = decoder.decodeObject(forKey: "centerCoord") as? CLLocation
        self.stations = decoder.decodeObject(forKey: "stations") as? [AddressTemp]
        self.airports = decoder.decodeObject(forKey: "airports") as? [AddressTemp]
        self.polygon = decoder.decodeObject(forKey: "polygon") as? [PolygonPoint]
        self.lat = decoder.decodeObject(forKey: "lat") as? Double
        self.lon = decoder.decodeObject(forKey: "lon") as? Double
        self.tariffs = decoder.decodeObject(forKey: "tariffs") as? [Tariff]
    }
    open func encode(with coder: NSCoder) {
        coder.encode(self.cityName, forKey: "cityName")
        coder.encode(self.cityID, forKey: "cityID")
        coder.encode(self.dispTel, forKey: "dispTel")
        coder.encode(self.currency, forKey: "currency")
        coder.encode(self.centerCoord, forKey: "centerCoord")
        coder.encode(self.stations, forKey: "stations")
        coder.encode(self.airports, forKey: "airports")
        coder.encode(self.polygon, forKey: "polygon")
        coder.encode(self.lat, forKey: "lat")
        coder.encode(self.lon, forKey: "lon")
        coder.encode(self.tariffs, forKey: "tariffs")
    }
}


open class Referral : NSObject, NSCoding {
    var referralId : String?
    var cityID : String?
    var content : String?
    var title : String?
    var text : String?
    var code : String?
    var isActive : Bool?
    
    override init () {
        referralId = ""
        cityID = ""
        content = ""
        title = ""
        text = ""
        code = ""
        isActive = false
    }
    required convenience public init(coder decoder: NSCoder) {
        self.init()
        self.referralId = decoder.decodeObject(forKey: "referralId") as? String
        self.cityID = decoder.decodeObject(forKey: "cityID") as? String
        self.content = decoder.decodeObject(forKey: "content") as? String
        self.title = decoder.decodeObject(forKey: "title") as? String
        self.text = decoder.decodeObject(forKey: "text") as? String
        self.code = decoder.decodeObject(forKey: "code") as? String
        self.isActive = decoder.decodeObject(forKey: "isActive") as? Bool
    }
    open func encode(with coder: NSCoder) {
        coder.encode(self.referralId, forKey: "referralId")
        coder.encode(self.cityID, forKey: "cityID")
        coder.encode(self.content, forKey: "content")
        coder.encode(self.title, forKey: "title")
        coder.encode(self.text, forKey: "text")
        coder.encode(self.code, forKey: "code")
        coder.encode(self.isActive, forKey: "isActive")
    }
}


func curCity() -> City {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: udefCurCity) == nil {
        return City()
    }
    else {
        for city in cities() {
            if city.cityID == defaults.object(forKey: udefCurCity) as? String {
                return city
            }
        }
    }
    return City()
}


func cities() -> [City] {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: udefCities) == nil {
        return [City]()
    }
    else {
        if defaults.object(forKey: udefCities) is NSData {
            NSKeyedUnarchiver.setClass(City.self, forClassName: "Utap.City")
            NSKeyedUnarchiver.setClass(Additional.self, forClassName: "Utap.Additional")
            NSKeyedUnarchiver.setClass(Tariff.self, forClassName: "Utap.Tariff")
            NSKeyedUnarchiver.setClass(PolygonPoint.self, forClassName: "Utap.PolygonPoint")
            if NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefCities) as! Data) is [City] {
                return NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefCities) as! Data) as! [City]
            }
        }
    }
    return [City]()
}

func getReferrals() -> [Referral]
{
    var referrals : [Referral]?
    let defaults = UserDefaults.standard
    
    let referralData = defaults.object(forKey: udefReferrals) as? Data
    if referralData != nil {
        NSKeyedUnarchiver.setClass(Referral.self, forClassName: "Utap.Referral")
        referrals = NSKeyedUnarchiver.unarchiveObject(with: referralData!) as? [Referral]

    }
    
    if referrals == nil {
        referrals = [Referral]()
    }
    return referrals!
    
}

func saveReferrals(_ referrals: [Referral]) {
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: referrals), forKey: udefReferrals)
}


func getCity(_ completion: @escaping (_ cities : [City]) -> Void, failure: (_ str : String) -> Void)
{
   
    gxGetCities({ (cties) -> Void in
        completion(cties)
        }, failure: { () -> Void in
            
    })
}

func gxGetCities(_ completion: @escaping (_ cties : [City]) -> Void, failure:() -> Void)
{
    gxDoGet(kGxApiGetTenantCities, params: Dictionary(), completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            
            completion(gxParseCities(result as! Dictionary<String, AnyObject>))
        }
        }) { (error) -> Void in
            
    }
}


func gxParseCities(_ cityArr : Dictionary<String, AnyObject>) -> [City] {
    let curCities = cities()
    var citiesa = [City]()
    
    if cityArr["result"] != nil {
        if cityArr["result"] is Dictionary<String, AnyObject> {
            if cityArr["result"]!["city_list"] != nil {
                if cityArr["result"]!["city_list"] is [Dictionary<String, AnyObject>] {
                    let ctes = cityArr["result"]!["city_list"] as! [Dictionary<String, AnyObject>]
                    for city in ctes {
                        let newCity = City()
                        if city["city_id"] != nil {
                            newCity.cityID = parseString(city["city_id"]!)
                            
                            if city["city_lat"] is Double {
                                newCity.lat = city["city_lat"] as? Double
                            }
                            else if city["city_lat"] is String {
                                newCity.lat = (city["city_lat"] as! NSString).doubleValue
                            }
                            if city["city_lon"] is Double {
                                newCity.lon = city["city_lon"] as? Double
                            }
                            else if city["city_lon"] is String {
                                newCity.lon = (city["city_lon"] as! NSString).doubleValue
                            }
                            if city["city_name"] != nil {
                                if city["city_name"] is String {
                                    newCity.cityName = city["city_name"] as? String
                                }
                            }
                            if city["currency"] != nil {
                                if city["currency"] is String {
                                    newCity.currency = city["currency"] as? String
                                }
                            }
                            if city["phone"] != nil {
                                if city["phone"] is String {
                                    newCity.dispTel = city["phone"]! as? String
                                }
                            }
                            if city["city_reseption_area"] != nil {
                                if city["city_reseption_area"] is [[AnyObject]] {
                                    let points = city["city_reseption_area"] as! [[AnyObject]]
                                    if points.count > 0 {
                                        var polygonPoints = [PolygonPoint]()
                                        for point in points {
                                            if point.count == 2 {
                                                let polygonPoint = PolygonPoint()
                                                if point[1] is String {
                                                    polygonPoint.lat = (point[1] as! NSString).doubleValue
                                                }
                                                else {
                                                    polygonPoint.lat = point[1] as? Double
                                                }
                                                if point[0] is String {
                                                    polygonPoint.lon = (point[0] as! NSString).doubleValue
                                                }
                                                else {
                                                    polygonPoint.lon = point[0] as? Double
                                                }
                                                polygonPoints.append(polygonPoint)
                                            }
                                        }
                                        newCity.polygon = polygonPoints
                                    }
                                }
                            }
                            if curCities.count > 0 {
                                for city in curCities {
                                    if city.cityID == newCity.cityID {
                                        newCity.tariffs = city.tariffs
                                        break
                                    }
                                }
                            }
                        }
                        citiesa.append(newCity)
                    }
                }
            }
        }
    }
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: citiesa), forKey: udefCities)
    return citiesa
}




func getReferralList(_ phone: String?, completion: @escaping (_ referrals : [Referral]) -> Void)
{
    var params = Dictionary<String, String>()
    
    if (phone != nil) {
        params =  ["phone" : phone!]
    }

    gxGetRefferalList(params, completion: { (referralsList) -> Void in
        completion(referralsList)
        }, failure: { () -> Void in
            
    })
}

func gxGetRefferalList(_ params: Dictionary<String, String>, completion: @escaping (_ referrals : [Referral]) -> Void, failure:@escaping () -> Void)
{
    gxDoGet(kGxApiGetReferralSystemList, params: params, completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            completion(gxParseRefferals(result as! Dictionary<String, AnyObject>))
        }
    }) { (error) -> Void in
        failure()
    }
}


func gxParseRefferals(_ referralArr : Dictionary<String, AnyObject>) -> [Referral] {
    var referrals = [Referral]()
    
    if referralArr["result"] != nil {
        if referralArr["result"] is Dictionary<String, AnyObject> {
            if referralArr["result"]!["referral_system"] != nil {
                if referralArr["result"]!["referral_system"] is [Dictionary<String, AnyObject>] {
                    let referrs = referralArr["result"]!["referral_system"] as! [Dictionary<String, AnyObject>]
                    for referral in referrs {
                        let newReferal = Referral()
                        if let cityId = referral["city_id"] {
                            newReferal.cityID = parseString(cityId)
                        }
                        if let tempRefId = referral["referral_id"] {
                            newReferal.referralId = parseString(tempRefId)
                        }
                        if let tempContent = referral["content"] {
                            newReferal.content = parseString(tempContent)
                        }
                        if let tempTitle = referral["title"] {
                            newReferal.title = parseString(tempTitle)
                        }
                        if let tempText = referral["text"] {
                            newReferal.text = parseString(tempText)
                        }
                        if let isActive = referral["is_activate"] {
                            newReferal.isActive = parseBool(isActive)
                            if (parseBool(isActive)) {
                                if let tempCode = referral["code"] {
                                    newReferal.code = parseString(tempCode)
                                }
                            }
                        }
                        referrals.append(newReferal)
                    }
                }
            }
        }
    }
    saveReferrals(referrals)
    return referrals
}


func getReferralSystemActivate(_ phone: String, referralId: String, completion: @escaping (_ code : String) -> Void)
{
    gxGetRefferalSystemActivate(phone, referralId: referralId, completion: { (code) -> Void in
        completion(code)
        }, failure: { () -> Void in
            
    })
}


func gxGetRefferalSystemActivate(_ phone: String, referralId: String, completion: @escaping (_ referrals : String) -> Void, failure:() -> Void)
{
    let params = ["phone" : phone,
                  "referral_id" : referralId]
    
    gxDoPOST(kGxApiActivateReferralSystem, params: params, completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            completion(gxParseActivateRefferal(result as! Dictionary<String, AnyObject>))
        }
    }) { (error) -> Void in
        
    }
}

func gxParseActivateRefferal(_ referralArr : Dictionary<String, AnyObject>) -> String {
    
    var code = ""
    
    if let referals = referralArr["result"] as? [String:Any] {
        if let isActive = referals["is_activate"] {
            NSLog(parseString(isActive))
            if (parseBool(isActive)) {
                if let tempCode = referals["code"] {
                    NSLog(parseString(tempCode))
                    code = parseString(tempCode)
                }
            }
        }
    }
    return code
}


func getReferralCodeActivate(_ code: String, phone: String, completion: @escaping (_ resultCode : Bool) -> Void)
{
    gxGetRefferalCodeActivate(code, phone: phone, completion: { (resultCode) -> Void in
        completion(resultCode)
        }, failure: { () -> Void in
            
    })
}


func gxGetRefferalCodeActivate(_ code: String, phone: String, completion: @escaping (_ referrals : Bool) -> Void, failure:() -> Void)
{
    let params = ["phone" : phone,
                  "code" : code]
    
    gxDoPOST(kGxApiActivateCodeReferralSystem, params: params, completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            completion(gxParseActivateRefferalCode(result as! Dictionary<String, AnyObject>))
        }
    }) { (error) -> Void in
        
    }
}


func gxParseActivateRefferalCode(_ referralArr : Dictionary<String, AnyObject>) -> Bool {
    var result = false
    if let tempActive = referralArr["result"] {
        result = parseBool(tempActive)
    }
    return result
}



