//
//  OrdSummaryTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class OrdSummaryTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
