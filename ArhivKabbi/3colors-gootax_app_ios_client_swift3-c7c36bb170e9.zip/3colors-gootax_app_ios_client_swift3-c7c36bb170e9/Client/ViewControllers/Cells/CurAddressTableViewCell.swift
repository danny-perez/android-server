//
//  CurAddressTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class CurAddressTableViewCell: UITableViewCell {

    @IBOutlet weak var addressLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        colorize()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func colorize() {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.addressLabel.textColor = colorMainText()
    }
    
    
}
