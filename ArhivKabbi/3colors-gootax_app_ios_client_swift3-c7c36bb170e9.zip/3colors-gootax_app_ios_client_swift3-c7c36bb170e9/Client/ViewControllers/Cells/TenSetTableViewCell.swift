//
//  TenSetTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 16.05.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class TenSetTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var tenLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        localize()
        
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(SetTenantTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func colorize()
    {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.tenLabel.textColor = colorMainText()
        self.tintColor = colorNewTint()
        self.applyCurvedShadow(self.backView)
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
    
    func localize()
    {
        self.tenLabel.textAlignment = .natural
        self.tenLabel.text = strSetConGootaxAcc()
    }
    
}
