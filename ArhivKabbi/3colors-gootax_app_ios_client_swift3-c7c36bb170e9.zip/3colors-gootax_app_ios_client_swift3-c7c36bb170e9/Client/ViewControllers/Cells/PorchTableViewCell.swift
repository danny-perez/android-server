//
//  PorchTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class PorchTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var porchField: UITextField!
    @IBOutlet weak var porchLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        porchField.delegate = self
        
        localize()
        
        colorize()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // если выбрали - сделать поле для редактирования адреса
        if selected {
            self.porchField.becomeFirstResponder()
        }
        
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentCharacterCount = textField.text?.characters.count ?? 0
        if (range.length + range.location > currentCharacterCount){
            return false
        }
        let newLength = currentCharacterCount + string.characters.count - range.length
        return newLength <= 5
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
//        self.porchLabel.textColor = colorMainText()
//        self.porchField.textColor = colorMainFieldText()
    }
    
    func localize()
    {
        self.porchLabel.text = strComPorch()
    }
    
}
