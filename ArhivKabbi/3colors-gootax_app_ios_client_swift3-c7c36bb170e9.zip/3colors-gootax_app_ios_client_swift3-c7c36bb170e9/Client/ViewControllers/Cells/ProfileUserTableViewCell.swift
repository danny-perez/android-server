//
//  ProfileUserTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher

extension UIImageView {
    public func imageFromUrl(_ urlString: String, completion: @escaping (_ data: UIImage) -> Void) {
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            NSURLConnection.sendAsynchronousRequest(request, queue: OperationQueue.main, completionHandler:{ response, data, error in
                if data != nil {
                    self.image = UIImage(data: data!)
                    completion(UIImage(data: data!)!)
                }
            })
            
        }
    }
}


class ProfileUserTableViewCell: UITableViewCell {

    @IBOutlet weak var userPhoto: UIImageView!
    
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var backView: UIView!
    
//    @IBOutlet weak var userMoneyBalance: UILabel!
    
//    @IBOutlet weak var userBonusBalance: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.colorize()
        
//        self.userPhoto.layer.masksToBounds = true
//        self.userPhoto.layer.cornerRadius = self.userPhoto.frame.size.height/2
        
        
        localize()
        // Initialization code
    }
    
    func setProfile(_ profile : Profile) {
        
        self.userName.text = profile.fullName()
        if profile.photo != nil {
            let url = URL(string: profile.photo!)
            print("paserPhoto1 \(profile.photo!)")
            
            self.userPhoto.kf.setImage(with: url, completionHandler: {
                (image, error, cacheType, imageUrl) in
                if image == nil {
                    self.userPhoto.image = UIImage(named: "driver")
                }
            })
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

    func colorize() {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.backView.backgroundColor = colorMain()
        self.userName.textColor = colorMainText()
        self.editButton.setTitleColor(colorNewTint(), for: UIControlState())
        self.editButton.tintColor = colorNewTint()
        self.applyCurvedShadow(self.userPhoto)
        self.applyCurvedShadow(self.backView)
    }
    
    func localize() {
        self.editButton.setTitle(strComEdit(), for: UIControlState())
    }
    
    func applyCurvedShadow(_ view: UIView) {
        view.setNeedsLayout()
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
    
}
