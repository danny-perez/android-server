//
//  AuthCodeTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthCodeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var codeTitle: UILabel!

    @IBOutlet weak var codeField: UITextField!
    
    @IBOutlet weak var backView: UIView!
    var wrongCode : Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        NotificationCenter.default.addObserver(self, selector: #selector(AuthCodeTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func flashRed() {
        UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.beginFromCurrentState, animations: { () -> Void in
            self.backView.backgroundColor = colorWrongCode()
            }) { (finished) -> Void in
                
        }
    }
    
    func unflash() {
        UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.beginFromCurrentState, animations: { () -> Void in
            self.backView.backgroundColor = colorMain()
            }) { (finished) -> Void in
                
        }
    }
    
    func colorize()
    {
//        self.contentView.backgroundColor = colorMain()
        if self.wrongCode {
            self.backView.backgroundColor = colorWrongCode()
        }
        else {
            self.backView.backgroundColor = colorMain()
        }
        self.codeTitle.textColor = colorMainText()
        self.codeField.textColor = colorMainFieldText()
        self.backView.layer.shouldRasterize = true
        self.backView.layer.rasterizationScale = UIScreen.main.scale
        self.backView.layer.shadowRadius = 1;
        self.backView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backView.layer.masksToBounds = false
        self.backView.layer.shadowOpacity = 0.3;
    }
    
    func localize()
    {
        if layoutDirection == .rightToLeft {
            self.codeField.textAlignment = .left
        } else {
            self.codeField.textAlignment = .right
        }
        self.codeTitle.text = strComCodeTitle()
    }
    
}
