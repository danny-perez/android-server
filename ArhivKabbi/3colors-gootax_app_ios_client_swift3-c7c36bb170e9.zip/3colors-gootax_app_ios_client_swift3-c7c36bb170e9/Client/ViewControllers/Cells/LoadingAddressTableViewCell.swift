//
//  LoadingAddressTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LoadingAddressTableViewCell: UITableViewCell {

    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        loadingIndicator.startAnimating()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
