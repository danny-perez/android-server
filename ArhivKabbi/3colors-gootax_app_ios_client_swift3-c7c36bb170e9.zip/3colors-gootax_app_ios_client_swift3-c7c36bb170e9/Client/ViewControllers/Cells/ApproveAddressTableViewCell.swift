//
//  ApproveAddressTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ApproveAddressTableViewCell: UITableViewCell {

    @IBOutlet weak var approveButton: UIButton!
    var onApproveClick = {}
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        localize()
        colorize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func onApproveAction(_ sender: Any) {
        onApproveClick()
    }
    
    func colorize()
    {
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.approveButton.setColors()
    }
    
    
    func localize()
    {
        self.approveButton.setTitle(strComButApprove(), for: UIControlState())
        self.approveButton.layer.cornerRadius = 16;
    }

    
    
}
