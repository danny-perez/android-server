//
//  ProfileFirstNameTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ProfileFirstNameTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var firstNameTitle: UILabel!
    @IBOutlet weak var firstNameLabel: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileFirstNameTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        self.backView.backgroundColor = colorMain()
        self.applyCurvedShadow(self.backView)
        self.firstNameTitle.textColor = colorMainText()
        self.firstNameLabel.textColor = colorMainFieldText()
    }
    
    func localize()
    {
        if layoutDirection == .rightToLeft {
            self.firstNameLabel.textAlignment = .left
        } else {
            self.firstNameLabel.textAlignment = .right
        }
        self.firstNameTitle.text = strComFirstName()
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 2
    }
}
