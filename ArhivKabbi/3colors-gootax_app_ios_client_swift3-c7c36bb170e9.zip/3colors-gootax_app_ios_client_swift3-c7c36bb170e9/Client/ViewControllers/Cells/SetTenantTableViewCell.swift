//
//  SetTenantTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 18.04.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class SetTenantTableViewCell: UITableViewCell {

    @IBOutlet weak var tenLabel: UILabel!
    @IBOutlet weak var tenField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        localize()
        
        colorize()
        NotificationCenter.default.addObserver(self, selector: #selector(SetTenantTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // если выбрали - сделать поле для редактирования адреса
        if selected {
            self.tenField.becomeFirstResponder()
        }
        
    }
    
    
    func colorize()
    {
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        //        self.porchLabel.textColor = colorMainText()
        //        self.porchField.textColor = colorMainFieldText()
    }
    
    func localize()
    {
        self.tenLabel?.textAlignment = .natural
        self.tenLabel.text = strYourTen()
    }

}
