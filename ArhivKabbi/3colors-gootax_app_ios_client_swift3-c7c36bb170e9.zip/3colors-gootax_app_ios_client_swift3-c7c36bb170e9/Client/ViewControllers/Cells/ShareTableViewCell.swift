//
//  ShareTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 28.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class ShareTableViewCell: UITableViewCell {

    @IBOutlet weak var shareLogo: UIImageView!
    @IBOutlet weak var shareTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ShareTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func colorize() {
        self.backgroundColor = colorMain()
        self.backgroundView?.backgroundColor = colorMain()
        self.shareTitle.textColor = colorMainText()
    }
    
    func localize() {
        self.shareTitle.text = strShareTitle()
    }
    
    
}
