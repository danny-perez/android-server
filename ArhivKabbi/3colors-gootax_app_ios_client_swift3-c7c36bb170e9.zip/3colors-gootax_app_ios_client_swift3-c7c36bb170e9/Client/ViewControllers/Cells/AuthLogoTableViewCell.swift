//
//  AuthLogoTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AuthLogoTableViewCell: UITableViewCell {

    @IBOutlet weak var logoImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        logoImage.image = UIImage(named: imageLogo())
        //self.contentView.backgroundColor = colorGrayBackground()
    }

}
