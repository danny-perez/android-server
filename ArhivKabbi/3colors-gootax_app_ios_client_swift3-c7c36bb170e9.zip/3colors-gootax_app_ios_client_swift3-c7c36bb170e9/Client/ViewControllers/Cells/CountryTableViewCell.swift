//
//  CountryTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 26.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class CountryTableViewCell: UITableViewCell {

    @IBOutlet weak var rightSpace: NSLayoutConstraint!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var shortWidth: NSLayoutConstraint!
    @IBOutlet weak var countryShortCode: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        colorize()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func colorize()
    {
        self.contentView.backgroundColor = colorMain()
        self.backgroundColor = colorMain()
        self.tintColor = colorNewTint()
        self.countryLabel.textColor = colorMainText()
        self.countryShortCode.textColor = colorMainFieldText()
    }

}
