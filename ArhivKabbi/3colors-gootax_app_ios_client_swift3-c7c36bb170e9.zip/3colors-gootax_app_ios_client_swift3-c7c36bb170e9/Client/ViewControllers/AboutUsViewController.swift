//
//  AboutUsViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 07.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var closeButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.webView.isHidden = true
        self.loadingIndicator.isHidden = false
        self.loadingIndicator.startAnimating()
        self.navigationItem.title = strComAboutApp()
        gxDoGet(kGxApiGetInfoPage, params: Dictionary<String, String>(), completion: { (response) -> Void in
            if let validResponse = response as? [String: Any] {
                if let result = validResponse["result"] as? [String: Any] {
                    if let wrappedResult = result["result"] as? String {
                        self.webView.loadHTMLString(wrappedResult.stringByDecodingHTMLEntities, baseURL: nil)
                        self.webView.isHidden = false
                    }
                }
            }
            }) { (error) -> Void in
                
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(AboutUsViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        localize()
        colorize()
        
        
        // Do any additional setup after loading the view.
    }

    @IBAction func closeAction(_ sender: UIBarButtonItem) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func localize()
    {
        self.navigationItem.title = strLeftAbout()
    }
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
