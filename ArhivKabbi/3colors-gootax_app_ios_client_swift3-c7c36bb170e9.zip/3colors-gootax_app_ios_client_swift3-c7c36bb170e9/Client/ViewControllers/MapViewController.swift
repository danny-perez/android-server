  //
//  MapViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import GoogleMaps
import MapKit
import AudioToolbox
import QuartzCore
import YandexMobileMetrica
import Kingfisher
  
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

  
@objc
protocol CenterViewControllerDelegate {
    @objc optional func toggleLeftPanel()
    @objc optional func collapseSidePanels()
    @objc optional func reloadLeftPanel()
    @objc optional func updateCityPhone(_ city: City?)
    @objc optional func showForeground()
    @objc optional func hideForeground()
    @objc optional func updateCenterView(controller: UINavigationController)
}

  
class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UIGestureRecognizerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UIActionSheetDelegate, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, UIAlertViewDelegate, GMSMapViewDelegate {
    
    
    // TITLE APPBAR
    // Navigation Drawer
    @IBOutlet weak var leftView: UIView!
    @IBOutlet weak var hamButton: UIBarButtonItem!
    
    
    // TITLE BOTTOM
    @IBOutlet weak var botView: UIView!
    // Tariff
    @IBOutlet weak var tariffCollectionView: UICollectionView!
    // Payment
    @IBOutlet weak var payTitle: UILabel!
    @IBOutlet weak var payLogo: UIImageView!
    @IBOutlet weak var payLabel: UILabel!
    // ORDER
    @IBOutlet weak var orderView: UIView!
    @IBOutlet weak var approveAddress: UIButton!
    // Cost
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var loadingCostIndicator: UIActivityIndicatorView!
    // WISH PANEL
    // Wishes
    @IBOutlet weak var wishesView: UIView!
    @IBOutlet weak var wishesLabel: UILabel!
    // Time
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeView: UIView!
    // Address
    @IBOutlet weak var addrLabel: UILabel!
    @IBOutlet weak var commentView: UIView!
    
    
    // TITLE FOOTER
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableHeight: NSLayoutConstraint!
    @IBOutlet weak var shadowView: UIView!
    @IBOutlet weak var addPathButton: UIButton!
    
    
    // TITLE MAIN
    // MAPS
    @IBOutlet weak var osmMap: MKMapView!
    @IBOutlet weak var googleMap: UIView!
    var gmsMap : GMSMapView?
    // Center marker
    @IBOutlet weak var userCenter: UIImageView!
    @IBOutlet weak var userCenterLabel: UILabel!
    @IBOutlet weak var annBorderOut: UIView!
    @IBOutlet weak var annBorderIn: UIView!
    // Center button
    @IBOutlet weak var centerButton: UIButton!
    
    
    // TITLE FOOTER DRIVER MENU
    @IBOutlet weak var driverView: UIView!
    @IBOutlet weak var driverPhoyo: UIImageView!
    @IBOutlet weak var driverName: UILabel!
    @IBOutlet weak var driverCar: UILabel!
    @IBOutlet weak var driverMark: UILabel!
    @IBOutlet weak var driverStar: UIImageView!
    @IBOutlet weak var driverTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var tableTop: NSLayoutConstraint!
    
    
    // TITLE BOTTOM ORDER MENU
    @IBOutlet weak var botCallView: UIView!
    // Reject button
    @IBOutlet weak var rejectLogo: UIImageView!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var rejectLabel: UILabel!
    @IBOutlet weak var constraintRejectWidth: NSLayoutConstraint!
    // Call button
    @IBOutlet weak var callButton: UIButton!
    @IBOutlet weak var callLogo: UIImageView!
    @IBOutlet weak var callLabel: UILabel!
    @IBOutlet weak var constraintCallWidth: NSLayoutConstraint!
    // Edit order button
    @IBOutlet weak var editOrderButton: UIButton!
    @IBOutlet weak var editOrderLogo: UIImageView!
    @IBOutlet weak var editOrderLabel: UILabel!
    @IBOutlet weak var constraintEditOrderWidth: NSLayoutConstraint!
    
    
    @IBOutlet weak var heightOfView: NSLayoutConstraint!
    @IBOutlet weak var bottomSpace: NSLayoutConstraint!
    @IBOutlet weak var uieSpace: NSLayoutConstraint!
    @IBOutlet weak var centerUserSpace: NSLayoutConstraint!
    @IBOutlet weak var bottomCallConstraint: NSLayoutConstraint!
    @IBOutlet weak var aSpaceConstraint: NSLayoutConstraint!

    
    // City
    var curCities : [City]?
    var currentCity : City?
    var setted = false

    
    // Tariff
    var tariffs : [Tariff]?
    var validTariff : [Tariff] = []
    
    
    // Address
    var addresses : [AddressTemp]?
    var loadAddressTimer : Timer?
    var regionNotSupported = false
    var loading : Bool = true
    
    
    // Cars    
    var curCars : [Car]?
    var curCarsAnnsOsm : [MKAnnotation]?
    var curCarsAnnsGgl : [GMSMarker]?
    var updateCarTimer : Timer?
    
    
    // ORDER
    var curOrder : OrderTemp?
    var curOrderStatus : OrderStatus?
    // Create order
    var createOrderTimer : Timer?
    var createdOrder : Bool = false
    var orderCreated : Order?
    let updateInterval = 5
    var updateTimer : Timer?
    // Reject order
    var rejectDialog : UIAlertView?
    var waitingDialog : UIAlertController?
    var countReject: Int = 0
    let updateIntervalReject = 1
    var updateReject : Timer?
    // Find
    var gglCircle : TCCircle?
    // Call
    var callActionSheet : UIActionSheet?
    
    
    // MAP
    var point : String?
    var locationManager : CLLocationManager?
    var lastScale: CGFloat!
    fileprivate var mapChangedFromUserInteraction = false
    var ftime : Bool = true
    var first = true
    var finishedPinch : Bool = true
    // osm
    var currentOverlay: MKTileOverlay?
    var osmMapPinch : UIPinchGestureRecognizer?
    var driverOsmLoc : MapPinCarDriver?
    var osmTimePoint : TimeAnnotation?
    var osmPointA : PointAnnotation?
    var osmPointB : PointAnnotation?
    var osmPointC : PointAnnotation?
    var osmPointD : PointAnnotation?
    var osmPointE : PointAnnotation?
    // Google
    var gglTimePoint : GMSMarker?
    var gglPointA : GMSMarker?
    var gglPointB : GMSMarker?
    var gglPointC : GMSMarker?
    var gglPointD : GMSMarker?
    var gglPointE : GMSMarker?
    var driverGglLoc : GMSMarker?
    
    
    // Other
    var removeBot = false
    
    var delegate: CenterViewControllerDelegate?
    var visualEffectView : UIVisualEffectView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showMap()
        self.openOrder()
        
        if self.curOrder == nil {
            self.curOrder = OrderTemp()
        } else {
            print(curOrder)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(MapViewController.updateOrderz(_:)), name: NSNotification.Name(rawValue: "updOrd"), object: nil)
        
        self.automaticallyAdjustsScrollViewInsets = false
        let lpgr : UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(MapViewController.handleLongPress(_:)))
        lpgr.minimumPressDuration = 0.5
        lpgr.delegate = self
        lpgr.delaysTouchesBegan = true
        self.tariffCollectionView.addGestureRecognizer(lpgr)
        self.navigationController?.navigationBar.isTranslucent = false
        self.heightOfView.constant = UIScreen.main.bounds.height

        
        getCity({ (cities) -> Void in
            self.curCities = cities
            self.locationManager?.startUpdatingLocation()
            if cities.count > 0 {
                let city = cities[0]
                if city.cityID != nil {
                    self.currentCity = city
                    let defaults = UserDefaults.standard
                    defaults.set(city.cityID!, forKey: udefCurCity)
                    self.delegate?.updateCityPhone!(city)
                    var setted = false
                    if city.tariffs != nil {
                        if city.tariffs!.count > 0 {
                            setted = true
                            if (Date().timeIntervalSince1970 - (city.tariffs![0].tariffDateLoaded?.timeIntervalSince1970)!) > 1 {
                                getTariffs { (arr) -> Void in
                                    city.tariffs = arr
                                    if arr.count > 0 {
                                        self.curOrder?.orderTariff = arr[0]
                                    }
                                    saveCit(city)
                                    self.tariffs = self.locCity().tariffs!
                                    self.validTariff = self.getValidateTariffList()
                                    self.updateTariffsCollection(self.locCity())
                                }
                            }
                        }
                    }
                    if setted == false {
                        getTariffs { (arr) -> Void in
                            city.tariffs = arr
                            if arr.count > 0 {
                                self.curOrder?.orderTariff = arr[0]
                            }
                            saveCit(city)
                            self.tariffs = self.locCity().tariffs!
                            self.validTariff = self.getValidateTariffList()
                            self.updateTariffsCollection(self.locCity())
                        }
                    }
                }
            }
        }) { (str) -> Void in
            getTariffs { (arr) -> Void in
                if arr.count > 0 {
                    self.curOrder?.orderTariff = arr[0]
                }
                self.tariffs = self.locCity().tariffs!
                self.validTariff = self.getValidateTariffList()
                self.updateTariffsCollection(self.locCity())
            }
        }
        
        if (allowReferralSystem) {
            getReferralList(profile().phone) { (referrals) in
            }
        }
        
        if self.createdOrder != true {
            locationManager = CLLocationManager()
            locationManager?.requestWhenInUseAuthorization()
            locationManager?.delegate = self
            locationManager?.desiredAccuracy = kCLLocationAccuracyBest
            locationManager?.startUpdatingLocation()
        }
        else {
            if curMap() == 0  || curMap() == 2 {
                let centerCoord = CLLocationCoordinate2DMake((self.orderCreated?.pointA?.lat.doubleValue)!, (self.orderCreated?.pointA?.lon.doubleValue)!)
                var region : MKCoordinateRegion = MKCoordinateRegion()
                var span : MKCoordinateSpan = MKCoordinateSpan()
                span.latitudeDelta = 0.005
                span.longitudeDelta = 0.005
                region.span = span
                region.center = centerCoord
                self.osmMap.setRegion(region, animated: true)
            }
            else if curMap() == 1 {
                let coord = CLLocationCoordinate2DMake((self.orderCreated?.pointA?.lat.doubleValue)!, (self.orderCreated?.pointA?.lon.doubleValue)!)
                self.gmsMap?.animate(toLocation: coord)
                self.gmsMap?.animate(toZoom: 17)
            }
        }
        
        self.updateAddressView()
        
        if self.point == nil {
            self.point = "a"
        }
        
        if self.point != "a" {
            self.navigationItem.leftBarButtonItem = self.navigationItem.backBarButtonItem
        }
        NotificationCenter.default.addObserver(self, selector: #selector(MapViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(MapViewController.doColorize), name: NSNotification.Name(rawValue: notifChangeCol), object: nil)
        
        self.approveAddress.isEnabled = false
        
        let tapLeft : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(MapViewController.tapLeft(_:)))
        self.leftView.addGestureRecognizer(tapLeft)
        
        self.tableView.estimatedRowHeight = 80
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        self.tableView.setNeedsLayout()
        self.tableView.layoutIfNeeded()
        
        localize()
        colorize()

        if self.curOrder?.orderTariff == nil {
            if self.locCity().tariffs!.count > 0 {
                self.curOrder?.orderTariff = self.locCity().tariffs![0]
            }
        }
        
        self.tariffs = self.locCity().tariffs!
        updateTableView()
        self.loadingCostIndicator.isHidden = true
        if !allowEditOrder { editOrderButton.isEnabled = false }
        
        if self.createdOrder != true {
            self.userCenter.alpha = 0
            self.userCenterLabel.alpha = 0
            self.annBorderOut.alpha = 0
            UIView.animate(withDuration: 2.3, animations: {
                self.userCenter.alpha = 1
                self.userCenterLabel.alpha = 1
                self.annBorderOut.alpha = 1
            })
        }
        
        if (NSClassFromString("UIVisualEffectView") != nil) {
            if self.visualEffectView == nil {
                self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                let frame = self.view.bounds
                self.visualEffectView?.frame = CGRect(x: 0, y: frame.height, width: frame.width, height: frame.height)
                self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                self.visualEffectView?.alpha = 1
                self.view.addSubview(self.visualEffectView!)
                self.visualEffectView?.backgroundColor = blurColor
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.removeBot = false
        showMap()
        
        self.currentCity = nil
        self.tariffs = self.locCity().tariffs!
        
        self.validTariff = self.getValidateTariffList()
        self.updateTariffsCollection(self.locCity())
        self.updateTariffCollectionFrame()
        
        
        
        if self.ftime != true {
            if self.curOrder?.pathA == nil {
                self.updateGeoloc()
            }
        }

        self.updateTableView()
        self.updateAddressView()
        self.setAnns()
        self.setPayment()
        self.setDateLabel()
        if isDemo {
            self.showInstruction()
        }
        
        
        if self.curOrder?.pathA?.lat != 0 {
            if curMap() == 0  || curMap() == 2 {
                if (self.countOfPaths() <= 1) {
                    let centerPoint = CLLocationCoordinate2DMake((self.curOrder?.pathA?.lat!)!, (self.curOrder?.pathA?.lon!)!)
                    var region : MKCoordinateRegion = MKCoordinateRegion()
                    var span : MKCoordinateSpan = MKCoordinateSpan()
                    span.latitudeDelta = 0.005
                    span.longitudeDelta = 0.005
                    region.span = span
                    region.center = centerPoint
                    self.ftime = true
                    self.osmMap.setRegion(region, animated: true)
                } else {
                    self.setPointsCamera()
                }
            }
            else if curMap() == 1 {
                delay(0.1, closure: {
                    self.ftime = true
                    if (self.countOfPaths() <= 1) {
                        self.gmsMap?.animate(toLocation: CLLocationCoordinate2DMake((self.curOrder?.pathA?.lat!)!, (self.curOrder?.pathA?.lon!)!))
                    } else {
                        self.setPointsCamera()
                    }
                })
            }
        }
        
        delegate?.reloadLeftPanel!()
        delay(0.7, closure: {
            self.removeBot = true
        })
        UIView.animate(withDuration: 0.3, animations: {
            let frame = self.view.bounds
            self.visualEffectView?.frame = CGRect(x: 0, y: frame.height, width: frame.width, height: frame.height)
        }) 
    }
    
    // MARK - @IBAction
    
    @IBAction func approveAction(_ sender: UIButton)
    {
        
        let profileSetted = profile().phone != ""
        if profileSetted {
            sender.isEnabled = false
            var canCreate = true // можно ли создать заказ
            if !orderWithOnePoint {
                if self.countOfPaths() < 2 {
                    let aView = UIAlertView()
                    aView.title = "";
                    aView.message = strErrNeedAtLeastTwoPointToMakeAnOrder()
                    aView.addButton(withTitle: strComClose())
                    aView.cancelButtonIndex = 0
                    aView.show()
                    canCreate = false
                } else {
                    canCreate = true
                }
            }
            self.createOrderProxy(canCreate, sender: sender)
        }
        else {
            self.openRegister(false)
        }
    }
    
    
    @IBAction func rejectOrder(_ sender: AnyObject) {
        self.rejectDialog = UIAlertView()
        self.rejectDialog?.title = strComRejectOrder()
        self.rejectDialog?.message = strComRejectOrderMessage()
        self.rejectDialog?.addButton(withTitle: strComYes())
        self.rejectDialog?.addButton(withTitle: strComNo())
        self.rejectDialog?.cancelButtonIndex = 1
        self.rejectDialog?.delegate = self
        if self.gglCircle != nil {
            //            self.gglCircle?.stop()
        }
        self.rejectDialog?.show()
        
    }
    
    
    @IBAction func onEditOrder(_ sender: Any) {
        let ncEditOrder = UIStoryboard.editOrderViewController()!
        let editOrderController = ncEditOrder.viewControllers[0] as! EditOrderViewController
        editOrderController.orderId = orderCreated?.orderID
        ncEditOrder.modalPresentationStyle = .overCurrentContext
        ncEditOrder.view.backgroundColor = UIColor.clear
        self.navigationController?.present(ncEditOrder, animated: true, completion: { () -> Void in
            
        })
    }
    
    
    @IBAction func selectTime(_ sender: UIButton) {
        let timeController = UIStoryboard.timePicker()!
        timeController.modalPresentationStyle = .overCurrentContext
        timeController.view.backgroundColor = UIColor.clear
        timeController.curOrder = self.curOrder
        DispatchQueue.main.async(execute: {
            self.navigationController?.present(timeController, animated: true, completion: { () -> Void in
                
            })
        });
    }
    
    @IBAction func openWishes(_ sender: UIButton) {
        let wishesController = UIStoryboard.wishesController()!
        wishesController.modalPresentationStyle = .overCurrentContext
        wishesController.view.backgroundColor = UIColor.clear
        wishesController.curOrder = self.curOrder
        self.navigationController?.present(wishesController, animated: true, completion: { () -> Void in
            
        })
        
    }
    
    
    @IBAction func openAddrDetail(_ sender: UIButton) {
        openAddressDetails()
    }
    
    
    @IBAction func openPayType(_ sender: UIButton) {
        let wishesController = UIStoryboard.payTypeController()!
        wishesController.modalPresentationStyle = .overCurrentContext
        let payController = wishesController.viewControllers[0] as! PayTypeViewController
        payController.curOrder = self.curOrder
        self.navigationController?.present(wishesController, animated: true, completion: { () -> Void in
        })
    }
    
    @IBAction func deletePath(_ sender: UIButton) {
        
        var indexPath: IndexPath!
        
        if let button = sender as? UIButton {
            if let superview = button.superview {
                if let cell = superview.superview?.superview as? AddressPathTableViewCell {
                    indexPath = self.tableView.indexPath(for: cell)
                    if indexPath.row == 1 && self.countOfPaths() == 2 {
                        self.curOrder?.pathB = nil
                        updateTableView()
                        self.setAnns()
                        self.setPayment()
                        self.setDateLabel()
                        
                        delegate?.reloadLeftPanel!()
                        delay(0.7, closure: {
                            self.removeBot = true
                        })
                        UIView.animate(withDuration: 0.3, animations: {
                            let frame = self.view.bounds
                            self.visualEffectView?.frame = CGRect(x: 0, y: frame.height, width: frame.width, height: frame.height)
                        }) 
                        
                    } else {
                        self.deletePathAtIndex(indexPath)
                    }
                    self.callCost()
                    
                    if curMap() == 1 {
                        if countOfPaths() == 1 {
                            gmsMap?.animate(toLocation: CLLocationCoordinate2DMake((self.curOrder?.pathA?.lat!)!, (self.curOrder?.pathA?.lon!)!))
                            gmsMap?.animate(toZoom: 17)
                        } else {
                            self.setPointsCamera()
                        }
                    } else {
                        if (self.countOfPaths() == 1) {
                            let centerPoint = CLLocationCoordinate2DMake((self.curOrder?.pathA?.lat!)!, (self.curOrder?.pathA?.lon!)!)
                            
                            var region : MKCoordinateRegion = MKCoordinateRegion()
                            var span : MKCoordinateSpan = MKCoordinateSpan()
                            span.latitudeDelta = 0.005
                            span.longitudeDelta = 0.005
                            region.span = span
                            region.center = centerPoint
                            self.ftime = true
                            self.osmMap.setRegion(region, animated: true)
                        } else {
                            self.setPointsCamera()
                        }
                    }
                }
            }
        }
        
        
    }
    
    
    @IBAction func addPath(_ sender: UIButton) {
        var point : String? = "a"
        switch self.countOfPaths() {
        case 1:
            point = "b"
        case 2:
            point = "c"
        case 3:
            point = "d"
        case 4:
            point = "e"
        default :
            print("error при добавлении")
            
        }
        self.performSegue(withIdentifier: "search", sender: point)
        self.updateTableView()
        
    }
    
    @IBAction func centerOnUser(_ sender: UIButton) {
        self.ftime = true
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.requestWhenInUseAuthorization()
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        locationManager?.startUpdatingLocation()
    }
    
    //MARK: Location Manager Delegate
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let firstCity = self.locCities()
        if (firstCity.count <= 0) { return }
        let closestCity = firstCity[0]
        let coord = CLLocationCoordinate2DMake((closestCity.lat)!, (closestCity.lon)!)
        if (curMap() == 0 || curMap() == 2) {
            var region : MKCoordinateRegion = MKCoordinateRegion()
            var span : MKCoordinateSpan = MKCoordinateSpan()
            span.latitudeDelta = 0.005
            span.longitudeDelta = 0.005
            region.span = span
            region.center = coord
            self.ftime = true
            self.osmMap.setRegion(region, animated: true)
            delay(1.5, closure: {
                self.ftime = false
            })
        }
        if self.locCities().count > 0 {
            if (curMap() == 1) {
                self.gmsMap?.animate(toLocation: coord)
                self.gmsMap?.animate(toZoom: 17)
            }
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if curMap() == 0 || curMap() == 2 {
            var region : MKCoordinateRegion = MKCoordinateRegion()
            var span : MKCoordinateSpan = MKCoordinateSpan()
            span.latitudeDelta = 0.005
            span.longitudeDelta = 0.005
            region.span = span
            region.center = locations[0].coordinate
            self.ftime = true
            self.osmMap.setRegion(region, animated: true)
            delay(1.5, closure: {
                self.ftime = false
            })
        }
        else if curMap() == 1 {
            self.ftime = true
            if self.first == true {
                
                let cameraPosition = GMSCameraPosition(target: locations[0].coordinate, zoom: 10, bearing: 0, viewingAngle: 0)
                self.gmsMap?.camera = cameraPosition
                let zoomIn = GMSCameraUpdate.zoom(to: 17)
                CATransaction.begin()
                CATransaction.setValue(1.0, forKey: kCATransactionAnimationDuration)
                
                self.gmsMap?.animate(with: zoomIn)
                CATransaction.commit()
                self.first = false
            }
            else {
                self.gmsMap?.animate(toLocation: locations[0].coordinate)
                self.gmsMap?.animate(toZoom: 17)
            }
            delay(1.5, closure: {
                self.ftime = false
            })
        }
        self.locationManager?.stopUpdatingLocation()
        self.locationManager = nil
    }
    

    
    
    //MARK: osm map delegate
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        mapChangedFromUserInteraction = mapViewRegionDidChangeFromUserInteraction()
        if self.countOfPaths() == 1 && self.curOrder?.pathA?.type != .autocomplete && mapChangedFromUserInteraction {
            self.curOrder?.pathA?.label = strComLoading()
            updateTableView()
        }
        if self.finishedPinch == true {
            self.hideBot()
        }
    }
    
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        if self.finishedPinch == true {
            if !self.createdOrder {
                if ftime == true || mapChangedFromUserInteraction {
                    runTimer()
                    self.updateAddressView()
                }
                self.showBot()
            }
        }
    }
    
    public func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        return MKTileOverlayRenderer(overlay: overlay)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation.isKind(of: MapPinCarDriver.self) {
            let aView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            if self.orderCreated?.driver?.angle != nil {
                aView.image = carMapImage().imageRotatedByDegrees(CGFloat((self.orderCreated?.driver?.angle)!), flip: false)
            }
            else {
                aView.image = UIImage(named: imageCarNoAngle())
            }
            return aView
        }
        if annotation.isKind(of: MapPinCar.self) {
            let aView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            let ann : MapPinCar = annotation as! MapPinCar
            aView.image = carMapImage().imageRotatedByDegrees(CGFloat((ann.car?.course)!), flip: false)
            return aView
        }
        
        if self.curOrderStatus == .new {
            if annotation.isKind(of: PointAnnotation.self) {
                let ann = annotation as! PointAnnotation
                if ann.point == "A" {
                    var pulsView = self.osmMap.dequeueReusableAnnotationView(withIdentifier: "pulseView") as? SVPulsingAnnotationView
                    if pulsView == nil {
                        pulsView = SVPulsingAnnotationView(annotation: annotation, reuseIdentifier: "pulseView")
                        pulsView?.outerColor = UIColor.clear
                        if !self.setted {
                            pulsView?.image = blankAnnView()
                            self.setted = true
                        }
                        else {
                            pulsView?.image = blankAnnView()
                        }
                        pulsView?.outerPulseAnimationDuration = 3
                        pulsView?.delayBetweenPulseCycles = 0
                        pulsView?.pulseScaleFactor = 15
                        
                    }
                    pulsView?.canShowCallout = true
                    return pulsView
                }
            }
        }
        if annotation.isKind(of: TimeAnnotation.self) {
            let aView = TimeAnnotationView(annotation: annotation, reuseIdentifier: "", time: self.timeToCar())
            return aView
        }
        if annotation.isKind(of: MapPin.self) {
            let aView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            aView.image = carMapImage()
            return aView
        }
        else {
            let ann = annotation as! PointAnnotation
            let aView = PointAnnotationView(annotation: annotation, reuseIdentifier: "", point: ann.point)
            return aView
        }
    }
    
    
    fileprivate func mapViewRegionDidChangeFromUserInteraction() -> Bool {
        if curMap() == 0 || curMap() == 2 {
            let view = self.osmMap.subviews[0]
            //  Look through gesture recognizers to determine whether this region change is from user interaction
            if let gestureRecognizers = view.gestureRecognizers {
                for recognizer in gestureRecognizers {
                    print(recognizer.state.rawValue)
                    if (recognizer.state == UIGestureRecognizerState.began || recognizer.state == UIGestureRecognizerState.ended) {
                        return true
                    }
                }
            }
        }
        return false
    }
    
    
    func didReceivePinch(_ gestureRecognizer: UIPinchGestureRecognizer) {
        if gestureRecognizer.state == UIGestureRecognizerState.began {
            self.lastScale = gestureRecognizer.scale
            self.changeConstr()
        }
        if gestureRecognizer.state == UIGestureRecognizerState.began || gestureRecognizer.state == UIGestureRecognizerState.changed {
            self.finishedPinch = false
            let maxScale: Double = 20
            let minScale: Double = 0.005
            let newScale: Double = Double(1 - (lastScale - gestureRecognizer.scale))
            
            var latitudeDelta: Double = self.osmMap.region.span.latitudeDelta / newScale
            var longitudeDelta: Double = self.osmMap.region.span.longitudeDelta / newScale
            
            latitudeDelta = max(min(latitudeDelta, maxScale), minScale)
            longitudeDelta = max(min(longitudeDelta, maxScale), minScale)
            let center = self.centerOsmCoordinate()
            self.osmMap.setRegion(MKCoordinateRegionMake(center, MKCoordinateSpanMake(latitudeDelta, longitudeDelta)), animated: false)
            lastScale = gestureRecognizer.scale
            print(gestureRecognizer.scale)
        }
        if gestureRecognizer.state == .ended {
            self.finishedPinch = true
            self.osmMap.isScrollEnabled = true
            self.showBot()
        }
        else {
           self.osmMap.isScrollEnabled = false
        }
    }
    
    func changeConstr() {
        if !self.createdOrder {
            if self.approveAddress.isEnabled == true {
                self.centerUserSpace.constant = 60
            }
            else {
                self.centerUserSpace.constant = 10
            }
            self.bottomSpace.constant = -20
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.botView?.superview?.layoutIfNeeded()
                self.centerButton.layoutIfNeeded()
            })
        }
    }
    
    // MARK: google map delegate
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        let count = countOfPaths()
        if count <= 1 && self.curOrder?.pathA?.type != .autocomplete {
            self.curOrder?.pathA?.label = strComLoading()
            self.regionNotSupported = false
            updateTableView()
        }
        
        if gesture == true {
            self.ftime = false
        }
        DispatchQueue.main.async(execute: {
            if !self.createdOrder {
                self.hideBot()
            }
        });
        
    }
    
    func mapView(_ animate: GMSMapView, idleAt position: GMSCameraPosition) {
        //
        if !self.createdOrder {
            if self.curOrder?.pathA?.type != .autocomplete {
                self.approveAddress.isEnabled = false
                runTimer()
            } else {
                self.curOrder?.pathA?.type = .common
            }
            self.showBot()
        }
    }

    func animateGmsByBounds(markers: [GMSMarker]) {
        var bounds = GMSCoordinateBounds()
        for marker in markers {
            bounds = bounds.includingCoordinate(marker.position)
        }
        var inset = CGFloat(250);
        if createdOrder {
            inset = CGFloat(200);
        }
        
        let camera = gmsMap?.camera(for: bounds, insets:UIEdgeInsets(top: inset, left: 20, bottom: inset, right: 20))

        if camera != nil {
            self.gmsMap?.camera = camera!
        }
    }
    
    func animateOsmByBounds(markers: [MKAnnotation]) {
        var commonLat: Double = 0
        var commonLon: Double = 0
        
        var minLat: Double = markers[0].coordinate.latitude
        var minLon: Double = markers[0].coordinate.longitude
        
        var maxLat: Double = markers[0].coordinate.latitude
        var maxLon: Double = markers[0].coordinate.longitude
        
        var latOffset: Double = 0.1
        var lonOffset: Double = 0.005
        
        if self.createdOrder {
            latOffset = 0.01
        }
        
        for marker in markers {
            let lat = marker.coordinate.latitude
            let lon = marker.coordinate.longitude
            
            commonLat += lat
            commonLon += lon
            
            if (lat > maxLat) {
                maxLat = lat
            }
            if (lon > maxLon) {
                maxLon = lon
            }
            
            if (lat < minLat) {
                minLat = lat
            }
            if (lon < minLon) {
                minLon = lon
            }
        }
        
        commonLat = commonLat / Double(markers.count)
        commonLon = commonLon / Double(markers.count)
        
        let centerPoint = CLLocationCoordinate2DMake(commonLat, commonLon)
        
        var region : MKCoordinateRegion = MKCoordinateRegion()
        var span : MKCoordinateSpan = MKCoordinateSpan()
        span.latitudeDelta = maxLat - minLat + latOffset
        span.longitudeDelta = maxLon - minLon + lonOffset
        region.span = span
        region.center = centerPoint
        self.ftime = true
        self.osmMap.setRegion(region, animated: true)
    }
    

    func setOrderCamera() {
        if curMap() == 1 {
            var markers = [GMSMarker]()
            if self.curOrderStatus == .carAssigned {
                markers.append(self.gglTimePoint!)
            } else {
                if self.gglPointA != nil {
                    markers.append(self.gglPointA!)
                }
            }

            if self.driverGglLoc != nil {
                markers.append(self.driverGglLoc!)
            }

            if self.curOrderStatus != .new {
                self.animateGmsByBounds(markers: markers)
            }
        } else {
            var markers = [MKAnnotation]()
            if self.curOrderStatus == .carAssigned {
                markers.append(self.osmTimePoint!)
            } else {
                if self.gglPointA != nil {
                    markers.append(self.osmPointA!)
                }
            }
            
            if self.driverOsmLoc != nil {
                markers.append(self.driverOsmLoc!)
            }
            
            if self.curOrderStatus != .new {
                if (markers.count > 0) {
                    self.animateOsmByBounds(markers: markers)
                }
            }
        }
    }

    func setPointsCamera() {
        if curMap() == 1 {
            var markers = [GMSMarker]()
            if self.gglPointA != nil {
                markers.append(self.gglPointA!)
            }

            if self.gglPointB != nil {
                markers.append(self.gglPointB!)
            }

            if self.gglPointC != nil {
                markers.append(self.gglPointC!)
            }

            if self.gglPointD != nil {
                markers.append(self.gglPointD!)
            }

            if self.gglPointE != nil {
                markers.append(self.gglPointE!)
            }

            self.animateGmsByBounds(markers: markers)
        } else {
            var markers = [MKAnnotation]()
            if self.osmPointA != nil {
                markers.append(self.osmPointA!)
            }
            
            if self.osmPointB != nil {
                markers.append(self.osmPointB!)
            }
            
            if self.osmPointC != nil {
                markers.append(self.osmPointC!)
            }
            
            if self.osmPointD != nil {
                markers.append(self.osmPointD!)
            }
            
            if self.osmPointE != nil {
                markers.append(self.osmPointE!)
            }
            
            if markers.count > 0 {
                self.animateOsmByBounds(markers: markers)
            }
        }
    }



    // MARK: - UICollectionViewDataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.validTariff.count
    }
    
    var isSettedTariff = false
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : TariffCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "tariff", for: indexPath) as! TariffCollectionViewCell
        cell.tariffImage.alpha = 0
        if self.tariffs == nil {
            self.tariffs = self.locCity().tariffs!
        }
        else {
            if self.tariffs?.count <= indexPath.row {
                self.tariffs = self.locCity().tariffs!
            }
        }
        cell.tariffName.text = self.validTariff[indexPath.row].tariffLabel
        //        print(self.tariffs![indexPath.row].tariffID)
        let curTariff = self.validTariff[indexPath.row]
        cell.tariffSelected.isHidden = !(self.curOrder?.orderTariff?.tariffID == curTariff.tariffID)
        cell.tariffSelected.backgroundColor = colorNewTint()
        
        var stted = false
        if curTariff.tariffLogoThumbString != nil {
            if curTariff.tariffLogoThumbString != "" {
                if curTariff.tariffLogoThumbImage == UIImage(named: "noCarImageSmall") {
                    let url = URL(string: validTariff[indexPath.row].tariffLogoThumbString!)
                    stted = true
                    cell.tariffImage.kf.setImage(with: url, completionHandler: {
                        (image, error, cacheType, imageUrl) in
                        if image == nil {
                            UIView.animate(withDuration: 0.1, animations: {
                                cell.tariffImage.image = curTariff.tariffLogoThumbImage
                                cell.tariffImage.alpha = 1
                            })
                        } else {
                            curTariff.tariffLogoThumbImage = image
                            
                            UIView.animate(withDuration: 0.1, animations: {
                                cell.tariffImage.alpha = 1
                            })
                        }
                    })
                }
            }
        }
        if stted == false {
            cell.tariffImage.image = curTariff.tariffLogoThumbImage
            if curTariff.tariffLogoThumbImage?.size.height > 0 {
                cell.tariffImage.image = curTariff.tariffLogoThumbImage
            }
            else {
                cell.tariffImage.image = UIImage(named: "noCarImageSmall")
            }
            cell.tariffImage.alpha = 1.0
        }
        return cell
    }
    
    //MARK: - UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.curOrder?.orderTariff?.tariffID == self.validTariff[indexPath.row].tariffID {
            let tariffController = UIStoryboard.tariffPickerViewController()!
            tariffController.modalPresentationStyle = .overCurrentContext
            tariffController.modalTransitionStyle = .crossDissolve
            tariffController.pickedIndex = indexPath.row
            tariffController.curOrder = self.curOrder
            DispatchQueue.main.async(execute: {
                self.navigationController?.present(tariffController, animated: true, completion: { () -> Void in
                    
                })
            });
        }
        self.curOrder?.orderTariff = validTariff[indexPath.row]
        var float1 = CGFloat(0)
        if indexPath.row > 0 {
            float1 = CGFloat((indexPath.row)*119)
        }
        var floatX = CGFloat(float1 - (collectionView.frame.width - 119)/2)
        if floatX > (self.tariffCollectionView.contentSize.width - self.tariffCollectionView.frame.width) {
            floatX = self.tariffCollectionView.contentSize.width - self.tariffCollectionView.frame.width
        }
        if floatX < 0 {
            floatX = CGFloat(0)
        }
        self.callCost()
        collectionView.setContentOffset(CGPoint(x: floatX, y: 0), animated: true)
        
        collectionView.reloadData()
    }
    

    
    func handleLongPress(_ gestureRecognizer : UILongPressGestureRecognizer){
        let p = gestureRecognizer.location(in: self.tariffCollectionView)
        
        if let indexPath : IndexPath = (self.tariffCollectionView.indexPathForItem(at: p)){
            let tariffController = UIStoryboard.tariffPickerViewController()!
            tariffController.modalPresentationStyle = .overCurrentContext
            tariffController.modalTransitionStyle = .crossDissolve
            tariffController.pickedIndex = indexPath.row
            tariffController.curOrder = self.curOrder
            DispatchQueue.main.async(execute: {
                self.navigationController?.present(tariffController, animated: true, completion: { () -> Void in
                    
                })
            });
        }
    }
    
    
    func getValidateTariffList() -> [Tariff] {
        var validateTariff = [Tariff]()
        for tariff in self.locCity().tariffs! {
            if tariff.clientTypes != nil {
                if tariff.clientTypes!.contains(profile().clientType!) {
                    if profile().clientType! == "base"
                        || (profile().clientType! == "company" && (tariff.companies?.contains(Int(defaultPayType().payCompanyID!)!))!) {
                        validateTariff.append(tariff)
                    }
                }
            }
        }
        return validateTariff
    }
    
    func updateTariffsCollection(_ city: City = City()) {
        if (self.validTariff.count > 0) {
            if let clientType = profile().clientType {
                if let tariffTemp: Tariff = self.curOrder?.orderTariff {
                    if (tariffTemp.clientTypes != nil) {
                        if !tariffTemp.clientTypes!.contains(clientType) {
                            self.curOrder?.orderTariff = self.validTariff[0]
                        }
                        if let companyId = Int(defaultPayType().payCompanyID!) {
                            if (tariffTemp.clientTypes!.contains("company") && !(tariffTemp.companies?.contains(companyId))!) {
                                self.curOrder?.orderTariff = self.validTariff[0]
                            }
                        }
                        if let cityId = city.cityID {
                            if locCity().cityID != cityId {
                                 self.currentCity = city
                                 self.validTariff = self.getValidateTariffList()
                                if (validTariff.count > 0) {
                                    self.curOrder?.orderTariff = self.validTariff[0]
                                }
                            }
                        }
                    }
                }
            }
        }
        self.tariffCollectionView.reloadData()
    }
    
    
    func updateTariffCollectionFrame() {
        var i = 0
        if self.validTariff.count > 0 {
            for tariff in self.validTariff {
                if tariff.tariffID == self.curOrder?.orderTariff?.tariffID {
                    var float1 = CGFloat(0)
                    if i > 0 {
                        float1 = CGFloat(i*119)
                    }
                    var floatX = CGFloat(float1 - (self.tariffCollectionView.frame.width - 119)/2)
                    if floatX > (self.tariffCollectionView.contentSize.width - self.tariffCollectionView.frame.width) {
                        floatX = self.tariffCollectionView.contentSize.width - self.tariffCollectionView.frame.width
                    }
                    if floatX < 0 {
                        floatX = CGFloat(0)
                    }
                    self.tariffCollectionView.setContentOffset(CGPoint(x: floatX, y: 0), animated: true)
                }
                i += 1
            }
        }
    }
    
    //MARK: work with timer for update geolocation
    
    func runTimer() {
        if loadAddressTimer != nil {
            loadAddressTimer?.invalidate()
            loadAddressTimer = nil
        }
        if self.countOfPaths() == 1 {
            if self.createdOrder != true {
                loadAddressTimer = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(MapViewController.updateGeoloc), userInfo: nil, repeats: false)
            }
        }
    }
    
    func updateGeoloc() {
        self.loading = true
        self.updateAddressView()
        var center : CLLocationCoordinate2D?
        if self.ftime == true {
            center = self.locationManager?.location?.coordinate
        }
        else {
            center = self.centerCoordinate()
        }
        if center == nil {
            center = self.centerCoordinate()
        }
        do {
            try self.gtCars()
        } catch {
            print("error while getting cars")
        }
        getAddressByCoords(center!, city: self.locCity() , completion: { (address: AddressTemp?, arr: [AddressTemp]) -> Void in
            self.approveAddress.isEnabled = true
            if self.createdOrder != true {
                if self.tableTop.constant != 0 {
                    if address != nil {
                        if address?.shortStrFromTempAddress() != strComNoAddrs() {
                            self.tableTop.constant = 0
                            UIView.animate(withDuration: 0.3, animations: {
                                self.tableView.layoutIfNeeded()
                            })
                        }
                    }
                    
                }
            }
            var setted : Bool = false
            if self.curOrder?.pathA != nil {
                if address != nil {
                    if self.curOrder?.pathA!.street == address!.street {
                        if self.curOrder?.pathA?.house == address!.house {
                            if self.curOrder?.pathA?.label == address?.label {
                                setted = true
                            }
                        }
                    }
                }
            }
            if self.curOrder?.pathA?.street == "" && self.curOrder?.pathA?.house == "" {
                setted = false
            }
            if setted == false {
                self.curOrder?.pathA = address
            }
            
            self.addresses = arr
            self.loading = false
            self.updateAddressView()
        }) { (error) -> Void in
        }
    }
    
   
    func callCost() {
        if self.createdOrder != true {
            if self.countOfPaths() > 1 && self.curOrder?.pathB != nil{
                self.loadingCostIndicator.isHidden = false
                self.loadingCostIndicator.startAnimating()
                self.costLabel.isHidden = true
                callCostForOrder(ord: self.curOrder!, completion: { (ccost) -> Void in
                    if ccost.isFixed == true {
                        self.costLabel.text = "\(strCCostFixPrice()) \(costStringFromDouble(ccost.cost!))"
                    }
                    else {
                        self.costLabel.text = "~ \(costStringFromDouble(ccost.cost!)), \(String(format: "%.1f", ccost.distance!)) \(strCCostKm()), \(String(format: "%.0f", ccost.time!)) \(strCCostMin())"
                    }
                    self.costLabel.isHidden = false
                    self.loadingCostIndicator.isHidden = true
                })
            }
            else {
                self.costLabel.text = strCCostPickB()
            }
        }
    }
    
    
    func gtCars() throws {
        
        if !createdOrder {
            if curCity().cityID != "" {
                if self.curCars == nil{
                    
                    let carsOptions = [
                        "from_lat" : "\(centerCoordinate().latitude)",
                        "from_lon" : "\(centerCoordinate().longitude)",
                        ]
                    gxGetCarsWith(carsOptions, completion: { (cars) -> Void in
                        
                            self.clearCarMarkers()
                            var anns = [MKAnnotation]()
                            self.curCars = cars
                            if curMap() == 0 || curMap() == 2 {
                                if self.curCarsAnnsOsm != nil {
                                    self.osmMap.removeAnnotations(self.curCarsAnnsOsm!)
                                }
                                
                                for car in cars! {
                                    let driv : MapPinCar = MapPinCar(coordinate: CLLocationCoordinate2DMake(car.lat, car.lon), title: "", subtitle: "")
                                    driv.car = car
                                    anns.append(driv)
                                }
                                self.curCarsAnnsOsm = anns
                                    self.osmMap.addAnnotations(anns)
                            }
                            else if curMap() == 1 {
                                if self.curCarsAnnsGgl != nil {
                                    self.gmsMap?.classForCoder
                                }
                                var anns = [GMSMarker]()
                                
                                for car in cars! {
                                    
                                    let coordinate = CLLocationCoordinate2DMake(car.lat, car.lon)
                                    let mark = GMSMarker(position: coordinate)
                                    mark.icon = UIImage(named: "carMapAngle")
                                    mark.rotation = car.course
                                    mark.map = self.gmsMap
                                    anns.append(mark)
                                    self.curCarsAnnsGgl = anns
                                    
                                }
                            }
                        }, failure: { (str) -> Void in
                            
                    })
                }
                else {
                    
                    self.curCars = nil
                }
            }
        }
    }

    
    func clearCarMarkers() {
        let OSMMap = 0
        let GisMap = 1
        self.gmsMap?.clear()
        if curMap() == OSMMap || curMap() == GisMap {
            if self.curCarsAnnsOsm != nil {
                self.osmMap.removeAnnotations(self.curCarsAnnsOsm!)
            }
        } else {
            if self.curCarsAnnsGgl != nil {
                for car in self.curCarsAnnsGgl! {
                    print("\(car.description)")
                    car.map = nil
                }
            }
        }
    }
    
    func addressTapped() {
        if self.point == "a" {
            if self.curOrder?.pathA != nil {
                self.performSegue(withIdentifier: "search", sender: self)
            }
        }
    }
    
    
    func invalidateCreateOrderTimer() {
        if (self.createOrderTimer != nil) {
            self.createOrderTimer?.invalidate()
            self.createOrderTimer = nil
        }
    }
    
    
    func createOrderProxy(_ canCreateOrder: Bool, sender: UIButton) {
        if canCreateOrder {
            if (createOrderTimer == nil) {
                createOrderTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.invalidateCreateOrderTimer), userInfo: nil, repeats: false)
            }
            else {
                return
            }
            self.addPathButton.isHidden = true
            createOrd(self.curOrder!, completion: { (order) -> Void in
                if order.orderID != nil {
                    let metricaParams = ["orderNumber" : order.orderID!]
                    let metricaMessage = "Order created"
                    YMMYandexMetrica.reportEvent(metricaMessage, parameters: metricaParams, onFailure: {error in
                        NSLog("error: %@", error.localizedDescription);
                    })
                    self.clearCarMarkers()
                    saveDefaultContext()
                    if order.statusID == "new" {
                        self.orderCreated = order
                        self.createdOrder = true
                        self.setStatus()
                        self.runUpdateOrder()
                    }
                    else {
                        self.updateTimer?.invalidate()
                        self.updateTimer = nil
                        
                        self.updateCarTimer?.invalidate()
                        self.updateCarTimer = nil
                        
                        self.updateReject?.invalidate()
                        self.updateReject = nil
                        
                        if (self.waitingDialog != nil) {
                            self.waitingDialog!.dismiss(animated: true, completion: nil)
                        }
                        
                        self.localize()
                        self.createdOrder = false
                        self.clearMap()
                        self.updViews()
                        self.curOrder = OrderTemp()
                        if self.curOrder?.orderTariff == nil {
                            if self.locCity().tariffs!.count > 0 {
                                self.curOrder?.orderTariff = self.locCity().tariffs![0]
                            }
                        }
                        self.tariffs = self.locCity().tariffs!
                        self.updateTableView()
                        
                        let viewController = UIStoryboard.preoderViewController()!
                        viewController.order = order
                        viewController.preOrder = true
                        let newNavController = UINavigationController()
                        newNavController.viewControllers = [viewController]
                        self.navigationController?.present(newNavController, animated: true, completion: nil)
                    }
                    if self.osmPointA != nil {
                        if curMap() == 0 || curMap() == 2 {
                            self.osmMap.removeAnnotation(self.osmPointA!)
                            self.osmPointA = nil
                        }
                    }
                    if self.gglPointA != nil {
                        if curMap() == 1 {
                            self.gglPointA!.map = nil
                            self.gglPointA = nil
                        }
                    }
                    self.invalidateCreateOrderTimer()
                    self.updViews()
                    sender.isEnabled = true
                }
                
                
            }) { (str) -> Void in
                self.invalidateCreateOrderTimer()
                sender.isEnabled = true
            }
        }
    }

    
    //MARK: - Order Update
    
    func updateOrderz(_ notification: Notification) {
        
        if self.createdOrder == true {
            if notification.object != nil {
                if notification.object is Order {
                    self.orderCreated = notification.object as? Order
                }
            }
            if (self.orderCreated!.statusID != "completed") || (self.orderCreated!.statusID != "rejected") {
                self.setStatus()
            }
        }
        else {
            self.openOrder()
        }
    }
    
    func setStatus() {
        if self.orderCreated != nil {
            switch (self.orderCreated?.statusID)! {
            case "new", "New" :
                self.curOrderStatus = .new
            case "car_assigned", "carAssigned" :
                self.curOrderStatus = .carAssigned
            case "car_at_place" :
                self.curOrderStatus = .carAtPlace
            case "rejected" :
                self.curOrderStatus = .rejected
            case "executing" :
                self.curOrderStatus = .executing
            case "completed" :
                self.curOrderStatus = .completed
            default :
                self.curOrderStatus = .new
            }
            if self.curOrderStatus != .new {
                if self.curOrderStatus == .carAssigned {
                    if self.orderCreated?.carAssigningDateTime == nil {
                        self.orderCreated?.carAssigningDateTime = Date()
                        self.playBeep()
                    }
                    if curMap() == 0 || curMap() == 2 {
                        if self.osmTimePoint == nil {
                            self.osmTimePoint = TimeAnnotation(coordinate: CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!), title: "", subtitle: "")
                            self.osmMap.addAnnotation(self.osmTimePoint!)
                            if self.osmPointA != nil {
                                self.osmMap.removeAnnotation(self.osmPointA!)
                                self.osmPointA = nil
                            }
                            self.setStatus()
                        }
                        else {
                            let annView : TimeAnnotationView? = self.osmMap.view(for: self.osmTimePoint!) as? TimeAnnotationView
                            if annView != nil {
                                annView!.timeLabel!.text = self.timeToCar()
                            }
                        }
                    } else if curMap() == 1 {
                        if self.gglTimePoint == nil {
                            let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                            self.gglTimePoint = GMSMarker(position: position)
                            self.gglTimePoint!.icon = imageFromView(TimeAnnotationView(annotation: TimeAnnotation(coordinate: position, title: "", subtitle: ""), reuseIdentifier: "", time: self.timeToCar()))
                            self.gglTimePoint!.map = self.gmsMap
                            if self.gglPointA != nil {
                                self.gglPointA!.map = nil
                                self.gglPointA = nil
                            }
                            self.setStatus()
                        }
                        else {
                            let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                            self.gglTimePoint!.icon = imageFromView(TimeAnnotationView(annotation: TimeAnnotation(coordinate: position, title: "", subtitle: ""), reuseIdentifier: "", time: self.timeToCar()))
                        }
                    }
                }
                if self.curOrderStatus == .carAtPlace {
                    if self.orderCreated?.carAtPlaceDateTime == nil {
                        self.orderCreated?.carAtPlaceDateTime = Date()
                        self.playBeep()
                    }
                }
                if curMap() == 0 || curMap() == 2 {
                    var anns = [MKAnnotation]()
                    //var setted = false
                    for annotation in self.osmMap.annotations {
                        if self.driverOsmLoc != nil {
                            if !(annotation is MapPinCarDriver) {
                                if !(annotation is TimeAnnotation) {
                                    if !(annotation is PointAnnotation) {
                                        anns.append(annotation)
                                    }
                                }
                                else {
                                    if self.curOrderStatus != .carAssigned {
                                        anns.append(annotation)
                                        self.osmTimePoint = nil
                                    }
                                }
                            }
                        }
                        else {
                            self.setDriver()
                            if self.driverOsmLoc == nil {
                                anns = self.osmMap.annotations
                            }
                        }
                    }
                    self.osmMap.removeAnnotations(anns)
                }
                else if curMap() == 1 {
                    if self.curCarsAnnsGgl != nil {
                        for marker in self.curCarsAnnsGgl! {
                            marker.map = nil
                        }
                        self.curCarsAnnsGgl = nil
                    }
                    if self.curOrderStatus != .carAssigned {
                        if self.gglTimePoint != nil {
                            self.gglTimePoint!.map = nil
                            self.gglTimePoint = nil
                        }
                    }
                    self.driverGglLoc?.map = nil
                    if self.driverGglLoc == nil {
                        self.setDriver()
                    } else {
                        self.driverGglLoc!.map = self.gmsMap
                    }
                }
                self.removeAnnns()
                self.setAnns()
            }
            
            if self.orderCreated?.statusLabel != "" {
                self.navigationItem.title = self.orderCreated?.statusLabel
            }
            
            if self.curOrderStatus == .completed || self.curOrderStatus == .rejected {
                self.updateTimer?.invalidate()
                self.updateTimer = nil
                
                self.updateCarTimer?.invalidate()
                self.updateCarTimer = nil
                
                self.updateReject?.invalidate()
                self.updateReject = nil
                
                if (self.waitingDialog != nil) {
                    self.waitingDialog!.dismiss(animated: true, completion: nil)
                }
                
                self.ftime = true
                locationManager = CLLocationManager()
                locationManager?.delegate = self
                locationManager?.requestWhenInUseAuthorization()
                locationManager?.desiredAccuracy = kCLLocationAccuracyBest
                locationManager?.startUpdatingLocation()
                
                self.localize()
                self.createdOrder = false
                self.updViews()
                for wish in (self.curOrder?.orderWishes)! {
                    wish.isChecked = false
                }
                self.curOrder = OrderTemp()
                if self.curOrder?.orderTariff == nil {
                    if self.locCity().tariffs!.count > 0 {
                        self.curOrder?.orderTariff = self.locCity().tariffs![0]
                    }
                }
                self.tariffs = self.locCity().tariffs!
                updateTableView()

                if self.curOrderStatus == .completed {
                    let navController = UIStoryboard.orderSummaryViewController()!
                    let controller : OrderSummaryViewController = navController.viewControllers[0] as! OrderSummaryViewController
                    controller.curOrd = self.orderCreated
                    controller.modalPresentationStyle = .overCurrentContext
                    self.navigationController?.present(navController, animated: true, completion: nil)
                }
                else {
                    let finishedController : FinishedOrderViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "completed") as! FinishedOrderViewController
                    finishedController.order = self.orderCreated
                    self.navigationController?.pushViewController(finishedController, animated: true)
                }
                self.clearMap()
            }
            //        self.setRejecting()
            self.setButtonsState()
        }
        saveDefaultContext()
    }
    
    func setButtonsState() {
        if (self.curOrderStatus != .new) && (self.curOrderStatus != .carAssigned) {
            self.rejectButton.isEnabled = false
            self.rejectLabel.textColor = colorGrayLabelText()
            self.rejectLogo.image = self.rejectLogo.image!.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
            self.rejectLogo.tintColor = UIColor(red: 200/255, green: 200/255, blue: 200/255, alpha: 1)
        }
        else {
            self.rejectButton.isEnabled = true
            self.rejectLabel.textColor = colorMainText()
            self.rejectLogo.image = self.rejectLogo.image!.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
            self.rejectLogo.tintColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        }
        if useCalls && (needOfficeCall || needDriverCall) && (self.orderCreated?.driver != nil)  && (self.orderCreated?.driver?.phone != "") || (dispPhone() != "") {
            self.callButton.isEnabled = true
            self.callLabel.textColor = colorMainText()
            self.callLogo.image = self.callLogo.image!.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
            self.callLogo.tintColor = UIColor(red: 154/255, green: 154/255, blue: 154/255, alpha: 1)
        }
        else {
            self.callButton.isEnabled = false
            self.callLabel.textColor = colorGrayLabelText()
            self.callLogo.image = self.callLogo.image!.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
            self.callLogo.tintColor = UIColor(red: 200/255, green: 200/255, blue: 200/255, alpha: 1)
        }
    }

    func playBeep() {
        if let soundURL = Bundle.main.url(forResource: "sound_beep", withExtension: "aiff") {
            var mySound: SystemSoundID = 0
            AudioServicesCreateSystemSoundID(soundURL as CFURL, &mySound)
            AudioServicesPlaySystemSound(mySound);
        }
    }
    
    func runUpdateOrder() {
        self.updateOrder()
        if self.updateTimer == nil {
            self.updateTimer = Timer.scheduledTimer(timeInterval: Double(self.updateInterval), target: self, selector: #selector(MapViewController.updateOrder), userInfo: "", repeats: true)
        }
    }
    
    func updateOrder() {
        if self.orderCreated != nil {
            updOrder(self.orderCreated!) { (order) -> Void in
                self.orderCreated = order
                self.setStatus()
                self.setDriver()
                self.setOrderCamera()
            }
        }
    }
    
    func setDriver() {
        if self.createdOrder {
            if self.orderCreated?.driver != nil {
                if (self.orderCreated?.driver?.name != "") && (self.orderCreated?.driver?.name != nil) {
                    self.driverName.text = self.orderCreated?.driver?.carModel
                    self.driverCar.text = self.orderCreated?.driver?.name
                    
                    self.driverTopConstraint.constant = 10
                    
                    UIView.animate(withDuration: 0.3, animations: { () -> Void in
                        self.driverView.layoutIfNeeded()
                    })
                    
                    if self.orderCreated?.driver?.rate == nil {
                        self.driverMark.isHidden = true
                        self.driverStar.isHidden = true
                    }
                    else {
                        if self.orderCreated?.driver?.rate?.doubleValue != 0 {
                            self.driverStar.isHidden = false
                            self.driverMark.isHidden = false
                            self.driverMark.text = NSString(format: "%.1f", (self.orderCreated?.driver?.rate?.doubleValue)!) as String
                        }
                        else {
                            self.driverMark.isHidden = true
                            self.driverStar.isHidden = true
                        }
                    }
                    
                    var setted = false
                    
                    if self.orderCreated?.driver != nil {
                        if self.orderCreated?.driver?.photo != nil {
                            if self.orderCreated?.driver?.loadedPhoto != nil {
                                self.driverPhoyo.image = UIImage(data: (self.orderCreated?.driver?.loadedPhoto)! as Data)
                                setted = true
                            }
                        }
                    }
                    
                    if self.orderCreated?.driver?.photo != nil {
                        if setted == false {
                            let url = URL(string: (self.orderCreated?.driver?.photo!)!)
                            self.driverPhoyo.kf.setImage(with: url, completionHandler: {
                                (image, error, cacheType, imageUrl) in
                                if image == nil {
                                    self.orderCreated?.driver?.loadedPhoto = UIImageJPEGRepresentation(UIImage(named: "driver")!, 1.0)
                                    self.driverPhoyo.image = UIImage(named: "driver")
                                } else {
                                    self.orderCreated?.driver?.loadedPhoto = UIImageJPEGRepresentation(image!, 1.0)
                                }
                                saveDefaultContext()
                            })
                        }
                    }
                    
                    
                }
                if curMap() == 0 || curMap() == 2 {
                    if self.driverOsmLoc == nil {
                        if self.orderCreated?.driver?.lat != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                            if self.orderCreated?.driver?.lon != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                                self.driverOsmLoc = MapPinCarDriver(coordinate: CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!), title: "", subtitle: "")
                                self.osmMap.addAnnotation(self.driverOsmLoc!)
                                var region : MKCoordinateRegion = MKCoordinateRegion()
                                var span : MKCoordinateSpan = MKCoordinateSpan()
                                span.latitudeDelta = 0.005
                                span.longitudeDelta = 0.005
                                region.span = span
                                region.center = CLLocationCoordinate2D(latitude: (self.orderCreated?.driver?.lat?.doubleValue)!, longitude: (self.orderCreated?.driver?.lon?.doubleValue)!)
                                self.osmMap.setRegion(region, animated: true)
                                if self.curOrderStatus == .carAssigned {
                                    if self.osmTimePoint == nil {
                                        self.osmTimePoint = TimeAnnotation(coordinate: CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!), title: "", subtitle: "")
                                        self.osmMap.addAnnotation(self.osmTimePoint!)
                                        if self.osmPointA != nil {
                                            self.osmMap.removeAnnotation(self.osmPointA!)
                                            self.osmPointA = nil
                                        }
                                        self.setStatus()
                                    }
                                }
                            }
                        }
                    }
                    else {
                        if self.orderCreated?.driver?.lat != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                            if self.orderCreated?.driver?.lon != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                                UIView.animate(withDuration: 5.2, delay: 0, options: [.curveLinear, .beginFromCurrentState], animations: { () -> Void in
                                    if self.driverOsmLoc != nil {
                                        self.driverOsmLoc?.coordinate = CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!)
                                        /*let newCamera = self.osmMap.camera
                                        newCamera.centerCoordinate = CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!)
                                        self.osmMap.camera = newCamera*/
                                        
                                        let aView = self.osmMap.view(for: self.driverOsmLoc!)
                                        if aView != nil {
                                            if self.orderCreated?.driver?.angle != nil {
                                                aView!.image = carMapImage().imageRotatedByDegrees(CGFloat((self.orderCreated?.driver?.angle!.doubleValue)!), flip: false)
                                            }
                                            else {
                                                aView!.image = UIImage(named: imageCarNoAngle())
                                            }
                                        }
                                    }
                                    }, completion: { (finished) -> Void in
                                        
                                })
                            }
                        }
                    }
                }
                else if curMap() == 1 {
                    
                    if self.driverGglLoc == nil {
                        if self.orderCreated?.driver?.lat != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                            if self.orderCreated?.driver?.lon != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                                let position = CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!)
                                self.driverGglLoc = GMSMarker(position: position)
                                self.driverGglLoc!.icon = carMapImage()
                                if self.orderCreated?.driver?.angle != nil {
                                    self.driverGglLoc?.rotation = (self.orderCreated?.driver?.angle?.doubleValue)!
                                }
                                self.driverGglLoc!.map = self.gmsMap
                                if self.curOrderStatus == .carAssigned {
                                    if self.gglTimePoint == nil {
                                        let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                                        self.gglTimePoint = GMSMarker(position: position)
                                        self.gglTimePoint!.icon = imageFromView(TimeAnnotationView(annotation: TimeAnnotation(coordinate: position, title: "", subtitle: ""), reuseIdentifier: "", time: self.timeToCar()))
                                        self.gglTimePoint?.isFlat = true
                                        self.gglTimePoint!.map = self.gmsMap
                                        
                                        if self.gglPointA != nil {
                                            self.gglPointA!.map = nil
                                            self.gglPointA = nil
                                        }
                                        self.setStatus()
                                    }
                                }
                            }
                        }
                    }
                    else {
                        if self.orderCreated?.driver?.lat != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                            if self.orderCreated?.driver?.lon != nil && self.orderCreated?.driver?.lat != NSNumber(value: 0 as Double) {
                                
                                let cameraPosition = GMSCameraPosition(target: CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!), zoom: self.gmsMap!.camera.zoom, bearing: 0, viewingAngle: 0)
                                
                                
                                let zoomIn = GMSCameraUpdate.setCamera(cameraPosition)
                                CATransaction.begin()
                                CATransaction.setValue(5.2, forKey: kCATransactionAnimationDuration)
                                self.gmsMap?.animate(with: zoomIn)
                                CATransaction.commit()
                                let position = CLLocationCoordinate2DMake((self.orderCreated?.driver?.lat?.doubleValue)!, (self.orderCreated?.driver?.lon?.doubleValue)!)
                                CATransaction.begin()
                                CATransaction.setAnimationDuration(5.2)
                                self.driverGglLoc!.position = position
                                if self.orderCreated?.driver?.angle != nil {
                                    self.driverGglLoc?.rotation = (self.orderCreated?.driver?.angle?.doubleValue)!
                                }
                                CATransaction.commit()
                            }
                        }
                    }
                    
                }
                
            }
            else {
                self.driverTopConstraint.constant = -86
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.driverView.layoutIfNeeded()
                })
            }
        }
    }

    
    
    func setOsmAnnotations() {
        if curMap() == 0 {
            if self.osmPointA == nil {
                self.osmPointA = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue), title: "", subtitle: "", point: "A")
                self.osmMap.addAnnotation(self.osmPointA!)
            }
            else {
                self.osmPointA?.coordinate = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
            }
            
            if #available(iOS 9.0, *) {
                self.osmMap.showsCompass = false
            }
            let overlay = MKTileOverlay(urlTemplate: kOSMTiles)
            overlay.canReplaceMapContent = true
            osmMap.add(overlay, level: MKOverlayLevel.aboveLabels)
            if let currentOverlay = self.currentOverlay {
                osmMap.remove(currentOverlay)
            }
            currentOverlay = overlay
        } else if curMap() == 1 {
            if self.gglPointA == nil {
                let position = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
                self.gglPointA = GMSMarker(position: position)
                self.gglPointA!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "A"), reuseIdentifier: "", point: "A"))
                self.gglPointA!.map = self.gmsMap;
            }
            if self.curOrderStatus == .new {
                if self.gglCircle == nil {
                    delay(0.5, closure: {
                        let position = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
                        self.gglCircle = TCCircle(position: position, radius: 10)
                        self.gglCircle!.map = self.gmsMap
                        self.gglCircle!.fillColor = UIColor.clear
                        self.gglCircle!.beginCircleAnimation(3)
                        self.gmsMap?.animate(toZoom: 15)
                        self.gmsMap?.animate(toLocation: position)
                    })
                    
                }
            }  else {
                if self.gglCircle != nil {
                    self.gglCircle?.stop()
                    self.gglCircle?.map = nil
                    self.gglCircle = nil
                }
            }
        } else if curMap() == 2 {
            if self.osmPointA == nil {
                self.osmPointA = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue), title: "", subtitle: "", point: "A")
                self.osmMap.addAnnotation(self.osmPointA!)
            }
            else {
                self.osmPointA?.coordinate = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
            }
            
            if #available(iOS 9.0, *) {
                self.osmMap.showsCompass = false
            }
            
          
            let tilesOverlay = DGSTileOverlay()
            tilesOverlay.canReplaceMapContent = true
            osmMap.add(tilesOverlay, level: MKOverlayLevel.aboveLabels)
            if let currentOverlay = self.currentOverlay {
                osmMap.remove(currentOverlay)
            }
            currentOverlay = tilesOverlay
        }
    }
    
    
    
    func setAnns() {
        let count = countOfPaths()
        if curMap() == 0 || curMap() == 2 {
            if self.createdOrder == false {
                var annsForAdd : [PointAnnotation]? = [PointAnnotation]()
                var annsForRemove : [PointAnnotation]? = [PointAnnotation]()
                
                if self.osmPointE != nil {
                    if count < 5 {
                        annsForRemove?.append(self.osmPointE!)
                        self.osmPointE = nil
                    }
                }
                if self.osmPointD != nil {
                    if count < 4 {
                        annsForRemove?.append(self.osmPointD!)
                        self.osmPointD = nil
                    }
                }
                if self.osmPointC != nil {
                    if count < 3 {
                        annsForRemove?.append(self.osmPointC!)
                        self.osmPointC = nil
                    }
                }
                if self.osmPointB != nil {
                    if count < 2 {
                        annsForRemove?.append(self.osmPointB!)
                        self.osmPointB = nil
                    }
                }
                if self.osmPointA != nil {
                    if count == 1 {
                        annsForRemove?.append(self.osmPointA!)
                        self.osmPointA = nil
                    }
                }
                
                if count > 1 {
                    if self.osmPointB == nil {
                        self.osmPointB = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.curOrder!.pathB!.lat!, self.curOrder!.pathB!.lon!), title: "", subtitle: "", point: "B")
                        annsForAdd?.append(self.osmPointB!)
                    }
                    if self.osmPointA == nil {
                        self.osmPointA = PointAnnotation(coordinate: CLLocationCoordinate2DMake((self.curOrder?.pathA!.lat!)!, (self.curOrder?.pathA!.lon!)!), title: "", subtitle: "", point: "A")
                        annsForAdd?.append(self.osmPointA!)
                        
                    }
                    else {
                        self.osmPointA?.coordinate = CLLocationCoordinate2DMake((self.curOrder?.pathA!.lat!)!, (self.curOrder?.pathA!.lon!)!)
                    }
                    self.userCenter.alpha = 0
                    self.userCenterLabel.alpha = 0
                    self.annBorderOut.alpha = 0
                    if count > 2 {
                        if self.osmPointC == nil {
                            self.osmPointC = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.curOrder!.pathC!.lat!, self.curOrder!.pathC!.lon!), title: "", subtitle: "", point: "C")
                            annsForAdd?.append(self.osmPointC!)
                        }
                        if count > 3 {
                            if self.osmPointD == nil {
                                self.osmPointD = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.curOrder!.pathD!.lat!, self.curOrder!.pathD!.lon!), title: "", subtitle: "", point: "D")
                                annsForAdd?.append(self.osmPointD!)
                            }
                        }
                        if count > 4 {
                            if self.osmPointE == nil {
                                self.osmPointE = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.curOrder!.pathE!.lat!, self.curOrder!.pathE!.lon!), title: "", subtitle: "", point: "E")
                                annsForAdd?.append(self.osmPointE!)
                            }
                        }
                    }
                }
                else {
                    self.userCenter.alpha = 1
                    self.userCenterLabel.alpha = 1
                    self.annBorderOut.alpha = 1
                }
                if annsForAdd?.count > 0 {
                    self.osmMap.addAnnotations(annsForAdd!)
                }
                
                if annsForRemove?.count > 0 {
                    self.osmMap.removeAnnotations(annsForRemove!)
                }
            }
            else {
                var annsForAdd : [PointAnnotation]? = [PointAnnotation]()
                
                if self.curOrderStatus == .carAssigned {
                    if self.osmTimePoint == nil {
                        self.osmTimePoint = TimeAnnotation(coordinate: CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!), title: "", subtitle: "")
                        self.osmMap.addAnnotation(self.osmTimePoint!)
                        if self.osmPointA != nil {
                            self.osmMap.removeAnnotation(self.osmPointA!)
                            self.osmPointA = nil
                        }
                        self.setStatus()
                    }
                }
                else {
                    if self.osmPointA == nil {
                        self.osmPointA = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue), title: "", subtitle: "", point: "A")
                        annsForAdd?.append(self.osmPointA!)
                    }
                    
                }
                
                if count > 1 {
                    if self.osmPointB == nil {
                        self.osmPointB = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointB!.lat.doubleValue, self.orderCreated!.pointB!.lon.doubleValue), title: "", subtitle: "", point: "B")
                        annsForAdd?.append(self.osmPointB!)
                    }
                    if count > 2 {
                        if self.osmPointC == nil {
                            self.osmPointC = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointC!.lat.doubleValue, self.orderCreated!.pointC!.lon.doubleValue), title: "", subtitle: "", point: "C")
                            annsForAdd?.append(self.osmPointC!)
                        }
                        if count > 3 {
                            if self.osmPointD == nil {
                                self.osmPointD = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointD!.lat.doubleValue, self.orderCreated!.pointD!.lon.doubleValue), title: "", subtitle: "", point: "D")
                                annsForAdd?.append(self.osmPointD!)
                            }
                            if count > 4 {
                                if self.osmPointE == nil {
                                    self.osmPointE = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.orderCreated!.pointE!.lat.doubleValue, self.orderCreated!.pointE!.lon.doubleValue), title: "", subtitle: "", point: "E")
                                    annsForAdd?.append(self.osmPointE!)
                                }
                            }
                        }
                    }
                }
                if annsForAdd?.count > 0 {
                    self.osmMap.addAnnotations(annsForAdd!)
                }
                
            }
        } else if curMap() == 1 {
            if self.createdOrder == false {
                
                if self.gglPointE != nil {
                    if count < 5 {
                        self.gglPointE!.map = nil
                        self.gglPointE = nil
                    }
                }
                if self.gglPointD != nil {
                    if count < 4 {
                        self.gglPointD!.map = nil
                        self.gglPointD = nil
                    }
                }
                if self.gglPointC != nil {
                    if count < 3 {
                        self.gglPointC!.map = nil
                        self.gglPointC = nil
                    }
                }
                if self.gglPointB != nil {
                    if count < 2 {
                        self.gglPointB!.map = nil
                        self.gglPointB = nil
                    }
                }
                if self.gglPointA != nil {
                    if count == 1 {
                        self.gglPointA!.map = nil
                        self.gglPointA = nil
                    }
                }
                
                if count > 1 && self.curOrder?.pathB != nil {
                    if self.gglPointB == nil {
                        let position = CLLocationCoordinate2DMake(self.curOrder!.pathB!.lat!, self.curOrder!.pathB!.lon!)
                        NSLog("Logos", "Location \(position)")
                        self.gglPointB = GMSMarker(position: position)
                        self.gglPointB!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "B"), reuseIdentifier: "", point: "B"))
                        self.gglPointB!.map = self.gmsMap;
                    }
                    else {
                        let position = CLLocationCoordinate2DMake(self.curOrder!.pathB!.lat!, self.curOrder!.pathB!.lon!)
                        self.gglPointB?.position = position
                        NSLog("Logos", "Location \(position)")
                    }
                    if self.gglPointA == nil {
                        let position = CLLocationCoordinate2DMake((self.curOrder?.pathA!.lat!)!, (self.curOrder?.pathA!.lon!)!)
                        self.gglPointA = GMSMarker(position: position)
                        self.gglPointA!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "A"), reuseIdentifier: "", point: "A"))
                        self.gglPointA!.map = self.gmsMap;
                    }
                    else {
                        self.gglPointA!.map = nil
                        self.gglPointA = nil
                        let position = CLLocationCoordinate2DMake((self.curOrder?.pathA!.lat!)!, (self.curOrder?.pathA!.lon!)!)
                        self.gglPointA = GMSMarker(position: position)
                        self.gglPointA!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "A"), reuseIdentifier: "", point: "A"))
                        self.gglPointA!.map = self.gmsMap;
                    }
                    self.userCenter.alpha = 0
                    self.userCenterLabel.alpha = 0
                    self.annBorderOut.alpha = 0
                    if count > 2 {
                        if self.gglPointC == nil {
                            let position = CLLocationCoordinate2DMake(self.curOrder!.pathC!.lat!, self.curOrder!.pathC!.lon!)
                            self.gglPointC = GMSMarker(position: position)
                            self.gglPointC!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "C"), reuseIdentifier: "", point: "C"))
                            self.gglPointC!.map = self.gmsMap;
                        }
                        else {
                            let position = CLLocationCoordinate2DMake(self.curOrder!.pathC!.lat!, self.curOrder!.pathC!.lon!)
                            self.gglPointC?.position = position
                        }
                        if count > 3 {
                            if self.gglPointD == nil {
                                let position = CLLocationCoordinate2DMake(self.curOrder!.pathD!.lat!, self.curOrder!.pathD!.lon!)
                                self.gglPointD = GMSMarker(position: position)
                                self.gglPointD!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "D"), reuseIdentifier: "", point: "D"))
                                self.gglPointD!.map = self.gmsMap;
                            }
                            else {
                                let position = CLLocationCoordinate2DMake(self.curOrder!.pathD!.lat!, self.curOrder!.pathD!.lon!)
                                self.gglPointD?.position = position
                            }
                        }
                        if count > 4 {
                            if self.gglPointE == nil {
                                let position = CLLocationCoordinate2DMake(self.curOrder!.pathE!.lat!, self.curOrder!.pathE!.lon!)
                                self.gglPointE = GMSMarker(position: position)
                                self.gglPointE!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "E"), reuseIdentifier: "", point: "E"))
                                self.gglPointE!.map = self.gmsMap;
                            }
                            else {
                                let position = CLLocationCoordinate2DMake(self.curOrder!.pathE!.lat!, self.curOrder!.pathE!.lon!)
                                self.gglPointE?.position = position
                            }
                        }
                    }
                    self.setPointsCamera()
                }
                else {
                    self.userCenter.alpha = 1
                    self.userCenterLabel.alpha = 1
                    self.annBorderOut.alpha = 1
                }
            }
            else {
                if self.curOrderStatus == .carAssigned {
                    if self.gglTimePoint == nil {
                        let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                        self.gglTimePoint = GMSMarker(position: position)
                        self.gglTimePoint!.icon = imageFromView(TimeAnnotationView(annotation: TimeAnnotation(coordinate: position, title: "", subtitle: ""), reuseIdentifier: "", time: self.timeToCar()))
                        self.gglTimePoint!.map = self.gmsMap
                        self.setStatus()
                    }
                    else {
                        let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                        self.gglTimePoint?.position = position
                    }
                }
                else {
                    if self.gglPointA == nil {
                        let position = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
                        self.gglPointA = GMSMarker(position: position)
                        self.gglPointA!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "A"), reuseIdentifier: "", point: "A"))
                        self.gglPointA!.map = self.gmsMap;
                    }
                    else {
                        let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointA?.lat.doubleValue)!, longitude: (self.orderCreated?.pointA?.lon.doubleValue)!)
                        self.gglPointA?.position = position
                    }
                }
                
                if self.curOrderStatus == .new {
                    if self.gglCircle == nil {
                        let position = CLLocationCoordinate2DMake(self.orderCreated!.pointA!.lat.doubleValue, self.orderCreated!.pointA!.lon.doubleValue)
                        self.gglCircle = TCCircle(position: position, radius: 10)
                        self.gglCircle!.map = self.gmsMap
                        self.gglCircle!.fillColor = UIColor.clear
                        self.gglCircle!.beginCircleAnimation(3)
                        self.gmsMap?.animate(toZoom: 15)
                        self.gmsMap?.animate(toLocation: position)
                    }
                }
                else {
                    if self.gglCircle != nil {
                        self.gglCircle?.stop()
                        self.gglCircle?.map = nil
                        self.gglCircle = nil
                    }
                }
                if count > 1 {
                    if self.gglPointB == nil {
                        let position = CLLocationCoordinate2DMake(self.orderCreated!.pointB!.lat.doubleValue, self.orderCreated!.pointB!.lon.doubleValue)
                        self.gglPointB = GMSMarker(position: position)
                        NSLog("Logos", "Location \(position)")
                        self.gglPointB!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "B"), reuseIdentifier: "", point: "B"))
                        self.gglPointB!.map = self.gmsMap;
                    }
                    else {
                        let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointB?.lat.doubleValue)!, longitude: (self.orderCreated?.pointB?.lon.doubleValue)!)
                        self.gglPointB?.position = position
                        NSLog("Logos", "Location \(position)")
                    }
                    if count > 2 {
                        if self.gglPointC == nil {
                            let position = CLLocationCoordinate2DMake(self.orderCreated!.pointC!.lat.doubleValue, self.orderCreated!.pointC!.lon.doubleValue)
                            self.gglPointC = GMSMarker(position: position)
                            self.gglPointC!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "C"), reuseIdentifier: "", point: "C"))
                            self.gglPointC!.map = self.gmsMap;
                        }
                        else {
                            let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointC?.lat.doubleValue)!, longitude: (self.orderCreated?.pointC?.lon.doubleValue)!)
                            self.gglPointC?.position = position
                        }
                        if count > 3 {
                            if self.gglPointD == nil {
                                let position = CLLocationCoordinate2DMake(self.orderCreated!.pointD!.lat.doubleValue, self.orderCreated!.pointD!.lon.doubleValue)
                                self.gglPointD = GMSMarker(position: position)
                                self.gglPointD!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "D"), reuseIdentifier: "", point: "D"))
                                self.gglPointD!.map = self.gmsMap;
                            }
                            else {
                                let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointD?.lat.doubleValue)!, longitude: (self.orderCreated?.pointD?.lon.doubleValue)!)
                                self.gglPointD?.position = position
                            }
                        }
                        if count > 4 {
                            if self.gglPointE == nil {
                                let position = CLLocationCoordinate2DMake(self.orderCreated!.pointE!.lat.doubleValue, self.orderCreated!.pointE!.lon.doubleValue)
                                self.gglPointE = GMSMarker(position: position)
                                self.gglPointE!.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "E"), reuseIdentifier: "", point: "E"))
                                self.gglPointE!.map = self.gmsMap;
                            }
                            else {
                                let position = CLLocationCoordinate2D(latitude: (self.orderCreated?.pointE?.lat.doubleValue)!, longitude: (self.orderCreated?.pointE?.lon.doubleValue)!)
                                self.gglPointE?.position = position
                            }
                        }
                    }
                }
            }
        }
    }
    
    func removeAnns() {
        if curMap() == 0 || curMap() == 2 {
            var annsForRemove : [PointAnnotation]? = [PointAnnotation]()
            
            if self.osmPointE != nil {
                annsForRemove?.append(self.osmPointE!)
                self.osmPointE = nil
            }
            if self.osmPointD != nil {
                annsForRemove?.append(self.osmPointD!)
                self.osmPointD = nil
            }
            if self.osmPointC != nil {
                annsForRemove?.append(self.osmPointC!)
                self.osmPointC = nil
            }
            if self.osmPointB != nil {
                annsForRemove?.append(self.osmPointB!)
                self.osmPointB = nil
            }
            if annsForRemove?.count > 0 {
                self.osmMap.removeAnnotations(annsForRemove!)
            }
        }
        else if curMap() == 1 {
            if self.gglPointA != nil {
                self.gglPointA!.map = nil
                self.gglPointA = nil
            }
            if self.gglPointB != nil {
                self.gglPointB!.map = nil
                self.gglPointB = nil
            }
            if self.gglPointC != nil {
                self.gglPointC!.map = nil
                self.gglPointC = nil
            }
            if self.gglPointD != nil {
                self.gglPointD!.map = nil
                self.gglPointD = nil
            }
            if self.gglPointE != nil {
                self.gglPointE!.map = nil
                self.gglPointE = nil
            }
        }
    }
    
    //MARK: UIAlertViewDelegate

    func alertView(_ alertView: UIAlertView, didDismissWithButtonIndex buttonIndex: Int) {
        if alertView == self.rejectDialog {
            if self.gglCircle != nil {
                self.gglCircle?.beginCircleAnimation(3)
            }
            if buttonIndex == 0 {
                rejectOrd(self.orderCreated!, completion: { (res) -> Void in
                    if res {
                        self.rejectCurrentOrder()
                        self.waitingDialog  = UIAlertController(title: nil, message: strComRejecting(), preferredStyle: UIAlertControllerStyle.alert)
                        
                        let spinnerIndicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
                        
                        spinnerIndicator.center = CGPoint(x: 135.0, y: 65.5)
                        spinnerIndicator.color = UIColor.black
                        spinnerIndicator.startAnimating()
                        
                        self.waitingDialog!.view.addSubview(spinnerIndicator)
                        self.present(self.waitingDialog!, animated: false, completion: nil)
        
                    }
                }) { (str) -> Void in
                }
            }
        }
    }
    
    
    func rejectCurrentOrder() {
        rejectOrderResult(self.orderCreated!, completion: { (res) -> Void in
            switch (res) {
            case "complete":
                if (self.waitingDialog != nil) {
                    
                }
            case "error":
                self.updateReject?.invalidate()
                self.updateReject = nil
                
                if self.waitingDialog != nil {
                    self.waitingDialog!.dismiss(animated: true, completion: {
                        showMessage(strComNotificationTitle(), message: strErrRejectOrder())
                    })
                }
                
                break;
            case "process":
                if self.countReject > 5 {
                    if (self.waitingDialog != nil) {
                        self.waitingDialog!.dismiss(animated: true, completion: {
                            self.acceptRejectOrder()
                        })
                        self.countReject = 0
                    }
                } else {
                    self.countReject += 1
                    if self.updateReject == nil {
                        self.updateReject =
                                Timer.scheduledTimer(timeInterval: Double(self.updateIntervalReject), target: self, selector: #selector(MapViewController.rejectCurrentOrder), userInfo: "", repeats: false)
                    }
                }
            default:
                break;
            }
        }) { (str) -> Void in
            if (self.waitingDialog != nil) {
                self.waitingDialog!.dismiss(animated: true, completion: nil)
            }
            
            self.updateReject?.invalidate()
            self.updateReject = nil
        }
    }
    
    
    func acceptRejectOrder() {
        self.orderCreated!.statusID = "rejected"
        self.orderCreated!.statusLabel = strComOrderRejected()
        let metricaParams = ["orderNumber" : self.orderCreated!.orderID!]
        let metricaMessage = "Order rejected"
        YMMYandexMetrica.reportEvent(metricaMessage, parameters: metricaParams, onFailure: {error in
            NSLog("error: %@", error.localizedDescription);
        })
        saveDefaultContext()
        self.setStatus()
    }
    
    //MARK: Commons
    
    @IBAction func doCall(_ sender: UIButton) {
        self.callActionSheet = UIActionSheet()
        self.callActionSheet?.title = strComDoCall()
        var addedCount = 0
        if needOfficeCall && dispPhone() != "" {
            self.callActionSheet?.addButton(withTitle: strComDispatcher())
            addedCount += 1
        }
        if needDriverCall {
            if self.orderCreated?.driver != nil {
                if self.orderCreated?.driver?.phone != nil {
                    if self.orderCreated?.driver?.phone != "" {
                        self.callActionSheet?.addButton(withTitle: strComDriver())
                        addedCount += 1
                    }
                }
            }
        }
        self.callActionSheet?.addButton(withTitle: strComCancel())
        self.callActionSheet?.cancelButtonIndex = addedCount
        self.callActionSheet?.delegate = self
        
        if addedCount != 0 {
            self.callActionSheet?.show(in: self.view)
        }
        
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        if actionSheet == self.callActionSheet {
            if buttonIndex == 0 {
                var phone = dispPhone()
                if phone != "" {
                    if phone[0] != "+" {
                        phone = "+\(phone)"
                    }
                    if let url = URL(string: "tel://\(phone)") {
                        UIApplication.shared.openURL(url)
                    }
                } else {
                    if self.orderCreated?.driver != nil {
                        if self.orderCreated?.driver?.phone != nil {
                            if self.orderCreated?.driver?.phone != "" {
                                var phone = (self.orderCreated?.driver?.phone)!
                                if phone[0] != "+" {
                                    phone = "+\(phone)"
                                }
                                if let url = URL(string: "tel://\(phone)") {
                                    UIApplication.shared.openURL(url)
                                }
                            }
                        }
                    }
                }
            } else if buttonIndex == 1 {
                if self.orderCreated?.driver != nil {
                    if self.orderCreated?.driver?.phone != nil {
                        if self.orderCreated?.driver?.phone != "" {
                            if let url = URL(string: "tel://+\((self.orderCreated?.driver?.phone)!)") {
                                UIApplication.shared.openURL(url)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func updViews()
    {
        if self.createdOrder == true {
            self.bottomSpace.constant = 0
            self.centerUserSpace.constant = 60
            self.bottomCallConstraint.constant = 0
            self.setOsmAnnotations()
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.centerButton.layoutIfNeeded()
                self.tableView.alpha = 0
                self.shadowView.alpha = 0.0
                self.userCenter.alpha = 0
                self.userCenterLabel.alpha = 0
                self.annBorderOut.alpha = 0
                self.botCallView.layoutIfNeeded()
                }, completion: { (completed) -> Void in
            })
        }
        else {
            self.driverTopConstraint.constant = -86
            self.bottomSpace.constant = 180
            self.bottomCallConstraint.constant = -50
            self.centerUserSpace.constant = 10
            
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.driverView.layoutIfNeeded()
                self.botView?.superview?.layoutIfNeeded()
                self.centerButton.layoutIfNeeded()
                self.botCallView.layoutIfNeeded()
                self.tableView.alpha = 1
                
                self.userCenter.alpha = 1
                self.userCenterLabel.alpha = 1
                self.annBorderOut.alpha = 1
            })
        }
        
    }
    
    func showMap()
    {
        let currentMap = curMap()
        if currentMap == 0 {
            if #available(iOS 9.0, *) {
                osmMap.showsCompass = false
                //osmMap.mapType = .HybridFlyover // не включать - можно случайно кончить
            } else {
                // Fallback on earlier versions
            }
            
            osmMap.showsUserLocation = false
            osmMap.delegate = self
            let overlay = MKTileOverlay(urlTemplate: kOSMTiles)
            overlay.canReplaceMapContent = true
            osmMap.add(overlay, level: MKOverlayLevel.aboveLabels)
            if let currentOverlay = self.currentOverlay {
                osmMap.remove(currentOverlay)
            }
            currentOverlay = overlay
            
            if self.osmMapPinch == nil {
                if #available(iOS 11, *) {} else {
                    self.osmMapPinch = UIPinchGestureRecognizer(target: self, action: #selector(MapViewController.didReceivePinch(_:)))
                    self.osmMapPinch?.delegate = self
                    
                    self.osmMap.addGestureRecognizer(self.osmMapPinch!)
                    self.osmMap.isZoomEnabled = true
                }
            }
            
            
            osmMap.isHidden = false
            googleMap.isHidden = true
            self.gmsMap?.isHidden = true
            self.aSpaceConstraint.constant = 25
        } else if currentMap == 2 {
            if #available(iOS 9.0, *) {
                osmMap.showsCompass = false
            }
            
            osmMap.showsUserLocation = false
            osmMap.delegate = self
            
            let tilesOverlay = DGSTileOverlay()
            tilesOverlay.canReplaceMapContent = true
            osmMap.add(tilesOverlay, level: MKOverlayLevel.aboveLabels)
            if let currentOverlay = self.currentOverlay {
                osmMap.remove(currentOverlay)
            }
            currentOverlay = tilesOverlay
            
            if self.osmMapPinch == nil {
                if #available(iOS 11, *) {} else {
                    self.osmMapPinch = UIPinchGestureRecognizer(target: self, action: #selector(MapViewController.didReceivePinch(_:)))
                    self.osmMapPinch?.delegate = self
                    
                    self.osmMap.addGestureRecognizer(self.osmMapPinch!)
                    self.osmMap.isZoomEnabled = true
                }
            }
            osmMap.isHidden = false
            googleMap.isHidden = true
            self.gmsMap?.isHidden = true
            self.aSpaceConstraint.constant = 25
        }
        else {
            self.aSpaceConstraint.constant = 0
            if gmsMap == nil {
                self.googleMap.sizeToFit()
                self.googleMap.setNeedsLayout()
                gmsMap = GMSMapView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
                gmsMap?.delegate = self
                gmsMap?.settings.allowScrollGesturesDuringRotateOrZoom = false
                gmsMap?.settings.rotateGestures = false
                self.googleMap.addSubview(gmsMap!)
                
            }
            if curGoogleMapType() {
                self.gmsMap!.mapType = .normal
            }
            else {
                self.gmsMap!.mapType = .hybrid
            }
            osmMap.isHidden = true
            googleMap.isHidden = false
            self.gmsMap?.isHidden = false
        }
        self.userCenter.layoutIfNeeded()
    }
    
    func timeToCar() -> String {
        if self.orderCreated != nil {
            if self.orderCreated?.carTime != nil {
                if self.orderCreated?.carAssigningDateTime != nil {
                    let dateCar = self.orderCreated?.carAssigningDateTime!.addingTimeInterval((self.orderCreated?.carTime!.doubleValue)! * 60)
                    var diff = dateCar?.timeIntervalSince(Date())
                    diff = diff!/60
                    if diff < 0 {
                        return "0"
                    }
                    else {
                        return String(format: "%.0f", arguments: [diff!])
                    }
                    
                }
            }
        }
        return "0"
    }
    
    
    
    //MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if maxOnePoint { return 1 }
        else { return self.curOrder?.pathB != nil ? self.countOfPaths() : self.regionNotSupported ? self.countOfPaths() : self.countOfPaths() + 1 }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addrPath", for: indexPath) as! AddressPathTableViewCell
        if indexPath.row == 0 {
            cell.topView.isHidden = true
            if self.curOrder?.pathA == nil {
                self.curOrder?.pathA = AddressTemp()
                if self.ftime != true {
                    self.updateGeoloc()
                }
            }
            
            if self.curOrder == nil {
                self.curOrder = OrderTemp()
            }
            
            cell.setAddress((self.curOrder?.pathA!)!,inCity: !self.regionNotSupported )
            cell.pointPath = "a"
            if cell.pathStreet.text == strComNoAddrs() {
                self.approveAddress.isEnabled = false
            }
            cell.pathImage.image = UIImage(named: imageListA())
            
            let gesture = UITapGestureRecognizer(target: self, action: #selector(self.openAddressDetails))
            cell.viewPorchContainer.addGestureRecognizer(gesture)
        }
        else if indexPath.row == 1 {
            if self.curOrder != nil {
                if self.curOrder?.pathB != nil {
                    cell.setAddress((self.curOrder?.pathB)!,inCity: !self.regionNotSupported)
                    cell.pointPath = "b"
                }
                else {
                    cell.pathStreet.text! = ""
                    cell.pathCity.text! = strNotePickSecondAddr()
                }
            }
            cell.pathImage.image = UIImage(named: imageListB())
        }
        else if indexPath.row == 2 {
            if self.curOrder != nil {
                if self.curOrder?.pathC != nil {
                    cell.setAddress((self.curOrder?.pathC)!,inCity: !self.regionNotSupported)
                    cell.pointPath = "c"
                }
            }
            cell.pathImage.image = UIImage(named: imageListC())
        }
        else if indexPath.row == 3 {
            if self.curOrder != nil {
                if self.curOrder?.pathD != nil {
                    cell.setAddress((self.curOrder?.pathD)!,inCity: !self.regionNotSupported)
                    cell.pointPath = "d"
                }
            }
            cell.pathImage.image = UIImage(named: imageListD())
        }
        else if indexPath.row == 4 {
            if self.curOrder != nil {
                if self.curOrder?.pathE != nil {
                    cell.setAddress((self.curOrder?.pathE)!,inCity: !self.regionNotSupported)
                    cell.pointPath = "e"
                }
            }
            cell.pathImage.image = UIImage(named: imageListE())
        }
        if indexPath.row == 0 {
            cell.topSpace.constant = 0
        }
        else {
            cell.topSpace.constant = 0
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        if indexPath.row != 0 {
            return .delete
        }
        return .none
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var point : String? = "a"
        switch indexPath.row {
        case 1:
            point = "b"
        case 2:
            point = "c"
        case 3:
            point = "d"
        case 4:
            point = "e"
        default :
            point = "a"
            
        }
        self.performSegue(withIdentifier: "search", sender: point)
        self.updateTableView()
    }
    
    
    // Override to support editing the table view.
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if tableView == self.tableView {
            if editingStyle == .delete {
                deletePathAtIndex(indexPath)
            }
        }
        self.callCost()
    }
    
    
    func openAddressDetails() {
        let detailController = UIStoryboard.addressDetailController()!
        detailController.modalPresentationStyle = .overCurrentContext
        detailController.view.backgroundColor = UIColor.clear
        detailController.point = "a"
        detailController.curOrder = self.curOrder
        detailController.rootCont = self
        DispatchQueue.main.async(execute: {
            self.navigationController?.present(detailController, animated: true, completion: { () -> Void in
                
            })
        });
    }
    
    func updateTableView() {
        self.tableView.reloadData()
        if self.createdOrder == false {
            self.addPathButton.isHidden = (self.curOrder?.pathB == nil || self.curOrder?.pathE != nil) && maxOnePoint
        } else {
            self.addPathButton.isHidden = true
        }
        if self.tableView.contentSize.height < 150 {
            self.tableHeight.constant = self.tableView.contentSize.height + 2
            UIView.animate(withDuration: 0.1, animations: { () -> Void in
                self.shadowView.alpha = 0.0
            })
        }
        else {
            self.tableHeight.constant = 150
            UIView.animate(withDuration: 0.1, animations: { () -> Void in
                self.shadowView.alpha = 0.0
            })
        }
        UIView.animate(withDuration: 0.1, animations: { () -> Void in
            self.tableView.layoutIfNeeded()
            self.shadowView.layoutIfNeeded()
        })
        self.tableView.isScrollEnabled = tableView.contentSize.height > self.tableHeight.constant
    }
    
    
    //MARK: - UISCrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == self.tableView {
            //        print(scrollView)
            let offset = scrollView.contentOffset
            let bounds = scrollView.bounds
            let size = scrollView.contentSize
            let inset = scrollView.contentInset
            let y = offset.y + bounds.size.height - inset.bottom
            let h = size.height
            
            let reload_distance = 0
            if y >= (h + CGFloat(reload_distance)) {
                UIView.animate(withDuration: 0.01, animations: { () -> Void in
                    self.shadowView.alpha = 0.0
                })
                
            }
            else {
                UIView.animate(withDuration: 0.2, animations: { () -> Void in
                    self.shadowView.alpha = 1.0
                })
            }
        }
    }
    
    //MARK: - Utils
    
    func centerOsmCoordinate() -> CLLocationCoordinate2D {
        var center = CLLocationCoordinate2DMake(0, 0)
        if curMap() == 0 || curMap() == 2 {
            center = self.osmMap.convert(CGPoint(x: self.view.frame.width/2, y: self.view.frame.height/2), toCoordinateFrom: self.view)
        }
        return center
    }
    
    func centerCoordinate() -> CLLocationCoordinate2D {
        var center = CLLocationCoordinate2DMake(0, 0)
        if self.countOfPaths() > 1 {
            center = CLLocationCoordinate2DMake((self.curOrder?.pathA!.lat)!, (self.curOrder?.pathA!.lon)!)
        }
        else {
            if curMap() == 0 || curMap() == 2 {
                center = self.osmMap.convert(CGPoint(x: self.view.frame.width/2, y: self.view.frame.height/2), toCoordinateFrom: self.view)
            }
            else if curMap() == 1 {
                center = (self.gmsMap?.projection.coordinate(for: self.gmsMap!.center))!
            }
        }
        return center
    }
    
    
    func locCities() -> [City]
    {
        if self.curCities == nil {
            self.curCities = cities()
        }
        return self.curCities!
    }
    
    func locCity() -> City
    {
        if self.currentCity == nil {
            self.currentCity = curCity()
        }
        return self.currentCity!
    }
    
    func deletePathAtIndex(_ ip : IndexPath)
    {
        switch ip.row {
        case 0 :
            self.curOrder?.pathA = self.curOrder?.pathB
            self.curOrder?.pathB = self.curOrder?.pathC
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            let pathCount = self.countOfPaths()
            if pathCount == 2 {
                curOrder?.pathB = AddressTemp()
            }
            if pathCount == 3 {
                curOrder?.pathC = nil
            }
            if pathCount == 4 {
                curOrder?.pathD = nil
            }
        case 1 :
            self.curOrder?.pathB = self.curOrder?.pathC
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            
            if self.osmPointB != nil {
                if self.osmPointC != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointB?.coordinate = (self.osmPointC?.coordinate)!
                    })
                }
            }
            if self.osmPointD != nil {
                if self.osmPointC != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointC?.coordinate = (self.osmPointD?.coordinate)!
                    })
                }
            }
            if self.osmPointE != nil {
                if self.osmPointD != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointD?.coordinate = (self.osmPointE?.coordinate)!
                    })
                }
            }
            
            let pathCount = self.countOfPaths()
            if pathCount == 1 {
                curOrder?.pathB = nil
            }
            if pathCount == 2 {
                curOrder?.pathC = nil
            }
            if pathCount == 3 {
                curOrder?.pathD = nil
            }
        case 2 :
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            if self.osmPointD != nil {
                if self.osmPointC != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointC?.coordinate = (self.osmPointD?.coordinate)!
                    })
                }
            }
            if self.osmPointE != nil {
                if self.osmPointD != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointD?.coordinate = (self.osmPointE?.coordinate)!
                    })
                }
            }
            
            let pathCount = self.countOfPaths()
            
            if pathCount == 4 {
                curOrder?.pathD = nil
            }
        case 3 :
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            if self.osmPointE != nil {
                if self.osmPointD != nil {
                    UIView.animate(withDuration: 0.1, animations: { () -> Void in
                        self.osmPointD?.coordinate = (self.osmPointE?.coordinate)!
                    })
                }
            }
        case 4 :
            self.curOrder?.pathE = nil
        default :
            print("trash")
        }
        self.tableView.beginUpdates()
        self.tableView.deleteRows(at: [ip], with: .fade)
        self.tableView.endUpdates()
        
        delay(0.15) { () -> () in
            self.updateTableView()
        }
        self.setAnns()
    }
    
    
    func setPayment() {
        if !(self.createdOrder == true) {
            let userProfile = profile()
            if userProfile.companies?.count == 0 && userProfile.balanceMoney == nil && userProfile.payments?.count == 0 {
                if allowPaymentInCash {
                    let cash = ClientPayment()
                    cash.payLabel = strPayCash()
                    cash.payID = "CASH"
                    cash.payCompanyID = ""
                    setDefaultPayment(cash)
                }
            }
            self.curOrder?.payType = defaultPayType().payID
            switch (self.curOrder?.payType)! {
            case "CASH" :
                self.payLogo.image = UIImage(named: "cash")
                self.curOrder?.payPan = strPayCash()
            case "PERSONAL_ACCOUNT" :
                self.payLogo.image = UIImage(named: "pers")
                self.curOrder?.payPan = strPayPersBal()
            case "CORP_BALANCE" :
                self.payLogo.image = UIImage(named: "comp")
                self.curOrder?.payPan = "\(defaultPayType().payLabel!)"
            case "CARD" :
                self.payLogo.image = UIImage(named: "visa")
            default :
                self.payLogo.image = UIImage(named: "visa")
                self.curOrder?.payPan = strPayUndefined()
            }
            if self.curOrder?.payType != "CARD" {
                self.payLabel.lineBreakMode = .byTruncatingTail
            }
            else {
                self.payLabel.lineBreakMode = .byTruncatingHead
            }
            self.payLabel.text = self.curOrder?.payPan
        }
        
    }
    
    func countOfPaths() -> Int {
        if self.createdOrder == false {
            if self.curOrder?.pathE != nil {
                return 5
            }
            if self.curOrder?.pathD != nil {
                return 4
            }
            if self.curOrder?.pathC != nil {
                return 3
            }
            if self.curOrder?.pathB != nil {
                return 2
            }
        }
        else {
            if self.orderCreated?.pointE != nil {
                return 5
            }
            if self.orderCreated?.pointD != nil {
                return 4
            }
            if self.orderCreated?.pointC != nil {
                return 3
            }
            if self.orderCreated?.pointB != nil {
                return 2
            }
        }
        
        return 1
    }
    
    // открыть последний заказ
    func openOrder() {
        if Order.mr_countOfEntities() > 0 {
            let predicate = NSPredicate(format: "statusID contains[c] %@ OR statusID contains[c] %@ OR statusID contains[c] %@ OR statusID contains[c] %@", argumentArray: ["new", "car_assigned", "car_at_place", "executing"])
            if let lastOrder = Order.mr_findFirst(with: predicate, sortedBy: "orderID", ascending: false, in: NSManagedObjectContext.mr_default()) {
                if (lastOrder.statusID != "completed") && lastOrder.statusID != "rejected" {
                    if lastOrder.orderID != "" {
                        if lastOrder.orderID != nil {
                            if lastOrder.statusID != "pre_order" {
                                if lastOrder.statusID != "preorder" {
                                    self.orderCreated = lastOrder
                                    self.createdOrder = true
                                }
                            }
                            self.updViews()
                            self.setStatus()
                            self.runUpdateOrder()
                        }
                    }
                }
            }
        }
    }
    
    func clearMap() {
        if curMap() == 0  || curMap() == 2 {
            self.osmMap.removeAnnotations(self.osmMap.annotations)
        }
        else if curMap() == 1 {
            self.gmsMap?.clear()
        }
        self.removeAnnns()
    }
    
    func removeAnnns() {
        if self.curOrderStatus != nil {
            if self.curOrderStatus != .carAssigned {
                self.osmTimePoint = nil
                self.gglTimePoint = nil
            }
        }
        self.osmPointA = nil
        self.osmPointB = nil
        self.osmPointC = nil
        self.osmPointD = nil
        self.osmPointE = nil
        
        self.gglPointA = nil
        self.gglPointB = nil
        self.gglPointC = nil
        self.gglPointD = nil
        self.gglPointE = nil
        
        if self.createdOrder == false {
            self.driverOsmLoc = nil
            self.driverGglLoc?.map = nil
            self.driverGglLoc = nil
        }
        
    }
    
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    
    // MARK: - UI
    
    // показать меню с тарифами
    func hideBot() {
        DispatchQueue.main.async(execute: {
            if !self.createdOrder {
                if self.removeBot == true {
                    if self.bottomSpace.constant != 0 {
                        if self.approveAddress.isEnabled == true {
                            self.centerUserSpace.constant = 60
                        }
                        else {
                            self.centerUserSpace.constant = 10
                        }
                        self.bottomSpace.constant = 0
                        UIView.animate(withDuration: 0.3, animations: { () -> Void in
                            self.botView?.superview?.layoutIfNeeded()
                            self.centerButton.layoutIfNeeded()
                        })
                    }
                }
            }
        });
    }
    
    // спрятать меню с тарифами
    func showBot() {
        DispatchQueue.main.async(execute: {
            if !self.createdOrder {
                if self.countOfPaths() > 1 {
                    self.approveAddress.isEnabled = true
                }
                if self.approveAddress.isEnabled == true {
                    if self.bottomSpace.constant != 180 {
                        self.bottomSpace.constant = 180
                        UIView.animate(withDuration: 0.3, animations: { () -> Void in
                            self.botView?.superview?.layoutIfNeeded()
                        })
                    }
                }
                if self.centerUserSpace.constant != 10 {
                    self.centerUserSpace.constant = 10
                    UIView.animate(withDuration: 0.3, animations: { () -> Void in
                        self.centerButton.layoutIfNeeded()
                    })
                }
            }
        });
    }
    
    // когда открыт гамбургер и тапнули по карте нужно свернуть гамбургер
    func tapLeft(_ gestureRecognizer : UILongPressGestureRecognizer){
        if gestureRecognizer.state == .ended {
            if self.leftView.frame.width > 100 {
                delegate?.toggleLeftPanel?()
            }
        }
    }
    
    //MARK: - Actions
    
    func updateAddressView()
    {
        if !self.loading {
            
            self.callCost()
            self.approveAddress.isEnabled = true
            let center = self.centerCoordinate()
            var pointInCity = false
            if self.locCities().count > 0 {
                
                var closestCity = self.locCities()[0]
                let centerLoc = CLLocation(latitude: center.latitude, longitude: center.longitude)
                var closestDist = centerLoc.distance(from: CLLocation(latitude: closestCity.lat!, longitude: closestCity.lon!))
                for city in self.locCities() {
                    let curDist = centerLoc.distance(from: CLLocation(latitude: city.lat!, longitude: city.lon!))
                    if curDist < closestDist {
                        closestDist = curDist
                        closestCity = city
                    }
                }
                var inPolygon = false
                if closestCity.polygon?.count > 1 {
                    inPolygon = pointOnPolygon(closestCity.polygon!, test: CGPoint(x: CGFloat((center.latitude)), y: CGFloat((center.longitude))))
                }
                else {
                    inPolygon = closestDist <= Double(ordersZone)
                }
                
                if inPolygon == true {
                    pointInCity = true
                    self.regionNotSupported = false
                    if self.createdOrder != true {
                        if self.navigationController?.isNavigationBarHidden == false {
                            self.bottomSpace.constant = 180
                            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                                self.botView?.superview?.layoutIfNeeded()
                            })
                        }
                    }
                    let defaults = UserDefaults.standard
                    if closestCity.cityID != nil {
                        var otherCity = false
                        otherCity = closestCity.cityID! != defaults.string(forKey: udefCurCity)
                        defaults.set(closestCity.cityID!, forKey: udefCurCity)

                        if (closestCity.cityID != self.currentCity!.cityID) {
                            self.delegate?.updateCityPhone!(closestCity)
                            self.updateTariffsCollection(closestCity)
                        }

                        self.currentCity = closestCity
                        
                        if closestCity.tariffs != nil {
                            if closestCity.tariffs?.count > 0 {
                                if (Date().timeIntervalSince1970 - (closestCity.tariffs![0].tariffDateLoaded?.timeIntervalSince1970)!) > 5*60 {
                                    getTariffs { (arr) -> Void in
                                        closestCity.tariffs = arr
                                        if arr.count > 0 {
                                            self.curOrder?.orderTariff = arr[0]
                                        }
                                        saveCit(closestCity)
                                        self.tariffs = self.locCity().tariffs!
                                        self.validTariff = self.getValidateTariffList()
                                        self.updateTariffsCollection(self.locCity())
                                        
                                    }
                                }
                                else {
                                    self.tariffs = self.locCity().tariffs!
                                    if otherCity == true {
                                        if self.tariffs!.count > 0 {
                                            self.validTariff = self.getValidateTariffList()
                                        }
                                    }
                                    self.updateTariffsCollection(self.locCity())
                                }
                            }
                            else {
                                getTariffs { (arr) -> Void in
                                    closestCity.tariffs = arr
                                    if arr.count > 0 {
                                        self.curOrder?.orderTariff = arr[0]
                                    }
                                    saveCit(closestCity)
                                    self.tariffs = self.locCity().tariffs!
                                    self.validTariff = self.getValidateTariffList()
                                    self.updateTariffsCollection(closestCity)
                                }
                            }
                        }
                        else {
                            getTariffs { (arr) -> Void in
                                if arr.count > 0 {
                                    self.curOrder?.orderTariff = arr[0]
                                }
                                closestCity.tariffs = arr
                                saveCit(closestCity)
                                self.tariffs = self.locCity().tariffs!
                                self.validTariff = self.getValidateTariffList()
                                self.updateTariffsCollection(self.locCity())
                            }
                        }
                    }
                }
                
            }
            
            if !pointInCity {
                self.approveAddress.isEnabled = false
                self.regionNotSupported = true
                self.bottomSpace.constant = 0
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.botView?.superview?.layoutIfNeeded()
                })
            }
            self.updateTableView()
        }
    }
    
    
    func localize()
    {
        if self.point == "a" {
            self.navigationItem.title = strComWhereYou()
        }
        else {
            self.navigationItem.title = strComSelectPoint()
        }
        self.approveAddress.setTitle(strComCreateOrder().uppercased(), for: UIControlState())
        self.approveAddress.layer.cornerRadius = 4;
        
        self.callLabel.text = strComDoCall()
        self.rejectLabel.text = strComRejectOrder()
        
        self.wishesLabel.text = strComWishes()
        self.addrLabel.text = strComQual()
        self.payTitle.text = strPayPay()
        self.editOrderLabel.text = strComEdit()
        
        if self.ftime != true {
            self.updateGeoloc()
        }
        self.setDateLabel()
        self.setPayment()
    }
    
    func setDateLabel() {
        if self.curOrder?.orderTime == nil {
            self.timeLabel.text = strTimeNow()
        }
        else {
            self.timeLabel.text = printShortDate(getFakeOrderDate((self.curOrder?.orderTime)!))
        }
    }
    
    func selectOnMap(_ path: String?) {
        let controller = UIStoryboard.mapPicker()
        controller?.path = path
        self.navigationController?.pushViewController(controller!, animated: true)
    }
    
    // MARK: - Navigation
    
    @IBAction func showHamb(_ sender: AnyObject) {
        delegate?.toggleLeftPanel?()
    }
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "search" {
            if let controller : UINavigationController = segue.destination as? UINavigationController {
                if let myCont = controller.viewControllers[0] as? SelectAddressTableViewController {
                    myCont.mainViewController = self
                    if sender is String {
                        myCont.point = sender as? String
                        myCont.centerCol = self.centerCoordinate()
                        myCont.curOrder = self.curOrder
                    }
                }
            }
        }
        if segue.identifier == "approveAddress1" {
            let controller : AddressDetailViewController = segue.destination as!  AddressDetailViewController
            controller.point = self.point
            controller.curOrder = self.curOrder
        }
    }
    
    func showInstruction() {
        let info = "Вы скачали демо-приложение Гутакс.\n" +
            "\n" +
            "Чтобы протестировать приложение вам необходимо:\n" +
            "\n" +
            "1. Подключить ваш аккаунт Гутакса в настройках. Для того, чтобы узнать ваш ID," +
            " свяжитесь с специалистами Гутакса по телефону +73412310932 или sales@gootax.pro;\n" +
            "\n" +
        "2. Подключите СМС-аккаунт или создайте нового клиента в Гутаксе и используйте его код, указанный в системе."
        let defaults = UserDefaults.standard
        let isSecondAuth = defaults.bool(forKey: "isSecondAuth")
        
        if !isSecondAuth {
            showMessage(strComWelcome(), message: info)
            defaults.set(true, forKey: "isSecondAuth")
            defaults.synchronize()
        }
    }
    
    func colorize()
    {
        self.hamButton?.tintColor = colorNewHamButton()
        self.approveAddress.setColors()
        
        self.addPathButton.layer.cornerRadius = 0.5 * self.addPathButton.bounds.size.width
        self.addPathButton.clipsToBounds = true
        self.addPathButton.setBackgroundImage(imageWithColor(colorNewTint()), for: UIControlState())
        self.addPathButton.setBackgroundImage(imageWithColor(UIColor.black), for: .highlighted)
        self.addPathButton.setBackgroundImage(imageWithColor(colorDisabledButton()), for: .disabled)
        
        let plusImage = UIImage(named: "plus")
        let tintedPlusImage = plusImage?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
        self.addPathButton.setImage(tintedPlusImage, for: UIControlState())
        self.addPathButton.tintColor = colorNewTextTint()
        
        
        self.driverView.layer.shadowRadius = 3;
        self.driverView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.driverView.layer.masksToBounds = false
        self.driverView.layer.shadowOpacity = 0.3;
        
        self.shadowView.layoutIfNeeded()
        self.shadowView.layer.shadowColor = UIColor.black.cgColor
        self.shadowView.layer.shadowOpacity = 0.88
        self.shadowView.layer.shadowRadius = 2
        self.shadowView.layer.shadowOffset = CGSize(width: 1, height: 0)
        self.shadowView.layer.shadowPath = CGPath(rect: CGRect(x: 0,y: -1,width: UIScreen.main.bounds.width-25,height: 1), transform: nil)
        self.shadowView.layer.masksToBounds = false
        
        let headerView : UIView = UIView(frame: CGRect(x: 0,y: 0,width: 10,height: 10))
        
        headerView.backgroundColor = UIColor.clear
        
        self.tableView.tableHeaderView = headerView
        
        self.tableView.reloadData()
        self.setPayment()
        self.orderView.backgroundColor = colorNewHamBack()
        self.costLabel.textColor = colorNewHamText()
        self.userCenter.image = blankAnnView()
        self.annBorderIn.backgroundColor = colorNewAnnBackColor()
        self.userCenterLabel.textColor = colorNewAnnTextColor()
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.addSubview(view)
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        UIApplication.shared.statusBarStyle = colorStatusBarStyle()
        self.tableView.layoutIfNeeded()
        self.applyCurvedShadow(self.tableView)
        
    }
    
    internal func applyCurvedShadow(_ view: UIView) {
        self.tableView.layer.shadowRadius = 2;
        self.tableView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.tableView.layer.masksToBounds = true
        self.tableView.clipsToBounds = true
        self.tableView.layer.shadowOpacity = 0.4;
    }
    
    func doColorize() {
        self.colorize()
        self.curCars = nil
        self.updateTariffsCollection(self.locCity())
    }
    
    
}

extension MapViewController: SidePanelViewControllerDelegate {
    func profileSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        if profile().phone == "" {
            openRegister(false)
        }
        else {
            let listController = UIStoryboard.profileViewController()!
            listController.modalPresentationStyle = .overCurrentContext
            self.navigationController?.present(listController, animated: true, completion: nil)
        }
        print("profile")
    }
    
    func paySelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        self.openPayType(UIButton())
        print("pay")
    }
    
    func ordersSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let listController = UIStoryboard.ordersListViewController()!
        listController.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(listController, animated: true, completion: nil)
        print("orders")
    }
    
    func preOrdersSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let listController = UIStoryboard.ordersListViewController()!
        let listViewController = listController.viewControllers[0] as! OrderListTableViewController
        listViewController.preOrders = true
        listController.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(listController, animated: true, completion: nil)
        print("preorders")
        
    }
    
    func myAddrsSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        print("myaddrs")
    }
    
    func newsSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        print("news")
    }
    
    func webScreenSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let webScreenController = UIStoryboard.webScreenViewController()!
        webScreenController.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(webScreenController, animated: true, completion: nil)
        print("webScreen")
    }
    
    func settingsSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let controller = UIStoryboard.settingsController()!
        controller.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(controller, animated: true, completion: nil)
        print("settings")
    }
    
    
    func referralSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let listController = UIStoryboard.referralSystemViewController()!
        listController.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(listController, animated: true, completion: nil)
        print("referral")
    }
    
    func aboutSelected() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        let listController = UIStoryboard.aboutUsViewController()!
        listController.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(listController, animated: true, completion: nil)
        print("about")
    }
    
    func login() {
        if !checkTransitionLeftPanel() {
            return
        }
        
        delegate?.toggleLeftPanel!()
        openRegister(true)
        print("login")
    }
    
    func register() {
        
        delegate?.toggleLeftPanel!()
        openRegister(false)
        print("registe")
    }
    
    func openRegister( _ auth: Bool) {
        
        let authController = UIStoryboard.authViewController()!
        let authorContr = authController.viewControllers[0] as! AuthorizationTableViewController
        if auth {
            authorContr.segmentedControl.selectedSegmentIndex = 1
        }
        else {
            authorContr.segmentedControl.selectedSegmentIndex = 0
        }
        authController.modalPresentationStyle = .overCurrentContext
        authController.view.backgroundColor = UIColor.clear
        DispatchQueue.main.async(execute: {
            self.navigationController?.present(authController, animated: true, completion: nil)
        });
    }
    
    private func checkTransitionLeftPanel() -> Bool {
        
        var position = CGFloat(0)
        if UI_USER_INTERFACE_IDIOM() == .pad {
            position = 300
        }
        else {
            position = UIScreen.main.bounds.width - 62
        }
        
        if let currentPosition = self.navigationController?.view.frame.origin.x {
            if layoutDirection == .rightToLeft {
                position = -position
            }
            if currentPosition != position {
                return false
            }
        }
        
        return true
    }
    
}

class TCCircle : GMSCircle {
    var duration : TimeInterval!
    var begin : Date!
    var go : Bool!
    
    func beginCircleAnimation(_ duration: TimeInterval) {
        self.duration = duration
        self.go = true
        self.begin = Date()
        self.performSelector(onMainThread: #selector(TCCircle.updateSelf), with: nil, waitUntilDone: false)
    }
    
    func updateSelf() {
        if self.go == true {
            let i : TimeInterval = Date().timeIntervalSince(self.begin)
            if (i >= self.duration) {
                self.beginCircleAnimation(3)
                return
            } else {
                delay(0.0, closure: {
                    self.radius = i*150
                    var alpha = CGFloat((3-CGFloat(i))/3)
                    if alpha > 1 {
                        alpha = 1
                    }
                    self.fillColor = colorNewTint().withAlphaComponent(alpha*0.7)
                    self.strokeColor = colorNewTint().withAlphaComponent(alpha)
                    self.performSelector(inBackground: #selector(TCCircle.updateSelf), with: nil)
                })
            }
        }
    }
    
    func stop() {
        self.go = false
    }
}
