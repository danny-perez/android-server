//
//  OrderListTableViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class OrderListTableViewController: UITableViewController {

//    @IBOutlet weak var segmentedControl: UISegmentedControl!
    var orders: [Order]?
    
    @IBOutlet weak var closeBut: UIBarButtonItem!
    var preOrders : Bool?
    var visualEffectView : UIVisualEffectView?
    var cur : String?
    var updateDelay : Double = 30
    var updateInfo : Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.preOrders == nil {
            self.preOrders = false
        }
        
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    let view = UIView(frame: self.view.bounds)
                    view.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.5)
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    view.addSubview(self.visualEffectView!)
                    self.tableView.backgroundView = view
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.tableView.backgroundView = view
        }
        
        self.localize()
        self.colorize()
        self.setOrders()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.localize()
        self.colorize()
        self.setOrders()
        
//        self.tableView.reloadData()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        self.updateInfo?.invalidate()
        self.updateInfo = nil
        if self.orders?.count > 0 {
            if self.preOrders == true {
                for cell in self.tableView.visibleCells {
                    let celln : NewOrderTableViewCell = cell as! NewOrderTableViewCell
                    celln.diealloc()
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    func runUpdateOrder() {
        if self.updateInfo == nil {
            self.updateInfo = Timer.scheduledTimer(timeInterval: Double(self.updateDelay), target: self,
                    selector: #selector(OrderListTableViewController.updateOrders), userInfo: "", repeats: true)
        }
    }

    func updateOrders() {
        gxGetOrdersInfo(orders!, completion: { (result) -> Void in
            self.orders = result
            self.tableView.reloadData()
            saveDefaultContext()
        }, failure: {
        })
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.orders?.count > 0 {
            return (self.orders?.count)!
        }
        else {
            return 1
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.orders?.count > 0 {
            let cell : NewOrderTableViewCell = tableView.dequeueReusableCell(withIdentifier: "orderNew", for: indexPath) as! NewOrderTableViewCell
            if indexPath.row == 0 {
                cell.topSpace.constant = 10
            }
            else {
                cell.topSpace.constant = 5
            }
            cell.mapView.delegate = cell
            cell.setOrder(self.orders![indexPath.row], cur: (self.orders![indexPath.row].currency))
//            print(cell)
            return cell
        }
        else {
            let cell : NoOrdsTableViewCell = tableView.dequeueReusableCell(withIdentifier: "noOrds", for: indexPath) as! NoOrdsTableViewCell
            if self.preOrders == true {
                cell.noOrdsLabel.text = strComNoPreOrders()
            }
            else {
                cell.noOrdsLabel.text = strComNoOrders()
            }
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if self.orders?.count > 0 {
            let cell : NewOrderTableViewCell = tableView.cellForRow(at: indexPath) as! NewOrderTableViewCell
            cell.diealloc()
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            if self.orders?.count > 0 {
                return 215
            }
            else {
                return tableView.frame.height - 64
            }
        }
        return 210
    }
    
    
    //MARK: - Actions
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        self.setOrders()
        self.tableView.reloadData()
    }
    
    //MARK: - calculations
    
    func tableViewHeight(_ order : Order) -> Double {
        var height = 0.0
        if order.pointA != nil {
            height += Double(heightForView((order.pointA)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8)
            if order.pointB != nil {
                height += Double(heightForView((order.pointB)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8)
                if order.pointC != nil {
                    height += Double(heightForView((order.pointC)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8)
                    if order.pointD != nil {
                        height += Double(heightForView((order.pointD)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8)
                        if order.pointE != nil {
                            height += Double(heightForView((order.pointE)!.strFromAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 77) + 8)
                        }
                    }
                }
            }
        }
        return height
    }
    
    func driverHeight(_ order : Order) -> Double {
        var height = 10.0
        
        if order.driver != nil {
            if order.driver?.name != nil {
                height += Double(heightForView((order.driver?.name)!, font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 50) + 10)
            }
            if order.driver?.photo == nil {
                if order.driver?.carModel != nil {
                    height += Double(heightForView((order.driver?.carModel.uppercased())!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - (UIScreen.main.bounds.width/2 + 70)) + 25)
                }
            }
            else {
                height += 105
            }
        }
        return height
    }
    
    // MARK: -UITableViewDelegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.orders != nil {
            if self.orders?.count > 0 {
                if (checkStatus(self.orders![indexPath.row]) == .completed) || (checkStatus(self.orders![indexPath.row]) == .rejected) {
//                    self.performSegueWithIdentifier("openFinishedOrder", sender: self.orders![indexPath.row])
                    let controller = UIStoryboard.finishedOrder()!
                    controller.order = self.orders![indexPath.row]
                    self.navigationController?.pushViewController(controller, animated: true)
                    self.updateInfo?.invalidate()
                    self.updateInfo = nil
                }
                else if checkStatus(self.orders![indexPath.row]) == .preorder {
                    self.performSegue(withIdentifier: "openFinishedOrder", sender: self.orders![indexPath.row])
                }
                else {
                    if (checkStatus(self.orders![indexPath.row]) == .new) && (self.orders![indexPath.row]).carDateTime != nil {
                        self.performSegue(withIdentifier: "openFinishedOrder", sender: self.orders![indexPath.row])
                    }
                    else {
                        self.performSegue(withIdentifier: "openOrder", sender: self.orders![indexPath.row])
                    }
                }
            }
        }
    }
    
    
    
    //MARK: - Common
    
    func checkStatus(_ ord : Order) -> OrderStatus {
        switch ord.statusID {
        case "new", "New" :
            return .new
        case "car_assigned", "carAssigned" :
            return .carAssigned
        case "car_at_place" :
            return .carAtPlace
        case "rejected" :
            return .rejected
        case "executing" :
            return .executing
        case "completed" :
            return .completed
        case "preorder", "pre_order" :
            return .preorder
        default :
            return .new
        }
    }

    func setOrders() {
        let predicate : NSPredicate?
        if self.preOrders != true {
            predicate = NSPredicate(format: "statusID contains[c] %@ OR statusID contains[c] %@", argumentArray: ["completed", "rejected"])
        }
        else {
            predicate = NSPredicate(format: "statusID contains[c] %@", argumentArray: ["pre_order"])
        }
        self.orders = Order.mr_findAllSorted(by: "createDateTime", ascending: false, with: predicate!) as? [Order]
        self.tableView.reloadData()
    }
    
    func curr() -> String {
        if self.cur == nil {
            self.cur = currency()
        }
        return self.cur!
    }
    
    //MARK: - Actions
    
    @IBAction func closeAction(_ sender: UIBarButtonItem) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    func localize() {
        if self.preOrders == true {
            self.navigationItem.title = strLeftPreOrders()
            if self.orders?.count > 0 {
                runUpdateOrder()
            }
        }
        else {
            self.navigationItem.title = strLeftOrders()
        }
    }
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        self.tableView.backgroundColor = UIColor.clear
        self.closeBut.tintColor = colorNewHamButton()
    }
    
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "openOrder" {
        }
        if segue.identifier == "openFinishedOrder" {
            let controller : FinishedOrderViewController = segue.destination as! FinishedOrderViewController
            if sender != nil {
                controller.order = sender as? Order
                if checkStatus(sender as! Order) == .preorder {
                    controller.preOrder = true
                }
                if (checkStatus(sender as! Order) == .new) && (sender as! Order).carDateTime != nil {
                    controller.preOrder = true
                }
                
            }
        }
    }
    

}
