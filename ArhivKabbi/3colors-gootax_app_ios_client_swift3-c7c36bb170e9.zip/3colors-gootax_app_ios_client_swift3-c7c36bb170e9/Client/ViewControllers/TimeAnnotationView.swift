//
//  TimeAnnotationView.swift
//  Client
//
//  Created by Dmitriy Kudrin on 21.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class TimeAnnotationView: MKAnnotationView {

    
    let width : CGFloat = 36
    let height : CGFloat = 49
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    var timeLabel : UILabel?
    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        
//    }
    
     init(annotation: MKAnnotation?, reuseIdentifier: String?, time : String) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        
        let img = blankAnnView()
        self.addSubview(UIImageView(image: img))
        let outBorderView = UIView(frame: CGRect(x: 3,y: 3,width: 30,height: 30))
        outBorderView.layer.cornerRadius = 15
        outBorderView.backgroundColor = UIColor.white
        let inBorderView = UIView(frame: CGRect(x: 1,y: 1,width: 28,height: 28))
        inBorderView.layer.cornerRadius = 14
        inBorderView.backgroundColor = colorNewAnnBackColor()
        outBorderView.addSubview(inBorderView)
        self.addSubview(outBorderView)
        let timeLbl = UILabel(frame: CGRect(x: 0,y: 5,width: width,height: 19))
        timeLbl.font = UIFont.systemFont(ofSize: 16)
        timeLbl.textColor = colorNewAnnTextColor()
        timeLbl.text = time
        self.timeLabel = timeLbl
        timeLbl.textAlignment = .center
        self.addSubview(timeLbl)
        
        let infoLbl = UILabel(frame: CGRect(x: 0,y: 16,width: width,height: 19))
        infoLbl.font = UIFont.systemFont(ofSize: 7)
        infoLbl.textColor = colorNewAnnTextColor()
        infoLbl.text = strCCostMin()
        
        infoLbl.textAlignment = .center
        
        self.addSubview(infoLbl)

        
        
        
        
        
        
        self.centerOffset = CGPoint(x: 0, y: -height/2)
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
