//
//  OfferViewController.swift
//  Client
//
//  Created by  Andrew on 27.03.17.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class OfferViewController: UIViewController {

    @IBOutlet weak var offerView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        localize()
        colorize()
        
        gxDoGet(kGxApiConfidentialPage, params: Dictionary<String, String>(), completion: { (response) -> Void in
            if let result = response["result"] as? [String: Any] {
                if let resultWrapper = result["result"] as? String {
                    self.offerView.loadHTMLString(resultWrapper.stringByDecodingHTMLEntities, baseURL: nil)
                    self.offerView.isHidden = false

                }
            }
        }) { (error) -> Void in
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func localize()
    {
        self.navigationItem.title = strComOffer()
    }
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
