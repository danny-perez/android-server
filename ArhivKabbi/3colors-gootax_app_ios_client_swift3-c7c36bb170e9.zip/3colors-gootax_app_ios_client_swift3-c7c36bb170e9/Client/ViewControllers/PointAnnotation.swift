//
//  PointAnnotation.swift
//  Client
//
//  Created by Dmitriy Kudrin on 24.02.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class PointAnnotationView: MKAnnotationView {

    let width : CGFloat = 36
    let height : CGFloat = 49

//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        
//    }
    
    init(annotation: MKAnnotation?, reuseIdentifier: String?, point: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        let img = blankAnnView()
        self.addSubview(UIImageView(image: img))
        let timeLbl = UILabel(frame: CGRect(x: 0,y: 8.5,width: width,height: 19))
        timeLbl.font = UIFont.systemFont(ofSize: 16)
        timeLbl.textColor = colorNewAnnTextColor()
        timeLbl.text = point
        timeLbl.textAlignment = .center
        
        
        let outBorderView = UIView(frame: CGRect(x: 3,y: 3,width: 30,height: 30))
        outBorderView.layer.cornerRadius = 15
        outBorderView.backgroundColor = UIColor.white
        let inBorderView = UIView(frame: CGRect(x: 1,y: 1,width: 28,height: 28))
        inBorderView.layer.cornerRadius = 14
        inBorderView.backgroundColor = colorNewAnnBackColor()
        outBorderView.addSubview(inBorderView)
        self.addSubview(outBorderView)
        self.addSubview(timeLbl)
        
        self.centerOffset = CGPoint(x: 0, y: -height/2)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }


}

class SmallPointAnnView: MKAnnotationView {
    
    let width : CGFloat = 16
    let height : CGFloat = 16
    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        
//    }
    
    init(annotation: MKAnnotation?, reuseIdentifier: String?, point: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        let view = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        view.backgroundColor = UIColor.black
        view.layer.cornerRadius = width/2
        self.addSubview(view)
        let timeLbl = UILabel(frame: CGRect(x: 0,y: 0,width: width,height: height))
        timeLbl.font = UIFont.systemFont(ofSize: 8.5)
        timeLbl.textColor = UIColor.white
        timeLbl.text = point
        timeLbl.textAlignment = .center
        self.addSubview(timeLbl)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
}
