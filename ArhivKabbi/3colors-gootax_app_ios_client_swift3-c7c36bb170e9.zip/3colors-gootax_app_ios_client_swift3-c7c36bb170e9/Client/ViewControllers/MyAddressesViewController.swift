//
//  MyAddressesViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 04.10.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class MyAddressesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    var addresses : [AddressTemp] = Array()
    
    var selectForOrder : Bool = false
    
    var curOrder : OrderTemp?
    
    var point : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addresses = getFavAddresses()
        self.localize()
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tableView.reloadData()
    }
    

    //MARK: - UITableView DataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.addresses.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : AddressTableViewCell = tableView.dequeueReusableCell(withIdentifier: "address", for: indexPath) as! AddressTableViewCell
        cell.addressStreet.text = (self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress()
        cell.addressCity.text = (self.addresses[indexPath.row] as AddressTemp).city
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return heightForView((self.addresses[indexPath.row] as AddressTemp).shortStrFromTempAddress(), font: UIFont.systemFont(ofSize: 17), width: UIScreen.main.bounds.width - 40) + 28;
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    
    
    //MARK : - UITableView DataSource
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if !self.selectForOrder {
            let controller : AddressDetailViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "addressDetail") as! AddressDetailViewController
            
            controller.address = self.addresses[indexPath.row]
            controller.redactFavorite = true
            
            self.navigationController?.pushViewController(controller, animated: true)
        }
        else {
//            let controller : NewOrderViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("newOrder") as! NewOrderViewController
//            switch self.point! {
//            case "a":
//                self.curOrder?.pathA = addresses[indexPath.row]
//            case "b":
//                self.curOrder?.pathB = addresses[indexPath.row]
//            case "c":
//                self.curOrder?.pathC = addresses[indexPath.row]
//            case "d":
//                self.curOrder?.pathD = addresses[indexPath.row]
//            case "e":
//                self.curOrder?.pathE = addresses[indexPath.row]
//            default:
//                self.curOrder?.pathA = addresses[indexPath.row]
//            }
//            controller.curOrder = self.curOrder
//            self.navigationController?.pushViewController(controller, animated: true)
        }
        //addressDetail
        
    }
    
    // Override to support editing the table view.
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let addrses : [FavAdress] = FavAdress.mr_findAll() as! [FavAdress]
            let addr = addrses[indexPath.row]
            addr.mr_deleteEntity()
            saveDefaultContext()
            self.addresses = getFavAddresses()
            self.tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    
    
    //MARK : Commons
    
    func localize() {
        self.navigationItem.title = strComMyAddrs()
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
