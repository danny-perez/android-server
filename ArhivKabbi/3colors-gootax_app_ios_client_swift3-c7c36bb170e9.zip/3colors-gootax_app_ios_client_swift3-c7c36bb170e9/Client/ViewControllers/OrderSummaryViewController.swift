//
//  OrderSummaryViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class OrderSummaryViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var botView: UIView!
    @IBOutlet weak var reportImage: UIImageView!
    @IBOutlet weak var reportLabel: UILabel!
    @IBOutlet weak var shareLabel: UILabel!
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var navBar: UINavigationItem!
    var curOrd : Order?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gxGetProfile(profile().phone!, completion: { (result) -> Void in
            
            }
        )
        
        localize()
        
        colorize()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    // MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell : OrdSummaryTableViewCell = tableView.dequeueReusableCell(withIdentifier: "sum", for: indexPath) as! OrdSummaryTableViewCell
            if self.curOrd != nil {
                cell.timeLabel.text = printFullsDate((self.curOrd?.createDateTime)!)
                cell.costLabel.text = costStringFromDouble((self.curOrd?.cost_order.doubleValue)!, currency: (self.curOrd?.currency)!)
            }
            return cell
        }
        else {
            if (useReviewDetail) {
                let cell : OrdMarkTableViewCell = tableView.dequeueReusableCell(withIdentifier: "mark", for: indexPath) as! OrdMarkTableViewCell
                if self.curOrd != nil {
                    cell.setStar((self.curOrd?.rate?.doubleValue)!)
                }
                return cell
            } else {
                let cell : OrderSummuryReviewTableViewCell = tableView.dequeueReusableCell(withIdentifier: "review", for: indexPath) as! OrderSummuryReviewTableViewCell
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 200
        }
        return 100
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    //MARK: - Actions
    
    @IBAction func openReport(_ sender: AnyObject) {
        let controller = UIStoryboard.finishedOrder()!
        controller.order = self.curOrd
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
    @IBAction func shareAction(_ sender: AnyObject) {
        let textToShare = strShareText()
        
        if let myWebsite = UserDefaults.standard.url(forKey: udefShareUrl),
            let androidUrl = UserDefaults.standard.url(forKey: udefAndroidShareUrl)
        {
            let iosShareText = "AppStore - \(myWebsite)\n"
            let androidShareText = "GooglePlay - \(androidUrl)\n"
            let objectsToShare = [textToShare, iosShareText, androidShareText] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList, UIActivityType.print, UIActivityType.copyToPasteboard, UIActivityType.assignToContact, UIActivityType.postToVimeo]
            if UI_USER_INTERFACE_IDIOM() == .phone {
                self.present(activityVC, animated: true, completion: nil)
            }
            else {
                let popup: UIPopoverController = UIPopoverController(contentViewController: activityVC)
                popup.present(from: CGRect(x: self.view.frame.size.width / 2, y: self.view.frame.size.height / 4, width: 0, height: 0), in: self.view, permittedArrowDirections: .any, animated: true)
            }
        }
    }
    
    @IBAction func closeAction(_ sender: AnyObject) {
        if (useReviewDetail) {
            self.navigationController?.dismiss(animated: true, completion: nil)
        } else {
            let cell = self.tableView.cellForRow(at: IndexPath(row: 1, section: 0)) as! OrderSummuryReviewTableViewCell
            let rating = Int(cell.currentValue)
            if (rating == 0) {
                self.navigationController?.dismiss(animated: true, completion: nil)
            } else {
                sendFeedBack(String(rating), text: "", order: self.curOrd!) { (result) -> Void in
                    self.curOrd?.rate = rating as NSNumber?
                    self.curOrd?.feedback = ""
                    saveDefaultContext()
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller : FeedbackViewController = segue.destination as! FeedbackViewController
        controller.order = self.curOrd
        
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    func colorize() {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.addSubview(view)
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.closeButton.tintColor = colorNewHamButton()
    }

    
    func localize() {
        self.reportLabel.text = strComOrderReport()
        self.shareLabel.text = strShareTitle()
        self.navBar.title = strComOrderFinished()
    }
    

}
