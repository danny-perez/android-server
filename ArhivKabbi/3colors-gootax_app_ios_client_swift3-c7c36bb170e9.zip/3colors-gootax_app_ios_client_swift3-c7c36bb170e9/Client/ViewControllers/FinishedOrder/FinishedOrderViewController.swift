//
//  FinishedOrderViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import GoogleMaps
import Polyline
import Kingfisher

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

//import ParallaxHeaderView

class FinishedOrderViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIAlertViewDelegate, UIScrollViewDelegate, UIActionSheetDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var addressTableView : UITableView?
    
    var order : Order?
    
    @IBOutlet weak var osmMapView: MKMapView!
    
    var headerView : ParallaxHeaderView?
    
    @IBOutlet weak var mapBlackView: UIView!
    var deleteDialog : UIAlertView?
    
    var preOrder : Bool?
    
    var updateReject : Timer?
    let updateIntervalReject = 1
    var countReject: Int = 0
    
    var curOrderStatus : OrderStatus?
    
    @IBOutlet weak var backScrollView: UIView!
    @IBOutlet weak var backHeight: NSLayoutConstraint!
    
    @IBOutlet weak var gmsMap: GMSMapView!
    var curInfos : [Dictionary<String, String>]?
    
    var osmPointA : PointAnnotation?
    var osmPointB : PointAnnotation?
    var osmPointC : PointAnnotation?
    var osmPointD : PointAnnotation?
    var osmPointE : PointAnnotation?
    
    var callActionSheet : UIActionSheet?
    var waitingDialog : UIAlertController?
    
    var timerRefreshCell : Timer?
    var timerRefreshOrder : Timer?
    
    var cur : String?
    
    var rejectDialog : UIAlertView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeader()
        
        self.setDriverToHeader()
        
        self.addressTableView!.layer.shadowRadius = 3;
        self.addressTableView!.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.addressTableView!.layer.masksToBounds = false
        self.addressTableView!.layer.shadowOpacity = 0.3;
        
        self.localize()
        self.setMap()
        if self.preOrder == true {
            self.backHeight.constant = 50;
            self.backScrollView.layoutIfNeeded()
        }
        if self.order?.statusID == "rejected" {
            self.backHeight.constant = 50;
            self.backScrollView.layoutIfNeeded()
        }
        
        if self.preOrder == true {
            self.runTimers()
        }
        
        if self.navigationController != nil {
            if !(self.navigationController?.viewControllers[0] is OrderListTableViewController) {
                if !(self.navigationController?.viewControllers[0] is MapViewController) {
                    let barButtonItem = UIBarButtonItem(barButtonSystemItem: .stop, target: self, action: #selector(FinishedOrderViewController.closeAction))
                    barButtonItem.tintColor = colorNewHamButton()
                    self.navigationItem.rightBarButtonItem = barButtonItem
                }
            }
        }
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        NotificationCenter.default.addObserver(self, selector: #selector(FinishedOrderViewController.setMaaark), name: NSNotification.Name(rawValue: "callSetMark"), object: nil)
        if curMap() == 0 {
            self.osmMapView.isHidden = false
            self.gmsMap.isHidden = true
        }
        else {
            self.osmMapView.isHidden = true
            self.gmsMap.isHidden = false
            if curGoogleMapType() {
                self.gmsMap.mapType = .normal
            }
            else {
                self.gmsMap.mapType = .hybrid
            }
        }
        self.colorize()
        // Do any additional setup after loading the view.
    }

    
    func setRoute() {
        if self.order!.routeCoords != nil {
            if self.order?.route != nil {
                if self.order?.routeEncoded == nil || self.order?.routeEncoded == "" {
                    let route = NSKeyedUnarchiver.unarchiveObject(with: (self.order!.route)! as Data) as! Dictionary<String, AnyObject>
                    var line = [CLLocation]()
                    
                    if route["result"] != nil {
                        if route["result"] is Dictionary<String, AnyObject> {
                            if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] != nil {
                                if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] is [Dictionary<String, AnyObject>] {
                                    for rt in (route["result"] as! Dictionary<String, AnyObject>)["route_data"] as! [Dictionary<String, AnyObject>] {
                                        if rt["status_id"] != nil {
                                            var status = ""
                                            if rt["status_id"] is String {
                                                status = rt["status_id"] as! String
                                            }
                                            else if rt["status_id"] is Int {
                                                status = String(rt["status_id"] as! Int)
                                            }
                                            
                                            if status != "17" && status != "55" {
                                                if rt["lat"] != nil {
                                                    var loc = CLLocationCoordinate2D()
                                                    if rt["lat"] is String {
                                                        loc.latitude = (rt["lat"] as! NSString).doubleValue
                                                    }
                                                    else if rt["lat"] is Double {
                                                        loc.latitude = rt["lat"] as! Double
                                                    }
                                                    if rt["lon"] != nil {
                                                        if rt["lon"] is String {
                                                            loc.longitude = (rt["lon"] as! NSString).doubleValue
                                                        }
                                                        else if rt["lon"] is Double {
                                                            loc.longitude = rt["lon"] as! Double
                                                        }
                                                        let location = CLLocation(latitude: loc.latitude, longitude: loc.longitude)
                                                        line.append(location)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                        }
                    }
                    let string = Polyline(locations: line).encodedPolyline
                    self.order?.routeEncoded = string
                }
                if curMap() == 1 {
                    let path = GMSPath(fromEncodedPath: (self.order?.routeEncoded!)!)
                    let polyline = GMSPolyline(path: path)
                    polyline.strokeWidth = 3
                    polyline.map = self.gmsMap
                    let bound = GMSCoordinateBounds(path: path!)
                    
                    let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 64)
                    self.gmsMap.frame = frame
                    let cameraUpd = GMSCameraUpdate.fit(bound, with: UIEdgeInsetsMake(self.addressTableView!.frame.size.height + 60,20,190,20))
                    self.gmsMap?.moveCamera(cameraUpd)
                    if self.gmsMap?.camera.zoom > 16 {
                        let newCamera = GMSCameraPosition(target: (self.gmsMap?.projection.coordinate(for: self.gmsMap!.center))!, zoom: 16, bearing: 0, viewingAngle: 0)
                        self.gmsMap?.camera = newCamera
                    }
                }
            }
            let line = NSKeyedUnarchiver.unarchiveObject(with: (self.order!.routeCoords)! as Data) as! [CLLocation]
            if line.count > 0 {
                if curMap() == 0 {
                    self.osmMapView!.setCenter(line[0].coordinate, animated: false)
                    var coordinates = line.map({(location: CLLocation) -> CLLocationCoordinate2D in return location.coordinate})
                    let mkPoly = MKPolyline(coordinates: &coordinates, count: line.count)
                    self.osmMapView!.add(mkPoly)
                    self.osmMapView!.setVisibleMapRect(mkPoly.boundingMapRect, edgePadding: UIEdgeInsetsMake(10,10,140,10), animated: false)
                }
            }
            
        }
        else {
            let route = NSKeyedUnarchiver.unarchiveObject(with: (self.order!.route)! as Data) as! Dictionary<String, AnyObject>
            var line = [CLLocation]()
            
            if route["result"] != nil {
                if route["result"] is Dictionary<String, AnyObject> {
                    if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] != nil {
                        if (route["result"] as! Dictionary<String, AnyObject>)["route_data"] is [Dictionary<String, AnyObject>] {
                            for rt in (route["result"] as! Dictionary<String, AnyObject>)["route_data"] as! [Dictionary<String, AnyObject>] {
                                if rt["status_id"] != nil {
                                    var status = ""
                                    if rt["status_id"] is String {
                                        status = rt["status_id"] as! String
                                    }
                                    else if rt["status_id"] is Int {
                                        status = String(rt["status_id"] as! Int)
                                    }
                                    
                                    if status != "17" && status != "55" {
                                        if rt["lat"] != nil {
                                            var loc = CLLocationCoordinate2D()
                                            if rt["lat"] is String {
                                                loc.latitude = (rt["lat"] as! NSString).doubleValue
                                            }
                                            else if rt["lat"] is Double {
                                                loc.latitude = rt["lat"] as! Double
                                            }
                                            if rt["lon"] != nil {
                                                if rt["lon"] is String {
                                                    loc.longitude = (rt["lon"] as! NSString).doubleValue
                                                }
                                                else if rt["lon"] is Double {
                                                    loc.longitude = rt["lon"] as! Double
                                                }
                                                let location = CLLocation(latitude: loc.latitude, longitude: loc.longitude)
                                                line.append(location)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            let string = Polyline(locations: line).encodedPolyline
            self.order?.routeEncoded = string
            saveDefaultContext()
            if curMap() == 1 {
                let path = GMSPath(fromEncodedPath: (self.order?.routeEncoded!)!)
                let polyline = GMSPolyline(path: path)
                polyline.map = self.gmsMap
                let bound = GMSCoordinateBounds(path: path!)
                let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 64)
                self.gmsMap.frame = frame
                let cameraUpd = GMSCameraUpdate.fit(bound, with: UIEdgeInsetsMake(self.addressTableView!.frame.size.height + 60,20,190,20))
                self.gmsMap?.moveCamera(cameraUpd)
                polyline.strokeWidth = 3
                if self.gmsMap?.camera.zoom > 16 {
                    let newCamera = GMSCameraPosition(target: (self.gmsMap?.projection.coordinate(for: self.gmsMap!.center))!, zoom: 16, bearing: 0, viewingAngle: 0)
                    self.gmsMap?.camera = newCamera
                    //                        self.gmsMap?.animateToZoom(16)
                }
            }
            if line.count > 0 {
                if curMap() == 0 {
                    let polyline = Polyline(encodedPolyline: (self.order?.routeEncoded)!)
                    let decodedCoordinates: [CLLocation]? = polyline.locations
                    self.osmMapView!.setCenter(decodedCoordinates![0].coordinate, animated: false)
                    var coordinates = line.map({(location: CLLocation) -> CLLocationCoordinate2D in return location.coordinate})
                    let mkPoly = MKPolyline(coordinates: &coordinates, count: line.count)
                    self.order?.routeCoords = NSKeyedArchiver.archivedData(withRootObject: line)
                    saveDefaultContext()
                    self.osmMapView!.add(mkPoly)
                    self.osmMapView!.setVisibleMapRect(mkPoly.boundingMapRect, edgePadding: UIEdgeInsetsMake(10,10,140,10), animated: false)
                }
            }
        }
        
    }
    
    func setMaaark() {
        self.performSegue(withIdentifier: "feedback", sender: nil)
         NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "callSetMark"), object: nil)
    }
    
    
    func closeAction() {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.timerRefreshOrder != nil {
            self.timerRefreshOrder?.invalidate()
            self.timerRefreshOrder = nil
        }
        self.updateReject?.invalidate()
        self.updateReject = nil
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "callSetMark"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(FinishedOrderViewController.setMaaark), name: NSNotification.Name(rawValue: "callSetMark"), object: nil)
        self.tableView.reloadData()
        self.setMark()
        if self.preOrder == false {
            if self.order?.route == nil {
                getRoute(self.order!, completion: { (ord) in
                    self.order = ord
                    self.setRoute()
                    
                    
                    }, failure: {
                        
                })
            }
            else {
                self.setRoute()
            }
        }
    }
    
    func runTimers() {
        self.updateOrder()
        if self.timerRefreshOrder == nil {
            self.timerRefreshOrder = Timer.scheduledTimer(timeInterval: Double(10), target: self, selector: #selector(FinishedOrderViewController.updateOrder), userInfo: "", repeats: true)
        }
    }
    
    func updateOrder() {
        if self.order != nil {
            updOrder(self.order!) { (order) -> Void in
                self.order = order
                self.setStatus()
            }
        }
    }
    
    func setStatus() {
        if self.order != nil {
            switch (self.order?.statusID)! {
            case "new", "New" :
                self.curOrderStatus = .new
            case "car_assigned", "carAssigned" :
                self.curOrderStatus = .carAssigned
            case "car_at_place" :
                self.curOrderStatus = .carAtPlace
            case "rejected" :
                self.curOrderStatus = .rejected
                self.updateReject?.invalidate()
                self.updateReject = nil
            case "executing" :
                self.curOrderStatus = .executing
            case "completed" :
                self.curOrderStatus = .completed
            case "preorder", "pre_order" :
                self.curOrderStatus = .preorder
            default :
                self.curOrderStatus = .new
            }
            
            if (self.waitingDialog != nil) {
                self.waitingDialog!.dismiss(animated: true, completion: nil)
            }
            
            if self.curOrderStatus == .preorder {
                self.setDriverToHeader()
            }
            else if self.curOrderStatus == .carAssigned || self.curOrderStatus == .carAtPlace || self.curOrderStatus == .executing {
                if self.navigationController?.presentingViewController?.childViewControllers[0] is UINavigationController {
                    let navContr = self.navigationController?.presentingViewController?.childViewControllers[0] as! UINavigationController
                    if navContr.viewControllers[0] is MapViewController {
                        let mapViewController = navContr.viewControllers[0] as! MapViewController
                        mapViewController.openOrder()
                        self.navigationController?.dismiss(animated: true, completion: nil)
                    }
                }
            }
            else {
                self.preOrder = false
                self.tableView.reloadData()
                self.colorize()
                self.setHeader()
                self.setDriverToHeader()
                if self.order?.route == nil {
                    getRoute(self.order!, completion: { (ord) in
                        self.order = ord
                        self.setRoute()
                        }, failure: {
                    })
                }
                else {
                    self.setRoute()
                }
            }
        }
        
    }
    
    func  scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == self.tableView {
            let header: ParallaxHeaderView = self.tableView.tableHeaderView as! ParallaxHeaderView
//            header.layoutHeaderViewForScrollViewOffset(scrollView.contentOffset)
            
            self.tableView.tableHeaderView = header
            if self.preOrder == true {
                self.backHeight.constant = 100 + scrollView.contentOffset.y + self.tableView.frame.height  - self.tableView.contentSize.height
            }
            else {
                if scrollView.contentOffset.y + self.tableView.frame.height > self.tableView.contentSize.height {
                    self.backHeight.constant = 30 + scrollView.contentOffset.y + self.tableView.frame.height  - self.tableView.contentSize.height
                }
                else {
                    self.backHeight.constant = 0
                }
            }
            
            if scrollView.contentOffset.y < 1 {
                self.mapBlackView.alpha = 0
            }
            else {
                self.mapBlackView.alpha = (scrollView.contentOffset.y / self.tableView.frame.height) * 1.2
            }
            
            self.backScrollView.layoutIfNeeded()
        }
    }
    
    //MARK: - UITableView DataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if tableView == self.tableView {
            if self.preOrder == true {
                return 1
            }
            if self.order?.statusID == "rejected" {
                return 1
            }
            return 2
        }
        else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == self.tableView {
            if self.preOrder == true {
                return 1
            }
            
            if self.order?.statusID == "rejected" {
                return 1
            }
            if section == 0 {
                let taxfee: Int = taxfeePercentage > 0.0 ? 1 : 0
                let cost: Int = ((self.order?.cost_order != 0) && (self.order?.cost_order != nil)) ? 1 : 0
                
                return self.orderInfo().count + 1 + taxfee + cost
            }
            if self.order?.payType != "" {
                return 3
            }
            else {
                return 2
            }
        }
        else {
            return self.numOfPoints()
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tableView {
            if self.order?.statusID == "rejected" {
                let cell : ReverseOrderTableViewCell = tableView.dequeueReusableCell(withIdentifier: "reverseOrder", for: indexPath) as! ReverseOrderTableViewCell
                return cell
            }
            if self.preOrder == true {
                let cell = tableView.dequeueReusableCell(withIdentifier: "rejOrder", for: indexPath)
                return cell
            }
            if indexPath.section == 0 {
                if indexPath.row == 0 {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "aboutOrder", for: indexPath)
                    return cell
                }
                let taxfee: Int = taxfeePercentage > 0.0 ? 1 : 0
                if (indexPath.row == self.orderInfo().count + 1 + taxfee) {
                    let cell : CostListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "costListBl", for: indexPath) as! CostListTableViewCell
                    cell.costLabel.text = costStringFromDouble(self.order!.cost_order.doubleValue, currency: self.curr())
                    cell.titleLabel.text = strCostSummary()
                    cell.headerView.isHidden = taxfeePercentage > 0.0
                    return cell
                }
                else if (indexPath.row == self.orderInfo().count + 1) {
                    let cell : CostListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "costListBl", for: indexPath) as! CostListTableViewCell
                    let taxfee = self.order!.cost_order.doubleValue - (self.order!.cost_order.doubleValue / (1.0 + taxfeePercentage/100.0))
                    cell.costLabel.text = String(format: "%.2f %@", taxfee, self.curr() == "RUB" ? "₽" : self.curr())
                    cell.titleLabel.text = String(format: "%@ %.0f%%", strCostTaxFee(), taxfeePercentage)
                    cell.footerView.isHidden = true
                    return cell
                }
                else {
                    let cell : CostListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "costList", for: indexPath) as! CostListTableViewCell
                    cell.titleLabel.text = Array((self.orderInfo()[indexPath.row - 1]).keys)[0]
                    cell.costLabel.text = (self.orderInfo()[indexPath.row - 1])[Array((self.orderInfo()[indexPath.row - 1]).keys)[0]]
                    return cell
                }
                
            }
            else  {
                if indexPath.row == 0 {
                    let cell : PaydedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "payAbout", for: indexPath) as! PaydedTableViewCell
                    cell.payded = self.order?.payType != ""
                    cell.localize()
                    return cell
                }
                if self.order?.payType != "" {
                    if indexPath.row == 1 {
                        let cell : PayOrderTableViewCell = tableView.dequeueReusableCell(withIdentifier: "pay", for: indexPath) as! PayOrderTableViewCell
                        cell.setOrder(self.order!)
                        return cell
                    }
                }
                let cell : ReverseOrderTableViewCell = tableView.dequeueReusableCell(withIdentifier: "reverseOrder", for: indexPath) as! ReverseOrderTableViewCell
                return cell
                
            }
        }
        else {
            var cell : FinishedAddressTableViewCell? = tableView.dequeueReusableCell(withIdentifier: "address") as? FinishedAddressTableViewCell
            if cell == nil {
                tableView.register(UINib(nibName: "FinishedAddressTableViewCell", bundle: nil), forCellReuseIdentifier: "address")
                cell = tableView.dequeueReusableCell(withIdentifier: "address") as? FinishedAddressTableViewCell
            }
            if indexPath.row == 0 {
                cell!.addressLogo.image = UIImage(named: imageListA())
                cell!.addressLabel.text = (self.order?.pointA)!.strFromAddress()
                cell!.cityLabel.text = self.order?.pointA?.city
                cell!.topView.isHidden = true
            }
            else if indexPath.row == 1 {
                cell!.addressLogo.image = UIImage(named: imageListB())
                cell!.addressLabel.text = (self.order?.pointB)!.strFromAddress()
                cell!.cityLabel.text = self.order?.pointB?.city
            }
            else if indexPath.row == 2 {
                cell!.addressLogo.image = UIImage(named: imageListC())
                cell!.addressLabel.text = (self.order?.pointC)!.strFromAddress()
                cell!.cityLabel.text = self.order?.pointC?.city
            }
            else if indexPath.row == 3 {
                cell!.addressLogo.image = UIImage(named: imageListD())
                cell!.addressLabel.text = (self.order?.pointD)!.strFromAddress()
                cell!.cityLabel.text = self.order?.pointD?.city
            }
            else if indexPath.row == 4 {
                cell!.addressLogo.image = UIImage(named: imageListE())
                cell!.addressLabel.text = (self.order?.pointE)!.strFromAddress()
                cell!.cityLabel.text = self.order?.pointE?.city
            }
            
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == self.tableView {
            if self.order?.statusID == "rejected" {
                return 50
            }
            if self.preOrder == true {
                if indexPath.row == 0 {
                    return 44
                }
                else {
                    return 50
                }
            }
            if indexPath.section == 0 {
                if indexPath.row == self.orderInfo().count {
                    return 38
                }
                else if indexPath.row == self.orderInfo().count + 1 {
                    return 40
                }
                if indexPath.row == 0 {
                    
                    return 35
                }
                else if indexPath.row == self.orderInfo().count + 1 {
                    if ((self.order?.cost_adds != 0) && (self.order?.cost_adds != nil)) {
                        return 30
                    }
                    else {
                        return 30
                    }
                }
                else {
                    return 30
                }
            }
            else {
                if indexPath.row == 0 {
                    return 30
                }
                if indexPath.row == 1 {
                    return 44
                }
                return 50
            }
        }
        else {
            if indexPath.row == 0 {
                return heightForView((self.order?.pointA!.strFromAddress())!, font: UIFont.systemFont(ofSize: 13), width: UIScreen.main.bounds.width - 77) + 8 + heightForView((self.order?.pointA!.city)!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - 77)
            }
            else if indexPath.row == 1 {
                return heightForView((self.order?.pointB!.strFromAddress())!, font: UIFont.systemFont(ofSize: 13), width: UIScreen.main.bounds.width - 77) + 8 + heightForView((self.order?.pointB!.city)!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - 77)
            }
            else if indexPath.row == 2 {
                return heightForView((self.order?.pointC!.strFromAddress())!, font: UIFont.systemFont(ofSize: 13), width: UIScreen.main.bounds.width - 77) + 8 + heightForView((self.order?.pointC!.city)!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - 77)
            }
            else if indexPath.row == 3 {
                return heightForView((self.order?.pointD!.strFromAddress())!, font: UIFont.systemFont(ofSize: 13), width: UIScreen.main.bounds.width - 77) + 8 + heightForView((self.order?.pointD!.city)!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - 77)
            }
            else if indexPath.row == 4 {
                return heightForView((self.order?.pointE!.strFromAddress())!, font: UIFont.systemFont(ofSize: 13), width: UIScreen.main.bounds.width - 77) + 8 + heightForView((self.order?.pointE!.city)!, font: UIFont.systemFont(ofSize: 11), width: UIScreen.main.bounds.width - 77)
            }
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tableView {
            if self.preOrder == true {
                self.rejectOrder()
            }
        }
    }
    
    func rejectOrder() {
        self.rejectDialog = UIAlertView()
        self.rejectDialog?.title = strComRejectOrder()
        self.rejectDialog?.message = strComRejectOrderMessage()
        self.rejectDialog?.addButton(withTitle: strComYes())
        self.rejectDialog?.addButton(withTitle: strComNo())
        self.rejectDialog?.cancelButtonIndex = 1
        self.rejectDialog?.delegate = self
        self.rejectDialog?.show()
        
    }
    
    //MARK: - reorders
    
    @IBAction func doReorder(_ sender: AnyObject) {
        self.reorder(self.order!)
    }
    
    @IBAction func doShare(_ sender: AnyObject) {
        self.showShare()
    }
    
    @IBAction func doReverse(_ sender: Any) {
        self.createReverseOrder(self.order!)
    }
    
    
    //reverseOrder
    func reorder(_ ord: Order) {
        let orderTemp = parseOrder(ord)
        if self.navigationController?.viewControllers[0] is MapViewController {
            let mapViewController = self.navigationController?.viewControllers[0] as! MapViewController
            mapViewController.curOrder = orderTemp
            mapViewController.viewWillAppear(true)
            self.navigationController?.popToRootViewController(animated: true)
        }
        else if let contr = self.navigationController?.presentingViewController as? ContainerViewController {
            let mapC = contr.centerNavigationController
            if let mapContr = mapC?.viewControllers[0] as? MapViewController {
                mapContr.curOrder = orderTemp
                mapContr.viewWillAppear(true)
                self.navigationController?.dismiss(animated: true, completion: nil)
            }
        }
        else if let contr = self.navigationController?.presentingViewController as? UINavigationController {
            if let mapContr = contr.viewControllers[0] as? MapViewController {
                mapContr.curOrder = orderTemp
                mapContr.viewWillAppear(true)
                self.navigationController?.dismiss(animated: true, completion: nil)
            }
        }
    }
    
    func createReverseOrder(_ ord: Order) {
        backOrder(ord)
    }
  
    func backOrder(_ ord: Order) {
        
        let orderTemp = parseOrder(ord)
        
        self.reverseOrder(orderTemp)
        if self.navigationController?.viewControllers[0] is MapViewController {
            let mapViewController = self.navigationController?.viewControllers[0] as! MapViewController
            mapViewController.curOrder = orderTemp
            mapViewController.viewWillAppear(true)
            self.navigationController?.popToRootViewController(animated: true)
        }
        else {
            if let contr = self.navigationController?.presentingViewController as? UINavigationController {
                if let mapContr = contr.viewControllers[0] as? MapViewController {
                    mapContr.curOrder = orderTemp
                    mapContr.viewWillAppear(true)
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    func reverseOrder(_ ord: OrderTemp) {
        var addresses = [AddressTemp]()
        if ord.pathA != nil {
            addresses.append(ord.pathA!)
            if ord.pathB != nil {
                addresses.append(ord.pathB!)
            }
            if ord.pathC != nil {
                addresses.append(ord.pathC!)
            }
            if ord.pathD != nil {
                addresses.append(ord.pathD!)
            }
            if ord.pathE != nil {
                addresses.append(ord.pathE!)
            }
        }
        addresses = addresses.reversed()
        for i in 1...addresses.count {
            switch i {
            case 1 :
                ord.pathA = addresses[i-1]
            case 2 :
                ord.pathB = addresses[i-1]
            case 3 :
                ord.pathC = addresses[i-1]
            case 4 :
                ord.pathD = addresses[i-1]
            case 5 :
                ord.pathE = addresses[i-1]
            default:
                print("fail")
            }
        }
    }
    
    
    //MARK: - Delete Order
    
    func deleteOrder() {
        self.deleteDialog = UIAlertView()
        self.deleteDialog?.message = strComDeleteOrderMessage()
        self.deleteDialog?.title = strComDeleteOrder()
        self.deleteDialog?.addButton(withTitle: strComYes())
        self.deleteDialog?.addButton(withTitle: strComCancel())
        self.deleteDialog?.cancelButtonIndex = 1
        self.deleteDialog?.delegate = self
        self.deleteDialog?.show()
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if alertView == self.deleteDialog {
            if buttonIndex == 0 {
                self.order?.mr_deleteEntity()
                saveDefaultContext()
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
        else if alertView == self.rejectDialog {
            if buttonIndex == 0 {
                rejectOrd(self.order!, completion: { (res) -> Void in
                    if res {
                        self.rejectCurrentOrder()
                        self.waitingDialog  = UIAlertController(title: nil, message: strComRejecting(), preferredStyle: UIAlertControllerStyle.alert)
                        
                        let spinnerIndicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
                        
                        spinnerIndicator.center = CGPoint(x: 135.0, y: 65.5)
                        spinnerIndicator.color = UIColor.black
                        spinnerIndicator.startAnimating()
                        
                        self.waitingDialog!.view.addSubview(spinnerIndicator)
                        self.present(self.waitingDialog!, animated: false, completion: nil)
                    }
                }) { (str) -> Void in
                }
            }
        }
    }

    
    func rejectCurrentOrder() {
        rejectOrderResult(self.order!, completion: { (res) -> Void in
            switch (res) {
            case "complete":
                self.acceptRejectOrder()
                break
            case "error":
                self.updateReject?.invalidate()
                self.updateReject = nil
                
                if self.waitingDialog != nil {
                    self.waitingDialog!.dismiss(animated: true, completion: {
                        showMessage(strComNotificationTitle(), message: strErrRejectOrder())
                    })
                }
                break;
            case "process":
                if self.countReject > 4 {
                    self.acceptRejectOrder()
                } else {
                    if self.updateReject == nil {
                        self.updateReject = Timer.scheduledTimer(timeInterval: Double(self.updateIntervalReject), target: self, selector: #selector(FinishedOrderViewController.rejectCurrentOrder), userInfo: "", repeats: false)
                    }
                    self.countReject += 1
                }
            default:
                break;
            }
        }) { (str) -> Void in
        }
    }
    
    func acceptRejectOrder() {
        self.order!.statusID = "rejected"
        self.order!.statusLabel = strComOrderRejected()
        saveDefaultContext()
        self.setStatus()
        self.countReject = 0
    }
    
    
    
    //MARK: - Commons
    
    func showShare() {
        let textToShare = strShareText()
        
        if let myWebsite = UserDefaults.standard.url(forKey: udefShareUrl),
            let androidUrl = UserDefaults.standard.url(forKey: udefAndroidShareUrl)
        {
            let iosShareText = "AppStore - \(myWebsite)\n"
            let androidShareText = "GooglePlay - \(androidUrl)\n"
            let objectsToShare = [textToShare, iosShareText, androidShareText] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList, UIActivityType.print, UIActivityType.copyToPasteboard, UIActivityType.assignToContact, UIActivityType.postToVimeo]
            if UI_USER_INTERFACE_IDIOM() == .phone {
                self.present(activityVC, animated: true, completion: nil)
            } else {
                let popup: UIPopoverController = UIPopoverController(contentViewController: activityVC)
                popup.present(from: CGRect(x: self.view.frame.size.width / 2, y: self.view.frame.size.height / 4, width: 0, height: 0), in: self.view, permittedArrowDirections: .any, animated: true)
            }
            
        }
    }
    
    func numOfPoints() -> Int {
        if self.order != nil {
            var i = 0
            if self.order?.pointA != nil {
                if self.order?.pointA?.lat != nil {
                    if self.order?.pointA?.lat.doubleValue != 0 {
                        i += 1
                    }
                }
                if self.order?.pointB != nil {
                    if self.order?.pointB?.street != nil {
                        if self.order?.pointB?.street != "" {
                            i += 1
                        }
                    }
                    if self.order?.pointC != nil {
                        if self.order?.pointC?.street != nil {
                            if self.order?.pointC?.street != "" {
                                i += 1
                            }
                        }
                        if self.order?.pointD != nil {
                            if self.order?.pointD?.street != nil {
                                if self.order?.pointD?.street != "" {
                                    i += 1
                                }
                            }
                            if self.order?.pointE != nil {
                                if self.order?.pointE?.street != nil {
                                    if self.order?.pointE?.street != "" {
                                        i += 1
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return i
        }
        return 0
    }
    
    @IBAction func doCall(_ sender: AnyObject) {
        self.callActionSheet = UIActionSheet()
        self.callActionSheet?.title = strComDoCall()
        var addedCount = 0
        if needOfficeCall && dispPhone() != "" {
            self.callActionSheet?.addButton(withTitle: strComDispatcher())
            addedCount += 1
        }
        if needDriverCall {
            if self.order?.driver != nil {
                if self.order?.driver?.phone != nil {
                    if self.order?.driver?.phone != "" {
                        self.callActionSheet?.addButton(withTitle: strComDriver())
                        addedCount += 1
                    }
                }
            }
        }
        self.callActionSheet?.addButton(withTitle: strComCancel())
        self.callActionSheet?.cancelButtonIndex = addedCount
        self.callActionSheet?.delegate = self
        
        if addedCount != 0 {
            self.callActionSheet?.show(in: self.view)
        }
    }
    
    @IBAction func doReject(_ sender: AnyObject) {
        self.rejectOrder()
    }
    
    //MARK: - Header
    
    func setHeader() {
        self.headerView = Bundle.main.loadNibNamed("HeaderView", owner: nil, options: nil)![0] as? ParallaxHeaderView
       
        self.addressTableView = self.headerView!.tableView
        self.addressTableView?.delegate = self
        self.addressTableView?.dataSource = self
        self.addressTableView?.reloadData()
        if self.preOrder == nil {
            self.preOrder = false
        }
        let pre = self.preOrder
        let headerView: ParallaxHeaderView = ParallaxHeaderView.parallaxHeaderView(withSubView: self.headerView!, andPreOrder: pre!) as! ParallaxHeaderView
        
        var frame : CGRect = headerView.frame

        frame.size.width = UIScreen.main.bounds.width
        
        headerView.frame = frame
        
        if (!useReviewForRejected) {
            self.headerView?.constraintReviewView.constant = 0
        }
        
        //headerView.sizeToFit()
        
        headerView.setNeedsLayout()
        
        headerView.driverNameLabel?.text = ""
        headerView.carModelLabel?.text = ""
        headerView.costLabel?.text = ""
        headerView.yourMark?.text = strRateYour()
        self.headerView!.tableViewHeight?.constant = (self.headerView!.tableView?.contentSize.height)! + 8
        
        
        self.tableView.tableHeaderView = headerView
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        if actionSheet == self.callActionSheet {
            if buttonIndex == 0 {
                if dispPhone() != "" {
                    var phone = dispPhone().replacingOccurrences(of: " ", with: "")
                    if phone[0] != "+" {
                        phone = "+\(phone)"
                    }
                    UIApplication.shared.openURL(URL(string: "tel://\(phone)")!)
                }
                else {
                    if self.order?.driver != nil {
                        if self.order?.driver?.phone != nil {
                            if self.order?.driver?.phone != "" {
                                var phone = (self.order?.driver?.phone)!.replacingOccurrences(of: " ", with: "")
                                if phone[0] != "+" {
                                    phone = "+\(phone)"
                                }
                                UIApplication.shared.openURL(URL(string: "tel://\(phone)")!)
                            }
                        }
                    }
                }
            }
            else if buttonIndex == 1  && needDriverCall {
                if self.order?.driver != nil {
                    if self.order?.driver?.phone != nil {
                        if self.order?.driver?.phone != "" {
                            let phone = (self.order?.driver?.phone)!.replacingOccurrences(of: " ", with: "")
                            UIApplication.shared.openURL(URL(string: "tel://+\(phone)")!)
                        }
                    }
                }
            }
        }
    }
    
    func setDriverToHeader() {
        let delayTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: delayTime) {
            var setted = false
            let header = self.headerView!
            header.yourMark?.text = strRateYour()
            header.setMarkLabel.text = self.order?.statusID == "rejected" ? strWriteFeedback() : strRateSet()
            if self.order != nil {
                if self.order?.driver != nil {
                    header.driverNameLabel?.text = self.order?.driver?.name
                    header.carModelLabel?.text = self.order?.driver?.carModel.uppercased()
                    if self.order?.cost_order != nil {
                        header.costLabel?.text = costStringFromDouble((self.order?.cost_order.doubleValue)!, currency: self.curr())
                    }
                    
                    var setteda = false
                    
                    if self.order?.driver != nil {
                        if self.order?.driver?.photo != nil {
                            if self.order?.driver?.loadedPhoto != nil {
                                header.driverPhoto.image = UIImage(data: (self.order?.driver?.loadedPhoto)! as Data)
                                setteda = true
                            }
                        }
                    }
                    if self.order?.driver?.photo != nil {
                        if setteda == false {
                            let url = URL(string: (self.order?.driver?.photo!)!)
                            header.driverPhoto.kf.setImage(with: url, completionHandler: {
                                (image, error, cacheType, imageUrl) in
                                if image == nil {
                                    self.order?.driver?.loadedPhoto = UIImageJPEGRepresentation(UIImage(named: "driver")!, 1.0)
                                    header.driverPhoto.image = UIImage(named: "driver")
                                } else {
                                    self.order?.driver?.loadedPhoto = UIImageJPEGRepresentation(image!, 1.0)
                                }
                                saveDefaultContext()
                            })
                        }
                    }
                    if self.preOrder != true {
                        header.statusLabel!.text = self.order?.statusLabel.uppercased()
                    }
                    else {
                        header.statusLabel.text =
                                "\(strComPreOrd()) \(printFullDate(getFakeOrderDate((self.order?.carDateTime)!)))".uppercased()
                    }
                    header.driverPhoto!.layer.shadowRadius = 2;
                    header.driverPhoto!.layer.shadowOffset = CGSize(width: 0, height: 0)
                    header.driverPhoto!.layer.masksToBounds = false
                    header.driverPhoto!.layer.shadowOpacity = 0.3;
                    header.yourMark?.text = strRateYour()
                    setted = true
                }
            }
            if !setted {
                
                if self.preOrder != true {
                    header.statusLabel!.text = self.order?.statusLabel.uppercased()
                }
                else {
                    header.statusLabel.text =
                            "\(strComPreOrd()) \(printFullDate(getFakeOrderDate((self.order?.carDateTime)!)))".uppercased()
                }
                header.driverNameLabel?.text = ""
                if self.preOrder == true {
                    header.carModelLabel?.text = strComDriverNotSettedYet()
                }
                else {
                    header.carModelLabel?.text = strComDriverNotWasSetted()
                }
                header.yourMark?.text = strRateYour()
                if self.order?.cost_order != nil {
                    header.costLabel?.text = costStringFromDouble((self.order?.cost_order.doubleValue)!, currency: self.curr())
                }
            }
            if self.preOrder == nil {
                self.preOrder = false
            }
            header.setConstr(self.preOrder!)
            header.setMarkView.backgroundColor = colorNewTint()
            header.setMarkLabel.textColor = colorNewTint()
            if self.preOrder == true {
                header.star1?.isHidden = true
                header.star2?.isHidden = true
                header.star3?.isHidden = true
                header.star4?.isHidden = true
                header.star5?.isHidden = true
                header.yourMark.isHidden = true
                header.toOrderLabel?.isHidden = false
                header.toOrderTitle?.isHidden = false
                header.toOrderTitle?.text = strComToOrder()
                header.setMarkView.isHidden = true
                self.setTime()
            }
            else {
                header.star1?.isHidden = false
                header.star2?.isHidden = false
                header.star3?.isHidden = false
                header.star4?.isHidden = false
                header.star5?.isHidden = false
                header.yourMark.isHidden = false
                header.toOrderLabel?.isHidden = true
                header.toOrderTitle?.isHidden = true
            }
        }
    }
    
    func setTime() {
        let header = self.headerView!
        print("settedTime")
        let ord = self.order!
        let startDate = Date()
        var strDate = ""
        if ord.carDateTime != nil {
            let calendar = Calendar.current
            let components = (calendar as NSCalendar).components([.day, .hour, .minute], from: startDate,
                    to: getFakeOrderDate(ord.carDateTime!), options: [])
            if components.day > 0 {
                strDate = "\(String(describing: components.day!)) \(strTimeD())."
            }
            if components.hour > 0 {
                if strDate == "" {
                    strDate = "\(String(describing: components.hour!)) \(strTimeH())."
                }
                else {
                    strDate = "\(strDate) \(String(describing: components.hour!)) \(strTimeH())."
                }
            }
            if components.minute > 0 {
                if strDate == "" {
                    strDate = "\(String(describing: components.minute!)) \(strTimeM())."
                }
                else {
                    strDate = "\(strDate) \(String(describing: components.minute!)) \(strTimeM())."
                }
            }
            header.toOrderLabel?.text = strDate
        }
        else {
            header.toOrderLabel?.text = ""
        }
    }
    
    func setMark() {
        let delayTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: delayTime) {

            let header = self.headerView!
            let ord = self.order!
            if ord.rate?.doubleValue > 0 {
                header.star1?.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
            }
            else {
                header.star1?.image = UIImage(named: imageRateSmallStroke())
            }
            if ord.rate?.doubleValue > 1 {
                header.star2?.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
            }
            else {
                header.star2?.image = UIImage(named: imageRateSmallStroke())
            }
            if ord.rate?.doubleValue > 2 {
                header.star3?.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
            }
            else {
                header.star3?.image = UIImage(named: imageRateSmallStroke())
            }
            if ord.rate?.doubleValue > 3 {
                header.star4?.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
            }
            else {
                header.star4?.image = UIImage(named: imageRateSmallStroke())
            }
            if ord.rate?.doubleValue > 4 {
                header.star5?.image = UIImage(named: imageRateSmallFill())?.imageWithColorz(colorNewTint())
            }
            else {
                header.star5?.image = UIImage(named: imageRateSmallStroke())
            }
            if self.preOrder != true {
                if ord.rate!.doubleValue == 0 || ord.rate == nil {
                    header.star1?.isHidden = true
                    header.star2?.isHidden = true
                    header.star3?.isHidden = true
                    header.star4?.isHidden = true
                    header.star5?.isHidden = true
                    header.yourMark.isHidden = true
                    header.toOrderLabel?.isHidden = true
                    header.toOrderTitle?.isHidden = true
                    header.toOrderTitle?.text = strComToOrder()
                    header.setMarkView.isHidden = false
                }
                else {
                    header.star1?.isHidden = false
                    header.star2?.isHidden = false
                    header.star3?.isHidden = false
                    header.star4?.isHidden = false
                    header.star5?.isHidden = false
                    header.yourMark.isHidden = false
                    header.toOrderLabel?.isHidden = true
                    header.toOrderTitle?.isHidden = true
                    header.setMarkView.isHidden = true
                }
            }

        }

    }
    
    func setMap() {
        if curMap() == 0 {
            let overlay = MKTileOverlay(urlTemplate: kOSMTiles)
            overlay.canReplaceMapContent = true
            self.osmMapView.add(overlay, level: MKOverlayLevel.aboveLabels)

            self.osmMapView.removeAnnotations(self.osmMapView.annotations)
      
            let region = MKCoordinateRegionMakeWithDistance(CLLocationCoordinate2DMake((self.order!.pointA?.lat.doubleValue)!, (self.order!.pointA?.lon.doubleValue)!), 500, 500)
            self.osmMapView.setRegion(region, animated: false)
            
            
            var annsForAdd : [PointAnnotation]? = [PointAnnotation]()
            

            if self.osmPointA == nil {
                self.osmPointA = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.order!.pointA!.lat.doubleValue, self.order!.pointA!.lon.doubleValue), title: "", subtitle: "", point: "A")
                annsForAdd?.append(self.osmPointA!)
            }
            
            
            if self.countOfPaths() > 1 {
                if self.osmPointB == nil {
                    self.osmPointB = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.order!.pointB!.lat.doubleValue, self.order!.pointB!.lon.doubleValue), title: "", subtitle: "", point: "B")
                    annsForAdd?.append(self.osmPointB!)
                }
                if self.countOfPaths() > 2 {
                    if self.osmPointC == nil {
                        self.osmPointC = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.order!.pointC!.lat.doubleValue, self.order!.pointC!.lon.doubleValue), title: "", subtitle: "", point: "C")
                        annsForAdd?.append(self.osmPointC!)
                    }
                    if self.countOfPaths() > 3 {
                        if self.osmPointD == nil {
                            self.osmPointD = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.order!.pointD!.lat.doubleValue, self.order!.pointD!.lon.doubleValue), title: "", subtitle: "", point: "D")
                            annsForAdd?.append(self.osmPointD!)
                        }
                        if self.countOfPaths() > 4 {
                            if self.osmPointE == nil {
                                self.osmPointE = PointAnnotation(coordinate: CLLocationCoordinate2DMake(self.order!.pointE!.lat.doubleValue, self.order!.pointE!.lon.doubleValue), title: "", subtitle: "", point: "E")
                                annsForAdd?.append(self.osmPointE!)
                            }
                        }
                    }
                }
            }
            if annsForAdd?.count > 0 {
                self.osmMapView.addAnnotations(annsForAdd!)
            }
        }
        else {
            let camera = GMSCameraPosition(target: CLLocationCoordinate2DMake((self.order!.pointA?.lat.doubleValue)!, (self.order!.pointA?.lon.doubleValue)!), zoom: 16, bearing: 0, viewingAngle: 0)
            self.gmsMap.camera = camera
            if self.countOfPaths() > 0 {
                let path = GMSMutablePath()
                path.add(CLLocationCoordinate2DMake((self.order!.pointA?.lat.doubleValue)!, (self.order!.pointA?.lon.doubleValue)!))
                if self.order?.pointB != nil {
                    path.add(CLLocationCoordinate2DMake((self.order!.pointB?.lat.doubleValue)!, (self.order!.pointB?.lon.doubleValue)!))
                    if self.order?.pointC != nil {
                        path.add(CLLocationCoordinate2DMake((self.order!.pointC?.lat.doubleValue)!, (self.order!.pointC?.lon.doubleValue)!))
                        if self.order?.pointD != nil {
                            path.add(CLLocationCoordinate2DMake((self.order!.pointD?.lat.doubleValue)!, (self.order!.pointD?.lon.doubleValue)!))
                            if self.order?.pointE != nil {
                                path.add(CLLocationCoordinate2DMake((self.order!.pointE?.lat.doubleValue)!, (self.order!.pointE?.lon.doubleValue)!))
                            }
                        }
                    }
                }
                let bound = GMSCoordinateBounds(path: path)
                
                let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 64)
                self.gmsMap.frame = frame
                let cameraUpd = GMSCameraUpdate.fit(bound, with: UIEdgeInsetsMake(self.addressTableView!.frame.size.height + 60,20,190,20))
                self.gmsMap?.moveCamera(cameraUpd)
                if self.gmsMap?.camera.zoom > 16 {
                    let newCamera = GMSCameraPosition(target: (self.gmsMap?.projection.coordinate(for: self.gmsMap!.center))!, zoom: 16, bearing: 0, viewingAngle: 0)
                    self.gmsMap?.camera = newCamera
                }
            }
            
            
            
            let position = CLLocationCoordinate2DMake(self.order!.pointA!.lat.doubleValue, self.order!.pointA!.lon.doubleValue)
            let markerA = GMSMarker(position: position)
            markerA.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "A"), reuseIdentifier: "", point: "A"))
            markerA.map = self.gmsMap
            
            
            
            
            if self.countOfPaths() > 1 {
                if self.osmPointB == nil {
                    let position = CLLocationCoordinate2DMake(self.order!.pointB!.lat.doubleValue, self.order!.pointB!.lon.doubleValue)
                    let markerB = GMSMarker(position: position)
                    markerB.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "B"), reuseIdentifier: "", point: "B"))
                    markerB.map = self.gmsMap
                }
                if self.countOfPaths() > 2 {
                    let position = CLLocationCoordinate2DMake(self.order!.pointC!.lat.doubleValue, self.order!.pointC!.lon.doubleValue)
                    let markerC = GMSMarker(position: position)
                    markerC.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "C"), reuseIdentifier: "", point: "C"))
                    markerC.map = self.gmsMap
                    if self.countOfPaths() > 3 {
                        let position = CLLocationCoordinate2DMake(self.order!.pointD!.lat.doubleValue, self.order!.pointD!.lon.doubleValue)
                        let markerD = GMSMarker(position: position)
                        markerD.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "D"), reuseIdentifier: "", point: "D"))
                        markerD.map = self.gmsMap
                        if self.countOfPaths() > 4 {
                            let position = CLLocationCoordinate2DMake(self.order!.pointE!.lat.doubleValue, self.order!.pointE!.lon.doubleValue)
                            let markerE = GMSMarker(position: position)
                            markerE.icon = imageFromView(PointAnnotationView(annotation: PointAnnotation(coordinate: position, title: "", subtitle: "", point: "E"), reuseIdentifier: "", point: "E"))
                            markerE.map = self.gmsMap
                        }
                    }
                }
            }
        }
        
    }
    
    func curr() -> String {
        if self.cur == nil {
            self.cur = self.order?.currency
        }
        return self.cur!
    }
    
    func countOfPaths() -> Int {
        if self.order?.pointE != nil {
            return 5
        }
        if self.order?.pointD != nil {
            return 4
        }
        if self.order?.pointC != nil {
            return 3
        }
        if self.order?.pointB != nil {
            return 2
        }
        
        return 1
    }
    
    //MARK: - MKMapViewDelegate
    
    func mapView(_ mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.blue
            polylineRenderer.lineWidth = 5
            return polylineRenderer
        }
        return MKTileOverlayRenderer(overlay: overlay)
    }
    
    func mapView(_ mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        let ann = annotation as! PointAnnotation
        let aView = PointAnnotationView(annotation: annotation, reuseIdentifier: "", point: ann.point)
        
        return aView
        
    }

    func getStatus(_ ord : Order) -> OrderStatus {
        switch (ord.statusID) {
        case "new", "New" :
            return .new
        case "car_assigned", "carAssigned" :
            return .carAssigned
        case "car_at_place" :
            return .carAtPlace
        case "rejected" :
            return .rejected
        case "executing" :
            return .executing
        case "completed" :
            return .completed
        default :
            return .new
        }
    }
    
    
    //MARK: - Info About Order
    
    func orderInfo() -> [Dictionary<String, String>] {
        if self.curInfos != nil {
            return curInfos!
        }
        var arr : [Dictionary<String, String>] = [Dictionary<String, String>]()
        
        if self.order?.tariff != nil {
            let tariff : Tariff = NSKeyedUnarchiver.unarchiveObject(with: (self.order?.tariff)! as Data) as! Tariff
            arr.append([strComTariff() : tariff.tariffLabel!])

            
            let isFixed = self.order?.isFix.boolValue
            
            if isFixed! {
                arr.append([strCCostFixPrice() : costStringFromDouble(self.order!.fixPrice!.doubleValue, currency: self.curr())])
            }
            else {
                if self.order?.cost_car_assigning != nil {
                    arr.append([strCostPlacing() : costStringFromDouble(self.order!.cost_car_assigning.doubleValue, currency: self.curr())])
                }
                
                if self.order?.cost_adds != nil {
                    if self.order?.cost_adds != 0 {
                        arr.append([strCostAdds() : costStringFromDouble(self.order!.cost_adds!.doubleValue, currency: self.curr())])
                    }
                }
                
                if self.order?.cost_city != nil {
                    if self.order?.accrualCity == nil || self.order?.accrualCity == "DISTANCE" || self.order?.accrualCity == "INTERVAL" || self.order?.accrualCity == "" {
                        if self.order?.dist_city != nil {
                            arr.append(["\(strCostInCity()) \(String(describing: (self.order?.dist_city)!)) \(strCCostKm())" : costStringFromDouble(self.order!.cost_city.doubleValue, currency: self.curr())])
                        }
                    }
                    else if self.order?.accrualCity == "TIME" {
                        if self.order?.time_city != nil {
                            arr.append(["\(strCostInCity()) \(String(describing: (self.order?.time_city)!)) \(strCCostMin())" : costStringFromDouble(self.order!.cost_city.doubleValue, currency: self.curr())])
                        }
                    }
                    else if self.order?.accrualCity == "MIXED" {
                        if self.order?.dist_city != nil {
                            if self.order?.time_city != nil {
                                let cost_city = self.order?.cost_city.doubleValue > 0 ? self.order?.cost_city.doubleValue : 0.0
                                arr.append(["\(strCostInCity()) \(String(describing: (self.order?.dist_city)!)) \(strCCostKm()), \(String(describing: (self.order?.time_city)!)) \(strCCostMin())" : costStringFromDouble(cost_city!, currency: self.curr())])
                            }
                        }
                    }
                }
                if self.order?.cost_outCity != nil {
                    if self.order?.accrualOutCity == nil || self.order?.accrualOutCity == "DISTANCE" || self.order?.accrualOutCity == "INTERVAL" || self.order?.accrualOutCity == "" {
                        if self.order?.dist_outCity != nil {
                            arr.append(["\(strCostOutCity()) \(String(describing: (self.order?.dist_outCity)!)) \(strCCostKm())" : costStringFromDouble(self.order!.cost_outCity!.doubleValue, currency: self.curr())])
                        }
                    }
                    else if self.order?.accrualOutCity == "TIME" {
                        if self.order?.time_outCity != nil {
                            arr.append(["\(strCostOutCity()) \(String(describing: (self.order?.time_outCity)!)) \(strCCostMin())" : costStringFromDouble(self.order!.cost_outCity!.doubleValue, currency: self.curr())])
                        }
                    }
                    else if self.order?.accrualOutCity == "MIXED" {
                        if self.order?.dist_outCity != nil {
                            if self.order?.time_outCity != nil {
                                let cost_outCity = self.order?.cost_outCity!.doubleValue > 0 ? self.order?.cost_outCity!.doubleValue : 0.0
                                arr.append(["\(strCostOutCity()) \(String(describing: (self.order?.dist_outCity)!)) \(strCCostKm()), \(String(describing: (self.order?.time_outCity)!)) \(strCCostMin())" : costStringFromDouble(cost_outCity!, currency: self.curr())])
                            }
                        }
                    }
                }
            }
            
            if self.order?.cost_clientWait != nil {
                if self.order?.time_clientWait != nil {
                    arr.append(["\(strComClientWait()) \(String(describing: (self.order?.time_clientWait)!)) \(strCCostMin())" : costStringFromDouble(self.order!.cost_clientWait!.doubleValue, currency: self.curr())])
                }
            }
            
            if self.order?.cost_prostCity != nil {
                if self.order?.dist_cityProst != nil {
                    arr.append(["\(strCostProstCity()) \(String(format: "%.2f", (self.order?.dist_cityProst?.doubleValue)!/60)) \(strCCostMin())" : costStringFromDouble(self.order!.cost_prostCity!.doubleValue, currency: self.curr())])
                }
            }
            if self.order?.cost_prostOutCity != nil {
                if self.order?.dist_outCityProst != nil {
                    arr.append(["\(strCostProstOutCity()) \(String(format: "%.2f", (self.order?.dist_outCityProst?.doubleValue)!/60)) \(strCCostMin())": costStringFromDouble(self.order!.cost_prostOutCity!.doubleValue/60, currency: self.curr())])
                }
            }
        }
        self.curInfos = arr
        return arr
    }

    //MARK: - Commons
    
    func localize() {
        if self.order != nil {
            let num = (self.order?.orderNumber)!
            self.navigationItem.title = "\(strComOrder())\(num)"
        }
    }
    
    func colorize() {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        if self.preOrder == true {
            self.backScrollView.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
        }
        else {
            self.backScrollView.backgroundColor = UIColor.white
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "feedback" {
            let controller : FeedbackViewController = segue.destination as! FeedbackViewController
            controller.order = self.order
        }
    }
}
