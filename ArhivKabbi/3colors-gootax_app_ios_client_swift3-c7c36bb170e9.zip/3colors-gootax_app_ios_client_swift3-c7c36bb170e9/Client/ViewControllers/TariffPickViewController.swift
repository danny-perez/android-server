//
//  TariffPickViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 13.01.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
import Kingfisher

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class TariffPickViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var scrollView: UIScrollView!
    var pickedIndex : Int?
    var curOrder : OrderTemp?
    var pageViews : [TariffPickView?] = []
    let tariffs = curCity().tariffs!
    var validTariffs: [Tariff] = []
    
    var visualEffectView : UIVisualEffectView?
    override func viewDidLoad() {
        super.viewDidLoad()
        if (NSClassFromString("UIVisualEffectView") != nil) {
            if self.visualEffectView == nil {
                self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                self.visualEffectView?.frame = self.view.bounds
                self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                self.visualEffectView?.alpha = 1
                self.view.insertSubview(self.visualEffectView!, at: 0)
                self.visualEffectView?.backgroundColor = blurColor
            }
        }
        
        validTariffs = getValidateTariffList()
        
        self.scrollView.contentSize = CGSize(width: 278*CGFloat(validTariffs.count), height: self.view.frame.height*0.54-10)
        if pickedIndex == nil {
            pickedIndex = 0
        }
        
        self.pageControl.numberOfPages = validTariffs.count
        self.pageControl.currentPage = pickedIndex!
        for _ in 0..<(validTariffs.count) {
            pageViews.append(nil)
        }
        
        self.scrollView.clipsToBounds = false
        if pickedIndex != nil {
            self.scrollView.setContentOffset(CGPoint(x: 278*CGFloat(pickedIndex!), y: 0), animated: false)
        }
        
        colorize()
        loadVisiblePages()
        // Do any additional setup after loading the view.
    }
    
    func loadPage(_ page : Int) {
        if page < 0 || page >= validTariffs.count {
            return
        }
        
        if self.pageViews[page] != nil {
            return
        }
        else {
            let view1 : TariffPickView = UIView.loadFromNibNamed("TariffPick") as! TariffPickView
            let tariff = self.validTariffs[page]
            view1.frame = CGRect(x: 278*CGFloat(page), y: 0, width: 278, height: self.scrollView.frame.height)
            view1.tariffName.text = tariff.tariffLabel
            view1.tariff = tariff
            view1.tariffDescr.text = tariff.tariffDescr
            view1.carPhoto.alpha = 0
            var stted = false
            if tariff.tariffLogoUrl != nil {
                if tariff.tariffLogoUrl != "" {
                    
                    if ((tariff.tariffLogoImage?.isEqualToImage(UIImage(named: "noCarImageBig")!)) == true )
                    {
                        stted = true
                        let url = URL(string: tariff.tariffLogoUrl!)
                        
                        view1.carPhoto.kf.setImage(with: url, completionHandler: {
                            (image, error, cacheType, imageUrl) in
                            if image == nil {
                                tariff.tariffLogoImage = UIImage(named: "noCarImageBig")
                                view1.carPhoto.image = UIImage(named: "noCarImageBig")
                                UIView.animate(withDuration: 0.1, animations: {
                                    view1.carPhoto.alpha = 1.0
                                })
                            } else {
                                tariff.tariffLogoImage = image
                                UIView.animate(withDuration: 0.1, animations: {
                                    view1.carPhoto.alpha = 1.0
                                })
                                let city = curCity()
                                city.tariffs = self.tariffs
                                /*dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                                    saveCit(city)
                                });*/
                            }
                        })
                    }
                }
            }
            
            if stted == false {
                print(tariff.tariffLogoImage ?? "Empty photo")
                if tariff.tariffLogoImage?.size.height > 0 {
                    view1.carPhoto.image = tariff.tariffLogoImage
                }
                else {
                    view1.carPhoto.image = UIImage(named: "noCarImageBig")
                }
                view1.carPhoto.alpha = 1
            }
            
            self.scrollView.addSubview(view1)
            self.pageViews[page] = view1
        }
        
    }
    
    func loadVisiblePages() {
        
        let pageWidth = CGFloat(278)
        let page = Int(floor((scrollView.contentOffset.x * 2.0 + pageWidth) / (pageWidth * 2.0)))
        
        pageControl.currentPage = page
        
        let firstPage = page - 1
        let lastPage = page + 1

        for index in firstPage..<lastPage+1{
            loadPage(index)
        }
    }
    
    func getValidateTariffList() -> [Tariff] {
        
        var validateTariff = [Tariff]()
        for tariff in curCity().tariffs! {
            if tariff.clientTypes != nil {
                if tariff.clientTypes!.contains(profile().clientType!) {
                    if profile().clientType! == "base"
                        || profile().clientType! == "company" && (tariff.companies?.contains(Int(defaultPayType().payCompanyID!)!))! {
                        validateTariff.append(tariff)
                    }
                }
                
            }
        }
        return validateTariff
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func closeAction(_ sender: AnyObject) {
        (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.dismiss(animated: true, completion: nil)
    }
    //MARK: - UISCrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = CGFloat(278)
        let page = Int(floor((scrollView.contentOffset.x * 2.0 + pageWidth) / (pageWidth * 2.0)))
        self.pageControl.currentPage = page
        loadVisiblePages()
    }
    
    
    func colorize() {
        self.pageControl.currentPageIndicatorTintColor = colorNewTint()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIImage {
    
    func isEqualToImage(_ image: UIImage) -> Bool {
        if UIImagePNGRepresentation(self) != nil {
                if UIImagePNGRepresentation(image) != nil {
                    let data1: Data = UIImagePNGRepresentation(self)!
                    let data2: Data = UIImagePNGRepresentation(image)!
                    return (data1 == data2)
            }
        }
        return true
    }
    
}

extension UIView {
    class func loadFromNibNamed(_ nibNamed: String, bundle : Bundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiate(withOwner: nil, options: nil)[0] as? UIView
    }
}
