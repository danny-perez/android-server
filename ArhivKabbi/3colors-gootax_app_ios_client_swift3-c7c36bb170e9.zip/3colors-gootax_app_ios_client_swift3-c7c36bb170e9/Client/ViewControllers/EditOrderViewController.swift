//
//  EditOrderViewController.swift
//  Client
//
//  Created by  Andrew on 20/11/2017.
//  Copyright © 2017 Gootax. All rights reserved.
//

import UIKit

class EditOrderViewController: UIViewController {
    
    // Constant
    private let ORDER_UPDATE_TIME_INTERVAL = 5.0
    
    // Views
    @IBOutlet weak var niTitle: UINavigationItem!
    @IBOutlet weak var bbiClose: UIBarButtonItem!
    
    @IBOutlet weak var tvAddresses: UITableView!
    @IBOutlet weak var labelAddressesTitle: UILabel!
    @IBOutlet weak var constraintTableViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var labelCallCost: UILabel!
    
    @IBOutlet weak var buttonAddAddress: UIButton!
    
    @IBOutlet weak var buttonUpdateOrder: UIButton!
    
    @IBOutlet weak var viewPaymentContainer: UIView!
    @IBOutlet weak var ivPaymentIcon: UIImageView!
    @IBOutlet weak var labelPaymentName: UILabel!
    @IBOutlet weak var labelPayment: UILabel!
    
    @IBOutlet weak var blurViewContainer: UIView!
    @IBOutlet weak var mainViewContainer: UIView!
    
    // Private fields
    fileprivate var mainProfile: Profile? = nil
    fileprivate var currentOrder: Order? = nil
    fileprivate var addressList: [AddressTemp] = []
    
    fileprivate var orderUpdateTimer: Timer? = nil
    fileprivate var visualEffectView : UIVisualEffectView?
    fileprivate var waitingAlert: UIAlertController? = nil
    
    fileprivate var updateId: String? = nil
    
    // Open fields
    public var orderId: String? = nil
    private(set) public var orderTemplate: OrderTemp? = nil
    
    
    // All existing payment types
    enum Payment: String {
        case cash = "CASH"
        case card = "CARD"
        case personal = "PERSONAL_ACCOUNT"
        case company = "CORP_BALANCE"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.constraintTableViewHeight.constant = 60
        
        if self.visualEffectView == nil {
            self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
            self.visualEffectView?.frame = self.view.bounds
            self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
            self.visualEffectView?.alpha = 1
            self.view.insertSubview(self.visualEffectView!, at: 1)
            self.visualEffectView?.backgroundColor = blurColor
        }
        
        self.initTheme()
        self.initLocale()
        self.initVariables()
        self.initTable()
        self.updateTableHeight()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.addressList = onFindAddresses(by: orderTemplate!)
        
        self.updatePayment(by: orderTemplate?.payType)
        self.tvAddresses.reloadData()
        self.updateCallCost()
        self.updateAddAddressButtonState()
        self.updateTableHeight()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // Close current screen
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    // Show addresses screen
    @IBAction func onAddAddressAction(_ sender: Any) {
        self.onAddAddress(by: getNextPoint())
    }
    
    
    // Start update order request
    @IBAction func onUpdateOrderAction(_ sender: Any) {
        self.updateCurrentOrder()
    }
    
    
    // Delete address from list
    @IBAction func onDeleteAddressAction(_ sender: Any) {
        var indexPath: IndexPath!
        
        if let button = sender as? UIButton {
            if let superview = button.superview {
                if let cell = superview.superview?.superview as? AddressPathTableViewCell {
                    indexPath = self.tvAddresses.indexPath(for: cell)
                    self.deletePathAtIndex(indexPath)
                    self.updateTableHeight()
                    self.updateAddAddressButtonState()
                    self.updateCallCost()
                }
            }
        }
    }
    
    
    // Show payment screen
    @objc fileprivate func onChangePayment() {
        let vcPayment = self.storyboard?.instantiateViewController(withIdentifier: "PaymentType") as? PayTypeViewController
        vcPayment?.curOrder = orderTemplate
        vcPayment?.isOrderCreated = true
        self.navigationController?.pushViewController(vcPayment!, animated: true)
    }
    
    
    // Show addresses screen
    fileprivate func onAddAddress(by point: String) {
        let vcSearchAddress = self.storyboard?.instantiateViewController(withIdentifier: "SelectAddress") as? SelectAddressTableViewController
        vcSearchAddress?.point = point
        vcSearchAddress?.centerCol = CLLocationCoordinate2D(latitude: CLLocationDegrees(addressList[0].lat!), longitude: CLLocationDegrees(addressList[0].lon!))
        vcSearchAddress?.curOrder = orderTemplate
        vcSearchAddress?.isOrderCreated = true
        self.navigationController?.pushViewController(vcSearchAddress!, animated: true)
    }
    
    
    // Initzialize important variables
    private func initVariables() {
        mainProfile = profile()
        currentOrder = onFindCurrentOrder(by: orderId)
        orderTemplate = parseOrder(currentOrder!)
        addressList = onFindAddresses(by: orderTemplate!)
        
        let paymentGesture = UITapGestureRecognizer(target: self, action: #selector(onChangePayment))
        self.viewPaymentContainer.addGestureRecognizer(paymentGesture)
    }
    
    
    // Initialize view colors and styles
    private func initTheme() {
        // Navigation
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        
        // Payment
        let paymentContainerLayer = viewPaymentContainer.layer
        paymentContainerLayer.borderWidth = 1
        paymentContainerLayer.borderColor = UIColor.gray.cgColor
        paymentContainerLayer.shadowColor = UIColor.gray.cgColor
        paymentContainerLayer.shouldRasterize = true
        paymentContainerLayer.rasterizationScale = UIScreen.main.scale
        paymentContainerLayer.shadowOffset = CGSize(width: 0, height: 0)
        paymentContainerLayer.shadowOpacity = 0.3
        paymentContainerLayer.shadowRadius = 2
        
        // Add path
        self.buttonAddAddress.layer.cornerRadius = 0.5 * self.buttonAddAddress.bounds.size.width
        self.buttonAddAddress.clipsToBounds = true
        self.buttonAddAddress.setBackgroundImage(imageWithColor(colorNewTint()), for: UIControlState())
        self.buttonAddAddress.setBackgroundImage(imageWithColor(UIColor.black), for: .highlighted)
        self.buttonAddAddress.setBackgroundImage(imageWithColor(colorDisabledButton()), for: .disabled)
        let plusImage = UIImage(named: "plus")
        let tintedPlusImage = plusImage?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
        self.buttonAddAddress.setImage(tintedPlusImage, for: UIControlState())
        self.buttonAddAddress.tintColor = colorNewTextTint()
        
        // Table Addresses
        let addressesContainerLayer = tvAddresses.layer
        addressesContainerLayer.borderWidth = 1
        addressesContainerLayer.borderColor = UIColor.gray.cgColor
        
        // Save button
        self.buttonUpdateOrder.setColors()
        self.buttonUpdateOrder.setTitle(strComSave(), for: .normal)
    }
    
    
    private func initLocale() {
        self.niTitle.title = strComEditOrder()
        self.labelPayment.text = strComPayment()
        self.labelAddressesTitle.text = strComAddresses()
    }
    
    
    private func initTable() {
        self.tvAddresses.estimatedRowHeight = 80
        self.tvAddresses.rowHeight = UITableViewAutomaticDimension
        self.tvAddresses.dataSource = self
        self.tvAddresses.delegate = self
        self.tvAddresses.isScrollEnabled = false
        self.tvAddresses.reloadData()
        self.updateTableHeight()
    }
    
    
    // Send request on update order
    fileprivate func updateCurrentOrder() {
        guard let safeOrderId = currentOrder?.orderID,
            let safeTemplateOrder = orderTemplate,
            let safeProfile = mainProfile else {
                return
        }
        
        postUpdateOrder(profile: safeProfile, order: safeTemplateOrder, orderId: safeOrderId, handler: { result in
            self.updateId = result
            self.startUpdateResultTimer()
            self.showWaitingDialog(message: strComUpdatingOrder())
        })
    }
    
    
    
    // Send requset on get update result
    @objc private func checkCurrentOrderUpdateResult() {
        guard let safeUpdateId = updateId, !safeUpdateId.isEmpty,
            let safePhone = mainProfile?.phone else {
                return
        }
        
        getUpdateOrderResult(updateId: safeUpdateId, phone: safePhone, completation: { result in
            switch (result) {
            case .failure:
                showMessage(strComUpdateOrder(), message: strComUpdateOrderError())
                self.stopUpdateResultTimer()
                self.dismissWaitingDialog()
            case .retry:
                return
            case .success:
                showMessage(strComUpdateOrder(), message: strComUpdateOrderSuccess())
                self.stopUpdateResultTimer()
                self.saveOrder(tempOrder: self.orderTemplate!, to: self.currentOrder)
                self.dismissWaitingDialog()
            }
        })
    }
    
    
    // Update current payment view
    fileprivate func updatePayment(by paymentType: String?) {
        switch paymentType! {
        case Payment.cash.rawValue:
            self.ivPaymentIcon.image = UIImage(named: "cash")
            self.labelPaymentName.text = strPayCash()
        case Payment.card.rawValue:
            self.ivPaymentIcon.image = UIImage(named: "visa")
            self.labelPaymentName.text = strComPaymentCard()
        case Payment.personal.rawValue:
            self.ivPaymentIcon.image = UIImage(named: "pers")
            self.labelPaymentName.text = strPayPersBal()
        case Payment.company.rawValue:
            self.ivPaymentIcon.image = UIImage(named: "comp")
            self.labelPaymentName.text = strPayCorpBal()
        default:
            self.ivPaymentIcon.image = UIImage(named: "cash")
            self.labelPaymentName.text = strPayCash()
        }
    }
    
    
    // Find order from Core Data
    fileprivate func onFindCurrentOrder(by orderId: String?) -> Order? {
        let predicate = NSPredicate(format: "orderID = %@", orderId!)
        let order = Order.mr_findFirst(with: predicate)
        return order
    }
    
    
    // Get addresses list from order
    fileprivate func onFindAddresses(by order: OrderTemp) -> [AddressTemp] {
        var addresses: [AddressTemp] = []
        if let address = order.pathA { addresses.append(address) }
        if let address = order.pathB { addresses.append(address) }
        if let address = order.pathC { addresses.append(address) }
        if let address = order.pathD { addresses.append(address) }
        if let address = order.pathE { addresses.append(address) }
        return addresses
    }
    
    
    // Get next empty point for add address
    fileprivate func getNextPoint() -> String {
        guard addressList.count < 5 else {
            return "e"
        }
        
        let points = ["a", "b", "c", "d", "e"]
        return points[addressList.count] // if count 1 then points return "B" etc.
    }
    
    
    // Show and hide add address button
    fileprivate func updateAddAddressButtonState() {
        if addressList.count == 5 {
            self.buttonAddAddress.isHidden = true
        } else {
            self.buttonAddAddress.isHidden = false
        }
    }
    
    
    // Set new height to TableView
    fileprivate func updateTableHeight() {
        self.tvAddresses.layoutIfNeeded()
        self.constraintTableViewHeight.constant = self.tvAddresses.contentSize.height + 2
    }
    
    
    // Start timer for get update result
    fileprivate func startUpdateResultTimer() {
        self.orderUpdateTimer = Timer.scheduledTimer(timeInterval: ORDER_UPDATE_TIME_INTERVAL, target: self, selector: #selector(self.checkCurrentOrderUpdateResult), userInfo: nil, repeats: true)
    }
    
    
    // Stop timer for get update result
    fileprivate func stopUpdateResultTimer() {
        if let safeUpdateTimer = self.orderUpdateTimer, safeUpdateTimer.isValid {
            safeUpdateTimer.invalidate()
            self.orderUpdateTimer = nil
        }
    }
    
    
    // Update pre cost label
    fileprivate func updateCallCost() {
        guard let safeTamplateOrder = self.orderTemplate else {
            return
        }
        
        callCostForOrder(ord: safeTamplateOrder, completion: { result in
            if result.isFixed == true {
                self.labelCallCost.text = "\(strCCostFixPrice()) \(costStringFromDouble(result.cost!))"
            }
            else {
                self.labelCallCost.text = "~ \(costStringFromDouble(result.cost!)), \(String(format: "%.1f", result.distance!)) \(strCCostKm()), \(String(format: "%.0f", result.time!)) \(strCCostMin())"
            }
        })
    }
    
    
    // Save changes order in CoreData
    fileprivate func saveOrder(tempOrder: OrderTemp, to order: Order?) {
        order?.payType = tempOrder.payType
        order?.companyId = tempOrder.payCompanyId
        if let pan = tempOrder.payPan { order?.cardNum = pan }
        
        for (index, address) in addressList.enumerated() {
            switch index {
            case 0:
                order?.pointA = addressTempToOrder(address)
            case 1:
                order?.pointB = addressTempToOrder(address)
            case 2:
                order?.pointC = addressTempToOrder(address)
            case 3:
                order?.pointD = addressTempToOrder(address)
            case 4:
                order?.pointE = addressTempToOrder(address)
            default:
                return
            }
        }
        
        saveDefaultContext()
    }
    
    
    // Show waiting dialog while updating order
    fileprivate func showWaitingDialog(message: String) {
        self.waitingAlert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        let spinnerIndicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        spinnerIndicator.center = CGPoint(x: 135.0, y: 65.5)
        spinnerIndicator.color = UIColor.black
        spinnerIndicator.startAnimating()
        
        self.waitingAlert!.view.addSubview(spinnerIndicator)
        self.present(self.waitingAlert!, animated: false, completion: nil)
    }
    
    
    // Dismiss waiting dialog after order update
    fileprivate func dismissWaitingDialog() {
        self.waitingAlert!.dismiss(animated: true, completion: nil)
    }
    
    
    // Delete address by index from order and addresses list
    fileprivate func deletePathAtIndex(_ ip : IndexPath) {
        self.addressList.remove(at: ip.row)
        switch ip.row {
        case 1 :
            self.orderTemplate?.pathB = self.orderTemplate?.pathC
            self.orderTemplate?.pathC = self.orderTemplate?.pathD
            self.orderTemplate?.pathD = self.orderTemplate?.pathE
            self.orderTemplate?.pathE = nil
        case 2 :
            self.orderTemplate?.pathC = self.orderTemplate?.pathD
            self.orderTemplate?.pathD = self.orderTemplate?.pathE
            self.orderTemplate?.pathE = nil
        case 3 :
            self.orderTemplate?.pathD = self.orderTemplate?.pathE
            self.orderTemplate?.pathE = nil
        case 4 :
            self.orderTemplate?.pathE = nil
        default :
            print("trash")
        }
        self.tvAddresses.reloadData()
    }
    
}


extension EditOrderViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addressList.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addrPath", for: indexPath) as! AddressPathTableViewCell
        let address = addressList[indexPath.row]
        cell.setAddress(address, inCity: true)
        
        switch indexPath.row {
        case 0:
            cell.pointPath = "a"
            cell.pathImage.image = UIImage(named: imageListA())
            cell.viewPorchContainer.isHidden = true
        case 1:
            cell.pointPath = "b"
            cell.pathImage.image = UIImage(named: imageListB())
        case 2:
            cell.pointPath = "c"
            cell.pathImage.image = UIImage(named: imageListC())
        case 3:
            cell.pointPath = "d"
            cell.pathImage.image = UIImage(named: imageListD())
        case 4:
            cell.pointPath = "e"
            cell.pathImage.image = UIImage(named: imageListE())
        default:
            break
        }
        
        return cell
    }
    
}


extension EditOrderViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard indexPath.row > 0 else { return }
        let addressCell = tableView.cellForRow(at: indexPath) as! AddressPathTableViewCell
        self.onAddAddressAction(by: addressCell.pointPath!)
    }
    
}

