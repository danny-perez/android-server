//
//  MapPickViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 04.04.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
import GoogleMaps

import UIKit
import GoogleMaps

class MapPickViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var osmMap: MKMapView!
    @IBOutlet weak var gmsMap: GMSMapView!
    @IBOutlet weak var annImage: UIImageView!
    @IBOutlet weak var addrView: UIView!
    @IBOutlet weak var streetLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var addrIcon: UIImageView!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var pathLabel: UILabel!
    @IBOutlet weak var centerOnUser: UIButton!
    
    
    var curAddress : AddressTemp?
    var locationManager : CLLocationManager?
    var loadAddressTimer : Timer?
    var curOrder : OrderTemp?
    var path : String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if path == nil {
            path = "b"
        }
        showMap()
        if self.curAddress == nil {
            self.curAddress = AddressTemp()
        }
        
        self.setAddress()
        self.pathLabel.text = self.path?.uppercased()
        
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.requestWhenInUseAuthorization()
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        locationManager?.startUpdatingLocation()
        
        localize()
        colorize()
        
        if path == "b" {
            self.addrIcon.image = UIImage(named: "b-list")
        }
        else if path == "c" {
            self.addrIcon.image = UIImage(named: "c-list")
        }
        else if path == "d" {
            self.addrIcon.image = UIImage(named: "d-list")
        }
        else if path == "e" {
            self.addrIcon.image = UIImage(named: "e-list")
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func showMap()
    {
        if curMap() == 0 {
            if #available(iOS 9.0, *) {
                osmMap.showsCompass = false
                //osmMap.mapType = .HybridFlyover // не включать - можно случайно кончить
            } else {
                // Fallback on earlier versions
            }
            
            osmMap.showsUserLocation = false
            osmMap.delegate = self
            let overlay = MKTileOverlay(urlTemplate: kOSMTiles)
            overlay.canReplaceMapContent = true
            osmMap.add(overlay, level: MKOverlayLevel.aboveLabels)
            
            osmMap.isHidden = false
            self.gmsMap?.isHidden = true
        } else if curMap() == 2 {
            if #available(iOS 9.0, *) {
                osmMap.showsCompass = false
                //osmMap.mapType = .HybridFlyover // не включать - можно случайно кончить
            } else {
                // Fallback on earlier versions
            }
            
            osmMap.showsUserLocation = false
            osmMap.delegate = self
            let tilesOverlay = DGSTileOverlay()
            osmMap.insert(tilesOverlay, at: 0, level: MKOverlayLevel.aboveLabels)
            
            osmMap.isHidden = false
            self.gmsMap?.isHidden = true
        }
        else {
            if gmsMap == nil {
                gmsMap = GMSMapView()
                gmsMap?.settings.allowScrollGesturesDuringRotateOrZoom = false
                gmsMap?.settings.rotateGestures = false
            }
            if curGoogleMapType() {
                gmsMap.mapType = .normal
            }
            else {
                gmsMap.mapType = .hybrid
            }
            gmsMap?.delegate = self
            osmMap.isHidden = true
            self.gmsMap?.isHidden = false
        }
    }
    
    //MARK: osm map delegate
    
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        self.curAddress?.label = strComLoading()
        self.setAddress()
    }
    
    
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        runTimer()
    }
    
    
    fileprivate func mapViewRegionDidChangeFromUserInteraction() -> Bool {
        if curMap() == 0 || curMap() == 2 {
            let view = self.osmMap.subviews[0]
            //  Look through gesture recognizers to determine whether this region change is from user interaction
            if let gestureRecognizers = view.gestureRecognizers {
                for recognizer in gestureRecognizers {
                    if( recognizer.state == UIGestureRecognizerState.began || recognizer.state == UIGestureRecognizerState.ended ) {
                        return true
                    }
                }
            }
        }
        return false
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        return MKTileOverlayRenderer(overlay: overlay)
    }
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        runTimer()
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        self.curAddress?.label = strComLoading()
        self.setAddress()
    }
    
    //MARK: work with timer for update geolocation
    
    func runTimer()
    {
        if loadAddressTimer != nil {
            loadAddressTimer?.invalidate()
            loadAddressTimer = nil
        }
        loadAddressTimer = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(MapPickViewController.updateGeoloc), userInfo: nil, repeats: false)
    }
    
    func updateGeoloc() {
        let center = self.centerCoordinate()
            getAddressByCoords(center, city: curCity() , completion: { (address: AddressTemp?, arr: [AddressTemp]) -> Void in
            var setted : Bool = false
            if self.curAddress != nil {
                if address != nil {
                    if self.curAddress!.street == address!.street {
                        if self.curAddress?.house == address!.house {
                            if self.curAddress?.label == address?.label {
                                setted = self.curAddress?.shortStrFromTempAddress() != strComNoAddrs()
                            }
                        }
                    }
                }
            }
            if setted == false {
                self.curAddress = address
            }
            self.setAddress()
        }) { (error) -> Void in
            
        }
    }
    
    func centerCoordinate() -> CLLocationCoordinate2D {
        var center = CLLocationCoordinate2DMake(0, 0)

        if curMap() == 1 {
            center = (self.gmsMap?.projection.coordinate(for: self.gmsMap!.center))!
        }
        else {
            center = self.osmMap.convert(CGPoint(x: self.view.frame.width/2, y: self.view.frame.height/2), toCoordinateFrom: self.view)
        }
        return center
    }
    
    
    @IBAction func doCenter(_ sender: AnyObject) {
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.requestWhenInUseAuthorization()
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager?.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let closestCity = curCity()
        // self.curCities![0].centerCoord?.coordinate.
        let coord = CLLocationCoordinate2DMake((closestCity.lat)!, (closestCity.lon)!)
        if (curMap() == 0 || curMap() == 2) {
            var region : MKCoordinateRegion = MKCoordinateRegion()
            var span : MKCoordinateSpan = MKCoordinateSpan()
            span.latitudeDelta = 0.005
            span.longitudeDelta = 0.005
            region.span = span
            region.center = coord
            self.osmMap.setRegion(region, animated: false)
        }
            if (curMap() == 1) {
                self.gmsMap?.animate(toLocation: coord)
                self.gmsMap?.animate(toZoom: 17)
            }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if curMap() == 1 {
            let camera = GMSCameraPosition.camera(withTarget: locations[0].coordinate, zoom: 17)
            self.gmsMap?.camera = camera
        }
        else {
            var region : MKCoordinateRegion = MKCoordinateRegion()
            var span : MKCoordinateSpan = MKCoordinateSpan()
            span.latitudeDelta = 0.005
            span.longitudeDelta = 0.005
            region.span = span
            region.center = locations[0].coordinate
            self.osmMap.setRegion(region, animated: true)
        }
        self.locationManager?.stopUpdatingLocation()
        self.locationManager = nil
    }
    
    
    func colorize()
    {
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.sizeToFit()
        self.approveButton.setColors()
        self.applyCurvedShadow(self.addrView)
    }
    
    @IBAction func approveAction(_ sender: AnyObject) {
        let label = self.curAddress?.label ?? ""
        guard label != strComLoading() else {
            showMessage(strErrTitle(), message: "Идет поиск заказа")
            return
        }
        
        let mapContrnoller = self.navigationController?.viewControllers.first(where: { viewController in
            return viewController is SelectAddressTableViewController
        }) as! SelectAddressTableViewController
        
        if self.path == "b" {
            mapContrnoller.curOrder?.pathB = self.curAddress
        }
        else if self.path == "c" {
            mapContrnoller.curOrder?.pathC = self.curAddress
        }
        else if self.path == "d" {
            mapContrnoller.curOrder?.pathD = self.curAddress
        }
        else if self.path == "e" {
            mapContrnoller.curOrder?.pathE = self.curAddress
        }
        mapContrnoller.selectOnMap()
    }
    
    
    func localize()
    {
        self.navigationItem.title = strComSelectPoint()
        self.approveButton.setTitle(strComButApprove().uppercased(), for: UIControlState())
        self.approveButton.layer.cornerRadius = 4;
    }
    
    
    func setAddress() {
        self.streetLabel.text = self.curAddress!.shortStrFromTempAddress()
        self.cityLabel.text = self.curAddress?.city
        
        if self.streetLabel.text == strComNoAddrs() {
            self.approveButton.isEnabled = false
        } else if (self.streetLabel.text == strComLoading()) {
            self.cityLabel.text = ""
        } else {
            self.approveButton.isEnabled = true
        }
        self.addrView.layoutIfNeeded()
    }
    
    func applyCurvedShadow(_ view: UIView) {
        let layer = view.layer
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.3
        layer.shadowRadius = 1
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
