//
//  NewTimePickViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 30.12.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class NewTimePickViewController: UIViewController {
    @IBOutlet weak var AVIEW: UIView!
    var visualEffectView : UIVisualEffectView?
    var timePicker : UIDatePicker?
    
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var selectTime: UIButton!
    @IBOutlet weak var nowBut: UIButton!
    var timerRefreshOrder : Timer?
    var curOrder : OrderTemp?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 1)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 1)
        }
        
        self.indicator.isHidden = false
        self.indicator.startAnimating()
        localize()
        colorize()
        
        //        self.timePicker?.addConstraint(NSLayoutConstraint(item: self.timePicker!, attribute: .CenterY, relatedBy: .Equal, toItem: self.view, attribute: .CenterY, multiplier: 1.0, constant: 0))
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    func setMinimum() {
        self.timePicker?.minimumDate = Date().addingTimeInterval(60*15)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.timerRefreshOrder != nil {
            self.timerRefreshOrder?.invalidate()
            self.timerRefreshOrder = nil
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.timePicker = UIDatePicker()
        let locale = Locale(identifier: selLan())
        //        let locale = NSLocale(localeIdentifier: "en")
        self.timePicker?.locale = locale
        if self.curOrder?.orderTime != nil {
            self.timePicker?.setDate(getFakeOrderDate((self.curOrder?.orderTime)!), animated: false)
        }
        
        self.timePicker?.minimumDate = Date().addingTimeInterval(60*15)
        self.timePicker?.alpha = 0
        self.AVIEW.insertSubview(self.timePicker!, at: 0)
        UIView.animate(withDuration: 0.1, animations: { () -> Void in
            self.timePicker?.alpha = 1
        })
        
        self.timePicker?.frame = CGRect(x: 0, y: (UIScreen.main.bounds.height - 64)/2 - 125, width: self.AVIEW.frame.width, height: 200)
        
        self.timePicker!.addTarget(self, action: #selector(NewTimePickViewController.changedAction), for: UIControlEvents.valueChanged)
        if self.timerRefreshOrder == nil {
            self.timerRefreshOrder = Timer.scheduledTimer(timeInterval: Double(10), target: self, selector: #selector(NewTimePickViewController.setMinimum), userInfo: "", repeats: true)
        }
        
        self.changedAction()
        self.indicator.isHidden = true
    }
    
    //MARK: - ACtions
    
    @IBAction func nowAction(_ sender: AnyObject) {
        self.curOrder?.orderTime = nil
        self.closeAction("" as AnyObject)
    }
    
    @IBAction func selectTimeAction(_ sender: AnyObject) {
        if self.timePicker != nil {
            self.curOrder?.orderTime =
                    Date(timeIntervalSince1970: (self.timePicker!.date.timeIntervalSince1970) - getInaccuracy())
            getTariffsType(order: self.curOrder!) { (arr) -> Void in
                
            }
        }
        self.closeAction("" as AnyObject)
    }
    
    func changedAction() {
        let dateFormatter = DateFormatter()
        if (profile().calendar == persian) {
            let calendar = Calendar(identifier: Calendar.Identifier.persian)
            timePicker?.calendar = calendar
        }
        dateFormatter.dateFormat = "yyyy-MM-dd hh:mm"
        let date1String = dateFormatter.string(from: (self.timePicker?.date)!)
        let date2String = dateFormatter.string(from: (self.timePicker?.minimumDate)!)
        if date1String == date2String {
            self.nowBut.isEnabled = false
        }
        else {
            self.nowBut.isEnabled = true
        }
    }
    
    @IBAction func closeAction(_ sender: AnyObject) {
        (self.presentingViewController as! UINavigationController).viewControllers[0].viewWillAppear(true)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    //MARK:- Commons
    
    func colorize() {
        self.selectTime.setColors()
        self.navBar.barTintColor = colorNewNavBarBack()
        self.navBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navBar.tintColor = colorNewHamButton()
        self.navBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navBar.addSubview(view)
        self.closeButton.tintColor = colorNewHamButton()
    }
    
    func localize() {
        self.selectTime.setTitle(strTimeSelect().uppercased(), for: UIControlState())
        self.selectTime.layer.cornerRadius = 4;
        self.nowBut.setTitle(strTimeNowLong(), for: UIControlState())
        self.nowBut.layer.cornerRadius = 4;
        self.navItem.title = strTimeTitle()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
