//
//  NewOrderViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 19.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class NewOrderViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var curOrder : OrderTemp!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var approveButton: UIButton!
    
    //первый ли экран
    var firstScreen : Bool = false
    
    var pathCount : Int = 2
    
    var pathTableView : UITableView?
    
    var collectionView : UICollectionView?
    
    var showCallCost : Bool = true
    
    var loadingCallCost = true
    
    var visualEffectView : UIVisualEffectView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "localize", name: notifChangeLan, object: nil)

        self.tableView.tableFooterView = UIView(frame: CGRectMake(0, 0, 1, 73))
        
        if self.curOrder == nil {
            self.curOrder = OrderTemp()
            self.firstScreen = true
        }
        
        if self.curOrder?.pathC != nil {
            pathCount++
            if self.curOrder?.pathD != nil {
                pathCount++
                if self.curOrder?.pathE != nil {
                    pathCount++
                }
            }
        }
        
        if self.pathCount == 2 {
            if self.curOrder.pathB?.street == "" {
                showCallCost = false
            }
        }
        
        if self.curOrder.orderTariff == nil {
            if curCity().tariffs!.count > 0 {
                self.curOrder.orderTariff = curCity().tariffs![0]
            }
        }
        
        self.tableView.delaysContentTouches = false
        
        for view in self.tableView.subviews {
            if (classNameAsString(view) == "UITableViewWrapperView") {
                if view.isKindOfClass(UIScrollView) {
                    let scroll = (view as! UIScrollView)
                    scroll.delaysContentTouches = false
                }
                break
            }
        }
        
        colorize()
        localize()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.pathTableView?.reloadData()
        self.tableView.reloadData()
        
        if self.collectionView != nil {
            self.collectionView?.reloadData()
        }
        self.callCost()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if tableView == self.tableView {
            return 1
        }
        else {
            return 1
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableView {
            return 5
        }
        else {
            return self.pathCount
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if tableView == self.tableView {
            if indexPath.row == 0 {
                let cell : PathTableViewCell = tableView.dequeueReusableCellWithIdentifier("path", forIndexPath: indexPath) as! PathTableViewCell
                
                cell.pathTableView.layer.cornerRadius = 6
                
                return cell
            }
            else if indexPath.row == 1 {
                let cell : TwoLabelsTableViewCell = tableView.dequeueReusableCellWithIdentifier("dflt", forIndexPath: indexPath) as! TwoLabelsTableViewCell
                cell.titleLabel.text = strComTariff()
                cell.valueLabel.text = self.curOrder.orderTariff?.tariffLabel
                
                return cell
                
            }
            else if indexPath.row == 2 {
                let cell : TwoLabelsTableViewCell = tableView.dequeueReusableCellWithIdentifier("dflt", forIndexPath: indexPath) as! TwoLabelsTableViewCell
                cell.titleLabel.text = strComCarTime()
                if self.curOrder.orderTime == nil {
                    cell.valueLabel.text = strComNow()
                }
                else {
                    cell.valueLabel.text = printFullDate(getFakeOrderDate(self.curOrder.orderTime!))
                }
                
                return cell
                
            }
            else if indexPath.row == 3 {
                let cell : WishesTableViewCell = tableView.dequeueReusableCellWithIdentifier("wishes", forIndexPath: indexPath) as! WishesTableViewCell
                if (self.curOrder.orderWishes?.count)! > 0 {
                    cell.notSelectedLabel.hidden = true
                }
                else {
                    cell.notSelectedLabel.hidden = false
                }
                
                return cell
                
            }
            else if indexPath.row == 4 {
                let cell : CallCostTableViewCell = tableView.dequeueReusableCellWithIdentifier("callcost", forIndexPath: indexPath) as! CallCostTableViewCell
                
                cell.setLoading(self.loadingCallCost)
                
                cell.hidden = !self.showCallCost
                
                return cell
            }
            else {
                let cell : CreateOrderTableViewCell = tableView.dequeueReusableCellWithIdentifier("approve", forIndexPath: indexPath) as! CreateOrderTableViewCell
                
                for view in cell.subviews {
                    if (classNameAsString(view) == "UITableViewCellScrollView") {
                        if view.isKindOfClass(UIScrollView) {
                            let scroll = (view as! UIScrollView)
                            scroll.delaysContentTouches = false
                        }
                    }
                }
                
                cell.separatorInset = UIEdgeInsetsMake(0, 150000, 0, 0);
                
                return cell
            }
        }
        else {
            let cell : SinglePathTableViewCell = tableView.dequeueReusableCellWithIdentifier("singlePath", forIndexPath: indexPath) as! SinglePathTableViewCell
            
            
            cell.pathLabel.text = ""
            
            cell.contentView.frame = cell.bounds
            
            var addr : AddressTemp = AddressTemp()
            if indexPath.row == 0 {
                cell.pathImage.image = UIImage(named: imagePathA())
                addr = (self.curOrder?.pathA)!
                cell.topView.hidden = true
                cell.botView.hidden = false
                cell.plusBut.hidden = true
            }
            else if indexPath.row == 1 {
                cell.pathImage.image = UIImage(named: imagePathB())
                addr = (self.curOrder?.pathB)!
                cell.topView.hidden = false
            }
            else if indexPath.row == 2 {
                cell.pathImage.image = UIImage(named: imagePathC())
                addr = (self.curOrder?.pathC)!
            }
            else if indexPath.row == 3 {
                cell.pathImage.image = UIImage(named: imagePathD())
                addr = (self.curOrder?.pathD)!
            }
            else if indexPath.row == 4 {
                cell.pathImage.image = UIImage(named: imagePathE())
                addr = (self.curOrder?.pathE)!
            }
            if self.pathCount == indexPath.row + 1 {
                cell.botView.hidden = true
                if self.pathCount < maxPoints {
                    cell.plusBut.hidden = false
                }
                else {
                    cell.plusBut.hidden = true
                }
                if addr.street == "" {
                    cell.plusBut.hidden = true
                }
                else {
                    cell.plusBut.hidden = false
                }
            }
            else {
                cell.botView.hidden = false
                cell.plusBut.hidden = true
            }
            if self.pathCount == maxPoints {
                cell.plusBut.hidden = true
            }
            
            cell.setAddress(addr)
            
            self.pathTableView = tableView
            tableView.separatorStyle = .None
            self.tableView.reloadData()
            return cell
        }
    }
    
    
    // Override to support conditional editing of the table view.
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        if tableView == self.tableView {
            return false
        }
        else {
            if indexPath.row == 0 {
                if pathCount == 2 {
                    if self.curOrder?.pathB?.street == "" {
                        return false
                    }
                    else {
                        return true
                    }
                }
                else {
                    return true
                }
            }
            if indexPath.row + 1 == pathCount {
                var addr : AddressTemp = AddressTemp()
                if indexPath.row == 0 {
                    addr = (self.curOrder?.pathA)!
                }
                else if indexPath.row == 1 {
                    addr = (self.curOrder?.pathB)!
                }
                else if indexPath.row == 2 {
                    addr = (self.curOrder?.pathC)!
                }
                else if indexPath.row == 3 {
                    addr = (self.curOrder?.pathD)!
                }
                else if indexPath.row == 4 {
                    addr = (self.curOrder?.pathE)!
                }
                if addr.street == "" {
                    return false
                }
                else {
                    return true
                }
                
            }
            return true
        }
    }
    
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if tableView == self.tableView {
            if indexPath.row == 0 {
                if let size : CGSize = self.pathTableView?.contentSize {
                    return size.height + 20
                }
                else {
                    return 120
                }
            }
            else if indexPath.row == 1 {
                return 44
            }
            else if indexPath.row == 2 {
                return 44
            }
            else if indexPath.row == 3 {
                return 44
            }
            else if indexPath.row == 4 {
                if self.showCallCost {
                    return 70
                }
                else {
                    return 0
                }
            }
            else {
                return 70
            }
        }
        else {
            var addr : AddressTemp = AddressTemp()
            if indexPath.row == 0 {
                addr = (self.curOrder?.pathA)!
            }
            else if indexPath.row == 1 {
                addr = (self.curOrder?.pathB)!
            }
            else if indexPath.row == 2 {
                addr = (self.curOrder?.pathC)!
            }
            else if indexPath.row == 3 {
                addr = (self.curOrder?.pathD)!
            }
            else if indexPath.row == 4 {
                addr = (self.curOrder?.pathE)!
            }
            if addr.street == "" {
                return heightForView(strInfoSetPoint(), font: UIFont.systemFontOfSize(13), width: UIScreen.mainScreen().bounds.width - 102) + 15
            }
            else {
                if indexPath.row + 1 == self.pathCount {
                    return heightForView(strFromTempAddress(addr), font: UIFont.systemFontOfSize(17), width: UIScreen.mainScreen().bounds.width - 102) + 15
                }
                else {
                    return heightForView(strFromTempAddress(addr), font: UIFont.systemFontOfSize(17), width: UIScreen.mainScreen().bounds.width - 102) + 10
                }
            }
            
        }
    }
    
    
    //MARK: TableView Delegate
    
    // Override to support editing the table view.
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if tableView != self.tableView {
            if editingStyle == .Delete {
                // Delete the row from the data source
                deletePathAtIndex(indexPath)
                //                UIView.animateWithDuration(0.0, animations: { () -> Void in
                if self.pathCount > 2 {
                    self.pathCount = self.pathCount - 1
                }
                tableView.reloadData()
                if let cell : SinglePathTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as? SinglePathTableViewCell {
                    cell.contentView.backgroundColor = colorPathBackground()
                }
                self.tableView.reloadData()
                
            }
        }
        self.callCost()
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if tableView != self.tableView {
            self.performSegueWithIdentifier("selectPath", sender: indexPath)
        }
        else {
            if indexPath.row == 1 {
                self.performSegueWithIdentifier("selectTariff", sender: self)
            }
            else if indexPath.row == 2 {
                self.performSegueWithIdentifier("selectTime", sender: self)
            }
            else if indexPath.row == 3 {
                self.performSegueWithIdentifier("selectAdds", sender: self)
            }
        }
    }
    
    func tableView(tableView: UITableView, willBeginEditingRowAtIndexPath indexPath: NSIndexPath) {
        if let cell : SinglePathTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as? SinglePathTableViewCell {
            cell.contentView.backgroundColor = colorPathBackgroundEdit()
        }
        
    }
    
    func tableView(tableView: UITableView, didEndEditingRowAtIndexPath indexPath: NSIndexPath) {
        if let cell : SinglePathTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as? SinglePathTableViewCell {
            cell.contentView.backgroundColor = colorPathBackground()
        }
    }

    
    
    
    
    
    //MARK: Collection View Data Source
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        if self.collectionView == nil {
            self.collectionView = collectionView
            collectionView.transform = CGAffineTransformMakeScale(-1, 1);
        }
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (self.curOrder.orderWishes?.count)!
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell : WishCollectionViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("wish", forIndexPath: indexPath) as! WishCollectionViewCell
        
        cell.wishLogo.image = UIImage(named: (self.curOrder.orderWishes)![indexPath.row].optionLogo!)
        
        cell.contentView.transform = CGAffineTransformMakeScale(-1, 1);
        
        return cell
    }
    
    
    
    //MARK: Actions
    
    @IBAction func createOrder(sender: UIButton)
    {
        if profile().phone != "" {
            self.disableView()
            
            createOrd(self.curOrder, completion: { (order) -> Void in
                print(order)
                self.enableView()
                
                let listNC = (self.tabBarController?.viewControllers)![1] as! UINavigationController
                if order.carDateTime == nil {
                    let curOrderView : CurrentOrderViewController = self.storyboard?.instantiateViewControllerWithIdentifier("CurOrder") as! CurrentOrderViewController
                    
                    curOrderView.curOrder = order
            
                    listNC.pushViewController(curOrderView, animated: false)
                    
                    UIView.transitionFromView(self.view, toView: curOrderView.view, duration: 0.3, options: UIViewAnimationOptions.TransitionFlipFromRight, completion: { (finished) -> Void in
                        print(finished)
                        self.tabBarController?.selectedIndex = 1
                        self.navigationController?.popToRootViewControllerAnimated(false)
                    })
                }
                else {
                    let curOrderView : PreorderViewController = self.storyboard?.instantiateViewControllerWithIdentifier("preorder") as! PreorderViewController
                    
                    curOrderView.ord = order
                    
                    
                    listNC.pushViewController(curOrderView, animated: false)
                    
                    UIView.transitionFromView(self.view, toView: curOrderView.view, duration: 0.3, options: UIViewAnimationOptions.TransitionFlipFromRight, completion: { (finished) -> Void in
                        print(finished)
                        self.tabBarController?.selectedIndex = 1
                        self.navigationController?.popToRootViewControllerAnimated(false)
                    })

                }
                
                }) { (str) -> Void in
                    self.enableView()
                    print(str)
            }
        }
        else {
            let dialog = UIAlertView()
            dialog.message = strComNeedAuth()
            dialog.addButtonWithTitle(strComClose())
            dialog.cancelButtonIndex = 0
            dialog.show()
        }
    }
    
    func disableView() {
        self.visualEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .ExtraLight)) as UIVisualEffectView
        
        self.visualEffectView!.frame = self.view.bounds
        self.visualEffectView!.alpha = 0
        self.view.addSubview(visualEffectView!)
        UIView.animateWithDuration(0.5) { () -> Void in
            self.visualEffectView!.alpha = 0.8
        }
        let text = "Создание заказа..."
        self.showWaitOverlayWithText(text)
        self.navigationController?.navigationBar.userInteractionEnabled = false
        self.navigationController?.navigationBar.tintColor = colorGrayLabelText()
    }
    
    func enableView() {
        self.removeAllOverlays()
        if self.visualEffectView != nil {
            UIView.animateWithDuration(0.5) { () -> Void in
                self.visualEffectView!.alpha = 0
            }
        }
        self.navigationController?.navigationBar.userInteractionEnabled = true
        self.navigationController?.navigationBar.tintColor = colorMainTint()
    }
    
    func callCost() {
        
        if (self.pathCount > 2) || (self.curOrder.pathB?.street != "") {
            self.showCallCost = true
            self.loadingCallCost = true
            self.reloadCallCostRow(true)
            callCostForOrder(self.curOrder) { (ccost) -> Void in
                self.loadingCallCost = false
                self.reloadCallCostRow(false)
                
                let ip = NSIndexPath(forRow: 4, inSection: 0)
                let cell : CallCostTableViewCell = self.tableView.cellForRowAtIndexPath(ip) as! CallCostTableViewCell
                cell.setCost(ccost)
            }
        }
        else {
            self.showCallCost = false
            self.reloadCallCostRow(true)
        }
    }
    
    func reloadCallCostRow(animated : Bool) {
        let ip = NSIndexPath(forRow: 4, inSection: 0)
        self.tableView.beginUpdates()
        var anim = UITableViewRowAnimation.None
        if animated {
            anim = .Fade
        }
        self.tableView.reloadRowsAtIndexPaths([ip], withRowAnimation: anim)
        self.tableView.endUpdates()
    }
    
    //MARK: Commons
    
    @IBAction func addPath(sender: AnyObject) {
        switch self.pathCount {
        case 2 :
            self.curOrder?.pathC = AddressTemp()
        case 3 :
            self.curOrder?.pathD = AddressTemp()
        case 4 :
            self.curOrder?.pathE = AddressTemp()
        default :
            print("trash kakoy to c plusom")
        }
        self.pathCount++
        self.pathTableView?.reloadData()
        self.performSegueWithIdentifier("selectPath", sender: NSIndexPath(forRow: self.pathCount-1, inSection: 0))
    }
    
    
    
    func deletePathAtIndex(ip : NSIndexPath)
    {
        switch ip.row {
        case 0 :
            self.curOrder?.pathA = self.curOrder?.pathB
            self.curOrder?.pathB = self.curOrder?.pathC
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            if pathCount == 2 {
                curOrder?.pathB = AddressTemp()
            }
            if pathCount == 3 {
                curOrder?.pathC = nil
            }
            if pathCount == 4 {
                curOrder?.pathD = nil
            }
        case 1 :
            self.curOrder?.pathB = self.curOrder?.pathC
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            if pathCount == 2 {
                curOrder?.pathB = AddressTemp()
            }
            if pathCount == 3 {
                curOrder?.pathC = nil
            }
            if pathCount == 4 {
                curOrder?.pathD = nil
            }
        case 2 :
            self.curOrder?.pathC = self.curOrder?.pathD
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
            if pathCount == 4 {
                curOrder?.pathD = nil
            }
        case 3 :
            self.curOrder?.pathD = self.curOrder?.pathE
            self.curOrder?.pathE = nil
        case 4 :
            self.curOrder?.pathE = nil
        default :
            print("trash")
        }
    }
    
    func colorize()
    {
        self.tableView.backgroundColor = colorGrayBackground()
        self.tableView.tableFooterView?.backgroundColor = colorGrayBackground()
        self.approveButton.setBackgroundImage(imageWithColor(colorMainTint()), forState: .Normal)
        self.approveButton.setBackgroundImage(imageWithColor(colorDisabledButton()), forState: .Disabled)
        self.approveButton.setBackgroundImage(imageWithColor(colorHighlightedButton()), forState: [UIControlState.Highlighted, UIControlState.Selected])
        self.approveButton.clipsToBounds = true
        self.approveButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
    }
    
    func localize()
    {
        self.navigationItem.title = strComOrder()
        self.approveButton.setTitle(strComCreateOrder(), forState: .Normal)
        self.approveButton.layer.cornerRadius = 16;
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "selectPath" {
            let controller : SelectAddressTableViewController = segue.destinationViewController as! SelectAddressTableViewController
            let ip : NSIndexPath = sender as! NSIndexPath
            
            if ip.row == 1 {
                controller.point = "b"
            }
            else if ip.row == 2 {
                controller.point = "c"
            }
            else if ip.row == 3 {
                controller.point = "d"
            }
            else if ip.row == 4 {
                controller.point = "e"
            }
            else {
                controller.point = "a"
            }
            
            controller.curOrder = self.curOrder
            
            controller.rootCont = self
            
        }
        else if segue.identifier == "selectTariff" {
            let controller : SelectTariffTableViewController = segue.destinationViewController as! SelectTariffTableViewController
            controller.curOrder = self.curOrder
        }
        else if segue.identifier == "selectTime" {
            let controller : SelectTimeTableViewController = segue.destinationViewController as! SelectTimeTableViewController
            controller.curOrder = self.curOrder
        }
        else if segue.identifier == "selectAdds" {
            let controller : WishesTableViewController = segue.destinationViewController as! WishesTableViewController
            controller.curOrder = self.curOrder
        }
        
    }
    
    
}
