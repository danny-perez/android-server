//
//  LanTitleTableViewCell.swift
//  Client
//
//  Created by Dmitriy Kudrin on 09.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

class LanTitleTableViewCell: UITableViewCell {

    @IBOutlet weak var lanTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        colorize()
        localize()
        
        NotificationCenter.default.addObserver(self, selector: #selector(LanTitleTableViewCell.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func colorize()
    {
        self.contentView.backgroundColor = colorGrayBackground()
        self.backgroundColor = colorGrayBackground()
        self.lanTitle.textColor = colorGrayLabelText()
    }
    
    func localize()
    {
        self.lanTitle.text = strComLanguage().uppercased()
    }

}
