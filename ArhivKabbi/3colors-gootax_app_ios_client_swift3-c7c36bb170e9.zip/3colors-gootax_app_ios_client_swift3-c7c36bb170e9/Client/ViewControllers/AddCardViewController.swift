//
//  AddCardViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 01.03.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class AddCardViewController: UIViewController, UIWebViewDelegate, UIAlertViewDelegate {

    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var webView: UIWebView!
    var updateDelay : Double = 5
    var updateInfo : Timer?
    var waitingDialog : UIAlertController?
    
    var firstPage = true
    
    var orderID : String?
    var url : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.indicator.isHidden = false
        self.webView.isHidden = true
        self.indicator.startAnimating()
        gxAddCard(profile()) { (result) -> Void in
            if result["orderId"] != nil {
                self.orderID = result["orderId"]! as String
            }
            if result["url"] != nil {
                self.url = result["url"]! as String
                let requestURL = URL(string:self.url!)
                let request = URLRequest(url: requestURL!)
                self.webView.loadRequest(request)
                self.webView.isHidden = false
                self.indicator.isHidden = true
            }
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        if self.firstPage == true {
            self.firstPage = false
        }
        else {
            let url = (webView.request?.url!.absoluteString)!
            let nsurl = URL(string:url)
            let comps = nsurl?.pathComponents
            if comps?.count > 0 {
                let last = comps?[(comps?.count)!-1]
                if (url.range(of: "success") != nil || last?.range(of: "errors") != nil) {
                    checkClientCard(self.orderID!, completion: { code in
                        self.webView.isHidden = true
                        self.indicator.isHidden = false
                        self.indicator.startAnimating()
                        switch(code) {
                        case 0:
                            self.updatePayments()
                            break
                        case 1:
                            self.updatePayments()
                            break
                        case 20:
                            self.showDialog()
                            if self.updateInfo == nil {
                                self.updateInfo = Timer.scheduledTimer(timeInterval: Double(self.updateDelay), target: self,
                                    selector: #selector(AddCardViewController.updatePayments), userInfo: "", repeats: false)
                            }
                            break
                        default: break
                        }
                    })
                }
            }
        }
    }
    
    func updatePayments() {
        gxUpdateProfile(profile(), completion: { (finished) -> Void in
            gxGetProfileCards(profile()) { (newProfile) -> Void in
            }
        })
        
        if (self.waitingDialog != nil) {
            self.waitingDialog!.dismiss(animated: true, completion: {
                showMessage("", message: strTieCardSucces())
                self.navigationController?.popViewController(animated: true)
            })
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func showDialog() {
        if self.waitingDialog == nil {
            self.waitingDialog  = UIAlertController(title: nil, message: strTieCard(), preferredStyle: UIAlertControllerStyle.alert)
            
            let spinnerIndicator: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
            
            spinnerIndicator.center = CGPoint(x: 135.0, y: 65.5)
            spinnerIndicator.color = UIColor.black
            spinnerIndicator.startAnimating()
            self.waitingDialog!.view.addSubview(spinnerIndicator)
            NSLog("showDialog")
            self.present(self.waitingDialog!, animated: true, completion: nil)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
