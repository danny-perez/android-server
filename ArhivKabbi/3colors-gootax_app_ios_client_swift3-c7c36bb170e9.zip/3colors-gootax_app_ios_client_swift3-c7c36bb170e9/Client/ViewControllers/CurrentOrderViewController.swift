//
//  CurrentOrderViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 17.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit

import MapKit

//import GoogleMaps

class CurrentOrderViewController: UIViewController, MKMapViewDelegate, GMSMapViewDelegate, UIActionSheetDelegate, UIAlertViewDelegate {

    @IBOutlet weak var osmMap: MKMapView!
    
    var gmsMap : GMSMapView?
    
    @IBOutlet weak var gMap: UIView!
    
    var curOrder : Order?
    
    var curOrderStatus : OrderStatus?
    
    var setted = false
    
    let updateInterval = 10
    
    var updateTimer : NSTimer?
    
    let updateCarInterval = 3
    
    var updateCarTimer : NSTimer?
    
    var rejectButton : UIBarButtonItem?
    
    var rejectDialog : UIAlertView?
    
    // driver
    
    var driverOsmLoc : MapPinCar?
    
    var callActionSheet : UIActionSheet?
    
    @IBOutlet weak var driverView: UIView!
    @IBOutlet weak var driverName: UILabel!
    @IBOutlet weak var driverCar: UILabel!
    @IBOutlet weak var driverCarNum: UILabel!
    //@IBOutlet weak var driverViewHeight: NSLayoutConstraint!
    @IBOutlet weak var driverPhoto: UIImageView!
    @IBOutlet weak var driverStarView: UIView!
    @IBOutlet weak var driverStarLogo: UIImageView!
    @IBOutlet weak var driverStarValue: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.curOrder == nil {
            self.curOrder = Order.MR_findFirst()
        }
        self.setStatus()
        self.setMap()
        self.colorize()
        self.localize()
        self.setDriver()
        self.runUpdateOrder()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        if self.isMovingFromParentViewController() {
            self.updateTimer?.invalidate()
            self.updateTimer = nil
            self.updateCarTimer?.invalidate()
            self.updateCarTimer = nil
        }
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - init
    
    func setMap() {
        
        if curMap() == 0 {
            self.osmInit()
            self.gMap.hidden = true
            self.osmMap.hidden = false
        }
        else {
            self.gmsInit()
            self.gMap.hidden = false
            self.osmMap.hidden = true
        }
    }
    
    //MARK: - OSM Map
    func osmInit() {
        var region : MKCoordinateRegion = MKCoordinateRegion()
        var span : MKCoordinateSpan = MKCoordinateSpan()
        span.latitudeDelta = 0.005
        span.longitudeDelta = 0.005
        region.span = span
        region.center = CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!)
        self.osmMap.setRegion(region, animated: true)
        
//        self.setOsmAnnotations()
        
    }
    
    func setOsmAnnotations() {
        //if self.osmMap.annotations.count > self.
        let userLoc : MapPin = MapPin(coordinate : CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!), title: "", subtitle: "")
        
        self.osmMap.addAnnotation(userLoc)
        
        if #available(iOS 9.0, *) {
            self.osmMap.showsCompass = false
        }
        let overlay = MKTileOverlay(URLTemplate: kOSMTiles)
        overlay.canReplaceMapContent = true
        osmMap.addOverlay(overlay, level: MKOverlayLevel.AboveLabels)
        let delay = 1.5 * Double(NSEC_PER_SEC)
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
        dispatch_after(time, dispatch_get_main_queue()) { () -> Void in
            let userLoc2 : MapPin = MapPin(coordinate : CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!), title: "", subtitle: "")
            
            self.osmMap.addAnnotation(userLoc2)
        }
    }
    
    //MARK: -GoogleMap
    
    func gmsInit() {
        if gmsMap == nil {
            self.gMap.sizeToFit()
            self.gMap.setNeedsLayout()
            // ебаные size classes!  Нужно из высоты экрана вычесть высоту статус бара, таб бара, навигейшн бара
            gmsMap = GMSMapView(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, UIScreen.mainScreen().bounds.height - (self.navigationController?.navigationBar.frame.height)! - (self.tabBarController?.tabBar.frame.height)! - UIApplication.sharedApplication().statusBarFrame.height))
            gmsMap?.delegate = self
            self.gMap.addSubview(gmsMap!)
            self.gmsMap?.animateToLocation(CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!))
            self.gmsMap?.animateToZoom(15)
            let marker = GMSMarker()
            marker.map = self.gmsMap
            marker.position = CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!)
            marker.icon = UIImage(named: "userCenter")!
            let circle : GMSCircle = GMSCircle()
            
            circle.position = CLLocationCoordinate2D(latitude: (self.curOrder?.pointA?.lat.doubleValue)!, longitude: (self.curOrder?.pointA?.lon.doubleValue)!)
            circle.radius = 2
            circle.fillColor = UIColor(red: 0.0, green: 0.0, blue: 1.0, alpha: 0.5)
            circle.strokeColor = UIColor.clearColor()
            circle.map = self.gmsMap
            let delay = 1.0 * Double(NSEC_PER_SEC)
            let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
            dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in
                self.updateCircle(circle)
                
            }
        }

    }
    
    func updateCircle(circle : GMSCircle) {
        var rad : Double = 0
        var color = UIColor(red: 0.0, green: 0.0, blue: 1.0, alpha: 0.5)
        if circle.radius > 900 {
            rad = 2
            color = UIColor(red: 0.0, green: 0.0, blue: 1.0, alpha: 0.5)
        }
        else {
            rad = circle.radius + 0.2
            color = UIColor(red: 0.0, green: 0.0, blue: 1.0, alpha: CGFloat(1-rad/1200))
        }
        let delay = 0.00001 * Double(NSEC_PER_SEC)
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
        dispatch_after(time, dispatch_get_main_queue()) { () -> Void in
            circle.radius = rad
            circle.fillColor = color
            self.updateCircle(circle)
        }
    }
    
    
    //MARK: -MKMapView Delegate
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation.isKindOfClass(MapPinCar) {
            let aView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            aView.image = UIImage(named: imageCarNoAngle())
            return aView
        }
        if self.curOrderStatus == .New {
            var pulsView = self.osmMap.dequeueReusableAnnotationViewWithIdentifier("pulseView") as? SVPulsingAnnotationView
            if pulsView == nil {
                pulsView = SVPulsingAnnotationView(annotation: annotation, reuseIdentifier: "pulseView")
                pulsView?.outerColor = UIColor.clearColor()
                //pulsView?.pulseColor = colorBlueText()
                if !self.setted {
                    pulsView?.image = UIImage(named: "userCenterBig")
                    self.setted = true
                }
                else {
                    pulsView?.image = UIImage()
                    
                }
                pulsView?.outerPulseAnimationDuration = 3
                pulsView?.delayBetweenPulseCycles = 0
                pulsView?.pulseScaleFactor = 15
                
            }
            pulsView?.canShowCallout = true
            return pulsView
        }
        else {
            let aView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            aView.image = UIImage(named: "userCenterBig")
            return aView
        }
    }

    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        return MKTileOverlayRenderer(overlay: overlay)
    }
    
    //MARK: - call
    
    @IBAction func call(sender: UIButton) {
        self.callActionSheet = UIActionSheet()
        self.callActionSheet?.title = strComDoCall()
        self.callActionSheet?.addButtonWithTitle(strComDispatcher())
        var added = false
        if self.curOrder?.driver != nil {
            if self.curOrder?.driver?.phone != nil {
                if self.curOrder?.driver?.phone != "" {
                    self.callActionSheet?.addButtonWithTitle(strComDriver())
                    added = true
                }
            }
        }
        self.callActionSheet?.addButtonWithTitle(strComCancel())
        if added {
            self.callActionSheet?.cancelButtonIndex = 2
        }
        else {
            self.callActionSheet?.cancelButtonIndex = 1
        }
        self.callActionSheet?.delegate = self
        self.callActionSheet?.showInView(self.view)
    }
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        if actionSheet == self.callActionSheet {
            if buttonIndex == 0 {
                UIApplication.sharedApplication().openURL(NSURL(string: "tel://\(dispPhone())")!)
            }
            else if buttonIndex == 1 {
                if self.curOrder?.driver != nil {
                    if self.curOrder?.driver?.phone != nil {
                        if self.curOrder?.driver?.phone != "" {
                            UIApplication.sharedApplication().openURL(NSURL(string: "tel://\(self.curOrder?.driver?.phone)")!)
                        }
                    }
                }

            }
        }
    }
    
    //MARK: - Order Update
    
    func setStatus() {
        switch (self.curOrder?.statusID)! {
        case "new", "New" :
            self.curOrderStatus = .New
        case "car_assigned", "carAssigned" :
            self.curOrderStatus = .CarAssigned
        case "car_at_place" :
            self.curOrderStatus = .CarAtPlace
        case "rejected" :
            self.curOrderStatus = .Rejected
        case "executing" :
            self.curOrderStatus = .Executing
        case "completed" :
            self.curOrderStatus = .Completed
        default :
            self.curOrderStatus = .New
        }
        if self.curOrderStatus != .New {
            var anns = [MKAnnotation]()
            //var setted = false
            for annotation in self.osmMap.annotations {
                if annotation is MapPin {
                    anns.append(annotation)
                }
            }
            if self.updateCarTimer == nil {
                self.updateCarTimer = NSTimer.scheduledTimerWithTimeInterval(Double(self.updateCarInterval), target: self, selector: "updateCar", userInfo: "", repeats: true)
            }
            self.osmMap.removeAnnotations(anns)
        }
        self.setOsmAnnotations()
        if self.curOrder?.statusLabel != "" {
            self.navigationItem.title = self.curOrder?.statusLabel
        }
        
        if self.curOrderStatus == .Completed || self.curOrderStatus == .Rejected {
            self.updateTimer?.invalidate()
            self.updateTimer = nil
            self.updateCarTimer?.invalidate()
            self.updateCarTimer = nil
            let finishedController : FinishedOrderViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("completed") as! FinishedOrderViewController
            finishedController.order = self.curOrder
            var navArray = self.navigationController?.viewControllers
            if navArray?.count > 0 {
                let ind = (navArray?.count)! - 1
                navArray![ind] = finishedController
                
                self.navigationController?.setViewControllers(navArray!, animated: true)
            }
        }
        self.setRejecting()
        
    }
    
    
    func runUpdateOrder() {
        self.updateOrder()
        if self.updateTimer == nil {
            self.updateTimer = NSTimer.scheduledTimerWithTimeInterval(Double(self.updateInterval), target: self, selector: "updateOrder", userInfo: "", repeats: true)
        }
    }
    
    func updateOrder() {
        updOrder(self.curOrder!) { (order) -> Void in
            self.curOrder = order
            self.setStatus()
            self.setDriver()
        }
    }
    
    func updateCar() {
        updCarInfo(self.curOrder!) { (order) -> Void in
            self.setDriver()
        }
    }
    
    func setDriver() {
        if self.curOrder?.driver != nil {
            if (self.curOrder?.driver?.name != "") && (self.curOrder?.driver?.name != nil) {
                self.driverName.text = self.curOrder?.driver?.name
                self.driverCar.text = self.curOrder?.driver?.carModel.uppercaseString
                self.driverCarNum.text = self.curOrder?.driver?.carNum.uppercaseString
                if self.curOrder?.driver?.photo != nil {
                    let imageData : NSData? = NSData(base64EncodedString: (self.curOrder?.driver?.photo)!, options: NSDataBase64DecodingOptions(rawValue: 0))
                    if imageData != nil {
                        let image = UIImage(data: imageData!)
                        print(self.curOrder?.driver?.photo)
                        self.driverPhoto.image = image
                    }
                }
                if self.curOrder != nil {
                    self.driverPhoto.hidden = !needShowDriverPhoto(self.curOrder!)
                }
                
                self.driverView.hidden = false
                
                if self.curOrder?.driver?.rate == nil {
                    self.driverStarView.hidden = true
                }
                else {
                    if self.curOrder?.driver?.rate == NSNumber(double: 0) {
                        self.driverStarView.hidden = true
                    }
                    else {
                        self.driverStarView.hidden = false
                    }
                }

            }
            if curMap() == 0 {
                if self.driverOsmLoc == nil {
                    if self.curOrder?.driver?.lat != nil && self.curOrder?.driver?.lat != NSNumber(double: 0) {
                        if self.curOrder?.driver?.lon != nil && self.curOrder?.driver?.lat != NSNumber(double: 0) {
                            self.driverOsmLoc = MapPinCar(coordinate: CLLocationCoordinate2DMake((self.curOrder?.driver?.lat?.doubleValue)!, (self.curOrder?.driver?.lon?.doubleValue)!), title: "", subtitle: "")
                            self.osmMap.addAnnotation(self.driverOsmLoc!)
                            var region : MKCoordinateRegion = MKCoordinateRegion()
                            var span : MKCoordinateSpan = MKCoordinateSpan()
                            span.latitudeDelta = 0.005
                            span.longitudeDelta = 0.005
                            region.span = span
                            region.center = CLLocationCoordinate2D(latitude: (self.curOrder?.driver?.lat?.doubleValue)!, longitude: (self.curOrder?.driver?.lon?.doubleValue)!)
                            self.osmMap.setRegion(region, animated: true)
                        }
                    }
                }
                else {
                    if self.curOrder?.driver?.lat != nil && self.curOrder?.driver?.lat != NSNumber(double: 0) {
                        if self.curOrder?.driver?.lon != nil && self.curOrder?.driver?.lat != NSNumber(double: 0) {
                            UIView.animateWithDuration(3.2, delay: 0, options: [.CurveLinear, .BeginFromCurrentState], animations: { () -> Void in
                                if self.driverOsmLoc != nil {
                                    //self.driverOsmLoc?.willChangeValueForKey("coordinate")
                                    self.driverOsmLoc?.coordinate = CLLocationCoordinate2DMake((self.curOrder?.driver?.lat?.doubleValue)!, (self.curOrder?.driver?.lon?.doubleValue)!)
                                    //self.driverOsmLoc?.didChangeValueForKey("coordinate")
                                    self.osmMap.setCenterCoordinate(CLLocationCoordinate2D(latitude: (self.curOrder?.driver?.lat?.doubleValue)!, longitude: (self.curOrder?.driver?.lon?.doubleValue)!), animated: false)
                                }
                                }, completion: { (finished) -> Void in
                                    
                            })
                        }
                    }
                }
            }
            
        }
        else {
            self.driverView.hidden = true
            self.driverPhoto.hidden = true
            self.driverStarView.hidden = true
        }
    }
    
    
    
    
    
    
    
    //MARK: - Rejecting
    
    func setRejecting() {
        if self.rejectButton == nil {
            self.rejectButton = UIBarButtonItem(title: strComRejectOrder(), style: .Plain, target: self, action: "showRejectAlert")
        }
        if self.curOrderStatus == .New || self.curOrderStatus == .CarAssigned {
            self.navigationItem.rightBarButtonItem = self.rejectButton!
        }
        else {
            self.navigationItem.rightBarButtonItems = nil
        }
    }
    
    func showRejectAlert() {
        self.rejectDialog = UIAlertView()
        self.rejectDialog?.title = strComRejectOrder()
        self.rejectDialog?.message = strComRejectOrderMessage()
        self.rejectDialog?.addButtonWithTitle(strComYes())
        self.rejectDialog?.addButtonWithTitle(strComNo())
        self.rejectDialog?.cancelButtonIndex = 1
        self.rejectDialog?.delegate = self
        self.rejectDialog?.show()
    }
    
    
    func rejectOrder() {
        self.rejectButton?.enabled = false
        rejectOrd(self.curOrder!, completion: { (res) -> Void in
            if res {
                self.curOrder!.statusID = "rejected"
                self.curOrder!.statusLabel = strComOrderRejected()
                print(self.curOrder?.statusLabel)
                print(self.curOrder?.statusID)
                saveDefaultContext()
                self.setStatus()
            }
            self.rejectButton?.enabled = true
            }) { (str) -> Void in
                self.rejectButton?.enabled = true
        }
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if alertView == self.rejectDialog {
            if buttonIndex == 0 {
                self.rejectOrder()
            }
        }
    }
    
    
    //MARK: - Commons
    
    func colorize() {
        self.driverView.layer.cornerRadius = 6
        self.driverView.layer.masksToBounds = true
        
        self.driverView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
        
        self.driverPhoto.layer.cornerRadius = 40
        self.driverPhoto.layer.masksToBounds = true
        self.driverPhoto.layer.borderWidth = 1
        self.driverPhoto.layer.borderColor = colorHighlightedColCell().CGColor
        
        self.driverStarView.backgroundColor = colorMain()
        self.driverStarView.layer.cornerRadius = 4
        self.driverStarView.layer.borderWidth = 1
        self.driverStarView.layer.borderColor = colorHighlightedColCell().CGColor
        
        self.navigationController?.navigationBar.tintColor = colorMainTint()
        
        self.rejectButton?.tintColor = colorRedText()
    }
    
    func localize() {
        let num  = self.curOrder?.orderNumber
        if (num != nil) {
            let number = num!
            self.navigationItem.title = String(format: "%@ №%@", arguments: [strComOrder(), number])
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
