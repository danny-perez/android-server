//
//  CoreDataHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import UIKit
import MagicalRecord

    // Сохранить инфу в коре дата
    public func saveDefaultContext() {
        NSManagedObjectContext.mr_default().mr_saveToPersistentStoreAndWait();
    }

