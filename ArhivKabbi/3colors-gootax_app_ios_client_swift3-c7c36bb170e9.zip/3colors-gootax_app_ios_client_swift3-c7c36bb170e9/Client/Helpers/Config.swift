//
//  Config.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation


/** COMMON SETTINGS **/
// Это демо-версия, будут включены все настройки, если true
public let isDemo = true
// сервер utap или prod
public let prodServer = true
// ID Арендатора
public let gxDefTenantID = "18"
// Версия Client API
public let versionClient = "1.20.0"
// секретный ключ
public let gxSecretKey = "jdshgjksahgjkasdhwehghkajsdgn" // 13131313 | jdshgjksahgjkasdhwehghkajsdgn
// Id приложения
public let appId = "4"
// Разрешить выбор страны при авторизации
public let withCountry = true
// Url для запросов к килентскому API
//"https://ca.uatgootax.ru:8089/"//"http://ca1.artem.taxi.lcl/" //https://ca2.gootax.pro:8089 //ca.uat.taxi.ru
public let baseUrl = "https://ca2.gootax.pro:8089/"
public let geoUrl = "https://geo.gootax.pro/v1/"
public let googleMapKey = "AIzaSyBsK49Ijp7tGhpKXkq4oIhkYHiA5I-mzvw"


public let useWebScreen = false
public let webScreenUrl = "http://www.gootax.pro"
public let webScreenTitle = "WebApplication"

/** METRICS SETTINGS **/
// Yandex Metrica API key
public let yandexMetricaAPIkey = "e2f7c8e4-9d51-41d9-b8e3-11deb44f7a58"


/** LANGUAGE SETTINGS **/
// стандартный язык
public let defaultLanguage = "ru"
// стандартная страна
func defaultCountry() -> [String: Any] {
    return ["mask" : "+7({ddd}){ddd}-{dd}-{dd}","placeholder" : "+7(___)___-__-__","minLength" : 11,"shortMask" : "+7","label" : getStringByKey("country.ru"),"code" : "RU"]
}

let languages = ["en", "ru", "ar", "de", "it", "fa", "sr", "tk", "uz", "ka", "az", "uz-Latn"]

let supportedLang = [
    ["code" : "ru",
        "title" : lanRu()],
    ["code" : "en",
        "title" : lanEnglish()],
    ["code" : "de",
        "title" : lanDe()],
    ["code" : "it",
        "title" : lanIt()],
    ["code" : "fa",
        "title" : lanFa()],
    ["code" : "sr",
        "title" : lanSerb()],
    ["code" : "me",
        "title" : lanMe()],
    ["code" : "tk",
        "title" : lanTk()],
    ["code" : "uz",
        "title" : lanUz()],
    ["code" : "ka",
        "title" : lanKa()],
    ["code" : "az",
        "title" : lanAz()],
    ["code" : "ar",
     "title" : lanAr()],
    ["code" : "uz-Latn",
     "title" : lanOr()]
];

/** THEME SETTINGS **/


/** CALENDAR SETTINGS **/
// 0 - Gregorian | 1 - Persian
public let useCalendarExtensions = false
public let defaultCalendar = 0
public let calendars = [strCalndarGregorian(), strCalndarPersian()]


/** MAPS SETTINGS **/
// стандартная карта
/* 0 - OSM | 1 - Google */
public let defaultMap = 1
/* true - Normal | false - Hybrid */
public let defaultGoogleType = true
// Наличее карт
public let needGisMap = false
public let needOSMMap = true
public let needGoogleMapNormal = true
public let needGoogleMapHybrid = true


/** SEARCH SETTINGS **/
// использовать search или autocomplete
public let useSearch = false // false - autocomplete
public let mapRadius = "0.1" // Радиус поиска по карте
public let listRadius = "1" // Радиус для ближайших адресов
public let searchRadius = "40" // Радиус для автокомплита
public let getCarsRadius = "3000" // Радиус поиска машин в метрах
// Зона приема заказов (в метрах) работает только когда нет полигона, иначе приоритетней полигон
public let ordersZone = 40000


/** PHOTO SETTINGS **/
//  Использовать фото машины (true) или водителя (false)
public let usePhoto = true
public let carPhoto = "car_photo"
public let driverPhoto = "driver_photo"
public let photoType = driverPhoto


/** CALLS SETTINGS **/
// Нужна ли возможность звонка водителю
public let useCalls = true
public let needDriverCall = true
public let needOfficeCall = true


/** OTHER SETTINGS **/
//Таймаут на повторную отправку смсъ
public let smsTimeout = 60
// нужно минимум две точки для создания заказа?
public let orderWithOnePoint = true
// можно ли редактировать заказ?
public let allowEditOrder = true
// максимум одна точка?
public let maxOnePoint = false
// Геокодинг
public let type_app = "client"
// размер налога, в процентах, 0 - не учитывать
public let taxfeePercentage = 0.0
// использовать ли реферальную систему
public let allowReferralSystem = true
// разрешить осталять отзыв без теста, с оценкой ниже 4
public let useReviewBlock = true
// радиус Blur для всех экранов
public let blurRadius : CGFloat = 20
// показывать детали при отправке отзыва
public let useReviewDetail = false
// разрешить осталять отзыв без теста, с оценкой ниже 4
public let isShowClientId = true
public let useReviewForRejected = false

/** ADDRESS DATAIL SETTINGS **/
// нужна ли квартира
public let needFlat = true
public let needStreet = true
public let needPorch = true
public let needComment = true


/** WITHES PANEL SETTINGS **/
public let needPreOrder = true
public let needWishes = true
public let needAddressDetail = true
public let needWishesPanel = needPreOrder && needWishes && needAddressDetail


/** PAYMENT SETTINGS **/
// разрешить оплату наличными?
public let allowPaymentInPerosnal = true
// разрешить оплату наличными?
public let allowPaymentInBonus = true
// разрешить оплату наличными?
public let allowPaymentInCompany = true
// разрешить оплату наличными?
public let allowPaymentInCash = true
// можно ли добавлять кредитные карты?
public let allowAddingCreditCard = true
// стандартная валюта
public let defCurrency = "RUB"
