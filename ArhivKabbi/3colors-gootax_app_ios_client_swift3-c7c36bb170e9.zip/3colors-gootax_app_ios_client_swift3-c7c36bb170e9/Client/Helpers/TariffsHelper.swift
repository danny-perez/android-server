//
//  TariffsHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 14.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

class Tariff : NSObject, NSCoding {
    var tariffLabel : String?
    var tariffID : String?
    var tariffDescr : String?
    var tariffLogoImage : UIImage?
    var tariffLogoThumbImage : UIImage?
    var tariffLogoUrl : String?
    var tariffLogoThumbString : String?
    var tariffDateLoaded : NSDate? // Когда загружен тариф. у них есть срок годности
    var tariffHasBonuses : Bool? // если тариф использует бонусную систему UDS Game 1 иначе 0
    var tariffType: String?;
    var options : [Additional]?
    var clientTypes : [String]?
    var companies : [Int]?
    
    override init() {
        tariffID = ""
        tariffLabel = ""
        tariffDescr = ""
        options = nil
        tariffLogoUrl = ""
        tariffLogoThumbString = ""
        tariffLogoImage = UIImage(named: "noCarImageBig")
        tariffLogoThumbImage = UIImage(named: "noCarImageSmall")
        tariffDateLoaded = NSDate()
        tariffHasBonuses = false
        tariffType = ""
        clientTypes = []
        companies = []
    }
    
    // нужно для того, чтобы можно было хранить в БД и в userDefaults
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.tariffLabel = decoder.decodeObject(forKey: "tariffLabel") as? String
        self.tariffID = decoder.decodeObject(forKey: "tariffID") as? String
        self.tariffDescr = decoder.decodeObject(forKey: "tariffDescr") as? String
        self.tariffLogoImage = decoder.decodeObject(forKey: "tariffLogoImage") as? UIImage
        self.tariffLogoThumbImage = decoder.decodeObject(forKey: "tariffLogoThumbImage") as? UIImage
        self.tariffLogoUrl = decoder.decodeObject(forKey: "tariffLogoUrl") as? String
        self.tariffLogoThumbString = decoder.decodeObject(forKey: "tariffLogoThumbString") as? String
        self.options = decoder.decodeObject(forKey: "options") as? [Additional]
        self.tariffDateLoaded = decoder.decodeObject(forKey: "tariffDateLoaded") as? NSDate
        self.tariffHasBonuses = decoder.decodeObject(forKey: "tariffHasBonuses") as? Bool
        self.tariffType = decoder.decodeObject(forKey: "tariffType") as? String
        self.clientTypes = decoder.decodeObject(forKey: "clientTypes") as? [String]
        self.companies = decoder.decodeObject(forKey: "companies") as? [Int]
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(self.tariffLabel, forKey: "tariffLabel")
        coder.encode(self.tariffID, forKey: "tariffID")
        coder.encode(self.tariffDescr, forKey: "tariffDescr")
        coder.encode(self.options, forKey: "options")
        coder.encode(self.tariffLogoImage, forKey: "tariffLogoImage")
        coder.encode(self.tariffLogoThumbImage, forKey: "tariffLogoThumbImage")
        coder.encode(self.tariffLogoUrl, forKey: "tariffLogoUrl")
        coder.encode(self.tariffLogoThumbString, forKey: "tariffLogoThumbString")
        coder.encode(self.tariffDateLoaded, forKey: "tariffDateLoaded")
        coder.encode(self.tariffHasBonuses, forKey: "tariffHasBonuses")
        coder.encode(self.tariffType, forKey: "tariffType")
        coder.encode(self.clientTypes, forKey: "clientTypes")
        coder.encode(self.companies, forKey: "companies")
    }
}

class Additional : NSObject, NSCoding  {
    var mainId : String?
    var optionId : String?
    var tariffId : String?
    var optionName : String?
    var optionLogo : String?
    var optionType : String?
    var cost : Double?
    var isChecked : Bool
    
    init(mainId : String, tariffId: String, fromId id : String, name : String, image : String, optionCost : Double) {
        self.mainId = mainId
        self.tariffId = tariffId
        optionId = id
        optionName = name
        optionLogo = image
        cost = optionCost
        isChecked = false
    }
    override init() {
        mainId = ""
        optionId = ""
        optionName = ""
        optionLogo = nil
        cost = 0
        optionType = ""
        isChecked = false
    }
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.mainId = decoder.decodeObject(forKey: "mainId") as? String
        self.tariffId = decoder.decodeObject(forKey: "tariffId") as? String
        self.optionId = decoder.decodeObject(forKey: "optionId") as? String
        self.optionName = decoder.decodeObject(forKey: "optionName") as? String
        self.optionLogo = decoder.decodeObject(forKey: "optionLogo") as? String
        self.cost = decoder.decodeDouble(forKey: "cost")
        self.optionType = decoder.decodeObject(forKey: "optionType") as? String
        self.isChecked = decoder.decodeBool(forKey: "isChecked") as Bool
    }
    func encode(with coder: NSCoder) {
        coder.encode(self.mainId, forKey: "mainId")
        coder.encode(self.tariffId, forKey: "tariffId")
        coder.encode(self.optionId, forKey: "optionId")
        coder.encode(self.optionName, forKey: "optionName")
        coder.encode(self.optionLogo, forKey: "optionLogo")
        coder.encode(self.cost!, forKey: "cost")
        coder.encode(self.optionType!, forKey: "optionType")
        coder.encode(self.isChecked, forKey: "isChecked")
    }
}

func getTariffsType(order: OrderTemp, completion: @escaping (_ arr: [Tariff]) -> Void)
{
    gxGetTariffsTypes(order: order, completion: { (arr) -> Void in
        completion(arr)
    })
}

func gxGetTariffsTypes(order: OrderTemp, completion: @escaping (_ arr: [Tariff]) -> Void)
{
    let formatter = DateFormatter()
    formatter.dateFormat = "dd.MM.yyyy HH:mm:ss"
    let defaults = UserDefaults.standard
    gxDoGet(kGxApiFindTariffsTypes, params: [
        "city_id" : defaults.object(forKey: udefCurCity) as! String,
        "date" : formatter.string(from: order.orderTime!)
        ], completion: { (result) -> Void in
            if let res = result["result"] as? [[String: Any]] {
                completion(gxParseTariffTypes(order: order, arr: res))
            }
    }
    ) { (error) -> Void in
        print(error.description)
    }
}

func gxParseTariffTypes (order: OrderTemp, arr : [[String: Any]]) -> [Tariff] {
    
    var tempTariffType: String?
    var tempTariffID: String?
    let city = curCity()
    let tariffList = city.tariffs
    
    
    for dict in arr {
        tempTariffType = dict["type"] as? String ?? ""
        tempTariffID = dict["tariff_id"] as? String ?? ""
        
        for tariff: Tariff in tariffList! {
            if tariff.tariffID == tempTariffID! {
                if tariff.tariffType != tempTariffType! {
                    tariff.tariffType = tempTariffType!
                    if (order.orderWishes!.count > 0) {
                        for (index, wish) in (order.orderWishes)!.enumerated() {
                            if (wish.tariffId == tempTariffID!) {
                                wish.isChecked = false
                                order.orderWishes!.remove(at: index)
                            }
                        }
                    }
                    if order.orderTariff?.tariffID! == tempTariffID {
                        order.orderTariff?.tariffType = tempTariffType
                        showMessage(strComNotificationTitle(), message: strComNotificationWishes())
                    }
                }
            }
        }
    }
    saveCit(city)
    return tariffList!
}

func getTariffs(completion: @escaping (_ arr: [Tariff]) -> Void)
{
    gxGetTariffs(completion: { (arr) -> Void in
        completion(arr)
    })
}

func gxGetTariffs(completion: @escaping (_ arr: [Tariff]) -> Void)
{
    let defaults = UserDefaults.standard
    var params = ["city_id" : defaults.object(forKey: udefCurCity) as! String]
    let phone = profile().phone
    
    if (phone != nil && !(phone?.isEmpty)!) {
        params["phone"] = profile().phone
    }
    
    gxDoGet(kGxApiFindTariffs, params: params, completion: { (result) -> Void in
        
        if let res = result["result"] as? [[String: Any]] {
            completion(gxParseTariff(arr: res))
        }
        
    }
    ) { (error) -> Void in
        print(error.description)
    }
}

func gxParseTariff (arr : [[String: Any]]) -> [Tariff]
{
    var tariffs : [Tariff] = [Tariff]()
    
    for dict in arr {
        let newTar = Tariff()
        var additionals = [Additional]()
        
        newTar.tariffID = parseString(dict["tariff_id"] ?? "")
        newTar.tariffLabel = parseString(dict["tariff_name"] ?? "")
        newTar.tariffType = parseString(dict["type"] ?? "")
        newTar.tariffDescr = parseString(dict["description"] ?? "")
        newTar.tariffLogoUrl = parseString(dict["logo"] ?? "")
        newTar.tariffLogoThumbString = parseString(dict["logo_thumb"] ?? "")
    
        newTar.clientTypes = dict["client_type"] as? [String] ?? [String]()
        newTar.companies = dict["companies"] as? [Int] ?? [Int]()
        
        newTar.tariffHasBonuses = parseBool(dict["is_bonus"] ?? false)
        
        
        if let additionalOptions = dict["additional_options"] as? [[String: Any]] {
            
            for additional in additionalOptions {
                let additionalTemp = Additional()
                
                additionalTemp.mainId = parseString(additional["id"] ?? "")
                additionalTemp.tariffId = parseString(additional["tariff_id"] ?? "")
                additionalTemp.optionId = parseString(additional["additional_option_id"] ?? "")
                additionalTemp.optionType = parseString(additional["tariff_type"] ?? "")
                
                if let option = additional["option"] as? [String: Any] {
                    additionalTemp.optionName = parseString(option["name"] ?? "")
                }
                
                additionalTemp.cost = additional["price"] as? Double ?? 0.0
                
                additionals.append(additionalTemp)
            }
            
        }
        newTar.options = additionals
        tariffs.append(newTar)
    }
    
    return tariffs
}


func curTariffs() -> [Tariff]
{
    var tariffs : [Tariff]?
    let defaults = UserDefaults.standard
    
    let tariffData = defaults.object(forKey: udefTariffs) as? NSData
    if tariffData != nil {
        NSKeyedUnarchiver.setClass(Tariff.self, forClassName: "Utap.Tariff")
        tariffs = NSKeyedUnarchiver.unarchiveObject(with: tariffData! as Data) as? [Tariff]
        
        if tariffs == nil {
            tariffs = [Tariff]()
        }
    }
    
    return tariffs!
    
}

func wishes() -> [Additional]
{
    var adds : [Additional] = [Additional]()
    
    let cond : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshCond(), image: imageWishCond(), optionCost: 10)
    adds.append(cond)
    
    let nosmoke : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshNoSmoke(), image: imageWishNoSmoke(), optionCost: 10)
    adds.append(nosmoke)
    
    let smoke : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshSmoke(), image: imageWishSmoke(), optionCost: 10)
    adds.append(smoke)
    
    let pet : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshPet(), image: imageWishPet(), optionCost: 10)
    adds.append(pet)
    
    let tee : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshTee(), image: imageWishTee(), optionCost: 0)
    adds.append(tee)
    
    let ords : Additional = Additional(mainId: "0", tariffId: "0", fromId: "0", name: strWshOrds(), image: imageWishOrds(), optionCost: 0)
    adds.append(ords)
    
    return adds
}



