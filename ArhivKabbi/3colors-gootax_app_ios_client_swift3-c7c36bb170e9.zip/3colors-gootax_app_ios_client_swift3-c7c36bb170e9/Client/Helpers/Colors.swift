//
//  Colors.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation


let colorSchemes : [[String: Any]] = [
    [
        "name" : strSchemeStandart(),
        "mainColor" : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        "grayBackgroundColor" : UIColor(red: 240.0/255.0, green: 240.0/255.0, blue: 240.0/255.0, alpha: 1.0),
        "grayLabelTextColor" : UIColor(red: 135.0/255.0, green: 135.0/255.0, blue: 135.0/255.0, alpha: 1.0),
        "fieldMainColor" : UIColor(red: 123.0/255.0, green: 123.0/255.0, blue: 123.0/255.0, alpha: 1.0),
        "mainColorTint" : UIColor(red: 42.0/255.0, green: 187.0/255.0, blue: 144.0/255.0, alpha: 1.0),
        "mainTextColor" : UIColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 1.0),
        "greenTextColor" : UIColor(red: 0.0/255.0, green: 146.0/255.0, blue: 69.0/255.0, alpha: 1.0),
        "redTextColor" : UIColor(red: 208.0/255.0, green: 2.0/255.0, blue: 27.0/255.0, alpha: 1.0),
        "disabledButtonColor" : UIColor(red: 210.0/255.0, green: 210.0/255.0, blue: 210.0/255.0, alpha: 1.0),
        "highlightedButtonColor" : UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 1.0),
        "highlightedCollectionViewCell" : UIColor(red: 210.0/255.0, green: 210.0/255.0, blue: 210.0/255.0, alpha: 1.0),
        "wrongCodeColor" : UIColor(red: 255.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.3),
        "tabbar1" : "Car",
        "tabbar2" : "Message",
        "tabbar3" : "Profile",
        "tabbar4" : "About",
        "logo" : "gootax",
        "pathBackBlack" : UIColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.7),
        "pathBackEdit" : UIColor(red: 125.0/255.0, green: 125.0/255.0, blue: 125.0/255.0, alpha: 1.0),
        "statusBarColor" : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        "statusBarStyle" : UIStatusBarStyle.default.rawValue,
        "navigationBarColor" : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        "tabBarColor" : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        "blueText" : UIColor(red: 67.0/255.0, green: 78.0/255.0, blue: 170.0/255.0, alpha: 1.0),
        "imageMyAddresses" : "myAddresses",
        "imageTypePorts" : "typePorts",
        "imageTypeSayToDriver" : "typeSayToDriver",
        "imageTypeMap" : "typesMap",
        "imagePathA" : "pathA",
        "imagePathB" : "pathB",
        "imagePathC" : "pathC",
        "imagePathD" : "pathD",
        "imagePathE" : "pathE",
        "imageListPathA" : "a-list",
        "imageListPathB" : "b-list",
        "imageListPathC" : "c-list",
        "imageListPathD" : "d-list",
        "imageListPathE" : "e-list",
        "imageWishCond" : "snow",
        "imageWishNoSmoke" : "no-smoking",
        "imageWishSmoke" : "smoke",
        "imageWishPet" : "pet",
        "imageWishWifi" : "wifi",
        "imageWishKid" : "kid",
        "imageWishTee" : "driver",
        "imageWishOrds" : "bill",
        "imageWishBag" : "bag",
        "imageCarNoAngle" : "no-angle",
        "imageSmallStarStroke" : "starStroke",
        "imageSmallStarFill" : "starFill",
        "imageBigStarStroke" : "big_star_stroke",
        "imageBigStarFill" : "big_star_fill",
        "imagePlain" : "plain",
        "imageTrain" : "train"
    ],
    [
        "name" : strSchemeDark(),
        "mainColor" : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        "grayBackgroundColor" : UIColor(red: 247.0/255.0, green: 247.0/255.0, blue: 247.0/255.0, alpha: 1.0),
        "grayLabelTextColor" : UIColor(red: 155.0/255.0, green: 155.0/255.0, blue: 155.0/255.0, alpha: 1.0),
        "fieldMainColor" : UIColor(red: 123.0/255.0, green: 123.0/255.0, blue: 123.0/255.0, alpha: 1.0),
        "mainColorTint" : UIColor(red: 248.0/255.0, green: 231.0/255.0, blue: 28.0/255.0, alpha: 1.0),
        "mainTextColor" : UIColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 1.0),
        "greenTextColor" : UIColor(red: 0.0/255.0, green: 146.0/255.0, blue: 69.0/255.0, alpha: 1.0),
        "redTextColor" : UIColor(red: 208.0/255.0, green: 2.0/255.0, blue: 27.0/255.0, alpha: 1.0),
        "disabledButtonColor" : UIColor(red: 210.0/255.0, green: 210.0/255.0, blue: 210.0/255.0, alpha: 1.0),
        "highlightedButtonColor" : UIColor(red: 206.0/255.0, green: 102.0/255.0, blue: 31.0/255.0, alpha: 1.0),
        "highlightedCollectionViewCell" : UIColor(red: 210.0/255.0, green: 210.0/255.0, blue: 210.0/255.0, alpha: 1.0),
        "wrongCodeColor" : UIColor(red: 255.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.3),
        "tabbar1" : "Car",
        "tabbar2" : "Message",
        "tabbar3" : "Profile",
        "tabbar4" : "About",
        "logo" : "gootax",
        "pathBackBlack" : UIColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.7),
        "pathBackEdit" : UIColor(red: 125.0/255.0, green: 125.0/255.0, blue: 125.0/255.0, alpha: 1.0),
        "statusBarColor" : UIColor(red: 19.0/255.0, green: 116.0/255.0, blue: 211.0/255.0, alpha: 1.0),
        "statusBarStyle" : UIStatusBarStyle.lightContent.rawValue,
        "navigationBarColor" : UIColor(red: 19.0/255.0, green: 116.0/255.0, blue: 211.0/255.0, alpha: 1.0),
        "tabBarColor" : UIColor(red: 19.0/255.0, green: 116.0/255.0, blue: 211.0/255.0, alpha: 1.0),
        "blueText" : UIColor(red: 67.0/255.0, green: 78.0/255.0, blue: 170.0/255.0, alpha: 1.0),
        "imageMyAddresses" : "myAddresses",
        "imageTypePorts" : "typePorts",
        "imageTypeSayToDriver" : "typeSayToDriver",
        "imageTypeMap" : "typesMap",
        "imagePathA" : "pathA",
        "imagePathB" : "pathB",
        "imagePathC" : "pathC",
        "imagePathD" : "pathD",
        "imagePathE" : "pathE",
        "imageListPathA" : "a-list",
        "imageListPathB" : "b-list",
        "imageListPathC" : "c-list",
        "imageListPathD" : "d-list",
        "imageListPathE" : "e-list",
        "imageWishCond" : "snow",
        "imageWishNoSmoke" : "no-smoking",
        "imageWishSmoke" : "smoke",
        "imageWishPet" : "pet",
        "imageWishWifi" : "wifi",
        "imageWishKid" : "kid",
        "imageWishTee" : "driver",
        "imageWishOrds" : "bill",
        "imageWishBag" : "bag",
        "imageCarNoAngle" : "no-angle",
        "imageSmallStarStroke" : "starStroke",
        "imageSmallStarFill" : "starFill",
        "imageBigStarStroke" : "big_star_stroke",
        "imageBigStarFill" : "big_star_fill",
        "imagePlain" : "plain",
        "imageTrain" : "train"
    ]
]

let blurColor: UIColor = {
    return UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 0.6)
}()


public func colorSchemeTitle() -> String
{
    if curScheme() == 0 {
        return strSchemeStandart()
    }
    else {
        return strSchemeDark()
    }
}

//MARK : Colors

public func colorTabBar() -> UIColor
{
    return colorSchemes[curScheme()]["tabBarColor"] as! UIColor
}

public func colorWrongCode() -> UIColor
{
    return colorSchemes[curScheme()]["wrongCodeColor"] as! UIColor
}

public func colorStatusBar() -> UIColor
{
    return colorSchemes[curScheme()]["statusBarColor"] as! UIColor
}

public func colorNavigationBar() -> UIColor
{
    return colorSchemes[curScheme()]["navigationBarColor"] as! UIColor
}

public func colorStatusBarStyle() -> UIStatusBarStyle
{
    if colorNewNavBarText().isLightColor() {
        return UIStatusBarStyle(rawValue: UIStatusBarStyle.lightContent.rawValue)!
    }
    else {
        return UIStatusBarStyle(rawValue: UIStatusBarStyle.default.rawValue)!
    }
}

public func colorMain() -> UIColor
{
    return colorSchemes[curScheme()]["mainColor"] as! UIColor
}

public func colorMainText() -> UIColor
{
    return colorSchemes[curScheme()]["mainTextColor"] as! UIColor
}

public func colorGreenText() -> UIColor
{
    return colorSchemes[curScheme()]["greenTextColor"] as! UIColor
}

public func colorHighlightedColCell() -> UIColor
{
    return colorSchemes[curScheme()]["highlightedCollectionViewCell"] as! UIColor
}

public func colorMainTint() -> UIColor
{
    return colorSchemes[curScheme()]["mainColorTint"] as! UIColor
}

public func colorGrayBackground() -> UIColor
{
    return colorSchemes[curScheme()]["grayBackgroundColor"] as! UIColor
}

public func colorRedText() -> UIColor
{
    return colorSchemes[curScheme()]["redTextColor"] as! UIColor
}

public func colorMainFieldText() -> UIColor
{
    return colorSchemes[curScheme()]["fieldMainColor"] as! UIColor
}

public func colorGrayLabelText() -> UIColor
{
    return colorSchemes[curScheme()]["grayLabelTextColor"] as! UIColor
}

public func colorBlueText() -> UIColor
{
    return colorSchemes[curScheme()]["blueText"] as! UIColor
}

public func colorDisabledButton() -> UIColor
{
    return colorSchemes[curScheme()]["disabledButtonColor"] as! UIColor
}

public func colorHighlightedButton() -> UIColor
{
    return colorSchemes[curScheme()]["highlightedButtonColor"] as! UIColor
}

public func colorPathBackground() -> UIColor
{
    return colorSchemes[curScheme()]["pathBackBlack"] as! UIColor
}

public func colorPathBackgroundEdit() -> UIColor
{
    return colorSchemes[curScheme()]["pathBackEdit"] as! UIColor
}

//MARK : Images

public func imageRateBigStroke() -> String
{
    return colorSchemes[curScheme()]["imageBigStarStroke"] as! String
}

public func imageRateBigFill() -> String
{
    return colorSchemes[curScheme()]["imageBigStarFill"] as! String
}

public func imageRateSmallStroke() -> String
{
    return colorSchemes[curScheme()]["imageSmallStarStroke"] as! String
}

public func imageRateSmallFill() -> String
{
    return colorSchemes[curScheme()]["imageSmallStarFill"] as! String
}

public func imageTypeAddresses() -> String
{
    return colorSchemes[curScheme()]["imageMyAddresses"] as! String
}

public func imageTypeSayToDriver() -> String
{
    return colorSchemes[curScheme()]["imageTypeSayToDriver"] as! String
}

public func imageTypeMap() -> String
{
    return colorSchemes[curScheme()]["imageTypeMap"] as! String
}

public func imageTypePorts() -> String
{
    return colorSchemes[curScheme()]["imageTypePorts"] as! String
}

public func imageTabBar1() -> String
{
    return colorSchemes[curScheme()]["tabbar1"] as! String
}

public func imageTabBar2() -> String
{
    return colorSchemes[curScheme()]["tabbar2"] as! String
}

public func imageTabBar3() -> String
{
    return colorSchemes[curScheme()]["tabbar3"] as! String
}

public func imageTabBar4() -> String
{
    return colorSchemes[curScheme()]["tabbar4"] as! String
}

public func imageLogo() -> String
{
    return colorSchemes[curScheme()]["logo"] as! String
}

public func imagePathA() -> String
{
    return colorSchemes[curScheme()]["imagePathA"] as! String
}

public func imagePathB() -> String
{
    return colorSchemes[curScheme()]["imagePathB"] as! String
}

public func imagePathC() -> String
{
    return colorSchemes[curScheme()]["imagePathC"] as! String
}

public func imagePathD() -> String
{
    return colorSchemes[curScheme()]["imagePathD"] as! String
}

public func imagePathE() -> String
{
    return colorSchemes[curScheme()]["imagePathE"] as! String
}

public func imagePlain() -> String
{
    return colorSchemes[curScheme()]["imagePlain"] as! String
}

public func imageTrain() -> String
{
    return colorSchemes[curScheme()]["imageTrain"] as! String
}

//wishes

public func imageWishCond() -> String
{
    return colorSchemes[curScheme()]["imageWishCond"] as! String
}

public func imageWishNoSmoke() -> String
{
    return colorSchemes[curScheme()]["imageWishNoSmoke"] as! String
}

public func imageWishSmoke() -> String
{
    return colorSchemes[curScheme()]["imageWishSmoke"] as! String
}

public func imageWishPet() -> String
{
    return colorSchemes[curScheme()]["imageWishPet"] as! String
}

public func imageWishWifi() -> String
{
    return colorSchemes[curScheme()]["imageWishWifi"] as! String
}

public func imageWishKid() -> String
{
    return colorSchemes[curScheme()]["imageWishKid"] as! String
}

public func imageWishTee() -> String
{
    return colorSchemes[curScheme()]["imageWishTee"] as! String
}

public func imageWishOrds() -> String
{
    return colorSchemes[curScheme()]["imageWishOrds"] as! String
}

public func imageWishBag() -> String
{
    return colorSchemes[curScheme()]["imageWishBag"] as! String
}

//other

public func imageListA() -> String
{
    return colorSchemes[curScheme()]["imageListPathA"] as! String
}

public func imageListB() -> String
{
    return colorSchemes[curScheme()]["imageListPathB"] as! String
}

public func imageListC() -> String
{
    return colorSchemes[curScheme()]["imageListPathC"] as! String
}

public func imageListD() -> String
{
    return colorSchemes[curScheme()]["imageListPathD"] as! String
}

public func imageListE() -> String
{
    return colorSchemes[curScheme()]["imageListPathE"] as! String
}

public func imageCarNoAngle() -> String
{
    return colorSchemes[curScheme()]["imageCarNoAngle"] as! String
}

// НОВЫЕ ЦВЕТОВЫЕ СХЕМЫ

public let schemes = [["splash_bg":"#ffffff","accent_bg":"#2aba90","accent_text":"#ffffff","menu_bg":"#3a3d3c","menu_text":"#ffffff","menu_stroke":"#ffffff","content_bg":"#ffffff","content_text":"#000000","content_stroke":"#000000","content_icon_bg":"#2aba90","content_icon_stroke":"#2aba90","map_marker_bg":"#3a3d3c","map_marker_bg_stroke":"#3a3d3c","map_marker_text":"#ffffff","map_car_bg":"#656a68"],
    ["splash_bg":"#ffffff",
        "accent_bg" : "#ffc614",
        "accent_text" : "#000000",
        "menu_bg" : "#323232",
        "menu_text" : "#ffffff",
        "menu_stroke" : "#ffffff",
        "content_bg" : "#ffc614",
        "content_text" : "#000000",
        "content_stroke" : "#000000",
        "content_icon_bg" : "#323232",
        "content_icon_stroke" : "#323232",
        "map_marker_bg" : "#323232",
        "map_marker_bg_stroke" : "#323232",
        "map_marker_text" : "#ffc614",
        "map_car_bg" : "#666a69"],
    ["splash_bg":"#ffffff",
        "accent_bg" : "#28a7ec",
        "accent_text" : "#ffffff",
        "menu_bg" : "#1b3146",
        "menu_text" : "#ffffff",
        "menu_stroke" : "#ffffff",
        "content_bg" : "#ffffff",
        "content_text" : "#000000",
        "content_stroke" : "#000000",
        "content_icon_bg" : "#28a7ec",
        "content_icon_stroke" : "#64c0f3",
        "map_marker_bg" : "#1b3146",
        "map_marker_bg_stroke" : "#1b3146",
        "map_marker_text" : "#ffffff",
        "map_car_bg" : "#5086a2"],
    ["splash_bg":"#ffffff",
        "accent_bg" : "#d0011b",
        "accent_text" : "#ffffff",
        "menu_bg" : "#cce0e1",
        "menu_text" : "#000000",
        "menu_stroke" : "#000000",
        "content_bg" : "#ffffff",
        "content_text" : "#000000",
        "content_stroke" : "#000000",
        "content_icon_bg" : "#ce021b",
        "content_icon_stroke" : "#ce021b",
        "map_marker_bg" : "#354344",
        "map_marker_bg_stroke" : "#354344",
        "map_marker_text" : "#ffffff",
        "map_car_bg" : "#728081"],
    ["splash_bg":"#ffffff",
        "accent_bg" : "#582e60",
        "accent_text" : "#ffffff",
        "menu_bg" : "#ffb500",
        "menu_text" : "#000000",
        "menu_stroke" : "#000000",
        "content_bg" : "#582e60",
        "content_text" : "#ffffff",
        "content_stroke" : "#ffffff",
        "content_icon_bg" : "#ffb500",
        "content_icon_stroke" : "#ffb500",
        "map_marker_bg" : "#582e60",
        "map_marker_bg_stroke" : "#582e60",
        "map_marker_text" : "#e9a40b",
        "map_car_bg" : "#614f69"],
    ["splash_bg":"#ffffff",
        "accent_bg" : "#ced628",
        "accent_text" : "#000000",
        "menu_bg" : "#3b3c51",
        "menu_text" : "#ffffff",
        "menu_stroke" : "#ffffff",
        "content_bg" : "#ced628",
        "content_text" : "#000000",
        "content_stroke" : "#000000",
        "content_icon_bg" : "#3b3c51",
        "content_icon_stroke" : "#3b3c51",
        "map_marker_bg" : "#3b3b53",
        "map_marker_bg_stroke" : "#3b3b53",
        "map_marker_text" : "#ced628",
        "map_car_bg" : "#7f81aa"]]

func currentScheme() -> Dictionary<String, AnyObject> {
    return schemes[currentSch()] as Dictionary<String, AnyObject>
}

func currentSch() -> Int {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: udefSch) == nil {
        defaults.set(0, forKey: udefSch)
    }
    return defaults.integer(forKey: udefSch)
}

func defaultScheme() -> [String: Any] {
    return ["splash_bg":"#ffffff",
            "accent_bg" : "#ffc614",
            "accent_text" : "#000000",
            "menu_bg" : "#323232",
            "menu_text" : "#ffffff",
            "menu_stroke" : "#ffffff",
            "content_bg" : "#ffc614",
            "content_text" : "#000000",
            "content_stroke" : "#000000",
            "content_icon_bg" : "#323232",
            "content_icon_stroke" : "#323232",
            "map_marker_bg" : "#323232",
            "map_marker_bg_stroke" : "#323232",
            "map_marker_text" : "#ffc614",
            "map_car_bg" : "#666a69"]
}

func colorNewTint() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["accent_bg"] != nil {
        if curSchem["accent_bg"] is String {
            return UIColor(hexString: curSchem["accent_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["accent_bg"] as! String)
}

func colorNewTextTint() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["accent_text"] != nil {
        if curSchem["accent_text"] is String {
            return UIColor(hexString: curSchem["accent_text"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["accent_text"] as! String)
}

func colorNewHamButton() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["content_icon_bg"] != nil {
        if curSchem["content_icon_bg"] is String {
            return UIColor(hexString: curSchem["content_icon_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["content_icon_bg"] as! String)
}

func colorSplash() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["splash_bg"] != nil {
        if curSchem["splash_bg"] is String {
            return UIColor(hexString: curSchem["splash_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["splash_bg"] as! String)
}

func colorNewHamBack() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["menu_bg"] != nil {
        if curSchem["menu_bg"] is String {
            return UIColor(hexString: curSchem["menu_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["menu_bg"] as! String)
}

func colorNewHamSelectedBack() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["menu_bg"] != nil {
        if curSchem["menu_bg"] is String {
            let color = UIColor(hexString: curSchem["menu_bg"] as! String)
            if color.isLightColor() == true {
                return UIColor(hexString: curSchem["menu_bg"] as! String).darker()
            }
            else {
                return UIColor(hexString: curSchem["menu_bg"] as! String).lighter()
            }
        }
    }
    return UIColor(hexString: defaultScheme()["menu_bg"] as! String)
}

func colorNewHamText() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["menu_text"] != nil {
        if curSchem["menu_text"] is String {
            return UIColor(hexString: curSchem["menu_text"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["menu_text"] as! String)
}

func colorNewCarMapColor() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["map_car_bg"] != nil {
        if curSchem["map_car_bg"] is String {
            return UIColor(hexString: curSchem["map_car_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["map_car_bg"] as! String)
}

func colorNewAnnBackColor() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["map_marker_bg"] != nil {
        if curSchem["map_marker_bg"] is String {
            return UIColor(hexString: curSchem["map_marker_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["map_marker_bg"] as! String)
}

func colorNewAnnTextColor() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["map_marker_text"] != nil {
        if curSchem["map_marker_text"] is String {
            return UIColor(hexString: curSchem["map_marker_text"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["map_marker_text"] as! String)
}

func colorNewNavBarBack() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["content_bg"] != nil {
        if curSchem["content_bg"] is String {
            return UIColor(hexString: curSchem["content_bg"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["content_bg"] as! String)
}

func colorNewNavBarText() -> UIColor {
    let curSchem = currentScheme()
    if curSchem["content_text"] != nil {
        if curSchem["content_text"] is String {
            return UIColor(hexString: curSchem["content_text"] as! String)
        }
    }
    return UIColor(hexString: defaultScheme()["content_text"] as! String)
}

func carMapImage() -> UIImage {
    var image = UIImage(named: "carMapAngle")
    image = (image!.withRenderingMode(.alwaysTemplate))
    //image = replaceColorForCar(image!)
    return image!
}

func blankAnnView() -> UIImage {
    var image = UIImage(named: "blankAnnView")
    image = image?.imageWithColorz(colorNewAnnBackColor())
    return image!
}



extension UIImage {
    func imageWithColorz(_ color1: UIColor) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        color1.setFill()
        
        let context = UIGraphicsGetCurrentContext()! as CGContext
        context.translateBy(x: 0, y: self.size.height)
        context.scaleBy(x: 1.0, y: -1.0);
        context.setBlendMode(CGBlendMode.normal)
        
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height) as CGRect
        context.clip(to: rect, mask: self.cgImage!)
        context.fill(rect)
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()! as UIImage
        UIGraphicsEndImageContext()
        
        return newImage
    }
}

/* mark - POINTER
func replaceColorForCar(_ inputImage: UIImage) -> UIImage {
    let inputCGImage     = inputImage.cgImage
    let colorSpace       = CGColorSpaceCreateDeviceRGB()
    let width            = inputCGImage!.width
    let height           = inputCGImage!.height
    let bytesPerPixel    = 4
    let bitsPerComponent = 8
    let bytesPerRow      = bytesPerPixel * width
    let bitmapInfo       = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
    
    let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: bitsPerComponent, bytesPerRow: bytesPerRow, space: colorSpace, bitmapInfo: bitmapInfo)!
    context.draw(inputCGImage!, in: CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))
    
    let pixelBuffer = UnsafeMutablePointer<UInt32>(context.data)
    
    var currentPixel = pixelBuffer
    
    for _ in 0 ..< Int(height) {
        for _ in 0 ..< Int(width) {
            let pixel = currentPixel.pointee
            if abs(Int(red(pixel))-101) < 10 && abs(Int(green(pixel))-106) < 10 && abs(Int(blue(pixel))-105) < 10 {
                let carColor = colorNewCarMapColor().rgb()
                currentPixel.pointee = rgba(red: UInt8((carColor?.red)!), green: UInt8((carColor?.green)!), blue: UInt8((carColor?.blue)!), alpha: 255)
            }
            currentPixel = currentPixel.successor()
        }
    }
    let outputCGImage = context.makeImage()
    let outputImage = UIImage(cgImage: outputCGImage!, scale: inputImage.scale, orientation: inputImage.imageOrientation)
    
    return outputImage
}*/

extension UIColor {
    
    func rgb() -> (red:Int, green:Int, blue:Int, alpha:Int)? {
        var fRed : CGFloat = 0
        var fGreen : CGFloat = 0
        var fBlue : CGFloat = 0
        var fAlpha: CGFloat = 0
        if self.getRed(&fRed, green: &fGreen, blue: &fBlue, alpha: &fAlpha) {
            let iRed = Int(fRed * 255.0)
            let iGreen = Int(fGreen * 255.0)
            let iBlue = Int(fBlue * 255.0)
            let iAlpha = Int(fAlpha * 255.0)
            
            return (red:iRed, green:iGreen, blue:iBlue, alpha:iAlpha)
        } else {
            // Could not extract RGBA components:
            return nil
        }
    }
}

func alpha(_ color: UInt32) -> UInt8 {
    return UInt8((color >> 24) & 255)
}

func red(_ color: UInt32) -> UInt8 {
    return UInt8((color >> 16) & 255)
}

func green(_ color: UInt32) -> UInt8 {
    return UInt8((color >> 8) & 255)
}

func blue(_ color: UInt32) -> UInt8 {
    return UInt8((color >> 0) & 255)
}

func rgba(red: UInt8, green: UInt8, blue: UInt8, alpha: UInt8) -> UInt32 {
    return (UInt32(alpha) << 24) | (UInt32(red) << 16) | (UInt32(green) << 8) | (UInt32(blue) << 0)
}


extension UIButton {
    func setColors() {
        self.setBackgroundImage(imageWithColor(colorNewTint()), for: UIControlState())
        self.setBackgroundImage(imageWithColor(UIColor.black), for: .highlighted)
        self.setBackgroundImage(imageWithColor(colorDisabledButton()), for: .disabled)
        
        self.backgroundColor = colorNewTint()
        self.setTitleColor(colorNewTextTint(), for: UIControlState())
        self.setTitleColor(colorNewTextTint(), for: .highlighted)
        self.setTitleColor(UIColor.white, for: .disabled)
        
        self.layer.cornerRadius = 4
        self.clipsToBounds = true
    }
}


extension UIColor {
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt32()
        Scanner(string: hex).scanHexInt32(&int)
        let a, r, g, b: UInt32
        switch hex.characters.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
    
    func lighter(_ amount : CGFloat = 0.25) -> UIColor {
        return hueColorWithBrightnessAmount(1 + amount)
    }
    
    func darker(_ amount : CGFloat = 0.25) -> UIColor {
        return hueColorWithBrightnessAmount(1 - amount)
    }
    
    fileprivate func hueColorWithBrightnessAmount(_ amount: CGFloat) -> UIColor {
        var hue         : CGFloat = 0
        var saturation  : CGFloat = 0
        var brightness  : CGFloat = 0
        var alpha       : CGFloat = 0
        
        if getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha) {
            return UIColor( hue: hue,
                            saturation: saturation,
                            brightness: brightness * amount,
                            alpha: alpha )
        } else {
            return self
        }
        
    }
    
    func isLightColor() -> Bool
    {
        var white: CGFloat = 0.0
        self.getWhite(&white, alpha: nil)
        
        var isLight = false
        
        if white >= 0.5
        {
            isLight = true
            NSLog("color is light: %f", white)
        }
        else
        {
            NSLog("Color is dark: %f", white)
        }
        
        return isLight
    }
}

