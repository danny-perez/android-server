//
//  FavoriteAddresses.swift
//  Client
//
//  Created by Dmitriy Kudrin on 13.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

func writeAddressesFromOrder(_ order : OrderTemp)
{
    if order.pathA != nil {
        checkAddress(order.pathA!)
    }
    if order.pathB != nil {
        checkAddress(order.pathB!)
    }
    if order.pathC != nil {
        checkAddress(order.pathC!)
    }
    if order.pathD != nil {
        checkAddress(order.pathD!)
    }
    if order.pathE != nil {
        checkAddress(order.pathE!)
    }
}


func checkAddress(_ address : AddressTemp)
{
    var street = ""
    
    if address.street == "" {
        street = address.label!
    }
    else {
        street = address.street!
    }
    if street != "" {
        let predicate : NSPredicate = NSPredicate(format: "city contains[c] %@ AND street contains[c] %@ AND house contains[c] %@", argumentArray: [address.city!, street, address.house!])
        if FavAdress.mr_countOfEntities(with: predicate) == 0 {
            if address.house == "" {
                let predicate2 : NSPredicate = NSPredicate(format: "city contains[c] %@ AND street contains[c] %@", argumentArray: [address.city!, street])
                if FavAdress.mr_countOfEntities(with: predicate2) == 0 {
                    if street != "" {
                        if address.lat != 0 {
                            if address.lon != 0 {
                                addAddress(address)
                            }
                        }
                        
                    }
                }
            }
            else {
                if street != "" {
                    if address.lat != 0 {
                        if address.lon != 0 {
                            addAddress(address)
                        }
                    }
                    
                }
            }
        }
    }
}

func addAddress(_ address : AddressTemp)
{
    let addr : FavAdress = FavAdress.mr_createEntity(in: NSManagedObjectContext.mr_default())!
    addr.city = address.city!
    addr.street = address.street!
    if addr.street == "" {
        addr.street = address.label!
    }
    addr.cityID = address.cityID!
    addr.house = address.house!
    addr.housing = address.housing!
    addr.publicPlace = address.publicPlace! as NSNumber
    addr.lat = NSNumber(value: address.lat!)
    addr.lon = NSNumber(value: address.lon!)
    addr.corp = address.corp!
    addr.building = ""
    saveDefaultContext()
}


func getFavAddresses() -> [AddressTemp]
{
    var forRet = [AddressTemp]()
    
    let addrses : [FavAdress] = FavAdress.mr_findAll() as! [FavAdress]
    
    
    
    for addr : FavAdress in addrses {
        let newTemp = AddressTemp()
        newTemp.city = addr.city
        newTemp.street = addr.street
        newTemp.house = addr.house
        newTemp.lat = addr.lat.doubleValue
        newTemp.lon = addr.lon.doubleValue
        forRet.append(newTemp)
    }
    
    var newResult = [AddressTemp()]
    for ad in forRet {
        if !newResult.contains(ad) {
            if ad.shortStrFromTempAddress() != strComNoAddrs() {
                newResult.append(ad)
            }
        }
    }
    
    
    return newResult
    
}




