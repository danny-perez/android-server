//
//  OrderHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 15.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


enum OrderStatus {
    case new
    case carAssigned
    case rejected
    case carAtPlace
    case executing
    case completed
    case driverBusy
    case preorder
}


func orderToCoreData(_ order : OrderTemp) -> Order {
    let ord : Order = Order.mr_createEntity(in: NSManagedObjectContext.mr_default())!
    
    ord.createDateTime = Date()
    if order.orderTime != nil {
        ord.carDateTime = order.orderTime!
    }
    else {
        ord.carDateTime = nil
    }
    if order.orderTariff != nil {
        ord.tariff = NSKeyedArchiver.archivedData(withRootObject: order.orderTariff!)
    }
    if order.orderWishes != nil {
        if order.orderWishes?.count > 0 {
            ord.wishes = NSKeyedArchiver.archivedData(withRootObject: order.orderWishes!)
        }
    }
    if order.payType != nil {
        if order.payType != "" {
            ord.payType = order.payType!
        }
    }
    if order.payPan != nil {
        if order.payPan != "" {
            ord.cardNum = order.payPan!
        }
    }
    if order.payCompanyId != nil {
        ord.companyId = order.payCompanyId
    }
    if order.pathA != nil {
        if order.pathA?.street != nil {
            ord.pointA = addressTempToOrder(order.pathA!)
        }
        if order.pathB != nil {
            if order.pathB?.street != nil {
                ord.pointB = addressTempToOrder(order.pathB!)
            }
            if order.pathC != nil {
                if order.pathC?.street != nil {
                    ord.pointC = addressTempToOrder(order.pathC!)
                }
                if order.pathD != nil {
                    if order.pathD?.street != nil {
                        ord.pointD = addressTempToOrder(order.pathD!)
                    }
                    if order.pathE != nil {
                        if order.pathE?.street != nil {
                            ord.pointE = addressTempToOrder(order.pathE!)
                        }
                    }
                }
            }
        }
    }
    
    ord.currency = currency()
    
    saveDefaultContext()
    
    return ord
}


func addressTempToOrder(_ address : AddressTemp) -> Address {
    let addr : Address = Address.mr_createEntity(in: NSManagedObjectContext.mr_default())!
    
    if address.city != nil {
        addr.city = address.city!
    }
    if address.cityID != nil {
        addr.cityID = address.cityID!
    }
    if address.street != nil {
        addr.street = address.street!
    }
    if addr.street == "" {
        addr.street = address.label!
    }
    if address.house != nil {
        addr.house = address.house!
    }
    if address.housing != nil {
        addr.housing = address.housing!
    }
    if address.lat != nil {
        if address.lat != 0 {
            addr.lat = NSNumber(value: address.lat! as Double)
        }
    }
    if address.lon != nil {
        if address.lon != 0 {
            addr.lon = NSNumber(value: address.lon! as Double)
        }
    }
    if address.publicPlace != nil {
        addr.publicPlace = NSNumber(value: address.publicPlace! as Bool)
    }
    if address.porch != nil {
        addr.porch = address.porch!
    }
    if address.corp != nil {
        addr.corp = address.corp!
    }
    
    return addr
}

func parseOrder(_ ord: Order) -> OrderTemp {
    let orderTemp = OrderTemp()
    if ord.pointA != nil {
        if ord.pointA?.lat.doubleValue != 0 {
            orderTemp.pathA = addressToTemp(ord.pointA!)
        }
        if ord.pointB != nil {
            if ord.pointB?.lat.doubleValue != 0 {
                orderTemp.pathB = addressToTemp(ord.pointB!)
            }
        }
        if ord.pointC != nil {
            if ord.pointC?.lat.doubleValue != 0 {
                orderTemp.pathC = addressToTemp(ord.pointC!)
            }
        }
        if ord.pointD != nil {
            if ord.pointD?.lat.doubleValue != 0 {
                orderTemp.pathD = addressToTemp(ord.pointD!)
            }
        }
        if ord.pointE != nil {
            if ord.pointE?.lat.doubleValue != 0 {
                orderTemp.pathE = addressToTemp(ord.pointE!)
            }
        }
    }
    
    orderTemp.payType = ord.payType ?? ""
    orderTemp.payCompanyId = ord.companyId ?? ""
    orderTemp.payPan = ord.cardNum
    
    NSKeyedUnarchiver.setClass(Additional.self, forClassName: "Utap.Additional")
    let wishes : [Additional]? = NSKeyedUnarchiver.unarchiveObject(with: ord.wishes as Data) as? [Additional]
    if wishes != nil {
        orderTemp.orderWishes = wishes
    }
    if ord.tariff != nil {
        NSKeyedUnarchiver.setClass(Tariff.self, forClassName: "Utap.Tariff")
        let tariff = NSKeyedUnarchiver.unarchiveObject(with: ord.tariff! as Data)
        if tariff is Tariff {
            orderTemp.orderTariff = tariff as? Tariff
        }
    }
    orderTemp.comment = ord.comment
    return orderTemp
}

func addressToTemp(_ addr : Address) -> AddressTemp {
    let addrTemp = AddressTemp()
    addrTemp.city = addr.city
    addrTemp.street = addr.street
    addrTemp.cityID = addr.cityID
    addrTemp.corp = addr.corp
    addrTemp.house = addr.house
    addrTemp.housing = addr.housing
    addrTemp.lat = addr.lat.doubleValue
    addrTemp.lon = addr.lon.doubleValue
    return addrTemp
}

// orderId: String, phone: String, address: String, payment: String, companyId: String = ""
func postUpdateOrder(profile: Profile, order: OrderTemp, orderId: String, handler completation: @escaping (String) -> Void)  {
    guard let safePhone = profile.phone else {
        showMessage("Error", message: "Phone is empty") // TODO TRANSLATE
        return
    }
    
    guard let safePayType = order.payType else {
        showMessage("Error", message: "Payment type is empty" ) // TODO TRANSLATE
        return
    }
    
    var args: [String: String] = [
        "address": gxStringAddrFromOrder(order: order),
        "order_id" : orderId,
        "phone": safePhone,
        "payment": safePayType
    ]
    
    if let companyId = order.payCompanyId, !companyId.isEmpty {
        args["company_id"] = companyId
    }
    
    if let pan = order.payPan, !pan.isEmpty {
        args["pan"] = pan
    }
    
    gxDoPOST(kGxApiPostUpdateOrder, params: args, completion: { (result) in
        guard let response = result as? [String: Any],
            let updateId = response["result"] as? String else {
            showMessage("Error", message: "Bad response from server") // TODO TRANSLATE
            return
        }
        
        completation(updateId)
    }) { (error) in
        // TODO
    }
}

enum UpdateResult: Int {
    case failure = 0
    case retry = 1
    case success = 2
}

func getUpdateOrderResult(updateId: String, phone: String, completation: @escaping (UpdateResult) -> Void) {
    let args = [
        "update_id" : updateId,
        "phone": phone
    ]
    
    gxDoGet(kGxApiGetUpdateOrderResult, params: args, completion: { (result) in
        guard let response = result as? [String: Any] else { return }
        if let unsafeCode = response["code"] {
            let code = parseString(unsafeCode)
            
            switch code {
            case "0":
                completation(.success)
            case "300":
                completation(.retry)
            default:
                completation(.failure)
            }
        }
    }) { (error) in
        
    }
}

func getRoute (_ ord : Order, completion: @escaping (_ ord: Order) -> Void, failure:() -> Void) {
    gxDoGet(kGxApiGetRoute, params: ["order_id" : ord.orderID!], completion: { (result) in
        if result is Dictionary<String, AnyObject> {
            let arch = NSKeyedArchiver.archivedData(withRootObject: result)
            ord.route = arch
            saveDefaultContext()
            completion(ord)
        }
    }) { (error) in
        print(error)
    }
}

func rejectOrd(_ ord : Order, completion: @escaping (_ res: Bool) -> Void, failure: (_ str : String) -> Void)
{
    gxRejectOrder(ord, completion: { (rejected) -> Void in
        completion(rejected)
    }, failure: { () -> Void in

    })
}


func gxRejectOrder(_ ord : Order, completion: @escaping (_ rejected: Bool) -> Void, failure:() -> Void) {
    if ord.orderID != nil {
        gxDoPOST(kGxApiRejectOrder, params: ["order_id" : ord.orderID!, "Request-Id" : ord.uuid], completion: { (result) -> Void in
            if result is Dictionary<String, AnyObject> {
                completion(true)
            }
        }) { (error) -> Void in
            completion(false)
        }
    }
}

func rejectOrderResult(_ ord : Order, completion: @escaping (_ res: String) -> Void, failure: (_ str : String) -> Void)
{
    gxRejectOrderResult(ord, completion: { (rejected) -> Void in
        completion(rejected)
    }, failure: { () -> Void in

    })
}

func gxRejectOrderResult(_ ord : Order, completion: @escaping (_ rejected: String) -> Void, failure:() -> Void) {
    gxRejectDoGet(kGxApiRejectOrderResult, params: ["request_id" : ord.uuid], completion: { (response) -> Void in
        if let result = response as? [String: Any] {
            if let code = result["code"] {
                switch (code as! Double) {
                case 0:
                    if let resultValid = result["result"] as? [String: Any] {
                        if resultValid["reject_result"] != nil {
                            if ((resultValid["reject_result"] as! Double) == 1) {
                                completion("complete")
                            }
                            else {
                                completion("error")
                            }
                        }
                    }
                case 300:
                    completion("process")
                default:
                    completion("error")
                }
            }
        }
    }) { (error) -> Void in
        completion("error")
    }
}


func gxGetOrdersInfo(_ ord : [Order], completion: @escaping (_ result: [Order]) -> Void, failure:@escaping () -> Void) {
    var dict = Dictionary<String, String>()
    var tempOrders = [Order]()
    var ordersIds = [String]()
    
    for orderTemp in ord {
        ordersIds.append(orderTemp.orderID!)
    }

    
    if usePhoto {
        switch photoType {
        case carPhoto:
            dict["need_car_photo"] = "1"
            dict["need_driver_photo"] = "0"
        case driverPhoto:
            dict["need_car_photo"] = "0"
            dict["need_driver_photo"] = "1"
        default:
            dict["need_car_photo"] = "0"
            dict["need_driver_photo"] = "0"
        }
        
    } else {
        dict["need_car_photo"] = "0"
        dict["need_driver_photo"] = "0"
    }
    
    dict["orders_id"] = ordersIds.joined(separator: ",")

    
    gxDoGet(kGxApiGetOrdersInfo, params: dict, completion: { (result) -> Void in
        if result is [String: Any] {
            if result["code"] != nil {
                if let resultValid = result["result"] as? [String: Any] {
                    if let orderList = resultValid["order_list"] as? [[String: Any]] {
                        for tempInfo in orderList {
                            for order in ord {
                                if (String(describing: tempInfo["order_id"]!) == order.orderID!) {
                                    tempOrders.append(updateOrderInfo(order, info: tempInfo))
                                }
                            }
                        }
                    }
                }
            }
        }
        completion(tempOrders)
    }){ (error) -> Void in
        failure()
    }
}

func updateOrderInfo(_ ord: Order, info: [String: Any]) -> Order {
    let orderInfo = info["order_info"] as! Dictionary<String, AnyObject>
    if orderInfo["car_data"] != nil {
        if orderInfo["car_data"] is Dictionary<String, AnyObject> {
            let carData = orderInfo["car_data"] as! Dictionary<String, AnyObject>
            if ord.driver == nil {
                ord.driver = Driver.mr_createEntity()
            }
            if carData["car_description"] != nil {
                if carData["car_description"] is String {
                    ord.driver?.carModel = carData["car_description"] as! String
                }
            }
            if carData["car_time"] != nil {
                if carData["car_time"] is String {
                    ord.carTime = Double(carData["car_time"] as! String) as NSNumber?
                }
                else if carData["car_time"] is Double {
                    ord.carTime = carData["car_time"] as? Double as NSNumber?
                }
            }
            if carData["driver_fio"] != nil {
                if carData["driver_fio"] is String {
                    ord.driver?.name = carData["driver_fio"] as! String
                }
            }
            if carData["driver_phone"] != nil {
                if carData["driver_phone"] is String {
                    ord.driver?.phone = carData["driver_phone"] as! String
                }
                else if carData["driver_phone"] is Double {
                    ord.driver?.phone = String(carData["driver_phone"] as! Double)
                }
            }
            if carData["raiting"] != nil {
                if carData["raiting"] is String {
                    ord.driver?.rate = Double(carData["raiting"] as! String) as NSNumber?
                }
                else if carData["raiting"] is Double {
                    ord.driver?.rate = carData["raiting"] as! Double as NSNumber?
                }
            }
            if carData[photo()] != nil {
                if carData[photo()] is String {
                    ord.driver?.photo = carData[photo()] as? String
                }
            }
            if carData["car_lat"] != nil {
                if carData["car_lat"] is String {
                    ord.driver?.lat = (carData["car_lat"] as! NSString).doubleValue as NSNumber?
                }
                else if carData["car_lat"] is Double {
                    ord.driver?.lat = carData["car_lat"] as! Double as NSNumber?
                }
            }
            if carData["car_lon"] != nil {
                if carData["car_lon"] is String {
                    ord.driver?.lon = (carData["car_lon"] as! NSString).doubleValue as NSNumber?
                }
                else if carData["car_lon"] is Double {
                    ord.driver?.lon = carData["car_lon"] as! Double as NSNumber?
                }
            }
            if carData["degree"] != nil {
                if carData["degree"] is String {
                    ord.driver?.angle = (carData["degree"] as! NSString).doubleValue as NSNumber?
                }
                else if carData["degree"] is Double {
                    ord.driver?.angle = carData["degree"] as! Double as NSNumber?
                }
            }
        }
    }

    if orderInfo["status_group"] != nil {
        if orderInfo["status_group"] is String {
            ord.statusID = orderInfo["status_group"] as! String
        }
    }
    if orderInfo["status_id"] != nil {
        if orderInfo["status_id"] is String {
            if orderInfo["status_id"] as! String == "38" {
                ord.payType = ""
            }
        }
        else if orderInfo["status_id"] is Double {
            if orderInfo["status_id"] as! Double == 38 {
                ord.payType = ""
            }
        }
    }
    if orderInfo["status_name"] != nil {
        if orderInfo["status_name"] is String {
            ord.statusLabel = orderInfo["status_name"] as! String
        }
    }
    if orderInfo["order_time"] != nil {
        if orderInfo["order_time"] is Double {
            ord.carDateTime = Date(timeIntervalSince1970: orderInfo["order_time"] as! Double - getInaccuracy())
        }
    }
    if ord.statusID == "completed" {
        if orderInfo["payment"]! is Dictionary<String, String> {
            if orderInfo["payment"]!["type"] != nil {
                if orderInfo["payment"]!["type"] is String {
                    ord.payType = orderInfo["payment"]!["type"] as? String
                    if ord.payType == "CARD" {
                        if orderInfo["payment"]!["pan"] != nil {
                            if orderInfo["payment"]!["pan"] is String {
                                ord.cardNum = (orderInfo["payment"]!["pan"] as? String)!
                            }
                        }
                    }
                }
            }
        }

        if orderInfo["status_id"] != nil {
            if orderInfo["status_id"] is String {
                if orderInfo["status_id"] as! String == "38" {
                    ord.payType = ""
                }
            }
            else if orderInfo["status_id"] is Double {
                if orderInfo["status_id"] as! Double == 38 {
                    ord.payType = ""
                }
            }
        }

    }
    return ord
}

//MARK: - Network

func createOrd(_ ord : OrderTemp, completion: @escaping (_ order: Order) -> Void, failure: (_ str : String) -> Void)
{
    gxCreateOrder(ord, completion: { (order) -> Void in
        completion(order)
        }, failure: { () -> Void in
            
    })
}

func gxCreateOrder(_ ord : OrderTemp, completion: @escaping (_ order: Order) -> Void, failure:() -> Void) {
    gxDoPOST(kGxApiCreateOrder, params: gxDictionaryCreateFromOrder(ord), completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            completion(gxParseOrder(result as! Dictionary<String, AnyObject>, ord: ord))
        }
        }) { (error) -> Void in
            
    }
}

func gxDictionaryCreateFromOrder(_ order : OrderTemp) -> Dictionary<String, String>
{
    var dict = Dictionary<String, String>()
    
    dict["address"] = gxStringAddrFromOrder(order: order)
    dict["type_request"] = "1"
    dict["device_token"] = deviceToken()
    dict["city_id"] = curCity().cityID
    dict["client_phone"] = profile().phone
    dict["company_id"] = defaultPayType().payCompanyID
    dict["tariff_id"] = order.orderTariff?.tariffID
    dict["client_id"] = profile().clientID
    dict["client_name"] = profile().firstName
    dict["pay_type"] = order.payType
    if order.payType == "CARD" {
        dict["pan"] = order.payPan
    }
    if order.payBonus == true {
        dict["bonus_payment"] = "1"
        if order.promoCode != nil {
            dict["promo_code"] = order.promoCode!
        }

    } else {
        dict["bonus_payment"] = "0"
    }
        var newComment = order.comment!
    if newComment.characters.count > 100 {
        let index: String.Index = newComment.characters.index(newComment.startIndex, offsetBy: 100)
        newComment = newComment.substring(to: index)
    }
    dict["comment"] = newComment

    if order.orderTime != nil {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy HH:mm:ss"
        dict["order_time"] = formatter.string(from: order.orderTime! as Date)
    }
    if order.orderWishes != nil {
        if order.orderWishes?.count > 0 {
            var wishes = ""
            for wish in order.orderWishes! {
                if wishes == "" {
                    wishes = wish.optionId!
                }
                else {
                    wishes = "\(wishes),\(wish.optionId!)"
                }
            }
            dict["additional_options"] = wishes
        }
    }
    return dict
}

func gxParseOrder(_ dict: Dictionary<String, AnyObject>, ord : OrderTemp) -> Order
{
    writeAddressesFromOrder(ord)
    
    let orderNew = orderToCoreData(ord)
    
    //orderNew.MR_inContext(NSManagedObjectContext.MR_defaultContext())
    
    if dict["result"] != nil {
        if dict["result"] is Dictionary<String, AnyObject> {
            if dict["result"]!["order_id"] != nil {
                if dict["result"]!["order_id"] is String {
                    orderNew.orderID = (dict["result"]!["order_id"] as? String)!
                }
                else if dict["result"]!["order_id"] is Int {
                    orderNew.orderID = String(dict["result"]!["order_id"] as! Int)
                }
            }
            
            if dict["result"]!["order_number"] != nil {
                if dict["result"]!["order_number"] is String {
                    orderNew.orderNumber = (dict["result"]!["order_number"] as? String)!
                }
                else if dict["result"]!["order_number"] is Int {
                    orderNew.orderNumber = String((dict["result"]!["order_number"] as! Int))
                }
            }
            if dict["result"]!["type"] != nil {
                if dict["result"]!["type"] is String {
                    orderNew.statusID = (dict["result"]!["type"] as? String)!
                }
                else if dict["result"]!["type"] is Int {
                    orderNew.statusID = String((dict["result"]!["type"] as! Int))
                }
            }
        }
    }
    
    if orderNew.statusID == "" {
        orderNew.statusID = "new"
    }
    if orderNew.statusID == "new" {
        orderNew.statusLabel = strComOrderNew()
    }
    
    let uuid = NSUUID().uuidString.lowercased()
    orderNew.uuid = uuid
    
    saveDefaultContext()
    
    return orderNew
}


func updOrder(_ ord : Order, completion: @escaping (_ order: Order) -> Void) {
    gxUpdateOrder(ord, completion: { (order) -> Void in
        completion(order)
    })
}

func gxUpdateOrder(_ ord : Order, completion: @escaping (_ order: Order) -> Void)
{
    if ord.orderID != nil {
        var params = ["order_id" : ord.orderID!]
        
        if usePhoto {
            switch photoType {
            case carPhoto:
                params["need_car_photo"] = "1"
                params["need_driver_photo"] = "0"
            case driverPhoto:
                params["need_car_photo"] = "0"
                params["need_driver_photo"] = "1"
            default:
                params["need_car_photo"] = "0"
                params["need_driver_photo"] = "0"
            }
            
        } else {
            params["need_car_photo"] = "0"
            params["need_driver_photo"] = "0"
        }
        
        gxDoGet(kGxApiGetOrderInfo, params: params, completion: { (result) -> Void in
            
            if let resultValid = result["result"] as? [String: Any] {
                if let orderInfo = resultValid["order_info"] as? [String:Any] {
                            if orderInfo["car_data"] != nil {
                                if orderInfo["car_data"] is [String: Any] {
                                    let carData = orderInfo["car_data"] as! [String: Any]
                                    if ord.driver == nil {
                                        ord.driver = Driver.mr_createEntity()
                                    }
                                    if carData["car_description"] != nil {
                                        if carData["car_description"] is String {
                                            ord.driver?.carModel = carData["car_description"] as! String
                                        }
                                    }
                                    if carData["car_time"] != nil {
                                        if carData["car_time"] is String {
                                            ord.carTime = Double(carData["car_time"] as! String) as NSNumber?
                                        }
                                        else if carData["car_time"] is Double {
                                            ord.carTime = carData["car_time"] as! NSNumber?
                                        }
                                    }
                                    if carData["driver_fio"] != nil {
                                        if carData["driver_fio"] is String {
                                            ord.driver?.name = carData["driver_fio"] as! String
                                        }
                                    }
                                    if carData["driver_phone"] != nil {
                                        if carData["driver_phone"] is String {
                                            ord.driver?.phone = carData["driver_phone"] as! String
                                        }
                                        else if carData["driver_phone"] is Double {
                                            ord.driver?.phone = String(carData["driver_phone"] as! Double)
                                        }
                                    }
                                    if carData["raiting"] != nil {
                                        if carData["raiting"] is String {
                                            ord.driver?.rate = Double(carData["raiting"] as! String) as NSNumber?
                                        }
                                        else if carData["raiting"] is Double {
                                            ord.driver?.rate = carData["raiting"] as! NSNumber?
                                        }
                                    }
                                    if carData[photo()] != nil {
                                        if carData[photo()] is String {
                                            ord.driver?.photo = carData[photo()] as? String
                                        }
                                    }
                                    if carData["car_lat"] != nil {
                                        if carData["car_lat"] is String {
                                            ord.driver?.lat = NSNumber(value: Double(carData["car_lat"] as! String)!)
                                        }
                                        else if carData["car_lat"] is Double {
                                            ord.driver?.lat = carData["car_lat"] as! NSNumber?
                                        }
                                    }
                                    if carData["car_lon"] != nil {
                                        if carData["car_lon"] is String {
                                            ord.driver?.lon = NSNumber(value: Double(carData["car_lon"] as! String)!)
                                        }
                                        else if carData["car_lon"] is Double {
                                            ord.driver?.lon = carData["car_lon"] as! NSNumber?
                                        }
                                    }
                                    if carData["degree"] != nil {
                                        if carData["degree"] is String {
                                            ord.driver?.angle = NSNumber(value: Double(carData["degree"] as! String)!)
                                        }
                                        else if carData["degree"] is Double {
                                            ord.driver?.angle = carData["degree"] as! NSNumber?
                                        }
                                    }
                                }
                            }
                            if orderInfo["currency"] != nil {
                                if orderInfo["currency"] is String {
                                    print(orderInfo["currency"]!)
                                    ord.currency = orderInfo["currency"] as! String
                                }
                            }
                            
                            if let addressList = orderInfo["address"] as? [[String: Any]] {
                                for (index, address) in addressList.enumerated() {
                                    let adr = AddressTemp()
                                    
                                    adr.publicPlace = false
                                    
                                    if let city = address["city"] as? String {
                                        adr.city = city
                                    }
                                    if let house = address["house"] as? String {
                                        adr.house = house
                                    }
                                    if let street = address["street"] as? String {
                                        adr.street = street
                                    }
                                    if let lat = (address["lat"] as? NSString)?.doubleValue{
                                        adr.lat = lat
                                    }
                                    if let lon: Double? = (address["lon"] as? NSString)?.doubleValue {
                                        adr.lon = lon
                                    }
                                    
                                    switch index {
                                    case 0:
                                        ord.pointA = addressTempToOrder(adr);
                                    case 1:
                                        ord.pointB = addressTempToOrder(adr);
                                    case 2:
                                        ord.pointC = addressTempToOrder(adr);
                                    case 3:
                                        ord.pointD = addressTempToOrder(adr);
                                    case 4:
                                        ord.pointE = addressTempToOrder(adr);
                                    default:
                                        break;
                                    }
                                }

                            }

                            
                            if orderInfo["detail_cost_info"] != nil {
                                if orderInfo["detail_cost_info"] is [String: Any] {
                                    let costInfo = orderInfo["detail_cost_info"] as! [String: Any]
                                    if costInfo["additional_cost"] != nil {
                                        if costInfo["additional_cost"] is String {
                                            ord.cost_adds = NSNumber(value: Double(costInfo["additional_cost"] as! String)!)
                                        }
                                        else if costInfo["additional_cost"] is Double {
                                            ord.cost_adds = costInfo["additional_cost"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["planting_price"] != nil {
                                        if costInfo["planting_price"] is String {
                                            ord.cost_car_assigning = NSNumber(value: Double(costInfo["planting_price"] as! String)!)
                                        }
                                        else if costInfo["planting_price"] is Double {
                                            ord.cost_car_assigning = (costInfo["planting_price"] as! NSNumber?)!
                                        }
                                    }
                                    if costInfo["city_cost"] != nil {
                                        if costInfo["city_cost"] is String {
                                            ord.cost_city = NSNumber(value: Double(costInfo["city_cost"] as! String)!)
                                        }
                                        else if costInfo["city_cost"] is Double {
                                            ord.cost_city = (costInfo["city_cost"] as! NSNumber?)!
                                        }
                                        
                                        if costInfo["city_cost_time"] != nil {
                                            if costInfo["city_cost_time"] is String {
                                                let cost = ord.cost_city.doubleValue + Double(costInfo["city_cost_time"] as! String)!
                                                ord.cost_city = NSNumber(value: cost)
                                            }
                                            else if costInfo["city_cost_time"] is Double {
                                                let cost = ord.cost_city.doubleValue + (costInfo["city_cost_time"] as! Double)
                                                ord.cost_city = NSNumber(value: cost)
                                            }
                                        }
                                        
                                    }
                                    if costInfo["city_time"] != nil {
                                        if costInfo["city_time"] is String {
                                            ord.time_city = NSNumber(value: Double(costInfo["city_time"] as! String)!)
                                        }
                                        else if costInfo["city_time"] is Double {
                                            ord.time_city = costInfo["city_time"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["out_city_time"] != nil {
                                        if costInfo["out_city_time"] is String {
                                            ord.time_outCity = NSNumber(value: Double(costInfo["out_city_time"] as! String)!)                                        }
                                        else if costInfo["out_city_time"] is Double {
                                            ord.time_outCity = costInfo["out_city_time"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["accrual_city"] != nil {
                                        if costInfo["accrual_city"] is String {
                                            ord.accrualCity = costInfo["accrual_city"] as! String
                                        }
                                    }
                                    if costInfo["accrual_out"] != nil {
                                        if costInfo["accrual_out"] is String {
                                            ord.accrualOutCity = costInfo["accrual_out"] as! String
                                        }
                                    }
                                    if costInfo["summary_cost"] != nil {
                                        if costInfo["summary_cost"] is String {
                                            ord.cost_order = NSNumber(value: Double(costInfo["summary_cost"] as! String)!)
                                        }
                                        else if costInfo["summary_cost"] is Double {
                                            ord.cost_order = (costInfo["summary_cost"] as! NSNumber?)!
                                        }
                                    }
                                    if costInfo["before_time_wait"] != nil {
                                        if costInfo["before_time_wait"] is String {
                                            ord.time_clientWait = NSNumber(value: Double(costInfo["before_time_wait"] as! String)!)
                                        }
                                        else if costInfo["before_time_wait"] is Double {
                                            ord.time_clientWait = costInfo["before_time_wait"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["before_time_wait_cost"] != nil {
                                        if costInfo["before_time_wait_cost"] is String {
                                            ord.cost_clientWait = NSNumber(value: Double(costInfo["before_time_wait_cost"] as! String)!)
                                        }
                                        else if costInfo["before_time_wait_cost"] is Double {
                                            ord.cost_clientWait = costInfo["before_time_wait_cost"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["out_city_cost"] != nil {
                                        if costInfo["out_city_cost"] is String {
                                            ord.cost_outCity = NSNumber(value: Double(costInfo["out_city_cost"] as! String)!)
                                        }
                                        else if costInfo["out_city_cost"] is Double {
                                            ord.cost_outCity = costInfo["out_city_cost"] as! NSNumber?
                                        }
                                        if ord.cost_outCity != nil {
                                            if costInfo["out_city_cost_time"] != nil {
                                                if costInfo["out_city_cost_time"] is String {
                                                    let cost = ord.cost_outCity!.doubleValue + Double(costInfo["out_city_cost_time"] as! String)!
                                                    ord.cost_outCity = NSNumber(value: cost)
                                                }
                                                else if costInfo["out_city_cost_time"] is Double {
                                                    let cost = ord.cost_outCity!.doubleValue + (costInfo["out_city_cost_time"] as! Double)
                                                    ord.cost_outCity = NSNumber(value: cost)
                                                }
                                            }
                                        }
                                    }
                                    if costInfo["city_wait_cost"] != nil {
                                        if costInfo["city_wait_cost"] is String {
                                            ord.cost_prostCity = NSNumber(value: Double(costInfo["city_wait_cost"] as! String)!)
                                        }
                                        else if costInfo["city_wait_cost"] is Double {
                                            ord.cost_prostCity = costInfo["city_wait_cost"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["out_wait_cost"] != nil {
                                        if costInfo["out_wait_cost"] is String {
                                            ord.cost_prostOutCity = NSNumber(value: Double(costInfo["out_wait_cost"] as! String)!)
                                        }
                                        else if costInfo["out_wait_cost"] is Double {
                                            ord.cost_prostOutCity = costInfo["out_wait_cost"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["city_distance"] != nil {
                                        if costInfo["city_distance"] is String {
                                            ord.dist_city = NSNumber(value: Double(costInfo["city_distance"] as! String)!)
                                        }
                                        else if costInfo["city_distance"] is Double {
                                            ord.dist_city = costInfo["city_distance"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["city_time_wait"] != nil {
                                        if costInfo["city_time_wait"] is String {
                                            ord.dist_cityProst = NSNumber(value: Double(costInfo["city_time_wait"] as! String)!)
                                        }
                                        else if costInfo["city_time_wait"] is Double {
                                            ord.dist_cityProst = costInfo["city_time_wait"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["planting_include"] != nil {
                                        if costInfo["planting_include"] is String {
                                            ord.dist_included = NSNumber(value: Double(costInfo["planting_include"] as! String)!)
                                        }
                                        else if costInfo["city_time_wait"] is Double {
                                            ord.dist_included = costInfo["planting_include"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["out_city_distance"] != nil {
                                        if costInfo["out_city_distance"] is String {
                                            ord.dist_outCity = NSNumber(value: Double(costInfo["out_city_distance"] as! String)!)
                                        }
                                        else if costInfo["out_city_distance"] is Double {
                                            ord.dist_outCity = costInfo["out_city_distance"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["out_time_wait"] != nil {
                                        if costInfo["out_time_wait"] is String {
                                            ord.dist_outCityProst = NSNumber(value: Double(costInfo["out_time_wait"] as! String)!)
                                        }
                                        else if costInfo["out_time_wait"] is Double {
                                            ord.dist_outCityProst = costInfo["out_time_wait"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["summary_distance"] != nil {
                                        if costInfo["summary_distance"] is String {
                                            ord.dist_sum = NSNumber(value: Double(costInfo["summary_distance"] as! String)!)
                                        }
                                        else if costInfo["summary_distance"] is Double {
                                            ord.dist_sum = costInfo["summary_distance"] as! NSNumber?
                                        }
                                    }
                                    if costInfo["is_fix"] != nil {
                                        if costInfo["is_fix"] is String {
                                            ord.isFix = NSNumber(value: Double(costInfo["is_fix"] as! String)!)
                                        }
                                        else if costInfo["is_fix"] is Double {
                                            ord.isFix = (costInfo["is_fix"] as! NSNumber?)!
                                        }
                                    }
                                }
                            }
                            if orderInfo["status_group"] != nil {
                                if orderInfo["status_group"] is String {
                                    ord.statusID = orderInfo["status_group"] as! String
                                }
                            }
                            if orderInfo["status_id"] != nil {
                                if orderInfo["status_id"] is String {
                                    if orderInfo["status_id"] as! String == "38" {
                                        ord.payType = ""
                                    }
                                }
                                else if orderInfo["status_id"] is Double {
                                    if orderInfo["status_id"] as! Double == 38 {
                                        ord.payType = ""
                                    }
                                }
                            }
                            if orderInfo["predv_price"] != nil {
                                if orderInfo["predv_price"] is String {
                                    ord.fixPrice = NSNumber(value: Double(orderInfo["predv_price"] as! String)!)
                                }
                                else if orderInfo["predv_price"] is Double {
                                        ord.fixPrice = orderInfo["predv_price"] as! NSNumber?
                                }
                            }
                            if orderInfo["status_name"] != nil {
                                if orderInfo["status_name"] is String {
                                    ord.statusLabel = orderInfo["status_name"] as! String
                                }
                            }
                            if ord.statusID == "completed" {
                                if let payment = orderInfo["payment"]! as? [String: Any] {
                                    if payment["type"] != nil {
                                        if payment["type"] is String {
                                            ord.payType = payment["type"] as? String
                                            if ord.payType == "CARD" {
                                                if payment["pan"] != nil {
                                                    if payment["pan"] is String {
                                                        ord.cardNum = (payment["pan"] as? String)!
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if orderInfo["status_id"] != nil {
                                    if orderInfo["status_id"] is String {
                                        if orderInfo["status_id"] as! String == "38" {
                                            ord.payType = ""
                                        }
                                    }
                                    else if orderInfo["status_id"] is Double {
                                        if orderInfo["status_id"] as! Double == 38 {
                                            ord.payType = ""
                                        }
                                    }
                                

                            }
                        }
                    }
                }
            saveDefaultContext()
            completion(ord)
            
            }, failure: { (error) -> Void in
                
        })
    }
}
