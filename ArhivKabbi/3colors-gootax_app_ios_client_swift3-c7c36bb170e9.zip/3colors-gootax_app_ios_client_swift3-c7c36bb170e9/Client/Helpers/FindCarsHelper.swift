//
//  FindCarsHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 01.10.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation


class Car {
    var free : Bool
    var lat : Double
    var lon : Double
    var course : Double
    init() {
        free = true
        lat = 0
        lon = 0
        course = 0
    }
}



func getCars(_ completion: @escaping (_ cars: [Car]?) -> Void, failure: (_ str : String) -> Void)
{
    gxGetCars({ (orderP) -> Void in
        completion(orderP)
        }, failure: {
            print("failure to get cars")
    })
}

func gxGetCarsWith(_ parameters: Dictionary <String, String>, completion: @escaping (_ cars: [Car]?) -> Void, failure:() -> Void)
{
    let prms = [
        "city_id" : curCity().cityID!,
        "from_lat" : "\(parameters["from_lat"]!)",
        "from_lon" : "\(parameters["from_lon"]!)",
        "radius" : getCarsRadius,
        ]
    gxDoGet(kGxApiGetCars, params: prms, completion: { (response) -> Void in
        //        print(result)
        if let result = response["result"] as? [String: Any] {
            if result["cars"] != nil {
                if result["cars"] is [[String: Any]] {
                    gxParseCars(result["cars"] as! [Dictionary<String, AnyObject>], completion: { (cars) -> Void in
                        completion(cars)
                    })
                }
            }
        }
    }) { (error) -> Void in
        
    }
    
}

func gxGetCars(_ completion: @escaping (_ cars: [Car]?) -> Void, failure:() -> Void)
{
    gxDoGet(kGxApiGetCars, params: ["city_id" : curCity().cityID!], completion: { (response) -> Void in
        //        print(result)
        if let result = response as? [String: Any] {
            if result["cars"] != nil {
                if result["cars"] is [String: Any] {
                    gxParseCars(result["cars"] as! [Dictionary<String, AnyObject>], completion: { (cars) -> Void in
                        completion(cars)
                    })
                }
            }
        }
    }) { (error) -> Void in
        
    }
}


func gxParseCars(_ carsDict : [Dictionary<String, AnyObject>], completion : @escaping (_ cars : [Car]) -> Void)
{
    let queue = OperationQueue()
    
    queue.addOperation({
        var carsArray = [Car]()
        
        if carsDict.count > 0 {
            for i in 0...carsDict.count-1 {
                let dict = carsDict[i]
                let newCar = Car()
                
                if dict["car_is_free"] != nil {
                    if dict["car_is_free"] is Double {
                        if dict["car_is_free"] as! Double == 0 {
                            newCar.free = false
                        }
                    }
                    else if dict["car_is_free"] is String {
                        if dict["car_is_free"] as! String == "0" {
                            newCar.free = false
                        }
                    }
                }
                if dict["car_lat"] != nil {
                    if dict["car_lat"] is Double {
                        newCar.lat = dict["car_lat"] as! Double
                    }
                    else if dict["car_lat"] is String {
                        newCar.lat = (dict["car_lat"] as! NSString).doubleValue
                    }
                }
                if dict["car_lon"] != nil {
                    if dict["car_lon"] is Double {
                        newCar.lon = dict["car_lon"] as! Double
                    }
                    else if dict["car_lon"] is String {
                        newCar.lon = (dict["car_lon"] as! NSString).doubleValue
                    }
                }
                
                if dict["degree"] != nil {
                    if dict["degree"] is Double {
                        newCar.course = dict["degree"] as! Double
                    }
                    else if dict["degree"] is String {
                        newCar.course = (dict["degree"] as! NSString).doubleValue
                    }
                }
                
                carsArray.append(newCar)
            }
        }
        OperationQueue.main.addOperation({
            completion(carsArray)
        })
    })
}

func parseCars(_ carsDict : [Dictionary<String, AnyObject>], completion : (_ cars : [Car]) -> Void)
{
    var carsArray = [Car]()
    if carsDict.count > 0 {
        for i in 0...carsDict.count-1 {
            
            let dict = carsDict[i]
            let newCar = Car()
            
            if dict["isFree"] != nil {
                if dict["isFree"] is Double {
                    if dict["isFree"] as! Double == 0 {
                        newCar.free = false
                    }
                }
                else if dict["isFree"] is String {
                    if dict["isFree"] as! String == "0" {
                        newCar.free = false
                    }
                }
            }
            if dict["lat"] != nil {
                if dict["lat"] is Double {
                    newCar.lat = dict["lat"] as! Double
                }
                else if dict["lat"] is String {
                    newCar.lat = (dict["lat"] as! NSString).doubleValue
                }
            }
            if dict["lon"] != nil {
                if dict["lon"] is Double {
                    newCar.lon = dict["lon"] as! Double
                }
                else if dict["lon"] is String {
                    newCar.lon = (dict["lon"] as! NSString).doubleValue
                }
            }
            carsArray.append(newCar)
        }
    }
    completion(carsArray)
}

