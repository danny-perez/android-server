//
//  Constants.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

// User Defaults
public let udefCurLan = "udefCurLan"
public let udefDevToken = "udefDevToken"
public let udefSecretKey = "udefSecretKey"
public let udefCurColorScheme = "udefCurColorScheme"
public let udefLastSendSMS = "udefLastSendedSMS"
public let udefCurCountry = "udefCurCountry"
public let udefCurMap = "udefCurMap"
public let udefGoogleMapType = "udefGoogleMapType"
public let udefCurTenID = "udefCurTenID"
public let udefLastAddresses = "udefLastAddresses"
public let udefTariffs = "udefTariffs"
public let udefCurrency = "udefCurrency"
public let udefDispPhone = "udefDispPhone"
public let udefProfile = "udefProfile"
public let udefRecentAddresses = "udefRecentAddresses"
public let udefBonusSystem = "udefBonusSystem"
public let udefCities = "udefCities"
public let udefReferrals = "udefReferrals"
public let udefCurCity = "udefCurCity"
public let udefSch = "udefNewScheme"
public let udefEditedAddr = "udefEditedAddress"
public let udefShareUrl = "udefShareUrl"
public let udefAndroidShareUrl = "udefAndroidShareUrl"

/* Только Taxi3c */
public let udefBrowserKey = "udefBrowserKey"
public let udefToken = "udefToken"

// Notifs
public let notifChangeLan = "changeLanNotif"
public let notifChangeCol = "changeColor"
public let notifChangeCalendar = "changeCalendar"

//Geocoding API
public let osmGeocodingURL = "http://nominatim.openstreetmap.org/reverse"
public let googleGeocodingURL = "http://maps.googleapis.com/maps/api/geocode/json"
public let osmGeocodingDir = "http://nominatim.openstreetmap.org/search"

//Autocomplete Gootax API
public let autocomplGxURL = prodServer ? geoUrl + "autocomplete" : "http://192.168.10.206:3100/v1/autocomplete"
public let searchGxURL = prodServer ? geoUrl + "search" : "http://192.168.10.206:3100/v1/search"
public let geocodeGxURL = prodServer ? geoUrl + "reverse" : "http://192.168.10.206:3100/v1/reverse"

// Calendars Type
public let gregorian = 0
public let persian = 1


// Account requests
public let kGxApiAcceptPassword = "accept_password"
public let kGxApiSendPassword = "send_password"
public let kGxApiUpdProfile = "update_client_profile"
public let kGxApiGetProfile = "get_client_profile"
public let kGxApiGetClientCards = "get_client_cards"
public let kGxApiCreateClientCard = "create_client_card"
public let kGxApiCheckClientCard = "check_client_card"
public let kGxApiDeleteClientCard = "delete_client_card"
public let kGxActivateBonusSystem = "activate_bonus_system"
public let kGxApiClientBalances = "get_client_balance"

// Order requests
public let kGxApiCreateOrder = "create_order"
public let kGxApiGetOrderInfo = "get_order_info"
public let kGxApiRejectOrder = "reject_order"
public let kGxApiRejectOrderResult = "get_reject_order_result"
public let kGxApiSendFeedback = "send_response"
public let kGxApiGetRoute = "get_order_route"
public let kGxApiGetOrdersInfo = "get_orders_info"

// Geo requests
public let kGxApiFindTariffs = "get_tariffs_list"
public let kGxApiFindTariffsTypes = "get_tariffs_type"
public let kGxApiGetCityList = "get_city_list" // для поиска
public let kGxApiGetTenantCities = "get_tenant_city_list" // для выбора города арендатора
public let kGxApiGetCars = "get_cars"
public let kGxApiGetAddressByCoords = "get_address_by_coords"
public let kGxApiGetClientHistory = "get_client_history_address"

// Help requests
public let kGxApiGetInfoPage = "get_info_page"
public let kGxApiPing = "ping"
public let kGxApiLinks = "get_download_links"
public let kGxApiConfidentialPage = "get_confidential_page"


public let kGxApiActivateReferralSystem = "activate_referral_system"
public let kGxApiActivateCodeReferralSystem = "activate_referral_system_code"
public let kGxApiGetReferralSystemList = "get_referral_system_list"


public let kGxApiPostUpdateOrder = "update_order"
public let kGxApiGetUpdateOrderResult = "update_order_result"

// Others
public let kOSMTiles = "http://tile.openstreetmap.org/{z}/{x}/{y}.png"

public func countryList() -> [[String: Any]] {
    
    var arr = [[String:Any]]()
    arr.append(["mask" : "+376-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.ad"), "code" : "AD", "placeholder" : "+376-___-___", "minLength" : 9, "shortMask" : "+376"])
    arr.append(["mask" : "+93-{dd}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.af"), "code" : "AF", "placeholder" : "+93-__-___-____", "minLength" : 11, "shortMask" : "+93"])
    arr.append(["mask" : "+1(264){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.ai"), "code" : "AI", "placeholder" : "+1(264)___-____", "minLength" : 11, "shortMask" : "+1(264)"])
    arr.append(["mask" : "+355({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.al"), "code" : "AL", "placeholder" : "+355(___)___-___", "minLength" : 12, "shortMask" : "+355"])
    arr.append(["mask" : "+374-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.am"), "code" : "AM", "placeholder" : "+374-__-___-___", "minLength" : 11, "shortMask" : "+374"])
    arr.append(["mask" : "+244({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.ao"), "code" : "AO", "placeholder" : "+244(___)___-___", "minLength" : 12, "shortMask" : "+244"])
    arr.append(["mask" : "+54({ddd}){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.ar"), "code" : "AR", "placeholder" : "+54(___)___-____", "minLength" : 12, "shortMask" : "+54"])
    arr.append(["mask" : "+43({ddd}){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.at"), "code" : "AT", "placeholder" : "+43(___)___-____", "minLength" : 12, "shortMask" : "+43"])
    arr.append(["mask" : "+61-{d}-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.au"), "code" : "AU", "placeholder" : "+61-_-____-____", "minLength" : 11, "shortMask" : "+61"])
    arr.append(["mask" : "+994-{dd}-{ddd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.az"), "code" : "AZ", "placeholder" : "+994-__-___-__-__", "minLength" : 12, "shortMask" : "+994"])
    arr.append(["mask" : "+387-{dd}-{ddddd}" as AnyObject, "label" : getStringByKey("country.ba"), "code" : "BA", "placeholder" : "+387-__-_____", "minLength" : 9, "shortMask" : "+387"])
    arr.append(["mask" : "+880-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.bd"), "code" : "BD", "placeholder" : "+880-__-___-___", "minLength" : 11, "shortMask" : "+880"])
    arr.append(["mask" : "+32({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.be"), "code" : "BE", "placeholder" : "+32(___)___-___", "minLength" : 11, "shortMask" : "+32"])
    arr.append(["mask" : "+226-{dd}-{dd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bf"), "code" : "BF", "placeholder" : "+226-__-__-____", "minLength" : 11, "shortMask" : "+226"])
    arr.append(["mask" : "+359({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.bg"), "code" : "BG", "placeholder" : "+359(___)___-___", "minLength" : 12, "shortMask" : "+359"])
    arr.append(["mask" : "+973-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bh"), "code" : "BH", "placeholder" : "+973-____-____", "minLength" : 11, "shortMask" : "+973"])
    arr.append(["mask" : "+257-{dd}-{dd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bi"), "code" : "BI", "placeholder" : "+257-__-__-____", "minLength" : 11, "shortMask" : "+257"])
    arr.append(["mask" : "+229-{dd}-{dd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bj"), "code" : "BJ", "placeholder" : "+229-__-__-____", "minLength" : 11, "shortMask" : "+229"])
    arr.append(["mask" : "+1(441){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bm"), "code" : "BM", "placeholder" : "+1(441)___-____", "minLength" : 11, "shortMask" : "+1(441)"])
    arr.append(["mask" : "+591-{d}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bo"), "code" : "BO", "placeholder" : "+591-_-___-____", "minLength" : 11, "shortMask" : "+591"])
    arr.append(["mask" : "+55-{dd}-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.br"), "code" : "BR", "placeholder" : "+55-__-____-____", "minLength" : 12, "shortMask" : "+55"])
    arr.append(["mask" : "+1(242){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bs"), "code" : "BS", "placeholder" : "+1(242)___-____", "minLength" : 11, "shortMask" : "+1(242)"])
    arr.append(["mask" : "+975-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.bt"), "code" : "BT", "placeholder" : "+975-__-___-___", "minLength" : 10, "shortMask" : "+975"])
    arr.append(["mask" : "+375({dd}){ddd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.by"), "code" : "BY", "placeholder" : "+375(__)___-__-__", "minLength" : 13, "shortMask" : "+375"])
    arr.append(["mask" : "+501-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.bz"), "code" : "BZ", "placeholder" : "+501-___-____", "minLength" : 10, "shortMask" : "+501"])
    arr.append(["mask" : "+243({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.cd"), "code" : "CD", "placeholder" : "+243(___)___-___", "minLength" : 12, "shortMask" : "+243"])
    arr.append(["mask" : "+236-{dd}-{dd}-{dddd}" as AnyObject, "label" : getStringByKey("country.cf"), "code" : "CF", "placeholder" : "+236-__-__-____", "minLength" : 11, "shortMask" : "+236"])
    arr.append(["mask" : "+41-{dd}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.ch"), "code" : "CH", "placeholder" : "+41-__-___-____", "minLength" : 11, "shortMask" : "+41"])
    arr.append(["mask" : "+225-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.ci"), "code" : "CI", "placeholder" : "+225-__-___-___", "minLength" : 11, "shortMask" : "+225"])
    arr.append(["mask" : "+682-{dd}-{ddd}" as AnyObject, "label" : getStringByKey("country.ck"), "code" : "CK", "placeholder" : "+682-__-___", "minLength" : 8, "shortMask" : "+682"])
    arr.append(["mask" : "+56-{d}-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.cl"), "code" : "CL", "placeholder" : "+56-_-____-____", "minLength" : 11, "shortMask" : "+56"])
    arr.append(["mask" : "+237-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.cm"), "code" : "CM", "placeholder" : "+237-____-____", "minLength" : 11, "shortMask" : "+237"])
    arr.append(["mask" : "+86-{dd}-{ddddd}-{ddddd}" as AnyObject, "label" : getStringByKey("country.cn"), "code" : "CN", "placeholder" : "+86-__-_____-_____", "minLength" : 12, "shortMask" : "+86"])
    arr.append(["mask" : "+57({ddd}){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.co"), "code" : "CO", "placeholder" : "+57(___)___-____", "minLength" : 12, "shortMask" : "+57"])
    arr.append(["mask" : "+506-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.cr"), "code" : "CR", "placeholder" : "+506-____-____", "minLength" : 11, "shortMask" : "+506"])
    arr.append(["mask" : "+53-{d}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.cu"), "code" : "CU", "placeholder" : "+53-_-___-____", "minLength" : 10, "shortMask" : "+53"])
    arr.append(["mask" : "+357-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.cy"), "code" : "CY", "placeholder" : "+357-__-___-___", "minLength" : 11, "shortMask" : "+357"])
    arr.append(["mask" : "+420({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.cz"), "code" : "CZ", "placeholder" : "+420(___)___-___", "minLength" : 12, "shortMask" : "+420"])
    arr.append(["mask" : "+49({ddd}){dd}-{dd}" as AnyObject, "label" : getStringByKey("country.de"), "code" : "DE", "placeholder" : "+49(__)__-__", "minLength" : 8, "shortMask" : "+49"])
    arr.append(["mask" : "+253-{dd}-{dd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.dj"), "code" : "DJ", "placeholder" : "+253-__-__-__-__", "minLength" : 11, "shortMask" : "+253"])
    arr.append(["mask" : "+45-{dd}-{dd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.dk"), "code" : "DK", "placeholder" : "+45-__-__-__-__", "minLength" : 10, "shortMask" : "+45"])
    arr.append(["mask" : "+1(767){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.dm"), "code" : "DM", "placeholder" : "+1(767)___-____", "minLength" : 11, "shortMask" : "+1(767)"])
    arr.append(["mask" : "+1({ddd}){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.do"), "code" : "DO", "placeholder" : "+1(___)___-____", "minLength" : 11, "shortMask" : "+1"])
    arr.append(["mask" : "+213-{dd}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.dz"), "code" : "DZ", "placeholder" : "+213-__-___-____", "minLength" : 12, "shortMask" : "+213"])
    arr.append(["mask" : "+593-{dd}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.ec"), "code" : "EC", "placeholder" : "+593-__-___-____", "minLength" : 11, "shortMask" : "+593"])
    arr.append(["mask" : "+372-{dddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.ee"), "code" : "EE", "placeholder" : "+372-____-____", "minLength" : 10, "shortMask" : "+372"])
    arr.append(["mask" : "+20({ddd}){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.eg"), "code" : "EG", "placeholder" : "+20(___)___-____", "minLength" : 12, "shortMask" : "+20"])
    arr.append(["mask" : "+34({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.es"), "code" : "ES", "placeholder" : "+34(___)___-___", "minLength" : 11, "shortMask" : "+34"])
    arr.append(["mask" : "+251-{dd}-{ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.et"), "code" : "ET", "placeholder" : "+251-__-___-____", "minLength" : 12, "shortMask" : "+251"])
    arr.append(["mask" : "+358({ddd}){ddd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.fi"), "code" : "FI", "placeholder" : "+358(___)___-__-__", "minLength" : 13, "shortMask" : "+358"])
    arr.append(["mask" : "+679-{dd}-{ddddd}" as AnyObject, "label" : getStringByKey("country.fj"), "code" : "FJ", "placeholder" : "+679-__-_____", "minLength" : 10, "shortMask" : "+679"])
    arr.append(["mask" : "+298-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.fo"), "code" : "FO", "placeholder" : "+298-___-___", "minLength" : 9, "shortMask" : "+298"])
    arr.append(["mask" : "+33({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.fr"), "code" : "FR", "placeholder" : "+33(___)___-___", "minLength" : 11, "shortMask" : "+33"])
    arr.append(["mask" : "+241-{d}-{dd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.ga"), "code" : "GA", "placeholder" : "+241-_-__-__-__", "minLength" : 10, "shortMask" : "+241"])
    arr.append(["mask" : "+1(473){ddd}-{dddd}" as AnyObject, "label" : getStringByKey("country.gd"), "code" : "GD", "placeholder" : "+1(473)___-____", "minLength" : 11, "shortMask" : "+1(473)"])
    arr.append(["mask" : "+995({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.ge"), "code" : "GE", "placeholder" : "+995(___)___-___", "minLength" : 12, "shortMask" : "+995"])
    arr.append(["mask" : "+233({ddd}){ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.gh"), "code" : "GH", "placeholder" : "+233(___)___-___", "minLength" : 12, "shortMask" : "+233"])
    arr.append(["mask" : "+350-{ddd}-{ddddd}" as AnyObject, "label" : getStringByKey("country.gi"), "code" : "GI", "placeholder" : "+350-___-_____", "minLength" : 11, "shortMask" : "+350"])
    arr.append(["mask" : "+299-{dd}-{dd}-{dd}" as AnyObject, "label" : getStringByKey("country.gl"), "code" : "GL", "placeholder" : "+299-__-__-__", "minLength" : 9, "shortMask" : "+299"])
    arr.append(["mask" : "+220({ddd}){dd}-{dd}" as AnyObject, "label" : getStringByKey("country.gm"), "code" : "GM", "placeholder" : "+220(___)__-__", "minLength" : 10, "shortMask" : "+220"])
    arr.append(["mask" : "+224-{dd}-{ddd}-{ddd}" as AnyObject, "label" : getStringByKey("country.gn"), "code" : "GN", "placeholder" : "+224-__-___-___", "minLength" : 11, "shortMask" : "+1"])
    arr.append(["mask" : "+30({ddd}){ddd}-{dddd}" as AnyObject,"placeholder":"+30(___)___-____" as AnyObject,"minLength":12 as AnyObject,"shortMask":"+30" as AnyObject,"label":getStringByKey("country.gr"),"code":"GR"])
    arr.append(["mask" : "+502-{d}-{ddd}-{dddd}" as AnyObject,"placeholder":"+502-_-___-____" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+502" as AnyObject,"label":getStringByKey("country.gt"),"code":"GT"])
    arr.append(["mask" : "+1(671){ddd}-{dddd}" as AnyObject,"placeholder":"+1(671)___-____" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+1(671)" as AnyObject,"label":getStringByKey("country.gu"),"code":"GU"])
    arr.append(["mask" : "+592-{ddd}-{dddd}" as AnyObject,"placeholder":"+592-___-____" as AnyObject,"minLength":10 as AnyObject,"shortMask":"+592" as AnyObject,"label":getStringByKey("country.gy"),"code":"GY"])
    arr.append(["mask" : "+852-{dddd}-{dddd}" as AnyObject,"placeholder":"+852-____-____" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+852" as AnyObject,"label":getStringByKey("country.hk"),"code":"HK"])
    arr.append(["mask" : "+504-{dddd}-{dddd}" as AnyObject,"placeholder":"+504-____-____" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+504" as AnyObject,"label":getStringByKey("country.hn"),"code":"HN"])
    arr.append(["mask" : "+509-{dd}-{dd}-{dddd}" as AnyObject,"placeholder":"+509-__-__-____" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+509" as AnyObject,"label":getStringByKey("country.ht"),"code":"HT"])
    arr.append(["mask" : "+36({ddd}){ddd}-{ddd}" as AnyObject,"placeholder":"+36(___)___-___" as AnyObject,"minLength":11 as AnyObject,"shortMask":"+36" as AnyObject,"label":getStringByKey("country.hu"),"code":"HU"])
    arr.append(["mask" : "+62-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder":"+62-__-___-___" as AnyObject,"minLength":10 as AnyObject,"shortMask":"+62" as AnyObject,"label":getStringByKey("country.id"),"code":"ID"])
    arr.append(["mask" : "+353({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+353(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+353" as AnyObject,"label" : getStringByKey("country.ie"),"code" : "IE"])
    arr.append(["mask" : "+972-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+972-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+972" as AnyObject,"label" : getStringByKey("country.il"),"code" : "IL"])
    arr.append(["mask" : "+91({dddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+91(____)___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+91" as AnyObject,"label" : getStringByKey("country.in"),"code" : "IN"])
    arr.append(["mask" : "+964({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+964(___)___-____" as AnyObject,"minLength" : 13 as AnyObject,"shortMask" : "+964" as AnyObject,"label" : getStringByKey("country.iq"),"code" : "IQ"])
    arr.append(["mask" : "+98({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+98(___)___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+98" as AnyObject,"label" : getStringByKey("country.ir"),"code" : "IR"])
    arr.append(["mask" : "+354-{ddd}-{dddd}" as AnyObject,"placeholder" : "+354-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+354" as AnyObject,"label" : getStringByKey("country.is"),"code" : "IS"])
    arr.append(["mask" : "+39({ddd}){dddd}-{ddd}" as AnyObject,"placeholder" : "+39(___)____-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+39" as AnyObject,"label" : getStringByKey("country.it"),"code" : "IT"])
    arr.append(["mask" : "+1(876){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(876)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(876)" as AnyObject,"label" : getStringByKey("country.jm"),"code" : "JM"])
    arr.append(["mask" : "+962-{d}-{dddd}-{dddd}" as AnyObject,"placeholder" : "+962-_-____-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+962" as AnyObject,"label" : getStringByKey("country.jo"),"code" : "JO"])
    arr.append(["mask" : "+81-{dd}-{dddd}-{dddd}" as AnyObject,"placeholder" : "+81-__-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+81" as AnyObject,"label" : getStringByKey("country.jp"),"code" : "JP"])
    arr.append(["mask" : "+254-{ddd}-{ddddd}d" as AnyObject,"placeholder" : "+254-___-______" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+254" as AnyObject,"label" : getStringByKey("country.ke"),"code" : "KE"])
    arr.append(["mask" : "+996({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+996(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+996" as AnyObject,"label" : getStringByKey("country.kg"),"code" : "KG"])
    arr.append(["mask" : "+855-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+855-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+855" as AnyObject,"label" : getStringByKey("country.kh"),"code" : "KH"])
    arr.append(["mask" : "+686-{dd}-{ddd}" as AnyObject,"placeholder" : "+686-__-___" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+686" as AnyObject,"label" : getStringByKey("country.ki"),"code" : "KI"])
    arr.append(["mask" : "+269-{dd}-{ddddd}" as AnyObject,"placeholder" : "+269-__-_____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+269" as AnyObject,"label" : getStringByKey("country.km"),"code" : "KM"])
    arr.append(["mask" : "+850-{dddd}-{ddddd}dddddddd" as AnyObject,"placeholder" : "+850-____-_____________" as AnyObject,"minLength" : 9 as AnyObject,"shortMask" : "+850" as AnyObject,"label" : getStringByKey("country.kp"),"code" : "KP"])
    arr.append(["mask" : "+82-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+82-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+82" as AnyObject,"label" : getStringByKey("country.kr"),"code" : "KR"])
    arr.append(["mask" : "+965-{dddd}-{dddd}" as AnyObject,"placeholder" : "+965-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+965" as AnyObject,"label" : getStringByKey("country.kw"),"code" : "KW"])
    arr.append(["mask" : "+1(345){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(345)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(345)" as AnyObject,"label" : getStringByKey("country.ky"),"code" : "KY"])
    arr.append(["mask" : "+7({ddd}){ddd}-{dd}-{dd}" as AnyObject,"placeholder" : "+7(___)___-__-__" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+7" as AnyObject,"label" : getStringByKey("country.kz"),"code" : "KZ"])
    arr.append(["mask" : "+856({dddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+856(____)___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+856" as AnyObject,"label" : getStringByKey("country.la"),"code" : "LA"])
    arr.append(["mask" : "+961-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+961-__-___-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+961" as AnyObject,"label" : getStringByKey("country.lb"),"code" : "LB"])
    arr.append(["mask" : "+1(758){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(758)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(758)" as AnyObject,"label" : getStringByKey("country.lc"),"code" : "LC"])
    arr.append(["mask" : "+423({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+423(___)___-____" as AnyObject,"minLength" : 13 as AnyObject,"shortMask" : "+423" as AnyObject,"label" : getStringByKey("country.li"),"code" : "LI"])
    arr.append(["mask" : "+94-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+94-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+94" as AnyObject,"label" : getStringByKey("country.lk"),"code" : "LK"])
    arr.append(["mask" : "+231-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+231-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+231" as AnyObject,"label" : getStringByKey("country.lr"),"code" : "LR"])
    arr.append(["mask" : "+370({ddd}){dd}-{ddd}" as AnyObject,"placeholder" : "+370(___)__-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+370" as AnyObject,"label" : getStringByKey("country.lt"),"code" : "LT"])
    arr.append(["mask" : "+352({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+352(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+352" as AnyObject,"label" : getStringByKey("country.lu"),"code" : "LU"])
    arr.append(["mask" : "+371-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+371-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+371" as AnyObject,"label" : getStringByKey("country.lv"),"code" : "LV"])
    arr.append(["mask" : "+218-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+218-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+218" as AnyObject,"label" : getStringByKey("country.ly"),"code" : "LY"])
    arr.append(["mask" : "+212-{dd}-{dddd}-{ddd}" as AnyObject,"placeholder" : "+212-__-____-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+212" as AnyObject,"label" : getStringByKey("country.ma"),"code" : "MA"])
    arr.append(["mask" : "+377-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+377-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+377" as AnyObject,"label" : getStringByKey("country.mc"),"code" : "MC"])
    arr.append(["mask" : "+373-{dddd}-{dddd}" as AnyObject,"placeholder" : "+373-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+373" as AnyObject,"label" : getStringByKey("country.md"),"code" : "MD"])
    arr.append(["mask" : "+382-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+382-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+382" as AnyObject,"label" : getStringByKey("country.me"),"code" : "ME"])
    arr.append(["mask" : "+261-{dd}-{dd}-{ddddd}" as AnyObject,"placeholder" : "+261-__-__-_____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+261" as AnyObject,"label" : getStringByKey("country.mg"),"code" : "MG"])
    arr.append(["mask" : "+692-{ddd}-{dddd}" as AnyObject,"placeholder" : "+692-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+692" as AnyObject,"label" : getStringByKey("country.mh"),"code" : "MH"])
    arr.append(["mask" : "+389-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+389-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+389" as AnyObject,"label" : getStringByKey("country.mk"),"code" : "MK"])
    arr.append(["mask" : "+223-{dd}-{dd}-{dddd}" as AnyObject,"placeholder" : "+223-__-__-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+223" as AnyObject,"label" : getStringByKey("country.ml"),"code" : "ML"])
    arr.append(["mask" : "+95-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+95-__-___-___" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+95" as AnyObject,"label" : getStringByKey("country.mm"),"code" : "MM"])
    arr.append(["mask" : "+976-{dd}-{dd}-{dddd}" as AnyObject,"placeholder" : "+976-__-__-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+976" as AnyObject,"label" : getStringByKey("country.mn"),"code" : "MN"])
    arr.append(["mask" : "+853-{dddd}-{dddd}" as AnyObject,"placeholder" : "+853-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+853" as AnyObject,"label" : getStringByKey("country.mo"),"code" : "MO"])
    arr.append(["mask" : "+596({ddd}){dd}-{dd}-{dd}" as AnyObject,"placeholder" : "+596(___)__-__-__" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+596" as AnyObject,"label" : getStringByKey("country.mq"),"code" : "MQ"])
    arr.append(["mask" : "+222-{dd}-{dd}-{dddd}" as AnyObject,"placeholder" : "+222-__-__-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+222" as AnyObject,"label" : getStringByKey("country.mr"),"code" : "MR"])
    arr.append(["mask" : "+1(664){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(664)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(664)" as AnyObject,"label" : getStringByKey("country.ms"),"code" : "MS"])
    arr.append(["mask" : "+356-{dddd}-{dddd}" as AnyObject,"placeholder" : "+356-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+356" as AnyObject,"label" : getStringByKey("country.mt"),"code" : "MT"])
    arr.append(["mask" : "+230-{ddd}-{dddd}" as AnyObject,"placeholder" : "+230-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+230" as AnyObject,"label" : getStringByKey("country.mu"),"code" : "MU"])
    arr.append(["mask" : "+960-{ddd}-{dddd}" as AnyObject,"placeholder" : "+960-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+960" as AnyObject,"label" : getStringByKey("country.mv"),"code" : "MV"])
    arr.append(["mask" : "+265-{d}-{dddd}-{dddd}" as AnyObject,"placeholder" : "+265-_-____-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+265" as AnyObject,"label" : getStringByKey("country.mw"),"code" : "MW"])
    arr.append(["mask" : "+52({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+52(___)___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+52" as AnyObject,"label" : getStringByKey("country.mx"),"code" : "MX"])
    arr.append(["mask" : "+60-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+60-__-___-____" as AnyObject,"minLength" : 9 as AnyObject,"shortMask" : "+60" as AnyObject,"label" : getStringByKey("country.my"),"code" : "MY"])
    arr.append(["mask" : "+258-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+258-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+258" as AnyObject,"label" : getStringByKey("country.mz"),"code" : "MZ"])
    arr.append(["mask" : "+264-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+264-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+264" as AnyObject,"label" : getStringByKey("country.na"),"code" : "NA"])
    arr.append(["mask" : "+227-{dd}-{dd}-{dddd}" as AnyObject,"placeholder" : "+227-__-__-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+227" as AnyObject,"label" : getStringByKey("country.ne"),"code" : "NE"])
    arr.append(["mask" : "+234({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+234(___)___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+234" as AnyObject,"label" : getStringByKey("country.ng"),"code" : "NG"])
    arr.append(["mask" : "+505-{dddd}-{dddd}" as AnyObject,"placeholder" : "+505-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+505" as AnyObject,"label" : getStringByKey("country.ni"),"code" : "NI"])
    arr.append(["mask" : "+31-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+31-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+31" as AnyObject,"label" : getStringByKey("country.nl"),"code" : "NL"])
    arr.append(["mask" : "+47({ddd}){dd}-{ddd}" as AnyObject,"placeholder" : "+47(___)__-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+47" as AnyObject,"label" : getStringByKey("country.no"),"code" : "NO"])
    arr.append(["mask" : "+977-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+977-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+977" as AnyObject,"label" : getStringByKey("country.np"),"code" : "NP"])
    arr.append(["mask" : "+674-{ddd}-{dddd}" as AnyObject,"placeholder" : "+674-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+674" as AnyObject,"label" : getStringByKey("country.nr"),"code" : "NR"])
    arr.append(["mask" : "+683-{dddd}" as AnyObject,"placeholder" : "+683-____" as AnyObject,"minLength" : 7 as AnyObject,"shortMask" : "+683" as AnyObject,"label" : getStringByKey("country.nu"),"code" : "NU"])
    arr.append(["mask" : "+64-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+64-__-___-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+64" as AnyObject,"label" : getStringByKey("country.nz"),"code" : "NZ"])
    arr.append(["mask" : "+968-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+968-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+968" as AnyObject,"label" : getStringByKey("country.om"),"code" : "OM"])
    arr.append(["mask" : "+507-{ddd}-{dddd}" as AnyObject,"placeholder" : "+507-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+507" as AnyObject,"label" : getStringByKey("country.pa"),"code" : "PA"])
    arr.append(["mask" : "+51({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+51(___)___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+51" as AnyObject,"label" : getStringByKey("country.pe"),"code" : "PE"])
    arr.append(["mask" : "+689-{dd}-{dd}-{dd}" as AnyObject,"placeholder" : "+689-__-__-__" as AnyObject,"minLength" : 9 as AnyObject,"shortMask" : "+689" as AnyObject,"label" : getStringByKey("country.pf"),"code" : "PF"])
    arr.append(["mask" : "+675({ddd}){dd}-{ddd}" as AnyObject,"placeholder" : "+675(___)__-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+675" as AnyObject,"label" : getStringByKey("country.pg"),"code" : "PG"])
    arr.append(["mask" : "+63({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+63(___)___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+63" as AnyObject,"label" : getStringByKey("country.ph"),"code" : "PH"])
    arr.append(["mask" : "+92({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+92(___)___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+92" as AnyObject,"label" : getStringByKey("country.pk"),"code" : "PK"])
    arr.append(["mask" : "+48({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+48(___)___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+48" as AnyObject,"label" : getStringByKey("country.pl"),"code" : "PL"])
    arr.append(["mask" : "+970-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+970-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+970" as AnyObject,"label" : getStringByKey("country.ps"),"code" : "PS"])
    arr.append(["mask" : "+351-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+351-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+351" as AnyObject,"label" : getStringByKey("country.pt"),"code" : "PT"])
    arr.append(["mask" : "+680-{ddd}-{dddd}" as AnyObject,"placeholder" : "+680-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+680" as AnyObject,"label" : getStringByKey("country.pw"),"code" : "PW"])
    arr.append(["mask" : "+974-{dddd}-{dddd}" as AnyObject,"placeholder" : "+974-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+974" as AnyObject,"label" : getStringByKey("country.qa"),"code" : "QA"])
    arr.append(["mask" : "+262-{ddddd}-{dddd}" as AnyObject,"placeholder" : "+262-_____-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+262" as AnyObject,"label" : getStringByKey("country.re"),"code" : "RE"])
    arr.append(["mask" : "+40-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+40-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+40" as AnyObject,"label" : getStringByKey("country.ro"),"code" : "RO"])
    arr.append(["mask" : "+381-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+381-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+381" as AnyObject,"label" : getStringByKey("country.rs"),"code" : "RS"])
    arr.append(["mask" : "+7({ddd}){ddd}-{dd}-{dd}" as AnyObject,"placeholder" : "+7(___)___-__-__" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+7" as AnyObject,"label" : getStringByKey("country.ru"),"code" : "RU"])
    arr.append(["mask" : "+250({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+250(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+250" as AnyObject,"label" : getStringByKey("country.rw"),"code" : "RW"])
    arr.append(["mask" : "+966-{d}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+966-_-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+966" as AnyObject,"label" : getStringByKey("country.sa"),"code" : "SA"])
    arr.append(["mask" : "+677-{ddd}-{dddd}" as AnyObject,"placeholder" : "+677-___-____" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+677" as AnyObject,"label" : getStringByKey("country.sb"),"code" : "SB"])
    arr.append(["mask" : "+248-{d}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+248-_-___-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+248" as AnyObject,"label" : getStringByKey("country.sc"),"code" : "SC"])
    arr.append(["mask" : "+249-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+249-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+249" as AnyObject,"label" : getStringByKey("country.sd"),"code" : "SD"])
    arr.append(["mask" : "+46-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+46-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+46" as AnyObject,"label" : getStringByKey("country.se"),"code" : "SE"])
    arr.append(["mask" : "+65-{dddd}-{dddd}" as AnyObject,"placeholder" : "+65-____-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+65" as AnyObject,"label" : getStringByKey("country.sg"),"code" : "SG"])
    arr.append(["mask" : "+290-{dddd}" as AnyObject,"placeholder" : "+290-____" as AnyObject,"minLength" : 7 as AnyObject,"shortMask" : "+290" as AnyObject,"label" : getStringByKey("country.sh"),"code" : "SH"])
    arr.append(["mask" : "+386-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+386-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+386" as AnyObject,"label" : getStringByKey("country.si"),"code" : "SI"])
    arr.append(["mask" : "+421({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+421(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+421" as AnyObject,"label" : getStringByKey("country.sk"),"code" : "SK"])
    arr.append(["mask" : "+232-{dd}-{ddddd}d" as AnyObject,"placeholder" : "+232-__-______" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+232" as AnyObject,"label" : getStringByKey("country.sl"),"code" : "SL"])
    arr.append(["mask" : "+378-{dddd}-{ddddd}d" as AnyObject,"placeholder" : "+378-____-______" as AnyObject,"minLength" : 13 as AnyObject,"shortMask" : "+378" as AnyObject,"label" : getStringByKey("country.sm"),"code" : "SM"])
    arr.append(["mask" : "+221-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+221-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+221" as AnyObject,"label" : getStringByKey("country.sn"),"code" : "SN"])
    arr.append(["mask" : "+252-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+252-__-___-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+252" as AnyObject,"label" : getStringByKey("country.so"),"code" : "SO"])
    arr.append(["mask" : "+597-{ddd}-{dddd}" as AnyObject,"placeholder" : "+597-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+597" as AnyObject,"label" : getStringByKey("country.sr"),"code" : "SR"])
    arr.append(["mask" : "+597-{ddd}-{ddd}" as AnyObject,"placeholder" : "+597-___-___" as AnyObject,"minLength" : 9 as AnyObject,"shortMask" : "+597" as AnyObject,"label" : getStringByKey("country.sr"),"code" : "SR"])
    arr.append(["mask" : "+211-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+211-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+211" as AnyObject,"label" : getStringByKey("country.ss"),"code" : "SS"])
    arr.append(["mask" : "+503-{dd}-{dd}-{dddd}" as AnyObject,"placeholder" : "+503-__-__-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+503" as AnyObject,"label" : getStringByKey("country.sv"),"code" : "SV"])
    arr.append(["mask" : "+1(721){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(721)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1" as AnyObject,"label" : getStringByKey("country.sx"),"code" : "SX"])
    arr.append(["mask" : "+235-{dd}-{dd}-{dd}-{dd}" as AnyObject,"placeholder" : "+235-__-__-__-__" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+235" as AnyObject,"label" : getStringByKey("country.td"),"code" : "TD"])
    arr.append(["mask" : "+228-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+228-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+228" as AnyObject,"label" : getStringByKey("country.tg"),"code" : "TG"])
    arr.append(["mask" : "+66-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+66-__-___-____" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+66" as AnyObject,"label" : getStringByKey("country.th"),"code" : "TH"])
    arr.append(["mask" : "+992-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+992-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+992" as AnyObject,"label" : getStringByKey("country.tj"),"code" : "TJ"])
    arr.append(["mask" : "+993-{d}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+993-_-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+993" as AnyObject,"label" : getStringByKey("country.tk"),"code" : "TM"])
    arr.append(["mask" : "+216-{dd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+216-__-___-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+216" as AnyObject,"label" : getStringByKey("country.tn"),"code" : "TN"])
    arr.append(["mask" : "+676-{ddddd}" as AnyObject,"placeholder" : "+676-_____" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+676" as AnyObject,"label" : getStringByKey("country.to"),"code" : "TO"])
    arr.append(["mask" : "+90({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+90(___)___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+90" as AnyObject,"label" : getStringByKey("country.tr"),"code" : "TR"])
    arr.append(["mask" : "+1(868){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(868)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(868)" as AnyObject,"label" : getStringByKey("country.tt"),"code" : "TT"])
    arr.append(["mask" : "+688-2dddd" as AnyObject,"placeholder" : "+688-2____" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+688" as AnyObject,"label" : getStringByKey("country.tv"),"code" : "TV"])
    arr.append(["mask" : "+886-{d}-{dddd}-{dddd}" as AnyObject,"placeholder" : "+886-_-____-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+886" as AnyObject,"label" : getStringByKey("country.tw"),"code" : "TW"])
    arr.append(["mask" : "+255-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+255-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+255" as AnyObject,"label" : getStringByKey("country.tz"),"code" : "TZ"])
    arr.append(["mask" : "+380({dd}){ddd}-{dd}-{dd}" as AnyObject,"placeholder" : "+380(__)___-__-__" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+380" as AnyObject,"label" : getStringByKey("country.ua"),"code" : "UA"])
    arr.append(["mask" : "+256({ddd}){ddd}-{ddd}" as AnyObject,"placeholder" : "+256(___)___-___" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+256" as AnyObject,"label" : getStringByKey("country.ug"),"code" : "UG"])
    arr.append(["mask" : "+44-{dd}-{dddd}-{dddd}" as AnyObject,"placeholder" : "+44-__-____-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+44" as AnyObject,"label" : getStringByKey("country.uk"),"code" : "UK"])
    arr.append(["mask" : "+998-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+998-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+998" as AnyObject,"label" : getStringByKey("country.uz"),"code" : "UZ"])
    arr.append(["mask" : "+39-6-698-{ddddd}" as AnyObject,"placeholder" : "+39-6-698-_____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+39" as AnyObject,"label" : getStringByKey("country.va"),"code" : "VA"])
    arr.append(["mask" : "+58({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+58(___)___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+58" as AnyObject,"label" : getStringByKey("country.ve"),"code" : "VE"])
    arr.append(["mask" : "+1(284){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(284)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(284)" as AnyObject,"label" : getStringByKey("country.vg"),"code" : "VG"])
    arr.append(["mask" : "+1(340){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(340)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1(340)" as AnyObject,"label" : getStringByKey("country.vi"),"code" : "VI"])
    arr.append(["mask" : "+84({ddd}){dddd}-{ddd}" as AnyObject,"placeholder" : "+84(___)____-___" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+84" as AnyObject,"label" : getStringByKey("country.vn"),"code" : "VN"])
    arr.append(["mask" : "+678-{dd}-{ddddd}" as AnyObject,"placeholder" : "+678-__-_____" as AnyObject,"minLength" : 8 as AnyObject,"shortMask" : "+678" as AnyObject,"label" : getStringByKey("country.vu"),"code" : "VU"])
    arr.append(["mask" : "+685-{dd}-{dddd}" as AnyObject,"placeholder" : "+685-__-____" as AnyObject,"minLength" : 9 as AnyObject,"shortMask" : "+685" as AnyObject,"label" : getStringByKey("country.ws"),"code" : "WS"])
    arr.append(["mask" : "+967-{ddd}-{ddd}-{ddd}" as AnyObject,"placeholder" : "+967-___-___-___" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+967" as AnyObject,"label" : getStringByKey("country.ye"),"code" : "YE"])
    arr.append(["mask" : "+27-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+27-__-___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+27" as AnyObject,"label" : getStringByKey("country.za"),"code" : "ZA"])
    arr.append(["mask" : "+260-{dd}-{ddd}-{dddd}" as AnyObject,"placeholder" : "+260-__-___-____" as AnyObject,"minLength" : 12 as AnyObject,"shortMask" : "+260" as AnyObject,"label" : getStringByKey("country.zm"),"code" : "ZM"])
    arr.append(["mask" : "+263-{d}-{ddddd}" as AnyObject,"placeholder" : "+263-_-______" as AnyObject,"minLength" : 10 as AnyObject,"shortMask" : "+263" as AnyObject,"label" : getStringByKey("country.zw"),"code" : "ZW"])
    arr.append(["mask" : "+1({ddd}){ddd}-{dddd}" as AnyObject,"placeholder" : "+1(___)___-____" as AnyObject,"minLength" : 11 as AnyObject,"shortMask" : "+1" as AnyObject,"label" : getStringByKey("country.us"),"code" : "US"])
    return arr
}

func indexes() -> [String]
{
    var arr : [String] = []
    
    let fullList = countryList()
    
    for dict in fullList {
        var have : Bool = false
        for str:String in arr {
            if ((dict["label"] as! NSString).substring(to: 1) == str) {
                have = true
            }
        }
        if !have {
            arr.append((dict["label"] as! NSString).substring(to: 1))
        }
    }
    return arr.sorted()
}

func countryByIndexes() -> [String: [[String: Any]]]
{
    let indexesList = indexes()
    let fullList = countryList()
    var forRet: [String: [[String: Any]]] = [:]
    for index:String in indexesList {
        var cntrysForIndex : [[String: Any]] = []
        
        for dict in fullList {
            if ((dict["label"] as! NSString).substring(to: 1) == index) {
                cntrysForIndex.append(dict)
            }
        }
        forRet[index] = cntrysForIndex
    }
    return forRet
}


