//
//  CallCostHelper.swift
//  Client
//
//  Created by Dmitriy Kudrin on 16.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation


class CallCost : NSObject, NSCoding {
    var distance : Double?
    var cost : Double?
    var time : Double?
    var isFixed : Bool?
    
    override init() // если значение какое-то отрицательное - не нужно его выводить и вообще обращать внимания. И в целом, если nil - то плохо это все говно хранить в БД, => приходится использовать отрицательные значения
    {
        distance = -1
        cost = -1
        time = -1
        isFixed = false
    }
    
    // нужно для того, чтобы можно было хранить в БД и в userDefaults
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.distance = decoder.decodeObject(forKey: "distance") as? Double
        self.cost = decoder.decodeObject(forKey: "cost") as? Double
        self.time = decoder.decodeObject(forKey: "time") as? Double
        self.isFixed = decoder.decodeObject(forKey: "isFixed") as? Bool
    }
    
    func encode(with withcoder: NSCoder) {
        withcoder.encode(self.distance, forKey: "distance")
        withcoder.encode(self.cost, forKey: "cost")
        withcoder.encode(self.time, forKey: "time")
        withcoder.encode(self.isFixed, forKey: "isFixed")
    }
    
}


func callCostForOrder(ord:OrderTemp, completion: @escaping (_ ccost: CallCost) -> Void)
{
    gxCallCostFromOrder(order: ord, completion: { (cost) -> Void in
        completion(cost)
    })
}


//MARK: Gootax

func gxCallCostFromOrder(order : OrderTemp, completion: @escaping (_ ccost: CallCost) -> Void)
{
    gxDoPOST(kGxApiCreateOrder, params: gxDictionaryFromOrder(order: order), completion: { (result) -> Void in
        if result is [String: Any] {
            completion(gxParseCallCost(arr: result as! [String: Any]))
        }
    }) { (error) -> Void in
    }
    
    
}

func gxParseCallCost(arr : [String: Any]) -> CallCost {
    let callCost = CallCost()
    
    if let result = arr["result"] as? [String: Any] {
        if let costResult = result["cost_result"] as? [String: Any] {
            callCost.cost = Double(costResult["summary_cost"] as? String ?? "0")
            callCost.distance = Double(costResult["summary_distance"] as? String ?? "0")
            callCost.time = Double(costResult["summary_time"] as? String ?? "0")
            callCost.isFixed = parseBool(costResult["is_fix"] ?? false)
        }
    }
    return callCost
}


func gxDictionaryFromOrder(order : OrderTemp) -> Dictionary<String, String>
{
    var dict = Dictionary<String, String>()
    dict["address"] = gxStringAddrFromOrder(order: order)
    dict["type_request"] = "2"
    dict["device_token"] = deviceToken()
    dict["city_id"] = curCity().cityID
    dict["client_phone"] = profile().phone
    dict["company_id"] = curTenant()
    dict["tariff_id"] = order.orderTariff?.tariffID
    dict["client_id"] = profile().clientID
    dict["client_name"] = profile().firstName
    dict["pay_type"] = order.payType
    dict["comment"] = order.comment
    if order.orderTime != nil {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy HH:mm:ss"
        dict["order_time"] = formatter.string(from: order.orderTime!)
    }
    if order.orderWishes != nil {
        if (order.orderWishes?.count)! > 0 {
            var wishes = ""
            for wish in order.orderWishes! {
                if wish.tariffId! == order.orderTariff?.tariffID! {
                    if wishes == "" {
                        wishes = wish.optionId!
                    }
                    else {
                        wishes = "\(wishes),\(wish.optionId!)"
                    }
                }
            }
            dict["additional_options"] = wishes
        }
    }
    return dict
}

func gxStringAddrFromOrder(order : OrderTemp) -> String
{
    var dict : [String: Any] = [String: Any]()
    
    var addresses : [[String: Any]] = [[String: Any]]()
    
    if order.pathA != nil {
        addresses.append(gxDictFromAddress(address: order.pathA!))
    }
    if order.pathB != nil {
        addresses.append(gxDictFromAddress(address: order.pathB!))
    }
    if order.pathC != nil {
        addresses.append(gxDictFromAddress(address: order.pathC!))
    }
    if order.pathD != nil {
        addresses.append(gxDictFromAddress(address: order.pathD!))
    }
    if order.pathE != nil {
        addresses.append(gxDictFromAddress(address: order.pathE!))
    }
    
    dict["address"] = addresses
    
    let str : NSData = try! JSONSerialization.data(withJSONObject: dict as Any, options: JSONSerialization.WritingOptions.prettyPrinted) as NSData
    let resStr = CFURLCreateStringByAddingPercentEscapes(
        nil,
        NSString(data: str as Data, encoding: String.Encoding.utf8.rawValue) as CFString!,
        nil,
        "!*'();:@&=+$,/?%#[]\" " as CFString!,
        CFStringBuiltInEncodings.UTF8.rawValue) as String
    
    
    var result =  resStr.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    result = result.replacingOccurrences(of: "%2F", with: "%5C")
    result = result.replacingOccurrences(of: "%5C%5C", with: "%2F%2F")
    //    print(result)
    return result
    
}

func gxDictFromAddress(address : AddressTemp) -> [String: Any]
{
    var dict : [String: Any] = [String: Any]()
    
    if address.cityID != nil {
        if address.cityID != "" {
            dict["city_id"] = address.cityID
        }
    }
    if address.city != nil {
        if address.city != "" {
            dict["city"] = address.city
        }
    }
    if address.street != nil {
        if address.street != "" {
            if address.publicPlace == true {
                dict["street"] = address.shortStrFromTempAddress()
            }
            else {
                dict["street"] = address.street
            }
        }
        else {
            if address.label != "" {
                dict["street"] = address.label
            }
        }
    }
    
    if address.house != nil {
        if address.house != "" {
            dict["house"] = address.house
        }
    }
    if address.housing != nil {
        if address.housing != "" {
            dict["housing"] = address.housing
        }
    }
    if address.porch != nil {
        if address.porch != "" {
            dict["porch"] = address.porch
        }
    }
    if address.flat != nil {
        if address.flat != "" {
            dict["apt"] = address.flat
        }
    }
    if address.lat != nil {
        if address.lat != 0 {
            dict["lat"] = String(format: "%f", address.lat!)
        }
    }
    if address.lon != nil {
        if address.lon != 0 {
            dict["lon"] = String(format: "%f", address.lon!)
        }
    }
    if dict["street"] == nil {
        dict["street"] = strComOrdByCoords()
    }
    return dict
}
