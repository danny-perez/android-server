//
//  Strings.swift
//  Client
//
//  Created by Dmitriy Kudrin on 22.06.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

func getStringByKey(_ key : String) -> String
{
    let path = Bundle.main.path(forResource: selLan(), ofType: "lproj")
        ?? Bundle.main.path(forResource: defaultLanguage, ofType: "lproj")
    let bundle = Bundle(path: path!)
    return  (bundle?.localizedString(forKey: key, value: nil, table: nil))!
}

func showMessage(_ title: String, message: String) {
    let aView = UIAlertView()
    aView.title = title
    aView.message = message
    aView.addButton(withTitle: strComNotificationClose())
    aView.cancelButtonIndex = 0
    aView.show()
}


func showMessageWithAction(_ title: String, message: String, action: String, actionHandler: @escaping () -> Void) {
    let alert = UIAlertController(title: title , message: message, preferredStyle: .alert)
    
    alert.addAction(UIAlertAction(title: strComExit(), style: .default, handler: { (action) -> Void in
        exit(0)
    }))
    alert.addAction(UIAlertAction(title: action, style: .default, handler: { (action) -> Void in
        actionHandler()
    }))
    UIApplication.shared.delegate!.window!!.rootViewController!.present(alert, animated: true, completion: nil)
}


func selLan() -> String {
    let defaults : UserDefaults = UserDefaults.standard;
    
    if (defaults.object(forKey: udefCurLan) == nil) {
        defaults.set(defaultLanguage, forKey: udefCurLan)
    }
    var language = defaults.string(forKey: udefCurLan)
    if language == "me" {
        language = "sr-ME"
    }
    return language!
}

func selectedLan() -> String
{
    let defaults : UserDefaults = UserDefaults.standard
    
    if let curLang = defaults.string(forKey: udefCurLan) {
        switch curLang {
        case "en":
            return lanEnglish()
        case "ru":
            return lanRu()
        case "az":
            return lanAz()
        case "fa":
            return lanFa()
        case "sr":
            return lanSerb()
        case "tk":
            return lanTk()
        case "uz":
            return lanUz()
        case "sr-ME":
            return lanMe()
        case "me":
            return lanMe()
        case "de":
            return lanDe()
        case "it":
            return lanIt()
        case "ka":
            return lanKa()
        case "ar":
            return lanAr()
        case "uz-Latn":
            return lanOr()
        default:
            return lanEnglish()
        }
    }
    return lanEnglish()
}


func languagesArray() -> [[String: String]] {
    var langs: [[String: String]] = []
    for lang in supportedLang {
        if let code = lang["code"] {
            if languages.contains(code) {
                langs.append(lang)
            }
        }
    }
    return langs
}


func mapsArray() -> [Dictionary<String, AnyObject>] {
    return [["code" : 0 as AnyObject,
             "title" : strMapOsm() as AnyObject],
            ["code" : 1 as AnyObject,
             "title" : strMapGoogle() as AnyObject],
            ["code" : 2 as AnyObject,
             "title" : strMapGis() as AnyObject]];
}

func calendarArray() -> [String] {
    return [strCalndarGregorian(), strCalndarPersian()] // TODO Strings
}


func countMaps() -> Int {
    let value = NSNumber(value: needOSMMap as Bool).intValue
        + NSNumber(value: needGoogleMapNormal as Bool).intValue
        + NSNumber(value: needGoogleMapHybrid as Bool).intValue
        + NSNumber(value: needGisMap as Bool).intValue
    return value
}

func strComPromoCode() -> String
{
    return getStringByKey("common.promoCode")
}

func strNoteEnterPromoCode() -> String
{
    return getStringByKey("note.enterPromoCode")
}

func strNotePickSecondAddr() -> String
{
    return getStringByKey("note.pickSecondAddress")
}

func strAlertButtonCheckCode() -> String
{
    return getStringByKey("alertBtn.checkCode")
}

func strLeftPay() -> String
{
    return getStringByKey("left.pay")
}


func strLeftInfo() -> String
{
    return getStringByKey("left.info")
}

func strLeftOrders() -> String
{
    return getStringByKey("left.orders")
}

func strLeftPreOrders() -> String
{
    return getStringByKey("left.preorders")
}


func strLeftMyAddresses() -> String
{
    return getStringByKey("left.myAddresses")
}

func strLeftNews() -> String
{
    return getStringByKey("left.news")
}

func strLeftSettings() -> String
{
    return getStringByKey("left.settings")
}

func strLeftAbout() -> String
{
    return getStringByKey("left.about")
}

func strLeftLogin() -> String
{
    return getStringByKey("left.login")
}

func strLeftRegister() -> String
{
    return getStringByKey("left.register")
}


func strTabBarNewOrder() -> String
{
    return getStringByKey("tabbar.newOrder")
}

func strTabBarMyOrders() -> String
{
    return getStringByKey("tabbar.history")
}

func strTabBarProfile() -> String
{
    return getStringByKey("tabbar.profile")
}

func strTabBarAboutUs() -> String
{
    return getStringByKey("tabbar.about")
}

func strSchemeStandart() -> String
{
    return getStringByKey("colorScheme.default")
}

func strCalndarTitle() -> String
{
    return getStringByKey("common.calendarTitle")
}

func strCalndarGregorian() -> String
{
    return getStringByKey("common.gregorian")
}

func strCalndarPersian() -> String
{
    return getStringByKey("common.persian")
}


func strSchemeDark() -> String
{
    return getStringByKey("colorScheme.dark")
}

func strAuthGetCode() -> String
{
    return getStringByKey("auth.getCode")
}

func strAuthNeed() -> String
{
    return getStringByKey("auth.needAuth")
}

func strRefCopyBuffer() -> String
{
    return getStringByKey("referral.copyInBuffer")
}

func strRefShare() -> String
{
    return getStringByKey("referral.share")
}


func strComPaymentCard() -> String
{
    return getStringByKey("common.paymentCard")
}


func strRefCopy() -> String
{
    return getStringByKey("referral.copy")
}
func strRefInfo() -> String
{
    return getStringByKey("referral.info")
}

func strRefActivatedSuccess() -> String
{
    return getStringByKey("referral.activatedSuccess")
}

func strRefErrActivated() -> String
{
    return getStringByKey("referral.referralErrActivated")
}

func strRefNotFound() -> String
{
    return getStringByKey("err.referralNotFound")
}

func strBonusLow() -> String
{
    return getStringByKey("pay.noBonus")
}


func strComAt() -> String
{
    return getStringByKey("common.at")
}

func strAuthLogin() -> String
{
    return getStringByKey("auth.login")
}

func strComClientWait() -> String
{
    return getStringByKey("common.clientWait")
}

func strComAirports() -> String
{
    return getStringByKey("common.airports")
}

func strComNotificationTitle() -> String
{
    return getStringByKey("common.alertNotificationTitle")
}

func strComNotificationWishes() -> String
{
    return getStringByKey("common.alertNotificationWishes")
}

func strComNotificationClose() -> String
{
    return getStringByKey("common.alertNotificationButtonClose")
}

func strErrRejected() -> String
{
    return getStringByKey("common.errorRejected")
}

func strErrCompleted() -> String
{
    return getStringByKey("common.errorComplete")
}

func strComStations() -> String
{
    return getStringByKey("common.stations")
}

func strComPhoneTitle() -> String
{
    return getStringByKey("common.phoneTitle")
}

func strComProfile() -> String
{
    return getStringByKey("common.profile")
}

func strComShortBonus() -> String
{
    return getStringByKey("common.shortBonus")
}

func strComWelcome() -> String
{
    return getStringByKey("common.welcome")
}

func strComEmail() -> String
{
    return getStringByKey("common.email")
}

func strComCodeTitle() -> String
{
    return getStringByKey("common.codeTitle")
}

func strComPayBonus() -> String
{
    return getStringByKey("common.payBonus")
}

func strComEdit() -> String
{
    return getStringByKey("common.edit")
}

func strComPayded() -> String
{
    return getStringByKey("common.payAbout")
}

func strComRejecting() -> String
{
    return getStringByKey("common.rejectingOrder")
}

func strTieCard() -> String
{
    return getStringByKey("common.tieCard")
}

func strTieCardSucces() -> String
{
    return getStringByKey("common.tieCardSuccess")
}

func strComNotPayded() -> String
{
    return getStringByKey("common.notPayded")
}

func strComMyAddrs() -> String
{
    return getStringByKey("common.myAddrs")
}

func strComSettings() -> String
{
    return getStringByKey("common.settings")
}

func strComAboutApp() -> String
{
    return getStringByKey("common.aboutApp")
}

func strComNotFound() -> String
{
    return getStringByKey("common.notFound")
}

func strInfoAboutSMS() -> String
{
    return getStringByKey("info.smsInfo")
}

func strInfoOffer() -> String
{
    return getStringByKey("info.offer")
}

func strInfoPublicOffer() -> String
{
    return getStringByKey("info.publicOffer")
}

func strAuthSendCode() -> String
{
    return getStringByKey("auth.sendCode")
}

func strAuthEnter() -> String
{
    return getStringByKey("auth.enter")
}

func strInfoResendSMS() -> String
{
    return getStringByKey("info.resendSMS")
}

func strComSec() -> String
{
    return getStringByKey("common.sec")
}

func strComCountry() -> String
{
    return getStringByKey("common.country")
}

func strComSearch() -> String
{
    return getStringByKey("common.search")
}

func strNoAddsForTariff() -> String
{
    return getStringByKey("common.noAddsForTariff")
}

func strComToOrder() -> String
{
    return getStringByKey("common.toOrder")
}

func strComWhereYou() -> String
{
    return getStringByKey("common.whereU")
}

func strComNoOrders() -> String
{
    return getStringByKey("common.noOrders")
}

func strComNoPreOrders() -> String
{
    return getStringByKey("common.noPreorders")
}

func strComThisRegion() -> String
{
    return getStringByKey("common.thisregion")
}

func strComNotSupported() -> String
{
    return getStringByKey("common.notsupported")
}

func strInfoNoService() -> String
{
    return getStringByKey("info.noService")
}

func strComNoAddrs() -> String
{
    return getStringByKey("common.noAddrs")
}

func strComSearchCountry() -> String
{
    return getStringByKey("common.searchCountry")
}

func strComOrderReport() -> String
{
    return getStringByKey("common.orderReport")
}

func strComOrderFinished() -> String
{
    return getStringByKey("common.orderFinished")
}

func strTypesMyAddrs() -> String
{
    return getStringByKey("types.myAddresses")
}

func strTypesPorts() -> String
{
    return getStringByKey("types.ports")
}

func strTypesMap() -> String
{
    return getStringByKey("types.pickMap")
}

func strTypesDriver() -> String
{
    return getStringByKey("types.sayToDriver")
}

func strComFinding() -> String
{
    return getStringByKey("common.finding")
}

func strComFrom() -> String
{
    return getStringByKey("common.from")
}

func strComDriverNotWasSetted() -> String
{
    return getStringByKey("common.driverNotWasSetted")
}

func strComDriverNotSettedYet() -> String
{
    return getStringByKey("common.driverNotSettedYet")
}

func strComTo() -> String
{
    return getStringByKey("common.to")
}

func strComRecent() -> String
{
    return getStringByKey("common.recent")
}

func strComNearly() -> String
{
    return getStringByKey("common.nearly")
}

func strComPickC() -> String
{
    return getStringByKey("common.pick")
}

func strComComment() -> String
{
    return getStringByKey("common.comment")
}

func strComButApprove() -> String
{
    return getStringByKey("common.butApprove")
}

func strComOffer() -> String
{
    return getStringByKey("common.offer")
}

func strComNeedAuth() -> String
{
    return getStringByKey("common.needAuth")
}

func strComPorch() -> String
{
    return getStringByKey("common.porch")
}

func strComButSave() -> String
{
    return getStringByKey("common.butSave")
}

func strComFlat() -> String
{
    return getStringByKey("common.flat")
}

func strComHouse() -> String
{
    return getStringByKey("common.house")
}

func strComCorp() -> String
{
    return getStringByKey("common.corp")
}

func strComQual() -> String
{
    return getStringByKey("common.qualification")
}

func strComStreetNHouseComment() -> String
{
    return getStringByKey("common.streetnhousecomment")
}

func strInfoComExample() -> String
{
    return getStringByKey("info.commentExample")
}

func strInfoSetPoint() -> String
{
    return getStringByKey("info.setPath");
}

func strComCreateOrder() -> String
{
    return getStringByKey("common.createOrder")
}

func strComTariff() -> String
{
    return getStringByKey("common.tariff")
}

func strComCarTime() -> String
{
    return getStringByKey("common.timeForCar")
}

func strComNow() -> String
{
    return getStringByKey("common.now")
}

func strComPick() -> String
{
    return getStringByKey("common.pickTime")
}

func strComOrder() -> String
{
    return getStringByKey("common.order")
}

func strComWishes() -> String
{
    return getStringByKey("common.wishes")
}

func strComSelectPoint() -> String
{
    return getStringByKey("common.selectAddress")
}

func strComLastName() -> String
{
    return getStringByKey("common.lastName")
}

func strComFirstName() -> String
{
    return getStringByKey("common.firstName")
}

func strComMiddleName() -> String
{
    return getStringByKey("common.middleName")
}
func strComAboutOrder() -> String
{
    return getStringByKey("common.aboutOrder")
}

func strComSave() -> String
{
    return getStringByKey("common.save")
}


func strComEditOrder() -> String
{
    return getStringByKey("common.editOrder")
}


func strComUpdateOrderError() -> String
{
    return getStringByKey("common.updateOrderError")
}


func strComUpdateOrderSuccess() -> String
{
    return getStringByKey("common.updateOrderSuccess")
}


func strComUpdateOrder() -> String
{
    return getStringByKey("common.updateOrder")
}


func strComPayment() -> String
{
    return getStringByKey("common.payment")
}


func strComAddresses() -> String
{
    return getStringByKey("common.addresses")
}


func strComLanguage() -> String
{
    return getStringByKey("common.language")
}


func strFreeTrip() -> String
{
    return getStringByKey("common.referralActivateTitle")
}

func strRefferalRegistration() -> String
{
    return getStringByKey("common.referralRegistration")
}

func strReviewStarCount() -> String
{
    return getStringByKey("review.errorStarCount")
}

func strReferralCodeTitle() -> String
{
    return getStringByKey("common.referralCodeTitle")
}

func strYourCode() -> String
{
    return getStringByKey("common.yourCode")
}

func strInputCode() -> String
{
    return getStringByKey("common.inputCode")
}

func strComClose() -> String
{
    return getStringByKey("common.close")
}

func strComYes() -> String
{
    return getStringByKey("common.yes")
}

func strComNo() -> String
{
    return getStringByKey("common.no")
}

func strComExit() -> String
{
    return getStringByKey("common.exit")
}

func strComUpdate() -> String
{
    return getStringByKey("common.update")
}

func strComEnterYourName() -> String
{
    return getStringByKey("common.enterYourName")
}

func strComLogoutApprove() -> String
{
    return getStringByKey("common.logoutApprove")
}

func strComLogout() -> String
{
    return getStringByKey("common.logout")
}

func strComOrdByCoords() -> String
{
    return getStringByKey("common.orderByCoords")
}


func strComLoading() -> String
{
    return getStringByKey("common.loading")
}

func strComPickAddress() -> String
{
    return getStringByKey("common.pickAddress")
}

func strComPickPorch() -> String
{
    return getStringByKey("common.pickPorch")
}

func strComPorchNumber() -> String
{
    return getStringByKey("common.porchNumber")
}


func strComCancel() -> String
{
    return getStringByKey("common.cancel")
}

func strComUploadPhoto() -> String
{
    return getStringByKey("common.uploadPhoto")
}

func strComChoosePhoto() -> String
{
    return getStringByKey("common.choosePhoto")
}

func strComTakePhoto() -> String
{
    return getStringByKey("common.takePhoto")
}

func strComMap() -> String
{
    return getStringByKey("common.map")
}

func strComColorScheme() -> String
{
    return getStringByKey("common.colorScheme")
}

func strComRetry() -> String
{
    return getStringByKey("common.retryOrder")
}

func strComReverse() -> String
{
    return getStringByKey("common.reverseOrder")
}

func strComDeleteOrder() -> String
{
    return getStringByKey("common.deleteOrder")
}

func strComDeleteOrderMessage() -> String
{
    return getStringByKey("common.deleteOrderMessage")
}

func strComDriver() -> String
{
    return getStringByKey("common.driver")
}

func strComPreOrd() -> String
{
    return getStringByKey("common.preOrd")
}

func strComDispatcher() -> String
{
    return getStringByKey("common.dispatcher")
}

func strComDoCall() -> String
{
    return getStringByKey("common.doCall")
}

func strComCurOrds() -> String
{
    return getStringByKey("common.currentOrds")
}

func strComPastOrds() -> String
{
    return getStringByKey("common.pastOrds")
}

func strComUpdatingOrder() -> String
{
    return getStringByKey("common.uodatingOrder")
}

func strComOrderNew() -> String
{
    return getStringByKey("common.newOrder")
}

func strComId() -> String
{
    return getStringByKey("common.id")
}

func strComOrderRejected() -> String
{
    return getStringByKey("common.rejected")
}

func strComRejectOrder() -> String
{
    return getStringByKey("common.rejectOrder")
}

func strComRejectOrderMessage() -> String
{
    return getStringByKey("common.rejectOrderSure")
}

func strComAnd() -> String
{
    return getStringByKey("common.and")
}

func strComTimeToCar() -> String
{
    return getStringByKey("common.timeToCar")
}

func strComPickCity() -> String
{
    return getStringByKey("common.pickCity")
}

func strTimeTitle() -> String
{
    return getStringByKey("time.title")
}

func strTimeNow() -> String
{
    return getStringByKey("time.now")
}

func strTimeNowLong() -> String
{
    return getStringByKey("time.nowLong")
}

func strTimeSelect() -> String
{
    return getStringByKey("time.select")
}

//Предрасчет

func strCCostTitle() -> String
{
    return getStringByKey("ccost.callCostTitle")
}

func strCCostKm() -> String
{
    return getStringByKey("ccost.kms")
}


func strCCostMin() -> String
{
    return getStringByKey("ccost.mins")
}

func strCCostPickB() -> String
{
    return  ""//getStringByKey("ccost.pickBPoint")
}

func strCCostFixPrice() -> String
{
    return getStringByKey("ccost.fixPrice")
}

func strCCostPrePrice() -> String
{
    return getStringByKey("ccost.prePrice")
}


//локализации

func lanEnglish() -> String
{
    return getStringByKey("language.english")
}

func lanRu() -> String
{
    return getStringByKey("language.ru")
}

func lanSerb() -> String
{
    return getStringByKey("language.sr")
}

func lanKa() -> String
{
    return getStringByKey("language.ka")
}

func lanAr() -> String
{
    return getStringByKey("language.ar")
}

func lanOr() -> String
{
    return getStringByKey("language.or")
}

func lanDe() -> String
{
    return getStringByKey("language.de")
}

func lanIt() -> String
{
    return getStringByKey("language.it")
}

func lanMe() -> String
{
    return getStringByKey("language.sr-ME")
}

func lanFa() -> String
{
    return getStringByKey("language.fa")
}


func lanAz() -> String
{
    return getStringByKey("language.az")
}

func lanUz() -> String
{
    return getStringByKey("language.uz")
}

func lanTk() -> String
{
    return getStringByKey("language.tk")
}

// пожелания
func strWshCond() -> String
{
    return getStringByKey("wish.cond")
}

func strWshNoSmoke() -> String
{
    return getStringByKey("wish.noSmoke")
}

func strWshSmoke() -> String
{
    return getStringByKey("wish.smoke")
}

func strWshPet() -> String
{
    return getStringByKey("wish.pet")
}

func strWshWifi() -> String
{
    return getStringByKey("wish.wifi")
}

func strWshKid() -> String
{
    return getStringByKey("wish.kid")
}

func strWshTee() -> String
{
    return getStringByKey("wish.tee")
}

func strWshOrds() -> String
{
    return getStringByKey("wish.ords")
}

func strWshNotSelected() -> String
{
    return getStringByKey("wish.notSelected")
}


// склонение времени

func strTimeDay0() -> String
{
    return getStringByKey("time.day0")
}

func strTimeDay1() -> String
{
    return getStringByKey("time.day1")
}

func strTimeDay2() -> String
{
    return getStringByKey("time.day2")
}

func strTimeHour0() -> String
{
    return getStringByKey("time.hour0")
}

func strTimeHour1() -> String
{
    return getStringByKey("time.hour1")
}

func strTimeHour2() -> String
{
    return getStringByKey("time.hour2")
}

func strTimeMin0() -> String
{
    return getStringByKey("time.min0")
}

func strTimeMin1() -> String
{
    return getStringByKey("time.min1")
}

func strTimeMin2() -> String
{
    return getStringByKey("time.min2")
}

func strTimeM() -> String
{
    return getStringByKey("time.m")
}

func strTimeD() -> String
{
    return getStringByKey("time.d")
}

func strTimeH() -> String
{
    return getStringByKey("time.h")
}

// Оценка поездки

func strRateSet() -> String
{
    return getStringByKey("rate.setRate")
}

func strRateYour() -> String
{
    return getStringByKey("rate.yourRate")
}

func strRateSend() -> String
{
    return getStringByKey("rate.send")
}

func strRateFeedback() -> String
{
    return getStringByKey("rate.feedback")
}

func strWriteFeedback() -> String{
    return getStringByKey("rate.writeFeedback")
}

// sharing

func strShareTitle() -> String
{
    return getStringByKey("share.title")
}

func strShareText() -> String
{
    let appName = Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as! String
    return String(format: getStringByKey("share.text"), appName)
}



// Стоимость поездки

func strCostPlacing() -> String
{
    return getStringByKey("cost.placing")
}

func strCostAdds() -> String
{
    return getStringByKey("common.wishes")
}

func strCostInCity() -> String
{
    return getStringByKey("cost.inCity")
}

func strCostOutCity() -> String
{
    return getStringByKey("cost.outCity")
}

func strCostProstCity() -> String
{
    return getStringByKey("cost.prostCity")
}

func strCostProstOutCity() -> String
{
    return getStringByKey("cost.prostOutCity")
}

func strCostIncluded() -> String
{
    return getStringByKey("cost.included")
}

func strCostSummary() -> String
{
    return getStringByKey("cost.summary")
}

func strCostTaxFee() -> String
{
    return getStringByKey("cost.taxfee")
}

// Ошибки

func strErrTitle() -> String
{
    return getStringByKey("err.title")
}

func strErrVersion() -> String
{
    return getStringByKey("err.versionError")
}

func strErrInternal() -> String
{
    return getStringByKey("err.internal")
}

func strErrSignature() -> String
{
    return getStringByKey("err.signature")
}

func strErrUnknownReq() -> String
{
    return getStringByKey("err.unknownReq")
}

func strErrBadParam() -> String
{
    return getStringByKey("err.badParam")
}

func strErrMissingParam() -> String
{
    return getStringByKey("err.missingParam")
}

func strErrEmptyValue() -> String
{
    return getStringByKey("err.emptyValue")
}

func strErrEmptyDataInDB() -> String
{
    return getStringByKey("err.emptyDataInDatabase")
}

func strErrEmptyTenantId() -> String
{
    return getStringByKey("err.emptyTenantID")
}

func strErrBlackList() -> String
{
    return getStringByKey("err.blackList")
}

func strErrNeedReauth() -> String
{
    return getStringByKey("err.needReauth")
}

func strErrBadPayType() -> String
{
    return getStringByKey("err.badPayType")
}

func strErrCantConnect() -> String
{
    return getStringByKey("err.cantConnectAcc")
}

func strErrNoMoney() -> String
{
    return getStringByKey("err.noMoney")
}

func strErrBadBonus() -> String
{
    return getStringByKey("err.badBonus")
}

func strErrGate() -> String
{
    return getStringByKey("err.paymentGateError")
}

func strErrRejectOrder() -> String
{
    return getStringByKey("err.rejectOrder")
}

func strErrBadPan() -> String
{
    return getStringByKey("err.invalidPan")
}

func strErrReferralCode() -> String
{
    return getStringByKey("err.invalidReferralCode")
}

func strErrNeedAtLeastTwoPointToMakeAnOrder() -> String
{
    return getStringByKey("err.needTwoPointsToMakeAnOrder")
}

func strErrBadPromoCode() -> String
{
    return getStringByKey("err.badPromoCode")
}

// оплата

func strPayTitleType() -> String
{
    return getStringByKey("pay.titleType")
}

func strPayCash() -> String
{
    return getStringByKey("pay.cash")
}

func strPayPersBal() -> String
{
    return getStringByKey("pay.persBal")
}

func strPayCorpBal() -> String
{
    return getStringByKey("pay.corp")
}

func strPayAddCard() -> String
{
    return getStringByKey("pay.addCard")
}

func strPayBonusPay() -> String
{
    return getStringByKey("pay.bonusPay")
}

func strPayInfoPay() -> String
{
    return getStringByKey("pay.infoPay")
}

func strPayPay() -> String
{
    return getStringByKey("pay.pay")
}

func strPayUndefined() -> String
{
    return getStringByKey("pay.undefined")
}



// Настрйоки

func strSetLan() -> String
{
    return getStringByKey("set.selectLan")
}

func strSetMap() -> String
{
    return getStringByKey("set.selectMap")
}

func strSetTen() -> String
{
    return getStringByKey("set.selectTen")
}

func strSetConGootaxAcc() -> String
{
    return getStringByKey("set.conGootaxAcc")
}

func strSetConGootaxAccTitle() -> String
{
    return getStringByKey("set.conAccTitle")
}

func strSetSelectColor() -> String
{
    return getStringByKey("set.selectColor")
}

func strYourTen() -> String
{
    return getStringByKey("set.yourTenId")
}


//Карты

func strMapGis() -> String
{
    return getStringByKey("map.gis")
}

func strMapGoogle() -> String
{
    return getStringByKey("map.google")
}

func strMapOsm() -> String
{
    return getStringByKey("map.osm")
}

