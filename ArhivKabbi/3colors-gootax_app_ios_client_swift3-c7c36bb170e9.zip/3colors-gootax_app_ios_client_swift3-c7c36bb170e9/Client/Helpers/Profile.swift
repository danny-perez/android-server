//
//  Profile.swift
//  Client
//
//  Created by Dmitriy Kudrin on 06.09.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation
import Alamofire
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class Profile : NSObject, NSCoding {
    var photo : String?
    var photoImage : UIImage?
    var firstName : String?
    var lastName : String?
    var middleName : String?
    var dob : Date?
    var balanceMoney : Double?
    var balanceBonus : Double?
    var currency : String?
    var phone : String?
    var email : String?
    var password : String?
    var clientID : String?
    var companies : [ClientCompany]?
    var payments : [ClientPayment]?
    var bonusSystem : BonusSystem?
    var isFirstSign: Bool?
    var inaccuracy: Double?
    var clientType: String!
    var calendar: Int?
    
    override init() {
        self.photo = ""
        self.photoImage = UIImage(named: "driver")
        self.firstName = ""
        self.lastName = ""
        self.middleName = ""
        self.dob = nil
        self.balanceMoney = nil
        self.balanceBonus = nil
        self.currency = nil
        self.phone = ""
        self.email = ""
        self.password = ""
        self.clientID = ""
        self.companies = [ClientCompany]()
        self.payments = [ClientPayment]()
        self.bonusSystem = BonusSystem()
        self.isFirstSign = false
        self.clientType = "base"
        self.calendar = defaultCalendar
    }
    
    // нужно для того, чтобы можно было хранить в БД и в userDefaults
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.photo = decoder.decodeObject(forKey: "photo") as? String
        self.photoImage = decoder.decodeObject(forKey: "photoImage") as? UIImage
        self.firstName = decoder.decodeObject(forKey: "firstName") as? String
        self.lastName = decoder.decodeObject(forKey: "lastName") as? String
        self.middleName = decoder.decodeObject(forKey: "middleName") as? String
        self.currency = decoder.decodeObject(forKey: "currency") as? String
        self.phone = decoder.decodeObject(forKey: "phone") as? String
        self.email = decoder.decodeObject(forKey: "email") as? String
        self.password = decoder.decodeObject(forKey: "password") as? String
        self.clientID = decoder.decodeObject(forKey: "clientID") as? String
        self.dob = decoder.decodeObject(forKey: "dob") as? Date
        self.balanceMoney = decoder.decodeObject(forKey: "balanceMoney") as? Double
        self.balanceBonus = decoder.decodeObject(forKey: "balanceBonus") as? Double
        self.companies = decoder.decodeObject(forKey: "companies") as? [ClientCompany]
        self.payments = decoder.decodeObject(forKey: "payments") as? [ClientPayment]
        self.bonusSystem = decoder.decodeObject(forKey: "bonusSystem") as? BonusSystem
        self.isFirstSign = decoder.decodeObject(forKey: "is_first_sign") as? Bool
        self.clientType = decoder.decodeObject(forKey: "clientType") as? String
        self.calendar = decoder.decodeObject(forKey: "calendar") as? Int
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(self.photo, forKey: "photo")
        coder.encode(self.photoImage, forKey: "photoImage")
        coder.encode(self.firstName, forKey: "firstName")
        coder.encode(self.lastName, forKey: "lastName")
        coder.encode(self.middleName, forKey: "middleName")
        coder.encode(self.currency, forKey: "currency")
        coder.encode(self.phone, forKey: "phone")
        coder.encode(self.email, forKey: "email")
        coder.encode(self.password, forKey: "password")
        coder.encode(self.dob, forKey: "dob")
        coder.encode(self.balanceMoney, forKey: "balanceMoney")
        coder.encode(self.balanceBonus, forKey: "balanceBonus")
        coder.encode(self.companies, forKey: "companies")
        coder.encode(self.clientID, forKey: "clientID")
        coder.encode(self.payments, forKey: "payments")
        coder.encode(self.bonusSystem, forKey: "bonusSystem")
        coder.encode(self.isFirstSign, forKey: "is_first_sign")
        coder.encode(self.clientType, forKey: "clientType")
        coder.encode(self.calendar, forKey: "calendar")
    }
    
    // Получить полное имя
    func fullName() -> String {
        if self.phone == "" {
            return strAuthNeed()
        }
        var fullName = ""
        if self.firstName != nil {
            if self.firstName != "" {
                if fullName == "" {
                    fullName = self.firstName!
                }
                else {
                    fullName = "\(fullName) \(self.firstName!)"
                }
            }
        }
        if self.lastName != nil {
            if fullName == "" {
                fullName = self.lastName!
            } else {
                fullName = "\(fullName) \(self.lastName!)"
            }
        }
        
        if fullName == "" {
            fullName = strComEnterYourName()
        }
        return fullName
    }
    
}


class ClientPayment : NSObject, NSCoding {
    var payID : String? // если когда-то добавится ID
    var payLabel : String? // для отображения
    
    var payCompanyID : String? // выбранная компания
    
    var payType : String? // Для отправки на сервер
    var paySubType : String? // если карта, то уточнить какая
    var payLogoURL : String? // если есть логотип
    
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.payID = decoder.decodeObject(forKey: "payID") as? String
        self.payLabel = decoder.decodeObject(forKey: "payLabel") as? String
        self.payCompanyID = decoder.decodeObject(forKey: "payCompanyID") as? String
        self.payType = decoder.decodeObject(forKey: "payType") as? String
        self.paySubType = decoder.decodeObject(forKey: "paySubType") as? String
        self.payLogoURL = decoder.decodeObject(forKey: "payLogoURL") as? String
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(self.payID, forKey: "payID")
        coder.encode(self.payLabel, forKey: "payLabel")
        coder.encode(self.payCompanyID, forKey: "payCompanyID")
        coder.encode(self.payType, forKey: "payType")
        coder.encode(self.paySubType, forKey: "paySubType")
        coder.encode(self.payLogoURL, forKey: "payLogoURL")
    }
    
    override init() {
        self.payID = ""
        self.payCompanyID = ""
        self.payLabel = ""
        self.payType = ""
        self.paySubType = ""
        self.payLogoURL = ""
    }
}

class ClientCompany : NSObject, NSCoding {
    var companyID : String?
    var companyValue : Double?
    var companyName : String?
    
    // нужно для того, чтобы можно было хранить в БД и в userDefaults
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.companyID = decoder.decodeObject(forKey: "companyID") as? String
        self.companyValue = decoder.decodeObject(forKey: "companyValue") as? Double
        self.companyName = decoder.decodeObject(forKey: "companyName") as? String

    }
    func encode(with coder: NSCoder) {
        coder.encode(self.companyID, forKey: "companyID")
        coder.encode(self.companyValue, forKey: "companyValue")
        coder.encode(self.companyName, forKey: "companyName")
    }
    override init() {
        self.companyID = ""
        self.companyValue = 0
        self.companyName = ""
    }
}

class BonusSystem : NSObject, NSCoding {
    var systemID : String?
    var systemName : String?
    var isActive : Bool?
    
    required convenience init(coder decoder: NSCoder) {
        self.init()
        self.systemID = decoder.decodeObject(forKey: "systemID") as? String
        self.systemName = decoder.decodeObject(forKey: "systemName") as? String
        self.isActive = decoder.decodeObject(forKey: "isActive") as? Bool
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.systemID, forKey: "systemID")
        aCoder.encode(self.systemName, forKey: "systemName")
        aCoder.encode(self.isActive, forKey: "isActive")
    }
    override init() {
        self.systemName = ""
        self.systemID = ""
        self.isActive = false
    }
}



func profile() -> Profile {
    var profile : Profile?
    let defaults = UserDefaults.standard
    if defaults.object(forKey: udefProfile) != nil {
        if defaults.object(forKey: udefProfile) is NSData {
            NSKeyedUnarchiver.setClass(Profile.self, forClassName: "Utap.Profile")
            profile = NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefProfile) as! Data) as? Profile
        }
        
    }
    else {
        updateProfile(Profile())
    }
    
    if profile == nil {
        profile = Profile()
    }
    
    return profile!
}

func bonus_system() -> BonusSystem {
    var bonusSystem: BonusSystem?
    let defaults = UserDefaults.standard
    if defaults.object(forKey: udefBonusSystem) != nil {
        if defaults.object(forKey: udefBonusSystem) is NSData {
            NSKeyedUnarchiver.setClass(BonusSystem.self, forClassName: "Utap.BonusSystem")
            bonusSystem = NSKeyedUnarchiver.unarchiveObject(with: defaults.object(forKey: udefBonusSystem) as! Data) as? BonusSystem
        }
        
    }
    else {
        updateBonusSystem(BonusSystem())
    }
    
    if bonusSystem == nil {
        bonusSystem = BonusSystem()
    }
    
    return bonusSystem!

}

func gxActivateBonusSystem(_ clientPhone: String, code: String, completion: @escaping (_ res: Bool) -> Void) {
    
    let params = [
        "client_phone" : clientPhone,
        "promo_code" : code
        ]
    gxDoPOST(kGxActivateBonusSystem, params: params, completion: { (response) -> Void in
        //        print(result)
        
        if let result = response as? [String: Any] {
             var activated = false
            if let isActivatedSystem = result["activate_Bonus_system"] as? Bool {
                activated = isActivatedSystem
                completion(activated)
            }
        }
    }) { (error) -> Void in
        print(error.description)
        completion(false)
    }
}



func urlRequestWithComponents(_ urlString:String, parameters:Dictionary<String, String>, imageData:NSData) -> (URLRequestConvertible, NSData) {
    
    // create url request to send
    let mutableURLRequest = NSMutableURLRequest(url: URL(string: urlString)!)

    //mutableURLRequest.httpMethod = .post.rawValue
    let boundaryConstant = "myRandomBoundary12345";
    //let contentType = "multipart/form-data;boundary="+boundaryConstant
    //mutableURLRequest.setValue(contentType, forHTTPHeaderField: "Content-Type")
    
    // create upload data to send
    let uploadData = NSMutableData()
    
    // add image
    uploadData.append("\r\n--\(boundaryConstant)\r\n".data(using: String.Encoding.utf8)!)
    uploadData.append("Content-Disposition: form-data; name=\"photo\"; filename=\"file.png\"\r\n".data(using: String.Encoding.utf8)!)
    uploadData.append("Content-Type: image/png\r\n\r\n".data(using: String.Encoding.utf8)!)
    uploadData.append(imageData as Data)
    let sorteda = parameters.keys.sorted()
    let objects = parameters.valuesForKeys(sorteda)
    
    for i in 0...sorteda.count-1 {
        let keyString : String! = sorteda[i];
        let valueString : String! = objects[i];
        uploadData.append("\r\n--\(boundaryConstant)\r\n".data(using: String.Encoding.utf8)!)
        uploadData.append("Content-Disposition: form-data; name=\"\(keyString)\"\r\n\r\n\(valueString)".data(using: String.Encoding.utf8)!)
    }
    uploadData.append("\r\n--\(boundaryConstant)--\r\n".data(using: String.Encoding.utf8)!)
    
    
    return (try! Alamofire.URLEncoding.default.encode(mutableURLRequest as! URLRequestConvertible, with: nil), uploadData)
}


func gxGetProfile(_ clientPhone: String, completion: @escaping (_ res: Bool) -> Void) {
    
    let params = ["phone" : clientPhone]
    gxDoGet(kGxApiGetProfile, params: params, completion: { (result) -> Void in
        if result is [String: Any] {
            let parseResult = result["result"] as! [String: Any]
            if parseResult["client_profile"] != nil {
                if parseResult["client_profile"] is [String: Any] {
                    if let clientProfile = parseResult["client_profile"] as? [String: Any] {
                        gxParseProfile(clientProfile)
                    }
                }
            }
            if parseResult["bonus_system"] != nil {
                if parseResult["bonus_system"] is [String: Any] {
                    if let bonusSystem = parseResult["bonus_system"] as? [String: Any] {
                        _ = gxParseBonusSystem(bonusSystem)
                    }
                }
            }
        } else {
            completion(false)
        }
    }) { (error) -> Void in
        print(error.description)
        completion(false)
    }
}


func gxGetShare() {
    
    gxDoGet(kGxApiLinks, params: Dictionary(), completion: { (result) -> Void in
        //        print(result)
        if let parseResult = result["result"] as? Dictionary<String, AnyObject> {
            let defaults = UserDefaults.standard
            if let iosShareUrl = parseResult["ios"] as? String {
                defaults.set(URL(string: iosShareUrl), forKey: udefShareUrl)
            }
            if let androidShareUrl = parseResult["android"] as? String {
                defaults.set(URL(string: androidShareUrl), forKey: udefAndroidShareUrl)
            }
        }
    }) { (error) -> Void in
        print(error.description)
    }
    
}


func gxDeleteCard(_ clientId: String, clientPhone: String, pan: String, completion: @escaping (_ res: Bool) -> Void) {
    
    let params = [
        "client_id" : clientId,
        "phone" : clientPhone,
        "pan" : pan
    ]
    
    gxDoPOST(kGxApiDeleteClientCard, params: params, completion: { (result) -> Void in
        if result is Dictionary<String, AnyObject> {
            if result["result"] != nil {
                if result["result"] is Bool {
                    if ((result["result"] as! Bool)) {
                        completion(true)
                    } else { completion(false) }
                }
            }
        }
        else {
            completion(false)
        }
    }) { (error) -> Void in
        print(error.description)
        completion(false)
    }
}

func uploadImage(_ urlString:String, parameters: Dictionary<String, String>, imageData: NSData, headers: [String: String], completion: @escaping (_ finished : Bool) -> Void) {
    Alamofire.upload(multipartFormData: { (multipartFormData) in
        multipartFormData.append(imageData as Data, withName: "photo", fileName: "file.png", mimeType: "image/png")
        let sorteda = parameters.keys.sorted()
        let objects = parameters.valuesForKeys(sorteda)
        
        for i in 0...sorteda.count-1 {
            let keyString : String! = sorteda[i];
            let valueString : String! = objects[i];
            multipartFormData.append(valueString.data(using: String.Encoding.utf8)!, withName: keyString)
        }
    }, to: urlString, headers: headers)
    { (result) in
        switch result {
        case .success(let upload, _, _):
            upload.responseJSON { response in
                if let result = response.result.value as? [String: Any] {
                    gxParseUpdateProfile(result)
                    completion(true)
                }
            }
            
        case .failure( _):
            break
        }
    }
}

func gxUpdateProfile(_ profileNew: Profile, isChangedPhoto: Bool = false, completion: @escaping (_ finished : Bool) -> Void) {
    let oldProfile = profile()
    
    var newLastName = profileNew.lastName!
    if newLastName.characters.count > 100 {
        let index: String.Index = newLastName.characters.index(newLastName.startIndex, offsetBy: 100)
        newLastName = newLastName.substring(to: index)
    }
    
    var newFirstName = profileNew.firstName!
    if newFirstName.characters.count > 100 {
        let index: String.Index = newFirstName.characters.index(newFirstName.startIndex, offsetBy: 100)
        newFirstName = newFirstName.substring(to: index)
    }
    
    var newMiddleName = profileNew.middleName!
    if newMiddleName.characters.count > 100 {
        let index: String.Index = newMiddleName.characters.index(newMiddleName.startIndex, offsetBy: 100)
        newMiddleName = newMiddleName.substring(to: index)
    }
    
    var newEmail = profileNew.email!
    if newEmail.characters.count > 100 {
        let index: String.Index = newEmail.characters.index(newEmail.startIndex, offsetBy: 100)
        newEmail = newEmail.substring(to: index)
    }
    
    var params = Dictionary<String, String>();
    params["client_id"] = profileNew.clientID!
    params["current_time"] = timestamp()
    params["old_phone"] = oldProfile.phone!
    params["new_phone"] = profileNew.phone!
    params["surname"] = newLastName
    params["name"] = newFirstName
    params["patronymic"] = newMiddleName
    params["email"] = newEmail
    
    
    // добавить заголовке
    var defaultHeaders: [String: String] = [:]
    
    defaultHeaders["typeclient"] = "ios"
    
    defaultHeaders["deviceid"] = deviceToken()
    
    defaultHeaders["lang"] = lang()
    
    defaultHeaders["tenantid"] = curTenant()
    
    defaultHeaders["versionclient"] = versionClient
    
    defaultHeaders["appid"] = appId
    
    defaultHeaders["signature"] = gxGenSignatureFromParams(params)
    
    if !isChangedPhoto {
        gxDoPOST(kGxApiUpdProfile, params: params, completion: { resultData in
            if let result = resultData as? [String: Any] {
                gxParseUpdateProfile(result)
                completion(true)
            }
            else {
                completion(false)
            }
        }, failure: { (error) -> Void in
            completion(false)
            print(error.description)
        })
    } else {
        let photoData = UIImagePNGRepresentation(profileNew.photoImage!)
        uploadImage("\(baseUrl)\(kGxApiUpdProfile)", parameters: params, imageData: photoData! as NSData, headers: defaultHeaders) { isSuccess in
            if isSuccess {
                completion(true)
            }
        }
    }
}

func gxParseUpdateProfile(_ dict :[String: Any]) -> Bool {
    var isUpdate : Bool = false
    
    if let result = dict["result"] as? [String: Any] {
        if let update = result["update_result"] as? Double, update == 1 {
            isUpdate = true
        }
        if isUpdate {
            if let clientProfile = result["client_profile"] as? [String: Any] {
                gxParseProfile(clientProfile)
            }
        }
    }
    return isUpdate
}


func gxParseProfile(_ dict: [String: Any])
{
    let tempProfile = profile()
    
    if (dict["birth"] != nil) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if dict["birth"] is String {
            let date = dateFormatter.date(from: dict["birth"] as! String)
            tempProfile.dob = date
        }
    }
    
    tempProfile.clientID = parseString(dict["client_id"] ?? "")
    
    if let phones = dict["client_phones"] as? [[String: Any]], phones.count > 0 {
        if let phone = phones[0]["phone"] as? String {
            tempProfile.phone = phone
        }
    }
    
    tempProfile.email = parseString(dict["email"] ?? "")
    tempProfile.firstName = parseString(dict["name"] ?? "")
    tempProfile.middleName = parseString(dict["patronymic"] ?? "")
    tempProfile.lastName = parseString(dict["surname"] ?? "")
    tempProfile.photo = parseString(dict["photo"] ?? "")
    
    if let presonalBalance = dict["personal_balance"] as? [String: Any] {
        tempProfile.currency = parseString(presonalBalance["personal_balance_currency"] ?? "")
        tempProfile.balanceMoney = presonalBalance["personal_balance_currency"] as? Double ?? 0.0
    }

    if let presonalBonus = dict["personal_balance"] as? [[String: Any]], presonalBonus.count > 0 {
        if let bouns = presonalBonus[0]["bonus_value"] as? Double {
            tempProfile.balanceBonus = bouns
        }
        
    }
    
   
    if let clientCompanies = dict["client_companies"] as? [[String: Any]], clientCompanies.count > 0 {
        tempProfile.companies = gxParseCompanies(clientCompanies)
    }
    
    
    updateProfile(tempProfile)
}

func gxGetClientBalances(_ clientPhone: String, cityId: String, completion: @escaping (_ res: Bool) -> Void) {
    
    let params = [
        "phone" : clientPhone,
        "city_id" : cityId
    ]
    
    gxDoGet(kGxApiClientBalances, params: params, completion: { (result) -> Void in
        //        print(result)
        if result is [String: Any] {
            if let parseResult = result["result"] as? [String: Any] {
                gxParseBalances(parseResult)
                completion(true)
            }
        }
        else {
            completion(false)
        }
    }) { (error) -> Void in
        print(error.description)
        completion(false)
    }
}

func gxParseBalances(_ dict: [String: Any]) {
    let newProfile = profile();
    
    
    if let currency = dict["currency"] as? [String: Any]{
        if let code = currency["code"]! as? String {
            newProfile.currency = code
        }
    }
    
    if let personalBalance = dict["personal_balance"] as? [String: Any]{
        if let value = personalBalance["value"]! as? String {
            newProfile.balanceMoney = Double(value)
        }
    }

    if let personalBonus = dict["personal_bonus"] as? [String: Any]{
        if let value = personalBonus["value"]! as? String {
            newProfile.balanceBonus = Double(value)
        }
    }
    
    if let personalBonusSystem = dict["bonus_system"] as? [String: Any] {
        newProfile.bonusSystem = gxParseBonusSystem(personalBonusSystem)
    }

    if let personalCompanies = dict["company_balance"] as? [[String: Any]], personalCompanies.count > 0 {
        newProfile.companies = gxParseCompanies(personalCompanies)
    }

    if let res = dict["cards"] as? [String] {
        var cards = [ClientPayment]()
        for card in res {
            let payment = ClientPayment()
            payment.payLabel = card
            cards.append(payment)
        }
        newProfile.payments = cards
    }

    updateProfile(newProfile)
}

func gxParseBonusSystem(_ bs: [String: Any]) -> BonusSystem {
    let parsedBonusSystem = BonusSystem()
    if bs["id"] != nil {
        if bs["id"] is String {
            parsedBonusSystem.systemID = bs["id"] as? String
        }
        else if bs["id"] is Int {
            parsedBonusSystem.systemID = String("\(String(describing: bs["id"] as? Int))")
        }
    }
    if bs["name"] != nil {
        if bs["name"] is String {
            parsedBonusSystem.systemName = bs["name"] as? String
            
        }
    }
    if bs["active"] != nil {
        if bs["active"] is Bool {
            parsedBonusSystem.isActive = bs["active"] as? Bool
        }
    }
    print("Bonus system info: \(String(describing: parsedBonusSystem.systemName)): ID:\(String(describing: parsedBonusSystem.systemID)), isActive: \(String(describing: parsedBonusSystem.isActive))")
//    profile.bonusSystem = parsedBonusSystem
    updateBonusSystem(parsedBonusSystem)
    return parsedBonusSystem
}


func gxParseCompanies(_ arr: [[String: Any]]) -> [ClientCompany] {
    var companies = [ClientCompany]()
    for company in arr {
        let newClientCompany = ClientCompany()
        if company["company_id"] != nil {
            if company["company_id"] is String {
                newClientCompany.companyID = company["company_id"]! as? String
                print("Comp \(newClientCompany.companyID)")
            }
            else if company["company_id"] is Int {
                newClientCompany.companyID = String(company["company_id"] as! Int)
            }
        }
        if company["value"] != nil {
            if company["value"] is Double {
                newClientCompany.companyValue = company["value"] as? Double
            }
        }
        if company["company_name"] != nil {
            if company["company_name"] is String {
                newClientCompany.companyName = company["company_name"] as? String
            }
        }
        companies.append(newClientCompany)
    }
    
    return companies
}

func gxPingTime() {
    let params : Dictionary<String, String>  = [:]

    gxDoGet(kGxApiPing, params: params, completion: { (result) -> Void in
        if let res = result["result"] as? Dictionary<String, AnyObject> {
            if let time = res["time"]! as? Double {
                let inaccuracy = Date().timeIntervalSince1970 - time
                let defaults = UserDefaults.standard
                defaults.set(inaccuracy, forKey: "inaccuracyTime")
            }
        }
        }
    ) { (error) -> Void in
        print(error.description)
    }
}

public func getInaccuracy() -> Double {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: "inaccuracyTime") != nil {
        return defaults.double(forKey: "inaccuracyTime")
    }
    return 0;
}

public func getFakeOrderDate(_ date: Date) -> Date {
    return Date(timeIntervalSince1970: date.timeIntervalSince1970 + getInaccuracy())
}

func updateProfile(_ profile : Profile) {
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: profile), forKey: udefProfile)

}

func updateBonusSystem(_ bonusSystem: BonusSystem) {
    let defaults = UserDefaults.standard
    defaults.set(NSKeyedArchiver.archivedData(withRootObject: bonusSystem), forKey:  udefBonusSystem)
}


//MARK: Cards

func gxGetProfileCards(_ profile: Profile, completion: @escaping (_ newProfile : Profile) -> Void) {
    let params : Dictionary<String, String> = ["client_id" : profile.clientID!,
        "phone" : profile.phone!]
    gxDoGet(kGxApiGetClientCards, params: params, completion: { (result) -> Void in
//        print(result)
        if let res = result["result"] as? [String] {
            var cards = [ClientPayment]()
            for card in res {
                let payment = ClientPayment()
                payment.payLabel = card
                cards.append(payment)
            }
            profile.payments = cards
            updateProfile(profile)
            completion(profile)
        }
        else {
            //completion(arr: [AddressTemp]())
        }
    }
        ) { (error) -> Void in
            print(error.description)
    }
}

func gxAddCard(_ profile: Profile, completion: @escaping (_ result : Dictionary<String, String>) -> Void) {
    let params : Dictionary<String, String> = ["client_id" : profile.clientID!,
        "phone" : profile.phone!]
    gxDoPOST(kGxApiCreateClientCard, params: params, completion: { (result) -> Void in
        
        if let res = result["result"] as? Dictionary<String, String> {
            
            completion(res)
        }
        else {
            //completion(arr: [AddressTemp]())
        }
        }
        ) { (error) -> Void in
            print(error.description)
    }
}


func checkClientCard(_ ordId : String, completion: @escaping (_ result : Int) -> Void) {
    let profil = profile()
    let params : Dictionary<String, String> = ["client_id" : profil.clientID!,
                                               "phone" : profil.phone!,
                                               "order_id" : ordId]
    gxDoPOST(kGxApiCheckClientCard, params: params, completion: { (result) -> Void in
        
        if let res = result["code"] as? Int {
            
            completion(res)
        }
        
        }
    ) { (error) -> Void in
        print(error.description)
    }
}





