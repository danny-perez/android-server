//
//  TenantSettingsViewController.swift
//  Client
//
//  Created by Dmitriy Kudrin on 16.05.16.
//  Copyright © 2016 Gootax. All rights reserved.
//

import UIKit

class TenantSettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var botSpace: NSLayoutConstraint!
    
    var visualEffectView : UIVisualEffectView?
    let endEffect = UIBlurEffect(style: .light)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if needBlur() {
            if (NSClassFromString("UIVisualEffectView") != nil) {
                if self.visualEffectView == nil {
                    self.visualEffectView = APCustomBlurView(withRadius: blurRadius)
                    self.visualEffectView?.frame = self.view.bounds
                    self.visualEffectView?.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                    self.visualEffectView?.alpha = 1
                    self.view.insertSubview(self.visualEffectView!, at: 0)
                    self.visualEffectView?.backgroundColor = blurColor
                }
            }
        }
        else {
            let view = UIView(frame: self.view.bounds)
            view.backgroundColor = UIColor.white
            self.view.insertSubview(view, at: 0)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(TenantSettingsViewController.localize), name: NSNotification.Name(rawValue: notifChangeLan), object: nil)
        
        localize()
        
        colorize()
        
        NotificationCenter.default.addObserver(self,
                                                         selector: #selector(TenantSettingsViewController.keyboardWillShow(_:)),
                                                         name: NSNotification.Name.UIKeyboardWillShow,
                                                         object: nil)
        NotificationCenter.default.addObserver(self,
                                                         selector: #selector(TenantSettingsViewController.keyboardWillHide(_:)),
                                                         name: NSNotification.Name.UIKeyboardWillHide,
                                                         object: nil)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func keyboardWillHide(_ note: Notification) {
            self.botSpace.constant = 10
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                    self.approveButton.layoutIfNeeded()
        })

    }
    
    func keyboardWillShow(_ note: Notification) {
        
        if let userInfo = note.userInfo {
            if let keyboardHeight = (userInfo[UIKeyboardFrameEndUserInfoKey] as AnyObject).cgRectValue.size.height as? CGFloat {
                self.botSpace.constant = keyboardHeight + 10
                UIView.animate(withDuration: 0.25, animations: { () -> Void in
                    self.approveButton.layoutIfNeeded()
                })
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "logoCell", for: indexPath)
            return cell
        }
        else {
            let cell : SetTenantTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ten", for: indexPath) as! SetTenantTableViewCell
            cell.tenField.text = curTenant()
            cell.tenField.becomeFirstResponder()
            
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        else {
            return 50
        }
    }
    
    @IBAction func saveTenant(_ sender: AnyObject) {
        let cell = self.tableView.cellForRow(at: IndexPath(row: 1, section: 0)) as! SetTenantTableViewCell
        let tenId = cell.tenField.text
        self.approveButton.isEnabled = false
        gxDoPing(tenId!, completion: { (result) in
            if result == true {
                if isDemo {
                    if cell.tenField.text != curTenant() {
                        let defaults : UserDefaults = UserDefaults.standard
                        defaults.set(cell.tenField?.text, forKey: udefCurTenID)
                        defaults.set(nil, forKey: udefProfile)
                        defaults.set(nil, forKey: udefCurCity)
                        defaults.set(nil, forKey: udefCities)
                        defaults.set(nil, forKey: udefTariffs)
                        defaults.set(nil, forKey: udefCurrency)
                        defaults.set(nil, forKey: udefDispPhone)
                        let mapCont = (self.navigationController!.presentingViewController as! UINavigationController).viewControllers[0] as! MapViewController
                        mapCont.curCars = nil
                        mapCont.curCities = nil
                        mapCont.currentCity = nil
                        mapCont.curOrder = OrderTemp()
                        mapCont.tariffs = nil
                        mapCont.clearMap()
                        mapCont.viewDidLoad()
                        mapCont.viewWillAppear(true)
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                    else {
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                }
            }
            else {
                let alertView = UIAlertView()
                alertView.title = strErrTitle()
                alertView.message = strErrCantConnect()
                alertView.addButton(withTitle: strComClose())
                alertView.cancelButtonIndex = 0
                alertView.show()
            }
            self.approveButton.isEnabled = true
            }) { (error) in
                
        }
    }
    func localize()
    {
        self.navigationItem.title = strSetConGootaxAccTitle()
        self.approveButton.setTitle(strComButApprove().uppercased(), for: UIControlState())
        //        self.navBar.topItem?.title = strComSettings()
        //        self.noTarrsLabel.text = strNoAddsForTariff()
    }
    
    func colorize() {
        self.approveButton.setColors()
        self.navigationController?.navigationBar.barTintColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.isTranslucent = false
        let view:UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 22))
        view.backgroundColor = colorNewNavBarBack()
        self.navigationController?.navigationBar.tintColor = colorNewHamButton()
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: colorNewNavBarText()]
        self.navigationController?.navigationBar.addSubview(view)
        //        self.closeButton.tintColor = colorNewHamButton()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
