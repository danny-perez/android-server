//
//  Car.swift
//  Client
//
//  Created by  Andrew on 21/08/2017.
//  Copyright © 2017 Gootax. All rights reserved.
//

import Foundation
import CoreData


@objc(Machine)
public class Machine: NSManagedObject {
    
    @NSManaged
    var carId : NSNumber
    
    @NSManaged
    var lat : NSNumber

    @NSManaged
    var lon : NSNumber
    
    @NSManaged
    var degree : NSNumber
    
    @NSManaged
    var carIsFree : Bool
    
}
