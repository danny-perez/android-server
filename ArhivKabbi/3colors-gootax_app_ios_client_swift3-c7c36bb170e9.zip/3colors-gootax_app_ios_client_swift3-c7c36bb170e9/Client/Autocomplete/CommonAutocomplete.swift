//
//  CommonAutocomplete.swift
//  Client
//
//  Created by Dmitriy Kudrin on 06.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation

func searchGeo(_ str: String, loc : CLLocationCoordinate2D, completion: @escaping (_ arr: [AddressTemp]) -> Void) {
    
    gxSearchGeo(str, location: loc, completion: { (array) -> Void in
        completion(array)
    })
}
