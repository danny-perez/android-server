//
//  GootaxAutocomplete.swift
//  Client
//
//  Created by Dmitriy Kudrin on 06.07.15.
//  Copyright © 2015 Gootax. All rights reserved.
//

import Foundation


func gxSearchGeo(_ str: String, location: CLLocationCoordinate2D, completion: @escaping (_ arr: [AddressTemp]) -> Void) {
    var newStr = str
    if newStr.characters.count > 100 {
        let index: String.Index = newStr.characters.index(newStr.startIndex, offsetBy: 100)
        newStr = newStr.substring(to: index)
    }
    var lang = ""
    if let curLan = UserDefaults.standard.object(forKey: udefCurLan) {
        lang = curLan as! String
    } else {
        lang = "ru"
    }
    var params = [
        "focus.point.lat" : String(location.latitude),
        "focus.point.lon" : String(location.longitude),
        "format" : "gootax",
        "type_app" : "client",
        "tenant_id": curTenant(),
        "text" : newStr,
        "sort" : useSearch ? "growth" : "distance",
        "radius" : searchRadius,
        "lang" : lang,
    ]
    if let city_id = curCity().cityID {
        params["city_id"] = city_id
    }
    params["hash"] = gxGenSignatureFromParams(params)
    gxAutoCompleteDoGet(params, completion: { (response) -> Void in
        
        if let result = response as? [String: Any] {
            if let res = result["results"] as? [[String: Any]] {
                completion(gxParseGeo(res))
            }
            else {
                completion([AddressTemp]())
            }
        }
    }
    ) { (error) -> Void in
        print(error.description)
    }
}


func gxParseGeo(_ arr : [[String: Any]]) -> [AddressTemp]
{
    var addresses : [AddressTemp] = [AddressTemp]()
    
    for dict: [String: Any] in arr
    {
        let newAddr : AddressTemp = AddressTemp()
        
        if let addr = dict["address"] as? [String: Any] {
            if addr["city"] != nil {
                newAddr.city = addr["city"] as? String
            }
            if addr["street"] != nil {
                newAddr.street = addr["street"] as? String
            }
            if addr["house"] != nil {
                if addr["house"] is String {
                    newAddr.house = addr["house"] as? String
                }
                else {
                    newAddr.house = String(describing: addr["house"] as? Double)
                }
            }
            if addr["housing"] != nil {
                if addr["housing"] is String {
                    newAddr.housing = addr["housing"] as? String
                }
                else {
                    newAddr.housing = String(describing: addr["housing"] as? Double)
                }
            }
            if addr["porch"] != nil {
                if addr["porch"] is String {
                    newAddr.porch = addr["porch"] as? String
                }
                else {
                    newAddr.porch = String(describing: addr["porch"] as? Double)
                }
            }
            if addr["lat"] != nil {
                if addr["lat"] is String {
                    newAddr.lat = (addr["lat"] as? NSString)?.doubleValue
                }
                else {
                    newAddr.lat = addr["lat"] as? Double
                }
            }
            if addr["lon"] != nil {
                if addr["lon"] is String {
                    newAddr.lon = (addr["lon"] as? NSString)?.doubleValue
                }
                else {
                    newAddr.lon = addr["lon"] as? Double
                }
            }
            if addr["label"] != nil {
                newAddr.label = addr["label"] as? String
            }
            
        }
        if dict["type"] != nil {
            if dict["type"] is String {
                if (dict["type"] as? String) == "public_place" {
                    newAddr.publicPlace = true
                }
            }
        }
        if newAddr.street != nil {
            if newAddr.street != "" || newAddr.label != "" {
                addresses.append(newAddr)
            }
        }
    }
    return addresses
}
