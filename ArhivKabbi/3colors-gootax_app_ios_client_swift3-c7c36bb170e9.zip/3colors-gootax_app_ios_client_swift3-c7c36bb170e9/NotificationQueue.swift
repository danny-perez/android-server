//
//  NotificatonQueue.swift
//  UITests
//
//  Created by Andrew Chupin on 28.02.17.
//  Copyright © 2017 Andrew Chupin. All rights reserved.
//

import Foundation
import UIKit

class NotificationQueue: NotificationDelegate {
    
    var value: UINotificationView?
    
    var next: UINotificationView?
    
    var window: UIWindow
    
    init(window: UIWindow) {
        self.window = window
    }
    
    func append(_ element: UINotificationView) {
        if element.message == nil || (element.message.text?.isEmpty)! { return }
        element.deleagte = self
        
        if value == nil {
            show(element)
        }
        else {
            if !(value?.isAttach)! {
                next = element
                self.dequeueValue()
                self.showNext()
            } else {
                next = element
            }
        }
    }
    
    fileprivate func show(_ element: UINotificationView) {
        value = element
        window.addSubview(value!)
        value?.start()
    }
    
    //
    func showNext() {
        if (next != nil) {
            value = next
            show(value!)
            next = nil
        }
        updateWindowState()
    }
    
    func dequeueValue() {
        value?.disappear()
        value = nil
        updateWindowState()
    }
    
    func updateWindowState() {
        if (value == nil && next == nil) {
            window.windowLevel = UIWindowLevelNormal
        } else {
            self.window.windowLevel = UIWindowLevelStatusBar + 1
            self.window.autoresizingMask = [.flexibleHeight, .flexibleHeight]
        }
    }
}
