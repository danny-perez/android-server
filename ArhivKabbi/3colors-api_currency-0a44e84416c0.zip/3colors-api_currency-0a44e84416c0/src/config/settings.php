<?php

return [
    'displayErrorDetails' => (bool)getenv('MY_DEBUG'),
];