0.0.2
  - added popularity setter/getter

0.0.1
  - added population setter/getter

0.0.0
  - initial release
  - basic getters and setters for all fields
