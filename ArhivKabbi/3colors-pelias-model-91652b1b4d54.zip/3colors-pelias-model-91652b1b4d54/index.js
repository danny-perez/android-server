module.exports.Document = require('./Document');
module.exports.createDocumentMapperStream = require('./DocumentMapperStream');
