<?php

return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'cache'                        => [
            'class' => 'yii\redis\Cache',
            'redis' => [
                'hostname' => 'redis-cache.taxi.lcl',
                'port'     => 6379,
                'database' => 0,
            ]
        ],
        'db'    => [
            'class'             => 'yii\db\Connection',
            'dsn'               => 'mysql:host=db2.taxi.lcl;dbname=taxi',
            'username'          => 'taxi',
            'password'          => 'JndfkkeiUSh38Zksf',
            'charset'           => 'utf8',
            'tablePrefix'       => 'tbl_',
        ],
    ],
];

