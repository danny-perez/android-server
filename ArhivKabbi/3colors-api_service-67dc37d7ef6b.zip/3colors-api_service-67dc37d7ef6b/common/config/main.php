<?php

return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
//        'cache' => [
//            'class' => 'yii\caching\FileCache',
//        ],
        'cache'                        => [
            'class' => 'yii\redis\Cache',
            'redis' => [
                'hostname' => '192.168.10.48',
                'port'     => 6379,
                'database' => 0,
            ]
        ],
        'db'    => [
            'class'             => 'yii\db\Connection',
            'charset'           => 'utf8',
            'tablePrefix'       => 'tbl_',
            'enableSchemaCache' => true,
            // configuration for the master
            'dsn'               => 'mysql:host=192.168.10.52;dbname=taxi',
            'username'          => 'api',
            'password'          => 'Toh7BagaeBaemee',
            // common configuration for slaves
            'slaveConfig'       => [
                'username' => 'api',
                'password' => 'Toh7BagaeBaemee',
                'charset'  => 'utf8',
            ],
            // list of slave configurations
            'slaves'            => [
                ['dsn' => 'mysql:host=192.168.10.51;dbname=taxi'],
            ],
        ],
    ],
];
