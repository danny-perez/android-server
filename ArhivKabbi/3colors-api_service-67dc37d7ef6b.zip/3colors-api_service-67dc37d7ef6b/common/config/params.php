<?php

return [
    'adminEmail'                    => 'sup1@gootax.pro',
    'supportEmail'                  => 'sup1@gootax.pro',
    'user.passwordResetTokenExpire' => 3600,
    'nodeApiUrl'                    => "http://192.168.10.54:8087"
];
