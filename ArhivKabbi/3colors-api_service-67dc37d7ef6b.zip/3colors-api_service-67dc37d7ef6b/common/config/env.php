<?php

defined('YII_ENV') or define('YII_ENV', 'prod');
