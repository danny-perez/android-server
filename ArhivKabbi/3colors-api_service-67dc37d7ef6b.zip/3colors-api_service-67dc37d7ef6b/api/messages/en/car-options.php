<?php

return[
    'Conditioner',
    'wi-fi',
    'Big luggage carrier',
    'Child safety chair',
    'Universal',
    'Card payment',
    'Fresh news papers and magazines',
    'Pet transport',
    'Strict report at payment',
    'Taxi checkers',
    'Yellow color',
    'Advertisement on car',
];
