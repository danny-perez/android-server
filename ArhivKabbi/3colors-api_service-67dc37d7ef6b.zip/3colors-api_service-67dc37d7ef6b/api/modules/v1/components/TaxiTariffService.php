<?php

namespace app\modules\v1\components;

use app\models\client_tariff\OptionActiveDate;
use app\models\client_tariff\TaxiTariff;
use app\models\client_tariff\TaxiTariffOption;

class TaxiTariffService
{

    public function getInfo()
    {

    }

    /**
     * Получить тип тарифа по времени
     *
     * @param int    $tariffId
     * @param string $orderTime 23.05.2017 16:33:00
     *
     * @return string $tariffType тип тарифа  ENUM('CURRENT', 'HOLIDAYS', 'EXCEPTIONS')
     */
    public function getAccrualType($tariffId, $orderTime)
    {

        $time           = new \DateTime($orderTime);

        $dateFull       = $time->format('d.m.Y');
        $dateShort      = $time->format('d.m');
        $dayOfWeek      = date('l', strtotime($orderTime));
        $hoursAndMinute = $time->format('H:i');
        $toDay          = [$dayOfWeek, $dateShort, $dateFull];


        $result = TaxiTariffOption::TYPE_CURRENT;

        $records = $this->findOptionActiveDateModel($tariffId);

        if (!empty($records)) {

            foreach ($records as $record) {

                $date = explode('|', $record['active_date']);

                // Игнорируем если день не совпал
                if (!in_array($date[0], $toDay)) {
                    continue;
                }
                $interval = isset($date[1]) ? explode('-', $date[1]) : ['00:00', '23:59'];

                // Игнорируем если не попали в часовой промежуток
                if ($interval[0] > $hoursAndMinute || $interval[1] < $hoursAndMinute) {
                    continue;
                }

                switch ($record['tariff_type']) {
                    case TaxiTariffOption::TYPE_EXCEPTIONS :
                        if ($this->isActiveTariff($tariffId, TaxiTariffOption::TYPE_EXCEPTIONS)) {
                            return TaxiTariffOption::TYPE_EXCEPTIONS;
                        }
                        break;
                    case TaxiTariffOption::TYPE_HOLIDAYS :
                        if ($this->isActiveTariff($tariffId, TaxiTariffOption::TYPE_HOLIDAYS)) {
                            $result = TaxiTariffOption::TYPE_HOLIDAYS;
                        }
                        break;
                }
            }
        }

        return $result;
    }

    protected function findOptionActiveDateModel($tariffId)
    {
        return OptionActiveDate::find()
            ->where(['tariff_id' => $tariffId])
            ->asArray()
            ->all();
    }

    protected function isActiveTariff($tariffId, $tariffType)
    {
        return TaxiTariffOption::find()
            ->where([
                'tariff_id'   => $tariffId,
                'tariff_type' => $tariffType,
            ])
            ->andWhere('active = :active OR active IS NULL', ['active' => TaxiTariff::ACTIVE])
            ->exists();
    }
}