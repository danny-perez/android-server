<?php

namespace app\modules\v1\components\taxiPushComponent;

class TaxiPushAndroid
{

    private $tokenArr;
    private $apiKey;
    private $command;
    private $command_params;
    private $title;
    private $message;
    private $sound;
    private $icon;
    private $url = "https://android.googleapis.com/gcm/send";

    function __construct($tokenArr, $apiKey, $command = null, $command_params = null, $title = null, $message = null, $sound = null, $icon = null)
    {

        if (is_array($tokenArr)) {
            $this->tokenArr = $tokenArr;
        } else {
            $this->tokenArr = array($tokenArr);
        }
        $this->apiKey = $apiKey;
        $this->command = $command;
        $this->command_params = $command_params;
        $this->title = $title;
        $this->message = $message;
        $this->sound = $sound;
        $this->icon = $icon;
    }

    public function sendPush()
    {
        $msg = array
            (
            'message'        => $this->message,
            'tickerText'     => $this->title,
            'sound'          => $this->sound,
            'icon'           => $this->icon,
            'command'        => $this->command,
            'command_params' => $this->command_params
        );

        $fields = array
            (
            'registration_ids' => $this->tokenArr,
            'data'             => $msg
        );

        $fields = json_encode($fields);
        $headers = array(
            'Authorization:key=' . $this->apiKey,
            'Content-Type:application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        $result = curl_exec($ch);

        curl_close($ch);
        $result = json_decode($result);
        if (isset($result->success)) {
            if ($result->success == true) {
                return true;
            }
        }
        return false;
    }

}
