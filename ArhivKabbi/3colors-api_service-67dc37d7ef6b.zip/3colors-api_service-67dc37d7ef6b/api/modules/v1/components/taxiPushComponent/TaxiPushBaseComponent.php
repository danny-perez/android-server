<?php

namespace app\modules\v1\components\taxiPushComponent;

use yii\base\Object;
use Yii;
use api\common\models\Tenant;
/**
 * Компонент для отправки смс
 * @author Сергей К.
 */
class TaxiPushBaseComponent extends Object
{

    public function __construct($config = [])
    {
        parent::__construct($config);
    }

    /**
     * Массовая рассылка пуш уведомлений
     * @param type $tenantId
     * @param type $pushDataArr
     * @param type $title
     * @param type $message
     * @param type $contentAvailable
     * @param type $actionLocKey
     * @param type $category
     * @param type $sound
     * @param type $command
     * @param type $command_params
     * @param type $type_app
     * @return boolean
     */
    public function sendManyPush($tenantId, $pushDataArr, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $command, $command_params, $type_app = "driver")
    {
        $iosArr = array();
        $androidArr = array();
        $winfonArr = array();
        foreach ($pushDataArr as $pushData) {
            switch ($pushData["device"]) {
                case "ios":
                    $iosArr[] = $pushData["device_token"];
                    break;
                case "android":
                    $androidArr[] = $pushData["device_token"];
                    break;
                case "winfon":
                    $winfonArr[] = $pushData["device_token"];
                    break;
                default:
                    break;
            }
        }
        $resultIos = true;
        $resultAndroid = true;
        $resultWinfon = true;
        if (!empty($iosArr)) {
            $iosApiKey = Tenant::getTenantPushApiKey("ios", $tenantId);
            $resultIos = $this->sendPush("ios", $iosApiKey, $iosArr, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $command, $command_params, $type_app);
        }
        if (!empty($androidArr)) {
            $androidApiKey = Tenant::getTenantPushApiKey("android", $tenantId);
            $resultAndroid = $this->sendPush("android", $androidApiKey, $androidArr, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $command, $command_params, $type_app);
        }
        if (!empty($winfonArr)) {
            $winfonApiKey = Tenant::getTenantPushApiKey("winfon", $tenantId);
            $resultWinfon = $this->sendPush("winfon", $winfonApiKey, $winfonArr, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $command, $command_params, $type_app);
        }
        if ($resultIos && $resultAndroid && $resultWinfon) {
            return true;
        } else {
            return false;
        }
    }

    /**
     *
     * @param string(ios/android/winfon)  $device  - тип устройства
     * @param string $apikey - апи кей приложения
     * @param array $tokenArr - массив токенов для рассылки
     * @param string $title - заголовок сообщения
     * @param string $message -сообщение
     * @param string $contentAvailable
     * @param string $actionLocKey - тип экшен для айфона
     * @param string $category  -категория для айфона
     * @param string $sound - звук сообщения
     * @param string $command - команда
     * @param string $command_params - параметры команды
     * @param string $type_app - тип приожения driver/client
     * @return boolean - результат рассылки
     */
    public function sendPush($device, $apikey, $tokenArr, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $command, $command_params, $type_app = "driver")
    {
        $result = false;
        if ($device == 'ios') {
            if ($type_app == "driver") {
                $iosServer = Yii::$app->params['iosDriverPushTypeServer'];
            }
            if ($type_app == "client") {
                $iosServer = Yii::$app->params['iosClientPushTypeServer'];
            }
            $iosPassphrase = null;
            $push = new TaxiPushIos($tokenArr, $apikey, $iosServer, $iosPassphrase, $command, $command_params, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $icon = null);
            $result = $push->sendPush();
        }
        if ($device == 'android') {
            $push = new TaxiPushAndroid($tokenArr, $apikey, $command, $command_params, $title, $message, $sound, $icon = null);
            $result = $push->sendPush();
        }
        return $result;
    }

}
