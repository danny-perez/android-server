<?php

namespace app\modules\v1\components\taxiPushComponent;

/**
 * Класс для отправки пушей на IOS
 */
class TaxiPushIos
{

    private $sandbox = "ssl://gateway.sandbox.push.apple.com:2195";
    private $production = "ssl://gateway.push.apple.com:2195";
    private $tokenArr;
    private $apiKey;
    private $iosPassphrase;
    private $command;
    private $command_params;
    private $title;
    private $message;
    private $contentAvailable;
    private $actionLocKey;
    private $category;
    private $sound;
    private $icon;
    private $url;
    private $fpName;

    /**
     *
     * @param type $tokenArr
     * @param type $apiKey
     * @param type $iosServer
     * @param type $iosPassphrase
     * @param type $command
     * @param type $command_params
     * @param type $title
     * @param type $message
     * @param type $contentAvailable
     * @param type $actionLocKey
     * @param type $category
     * @param type $sound
     * @param type $icon
     * @throws Exception
     */
    function __construct($tokenArr, $apiKey, $iosServer, $iosPassphrase, $command, $command_params, $title, $message, $contentAvailable, $actionLocKey, $category, $sound, $icon)
    {
        if (is_array($tokenArr)) {
            $this->tokenArr = $tokenArr;
        } else {
            $this->tokenArr = array($tokenArr);
        }
        $this->tokenArr = $tokenArr;
        $fpName = tempnam("./ioscert/", "apns-cert");
        $this->fpName = $fpName;
        $fpHandle = fopen($fpName, "w");
        $cert = fwrite($fpHandle, $apiKey);
        fclose($fpHandle);
        $fpNameArr = explode("/", $fpName);
        $fpShortName = array_pop($fpNameArr);
        $this->apiKey = "./ioscert/" . "$fpShortName";
        $this->iosServer = $iosServer;
        $this->iosPassphrase = $iosPassphrase;
        $this->command = $command;
        $this->command_params = $command_params;
        $this->title = $title;
        $this->message = $message;
        $this->contentAvailable = $contentAvailable;
        $this->actionLocKey = $actionLocKey;
        $this->category = $category;
        $this->sound = $sound;
        $this->icon = $icon;
        if ($iosServer != "sandbox" && $iosServer != "production") {
            throw new Exception("Invalid iosServer specified");
        } else {
            if ($iosServer == "sandbox") {
                $this->url = $this->sandbox;
            } else {
                $this->url = $this->production;
            }
        }
    }

    public function sendPush()
    {
        if (is_array($this->tokenArr)) {
            $i = 0;
            $countOk = 0;
            foreach ($this->tokenArr as $token) {
                $result = $this->sendNotification($token, $i);
                $countOk = $countOk + $result;
                $i++;
            }
            unlink($this->fpName);
            if ($i == $countOk) {
                return true;
            } else {
                return false;
            }
        } else {
            $result = $this->sendNotification($this->tokenArr, 1);
            unlink($this->fpName);
            return ($result == 1) ? true : false;
        }
    }

    private function sendNotification($token, $i)
    {
        $ctx = stream_context_create();
        stream_context_set_option($ctx, 'ssl', 'local_cert', $this->apiKey);


        if (!empty($this->passphrase)) {
            stream_context_set_option($ctx, 'ssl', 'passphrase', $this->passphrase);
        }
        $sp = @stream_socket_client($this->url, $err, $errstr, 15, (STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT), $ctx);
        if (!$sp) return 0;
        $alert = null;
        if (isset($this->title) || isset($this->message) || isset($this->actionLocKey)) {
            $alert = array(
                'title'          => $this->title,
                'body'           => $this->message,
                'action-loc-key' => $this->actionLocKey,
            );
        }
        $payload = array();
        $payload['aps'] = array(
            'command'           => $this->command,
            'command_params'    => $this->command_params,
            'alert'             => $alert,
            'badge'             => 0,
            'content-available' => $this->contentAvailable,
            'sound'             => $this->sound,
            'category'          => $this->category
        );
        $output = json_encode($payload);
        $msg = chr(0) . pack('n', 32) . @pack('H*', $token) . pack('n', strlen($output)) . $output;
        $result = @fwrite($sp, $msg, strlen($msg));
        fclose($sp);
        if (!$result) {
            return 0;
        } else return 1;
    }

}
