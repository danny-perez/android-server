<?php

namespace app\modules\v1\components\routeAnalyzerNew\exceptions;

use yii\base\Exception;

class LimitAddressPoints extends Exception
{

}