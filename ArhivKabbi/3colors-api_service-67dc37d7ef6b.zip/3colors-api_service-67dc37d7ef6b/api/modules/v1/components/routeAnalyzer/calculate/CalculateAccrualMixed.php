<?php

namespace app\modules\v1\components\routeAnalyzer\calculate;

use app\modules\v1\components\routeAnalyzer\route\Point;
use app\modules\v1\components\routeAnalyzer\route\Route;
use app\modules\v1\components\routeAnalyzer\route\RouteItem;
use app\modules\v1\components\routeAnalyzer\TariffInfo;

class CalculateAccrualMixed extends BaseCalculate
{

    /**
     * @inheritdoc
     */
    public function execute($route, $tariffInfo, $type)
    {
        $costAsTime = $this->calculateAsTime($route, $tariffInfo, $type);

        $costAsDistance = $this->calculateAsDistance($route, $tariffInfo, $type);

        return $costAsTime + $costAsDistance;
    }

    /**
     * @param Route $route
     * @param TariffInfo $tariffInfo
     * @param string $type
     *
     * @return float
     */
    protected function calculateAsTime($route, $tariffInfo, $type)
    {
        $time = 0;
        $cost = 0;
        /** @var RouteItem $routeItem */
        foreach ($route->items as $routeItem) {
            if ($this->isAirportItem($routeItem, $tariffInfo) || $this->isStationItem($routeItem, $tariffInfo)) {
                continue;
            }

            switch ($type) {
                case Point::TYPE_CITY:
                    $time += $routeItem->getCityTime();
                    break;
                case Point::TYPE_TRACK:
                    $time += $routeItem->getTrackTime();
                    break;
            }
        }

        // Вычитаем "включено в стоимость посадки"
        if ($route->getStartPointType() === $type) {
            $plantingInclude = $tariffInfo->getPlantingIncludeTime($type);
            $plantingInclude = (int)$plantingInclude * 60;
            $time            -= $plantingInclude;
            $time            = $time < 0 ? 0 : $time;
        }

        $nextCostUnit = $tariffInfo->getNextCostUnit($type);
        $nextKmPrice  = $tariffInfo->getNextKmPriceTime($type);

        $roundingTime = ceil($time / $nextCostUnit);
        $cost = $roundingTime * $nextKmPrice;

        return $cost;
    }

    /**
     * @param Route $route
     * @param TariffInfo $tariffInfo
     * @param string $type
     *
     * @return float
     */
    protected function calculateAsDistance($route, $tariffInfo, $type)
    {
        return (new CalculateAccrualDistance())->execute($route, $tariffInfo, $type);
    }
}