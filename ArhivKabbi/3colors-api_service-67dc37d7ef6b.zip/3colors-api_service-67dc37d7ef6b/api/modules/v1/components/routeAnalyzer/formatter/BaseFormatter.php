<?php

namespace app\modules\v1\components\routeAnalyzer\formatter;

use app\modules\v1\components\routeAnalyzer\route\Point;

class BaseFormatter implements FormatterInterface
{
    public static function formatter($data)
    {
        $result = [
            'additionalCost'      => (float)$data['additionalCost'],
            'additionalParking'   => (array)$data['additionalParking'],
            'cityCost'            => (float)$data['cityCost'],
            'cityDistance'        => (float)(ceil($data['cityDistance'] / 100) / 10),
            'cityTime'            => (int)ceil($data['cityTime'] / 60),
            'isFix'               => (bool)$data['isFix'],
            'isAirport'           => (bool)$data['isAirport'],
            'isStation'           => (bool)$data['isStation'],
            'finishPointLocation' => $data['finishPointLocation'] == Point::TYPE_CITY ? self::POINT_IN : self::POINT_OUT,
            'minPrice'            => (float)$data['minPrice'],
            'outCityCost'         => (float)$data['outCityCost'],
            'outCityDistance'     => (float)(ceil($data['outCityDistance'] / 100) / 10),
            'outCityTime'         => (int)ceil($data['outCityTime'] / 60),
            'routeLine'           => (array)$data['routeLine'],
            'startPointLocation'  => $data['startPointLocation'] == Point::TYPE_CITY ? self::POINT_IN : self::POINT_OUT,
            'summaryCost'         => (float)$data['summaryCost'],
            'summaryDistance'     => (float)(ceil($data['summaryDistance'] / 100) / 10),
            'summaryTime'         => (int)ceil($data['summaryTime'] / 60),
            'tariffInfo'          => self::formatterTariffInfo($data['tariffInfo']),
//            '_dev'                => $data['_dev'],
        ];

        return $result;
    }

    protected static function formatterTariffInfo($tariffInfo)
    {
        return [
            'tariffType'      => $tariffInfo->tariffType,
            'tariffDataCity'  => $tariffInfo->tariffDataCity,
            'tariffDataTrack' => $tariffInfo->tariffDataTrack,
            'isDay'           => (int)$tariffInfo->isDay,
        ];
    }
}