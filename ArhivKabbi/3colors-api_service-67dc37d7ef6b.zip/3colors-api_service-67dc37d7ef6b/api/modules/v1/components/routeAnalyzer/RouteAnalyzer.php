<?php

namespace app\modules\v1\components\routeAnalyzer;

use api\common\models\AdditionalOption;
use app\models\client_tariff\TaxiTariff;
use app\models\client_tariff\TaxiTariffOption;
use app\modules\v1\components\routeAnalyzer\route\Route;
use yii\base\Object;
use yii\helpers\ArrayHelper;

class RouteAnalyzer extends Object
{
    public $tenantId;
    public $cityId;
    public $address;
    public $route;
    public $additional;
    public $lang;
    public $tariffId;
    public $orderTime;
    public $geocoderType;

    protected $_tariff = null;
    protected $tariffInfo;


    public function __construct(array $config = [])
    {

        parent::__construct($config);

        $this->tenantId = (int)$this->tenantId;
        $this->cityId   = (int)$this->cityId;
        $this->tariffId = (int)$this->tariffId;

    }

    public function execute()
    {
        $this->_tariff = $this->getTariff();
        $tariffType    = \Yii::$app->get('taxiTariffService')->getAccrualType($this->tariffId, $this->orderTime);

        switch ($tariffType) {
            case TaxiTariffOption::TYPE_EXCEPTIONS:
                $tariffDataCity    = $this->_tariff->exceptionAreaCityOption;
                $tariffDataTrack   = $this->_tariff->exceptionAreaTrackOption;
                $tariffDataAirport = $this->_tariff->exceptionAreaAirportOption;
                $tariffDataStation = $this->_tariff->exceptionAreaStationOption;
                break;
            case TaxiTariffOption::TYPE_HOLIDAYS:
                $tariffDataCity    = $this->_tariff->holidaysAreaCityOption;
                $tariffDataTrack   = $this->_tariff->holidaysAreaTrackOption;
                $tariffDataAirport = $this->_tariff->holidaysAreaAirportOption;
                $tariffDataStation = $this->_tariff->holidaysAreaStationOption;
                break;
            case TaxiTariffOption::TYPE_CURRENT:
            default:
                $tariffDataCity    = $this->_tariff->currentAreaCityOption;
                $tariffDataTrack   = $this->_tariff->currentAreaTrackOption;
                $tariffDataAirport = $this->_tariff->currentAreaAirportOption;
                $tariffDataStation = $this->_tariff->currentAreaStationOption;
        }

        $this->route = Route::make($this->address);


        $response = new RouteAnalyzerResponse([
            'tariffInfo' => new TariffInfo([
                'tariffType'        => $tariffType,
                'tariffDataCity'    => $tariffDataCity,
                'tariffDataTrack'   => $tariffDataTrack,
                'tariffDataAirport' => $tariffDataAirport,
                'tariffDataStation' => $tariffDataStation,
            ]),
            'orderTime'  => $this->orderTime,
            'route'      => $this->route,
            'additionalCost' => $this->getAdditionalCost($tariffType),
        ]);

        $response->calculate();


//        return $response;
        return $response->formatter();
    }


    /**
     * Получить тариф
     *
     * @return TaxiTariff
     * @throws TariffNotFoundException
     */
    protected function getTariff()
    {
        /** @var TaxiTariff $tariff */
        $tariff = TaxiTariff::find()
            ->joinWith([])
            ->where([
                'tariff_id' => $this->tariffId,
                'tenant_id' => $this->tenantId,
            ])
            ->one();

        if (!$tariff) {
            throw new TariffNotFoundException();
        }

        return $tariff;
    }

    protected function getAdditionalCost($type)
    {

        $models = $this->findAdditionalModels($type, $this->additional);

        $array = ArrayHelper::getColumn($models, 'price');

        return array_sum($array);
    }

    protected function findAdditionalModels($type, $additional)
    {
        return AdditionalOption::find()
            ->where([
                'tariff_id' => $this->tariffId,
                'additional_option_id' => $additional,
                'tariff_type' => $type,
            ])
            ->all();
    }
}