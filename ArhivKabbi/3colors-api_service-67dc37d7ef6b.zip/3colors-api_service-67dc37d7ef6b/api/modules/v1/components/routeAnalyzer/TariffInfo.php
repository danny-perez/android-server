<?php

namespace app\modules\v1\components\routeAnalyzer;

use app\models\client_tariff\TaxiTariffOption;
use app\modules\v1\components\routeAnalyzer\route\Point;
use yii\base\Object;

class TariffInfo extends Object
{
    public $isDay;
    public $tariffType;
    public $tariffDataCity;
    public $tariffDataTrack;
    public $tariffDataAirport;
    public $tariffDataStation;

    public function setIsDay($orderTime)
    {
        $allowDayNight = $this->tariffDataCity->allow_day_night;
        $startDay      = $this->tariffDataCity->start_day;
        $endDay        = $this->tariffDataCity->end_day;

        if ($allowDayNight != 1 || empty($startDay) || empty($endDay)) {
            $this->isDay = true;
            return;
        }

        $orderDate = new \DateTime($orderTime);
        $orderTime = (int)($orderDate->format('H') * 60 + $orderDate->format('i'));
        $startDay  = explode(':', $startDay);
        $startTime = (int)($startDay[0] * 60 + $startDay[1]);
        $endDay    = explode(':', $endDay);
        $endTime   = (int)($endDay[0] * 60 + $endDay[1]);

        if ($startTime < $endTime) {
            if ($startTime <= $orderTime && $orderTime < $endTime) {
                $this->isDay = true;
            } else {
                $this->isDay = false;
            }
        } else {
            if ($endTime <= $orderTime && $orderTime < $startTime) {
                $this->isDay = false;
            } else {
                $this->isDay = true;
            }
        }
    }

    public function getPlantingPrice($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->planting_price_day : $this->tariffDataCity->planting_price_night;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->planting_price_day : $this->tariffDataTrack->planting_price_night;
        }

        return 0;
    }

    public function getPlantingInclude($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->planting_include_day : $this->tariffDataCity->planting_include_night;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->planting_include_day : $this->tariffDataTrack->planting_include_night;
        }

        return 0;
    }

    public function getPlantingIncludeTime($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->planting_include_day_time : $this->tariffDataCity->planting_include_night_time;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->planting_include_day_time : $this->tariffDataTrack->planting_include_night_time;
        }

        return 0;
    }

    public function getNextKmPrice($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->next_km_price_day : $this->tariffDataCity->next_km_price_night;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->next_km_price_day : $this->tariffDataTrack->next_km_price_night;
        }

        return 0;
    }

    public function getNextKmPriceTime($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->next_km_price_day_time : $this->tariffDataCity->next_km_price_night_time;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->next_km_price_day_time : $this->tariffDataTrack->next_km_price_night_time;
        }

        return 0;
    }


    public function getNextCostUnit($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                $result = $this->isDay ? $this->tariffDataCity->next_cost_unit_day : $this->tariffDataCity->next_cost_unit_night;
                break;
            case Point::TYPE_TRACK:
                $result = $this->isDay ? $this->tariffDataTrack->next_cost_unit_day : $this->tariffDataTrack->next_cost_unit_night;
                break;
            default:
                $result = null;
        }

        switch ($result) {
            case TaxiTariffOption::COST_UNIT_1_MINUTE:
                return 60;
            case TaxiTariffOption::COST_UNIT_30_MINUTE:
                return 30 * 60;
            case TaxiTariffOption::COST_UNIT_1_HOUR:
                return 60 * 60;
        }

        return 0;
    }

    public function getRounding($type)
    {
        $rounding = TaxiTariffOption::DEFAULT_ROUNDING;
        switch ($type) {
            case Point::TYPE_CITY:
                $rounding = $this->isDay ? $this->tariffDataCity->rounding_day : $this->tariffDataCity->rounding_night;
                break;
            case Point::TYPE_TRACK:
                $rounding = $this->isDay ? $this->tariffDataTrack->rounding_day : $this->tariffDataTrack->rounding_night;
                break;
        }

        $rounding = $rounding == 0 ? TaxiTariffOption::DEFAULT_ROUNDING : $rounding;
        return $rounding;
    }

    public function getRoundingType($type)
    {
        $roundingType = TaxiTariffOption::ROUNDING_TYPE_ROUND;
        switch ($type) {
            case Point::TYPE_CITY:
                $roundingType = $this->isDay ? $this->tariffDataCity->rounding_type_day : $this->tariffDataCity->rounding_type_night;
                break;
            case Point::TYPE_TRACK:
                $roundingType = $this->isDay ? $this->tariffDataTrack->rounding_type_day : $this->tariffDataTrack->rounding_type_night;
                break;
        }

        return $roundingType;
    }

    public function getMinPrice($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->min_price_day : $this->tariffDataCity->min_price_night;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->min_price_day : $this->tariffDataTrack->min_price_night;
        }

        return 0;
    }

    public function getSecondMinPrice($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->isDay ? $this->tariffDataCity->second_min_price_day : $this->tariffDataCity->second_min_price_night;
            case Point::TYPE_TRACK:
                return $this->isDay ? $this->tariffDataTrack->second_min_price_day : $this->tariffDataTrack->second_min_price_night;
        }

        return 0;
    }

    public function getCalculationFix($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->tariffDataCity->calculation_fix;
            case Point::TYPE_TRACK:
                return $this->tariffDataTrack->calculation_fix;
        }

        return 0;
    }

    public function getEnabledParkingRatio($type)
    {
        switch ($type) {
            case Point::TYPE_CITY:
                return $this->tariffDataCity->enabled_parking_ratio;
            case Point::TYPE_TRACK:
                return $this->tariffDataTrack->enabled_parking_ratio;
        }

        return 0;
    }
}