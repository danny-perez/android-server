<?php

namespace app\modules\v1\components\routeAnalyzer;

use api\common\models\Parking;
use app\models\client_tariff\TaxiTariffOption;
use app\modules\v1\components\routeAnalyzer\calculate\CalculateAccrualAirport;
use app\modules\v1\components\routeAnalyzer\calculate\CalculateAccrualStation;
use app\modules\v1\components\routeAnalyzer\calculate\CalculateFactory;
use app\modules\v1\components\routeAnalyzer\formatter\BaseFormatter;
use app\modules\v1\components\routeAnalyzer\route\Point;
use app\modules\v1\components\routeAnalyzer\route\Route;
use yii\base\Object;

/**
 * Class RouteAnalyzerResponse
 * @package app\modules\v1\components\routeAnalyzer
 *
 * @property TariffInfo $tariffInfo
 * @property Route      $route
 * @property string     $orderTime
 */
class RouteAnalyzerResponse extends Object
{
    public $tariffInfo;
    public $route;
    public $orderTime;
    public $additionalCost;

    protected $isFix = false;
    protected $cityCost;
    protected $trackCost;
    protected $summaryCost;
    protected $isAirport;
    protected $isStation;
    protected $district;

    protected $_dev;

    const DISTRICT_TYPE_PERCENT = 'PERCENT';
    const DISTRICT_TYPE_MONEY = 'MONEY';

    public function init()
    {
        $this->tariffInfo->setIsDay($this->orderTime);
    }

    public function calculate()
    {

        $calculateAirport = new CalculateAccrualAirport();
        $response         = $calculateAirport->execute($this->route, $this->tariffInfo);
        $airportCost      = $response;

        $calculateStation = new CalculateAccrualStation();
        $response         = $calculateStation->execute($this->route, $this->tariffInfo);
        $stationCost      = $response;

        $calculateTrack = CalculateFactory::getFactory($this->tariffInfo->tariffDataTrack->accrual);
        $response       = $calculateTrack->execute($this->route, $this->tariffInfo, Point::TYPE_TRACK);
        $trackCost      = $response;

        if ($this->tariffInfo->tariffDataTrack->accrual === TaxiTariffOption::ACCRUAL_FIX && $this->route->getIsTrack()) {
            $cityCost    = 0;
            $this->isFix = true;
        } else {
            $calculateCity = CalculateFactory::getFactory($this->tariffInfo->tariffDataCity->accrual);
            $response      = $calculateCity->execute($this->route, $this->tariffInfo, Point::TYPE_CITY);
            $cityCost      = $response;
            if ($this->tariffInfo->tariffDataCity->accrual === TaxiTariffOption::ACCRUAL_FIX && $this->route->getIsCity()) {
                $this->isFix = true;
            }
        }


        $rounding = $this->tariffInfo->getRounding($this->route->getFinishPointType());
        $roundingType = $this->tariffInfo->getRoundingType($this->route->getFinishPointType());
        $minPrice = $this->getMinPrice();

        $enabledParkingRatio = $this->tariffInfo->getEnabledParkingRatio($this->route->getStartPointType());
        $district            = ($enabledParkingRatio === 1) ? $this->route->getDistinctValues() : $this->route->getDistinctDefaultValues();

        $summaryCost = $cityCost + $trackCost + $airportCost + $stationCost;
        $summaryCost = $summaryCost * $district[Parking::DISTRICT_TYPE_PERCENT] / 100 + $district[Parking::DISTRICT_TYPE_MONEY];
        $summaryCost += $this->additionalCost;

        switch ($roundingType) {
            case TaxiTariffOption::ROUNDING_TYPE_FLOOR:
                $summaryCost = floor($summaryCost / $rounding) * $rounding;
                break;

            case TaxiTariffOption::ROUNDING_TYPE_CEIL:
                $summaryCost = ceil($summaryCost / $rounding) * $rounding;
                break;

            default:
                $summaryCost = round($summaryCost / $rounding) * $rounding;
        }

        if ($calculateAirport->getIsAirport() || $calculateStation->getIsStation()) {
            $this->isFix = true;
        } else {
            $summaryCost = $summaryCost < $minPrice ? $minPrice : $summaryCost;
        }

        if($this->tariffInfo->tariffDataTrack->calculation_fix === 1 && $this->tariffInfo->tariffDataCity->calculation_fix === 1) {
            $this->isFix = true;
        }

        $this->cityCost    = $cityCost;
        $this->trackCost   = $trackCost;
        $this->summaryCost = $summaryCost;
        $this->isAirport   = $calculateAirport->getIsAirport();
        $this->isStation   = $calculateStation->getIsStation();
        $this->district    = $district;
    }


    public function getMinPrice()
    {
        $minPrice = $this->tariffInfo->getMinPrice($this->route->getFinishPointType());

        $calculationFix = $this->tariffInfo->getCalculationFix($this->route->getFinishPointType());
        $secondMinPrice = ($calculationFix === 1) ? $this->tariffInfo->getSecondMinPrice($this->route->getFinishPointType()) : 0;

        $count = count($this->route->items);

        return $minPrice + $secondMinPrice * ($count - 1);
    }

    public function formatter()
    {
        $data = [
            'additionalCost'      => $this->additionalCost,
            'additionalParking'   => $this->district,
            'cityCost'            => $this->cityCost,
            'cityDistance'        => $this->route->getCityDistance(),
            'cityTime'            => $this->route->getCityTime(),
            'isFix'               => $this->isFix,
            'isAirport'           => $this->isAirport,
            'isStation'           => $this->isStation,
            'finishPointLocation' => $this->route->getFinishPointType(),
            'minPrice'            => $this->getMinPrice(),
            'outCityCost'         => $this->trackCost,
            'outCityDistance'     => $this->route->getTrackDistance(),
            'outCityTime'         => $this->route->getTrackTime(),
            'routeLine'           => $this->route->getInterval(),
            'startPointLocation'  => $this->route->getStartPointType(),
            'summaryCost'         => $this->summaryCost,
            'summaryDistance'     => $this->route->getSummaryDistance(),
            'summaryTime'         => $this->route->getSummaryTime(),
            'tariffInfo'          => $this->tariffInfo,
            '_dev'                => $this->_dev,
        ];

        return BaseFormatter::formatter($data);
    }

}