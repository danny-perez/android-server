<?php

namespace app\modules\v1\components\routeAnalyzer\calculate;

use app\models\client_tariff\TaxiTariffOption;

class CalculateFactory
{
    /**
     * @param $accrual
     *
     * @return BaseCalculate|null
     */
    public static function getFactory($accrual) {
        switch ($accrual) {
            case TaxiTariffOption::ACCRUAL_FIX:
                return new CalculateAccrualFix();
            case TaxiTariffOption::ACCRUAL_TIME:
                return new CalculateAccrualTime();
            case TaxiTariffOption::ACCRUAL_DISTANCE:
                return new CalculateAccrualDistance();
            case TaxiTariffOption::ACCRUAL_MIXED:
                return new CalculateAccrualMixed();
            case TaxiTariffOption::ACCRUAL_INTERVAL:
                return new CalculateAccrualInterval();
        }

        return null;
    }
}