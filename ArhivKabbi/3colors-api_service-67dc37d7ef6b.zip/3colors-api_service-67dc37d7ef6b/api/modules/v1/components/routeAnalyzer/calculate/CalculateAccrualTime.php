<?php

namespace app\modules\v1\components\routeAnalyzer\calculate;

use app\modules\v1\components\routeAnalyzer\route\Point;
use app\modules\v1\components\routeAnalyzer\route\RouteItem;

class CalculateAccrualTime extends BaseCalculate
{
    /**
     * @inheritdoc
     */
    public function execute($route, $tariffInfo, $type)
    {
        $time = 0;

        /** @var RouteItem $routeItem */
        foreach ($route->items as $routeItem) {
            if ($this->isAirportItem($routeItem, $tariffInfo) || $this->isStationItem($routeItem, $tariffInfo)) {
                continue;
            }

            switch ($type) {
                case Point::TYPE_CITY:
                    $time += $routeItem->getCityTime();
                    break;
                case Point::TYPE_TRACK:
                    $time += $routeItem->getTrackTime();
                    break;
            }
        }

        // Вычитаем "включено в стоимость посадки"
        if ($route->getStartPointType() === $type) {
            $plantingInclude = $tariffInfo->getPlantingInclude($type);
            $plantingInclude = (int)$plantingInclude * 60;
            $time            -= $plantingInclude;
            $time            = $time < 0 ? 0 : $time;
            $this->cost      += $tariffInfo->getPlantingPrice($type);
        }

        $nextCostUnit = $tariffInfo->getNextCostUnit($type);
        $nextKmPrice  = $tariffInfo->getNextKmPrice($type);

        $roundingTime = ceil($time / $nextCostUnit);

        $this->cost += $roundingTime * $nextKmPrice;

        return $this->cost;
    }

}