<?php

namespace app\modules\v1\components\routeAnalyzer;

use yii\base\Exception;

class TariffNotFoundException extends Exception
{

}