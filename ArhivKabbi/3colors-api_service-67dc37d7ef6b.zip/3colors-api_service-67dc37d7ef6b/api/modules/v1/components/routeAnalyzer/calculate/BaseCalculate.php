<?php

namespace app\modules\v1\components\routeAnalyzer\calculate;

use app\modules\v1\components\routeAnalyzer\route\Route;
use app\modules\v1\components\routeAnalyzer\route\RouteItem;
use app\modules\v1\components\routeAnalyzer\TariffInfo;
use yii\base\Object;

abstract class BaseCalculate extends Object
{
    protected $cost = 0;

    /**
     * @param Route      $route
     * @param TariffInfo $tariffInfo
     * @param string     $type
     *
     * @return float
     */
    public function execute($route, $tariffInfo, $type)
    {

    }

    /**
     * @param RouteItem  $routeItem
     * @param TariffInfo $tariffInfo
     *
     * @return bool
     */
    protected function isAirportItem($routeItem, $tariffInfo)
    {
        if ($tariffInfo->tariffDataAirport && $routeItem->getIsAirport()) {

            $optionId      = $tariffInfo->tariffDataAirport->option_id;
            $fromParkingId = $routeItem->startPoint->getParkingId();
            $toParkingId   = $routeItem->finishPoint->getParkingId();

            $cost = \Yii::$app->get('parkingService')->getFix($optionId, $fromParkingId, $toParkingId);

            if ($cost === 0) {
                return false;
            }

            return true;
        }

        return false;
    }

    /**
     * @param RouteItem  $routeItem
     * @param TariffInfo $tariffInfo
     *
     * @return bool
     */
    protected function isStationItem($routeItem, $tariffInfo)
    {
        if ($tariffInfo->tariffDataStation && $routeItem->getIsStation()) {

            $optionId      = $tariffInfo->tariffDataStation->option_id;
            $fromParkingId = $routeItem->startPoint->getParkingId();
            $toParkingId   = $routeItem->finishPoint->getParkingId();

            $cost = \Yii::$app->get('parkingService')->getFix($optionId, $fromParkingId, $toParkingId);

            if ($cost === 0) {
                return false;
            }

            return true;
        }

        return false;
    }

}
