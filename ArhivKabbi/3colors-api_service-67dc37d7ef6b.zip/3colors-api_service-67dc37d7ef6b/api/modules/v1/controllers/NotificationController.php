<?php

namespace app\modules\v1\controllers;

use api\common\models\Currency;
use api\common\models\Order;
use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use api\common\models\Tenant;
use api\common\models\OrderStatus;
use api\common\models\Client;
use app\modules\v1\models\SmsModel;

/**
 * Middlware для работы с уведомлениями (push,sms,call), обновление бейджиков заказов,
 *
 * @author Sergey K.
 */
class NotificationController extends Controller
{

    public function behaviors()
    {
        return [
            'verbs' => [
                'class'   => VerbFilter::className(),
                'actions' => [
                    'ping'                             => ['get'],
                    'update_dispatcher_order_counters' => ['get'],
                    'send_sms_notification_for_client' => ['get'],
                ],
            ],
        ];
    }

    public function init()
    {
        parent::init();
    }

    /**
     * Оновления счетчиков заказов у диспетчера. Вызывается nodejs api
     * @params status_id
     * @params tenant_id
     * @params city_id
     */ public function actionUpdate_dispatcher_order_counters()
    {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $tenantId = Yii::$app->request->get('tenant_id');
        $statusId = Yii::$app->request->get('status_id');
        $cityId = Yii::$app->request->get('city_id');
        $inc = (string) Yii::$app->request->get('inc');
        if (empty($inc)) {
            $inc = "1";
        }
        OrderStatus::updateDispatcherOrderCounters($statusId, $tenantId, $cityId, $inc);
        $response = array(
            'result' => 1,
        );
        return $response;
    }

    /**
     * Обновления счетчиков заказов у клиента.Вызывается nodejs api
     * @params tenant_id
     * @params client_id
     * @params status_id
     */
    public function actionUpdate_client_order_counters()
    {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $statusId = Yii::$app->request->get('status_id');
        $clientId = Yii::$app->request->get('client_id');
        $response = array(
            'result' => (int)Client::updateClientOrderCounters($clientId, $statusId),
        );
        return $response;
    }

    /**
     * Отправка смс уведомелния клиенту. Вызывается nodejs api
     * @params tenant_id
     * @params phone
     * @params status_id
     * @params order_id
     * @params city_id
     */
    public function actionSend_sms_notification_for_client()
    {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $tenantId = Yii::$app->request->get('tenant_id');
        $statusId = Yii::$app->request->get('status_id');
        $phone = Yii::$app->request->get('phone');
        $orderId = Yii::$app->request->get('order_id');
        $cityId = Yii::$app->request->get('city_id');
        $sendResult = SmsModel::sendSmsNotification($tenantId, $phone, $statusId, $orderId, $cityId);

        return [
            'result' => $sendResult ? 1 : 0,
        ];
    }


    public function actionSend_password_for_client()
    {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

        $tenantId = Yii::$app->request->get('tenant_id');
        $phone = Yii::$app->request->get('phone');
        $cityId = Yii::$app->request->get('city_id');
        $positionId = Yii::$app->request->get('position_id', 1);

        $sendResult = SmsModel::sendPassword($tenantId, $phone, $cityId, $positionId);

        return [
            'result' => $sendResult ? 1 : 0,
        ];
    }

    /**
     * Функция перевода на другой язык
     * @param type $category
     * @param type $message
     * @param type $params
     * @param type $language
     * @return type
     */
    private function t($category, $message, $params = [], $language = null)
    {
        return Yii::t($category, $message, $params, $language);
    }

    /**
     * Получить язык
     * @return type
     */
    private function getLang()
    {
        $headersObject = Yii::$app->request->getHeaders();
        $headers = $headersObject->toArray();
        $lang = isset($headers['lang']['0']) ? $headers['lang']['0'] : null;
        return $lang;
    }

    /**
     * Получение ID тенанта по его логину, результат кэшим на сутки
     * @param type $tenantLogin
     * @return type
     */
    private function getTenantId($tenantLogin)
    {
        $tenantData = Tenant::getDb()->cache(function ($db) use ($tenantLogin) {
            return Tenant::find()
                    ->where(['domain' => $tenantLogin])
                    ->asArray()
                    ->one();
        }, 60 * 60 * 24);
        if (!empty($tenantData)) {
            return $tenantData['tenant_id'];
        }
        return null;
    }

}