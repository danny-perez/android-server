<?php

namespace app\modules\v1\models;

use app\modules\v1\components\SmsTemplateService;
use Yii;
use app\models\order\OrderService;
use yii\helpers\ArrayHelper;

/**
 * Class SmsModel
 * @package app\modules\v1\models
 */
class SmsModel extends \yii\base\Model
{

    /**
     * Отправка SMS уведомления клиенту о статусе заказа
     *
     * @param int    $tenantId
     * @param string $phone
     * @param int    $statusId
     * @param int    $orderId
     * @param int    $cityId
     *
     * @return boolean
     */
    public static function sendSmsNotification($tenantId, $phone, $statusId, $orderId, $cityId)
    {
        $order_data  = OrderService::getOrder($tenantId, $orderId);

        $cityId = empty($cityId) ? ArrayHelper::getValue($order_data, 'city_id') : $cityId;

        $smsTemplateService = new SmsTemplateService();
        $templateText       = $smsTemplateService->getSmsMessage($tenantId, $cityId, $phone, $statusId,
            $order_data['position_id'], $order_data);

        if (empty($templateText)) {
            return false;
        }

        $smsComponent = Yii::$app->sms_v1;

        return (bool)$smsComponent->sendSms($tenantId, $cityId, $phone, $templateText);
    }

    public static function sendPassword($tenantId, $phone, $cityId, $positionId)
    {
        $smsTemplateService = new SmsTemplateService();
        $templateText       = $smsTemplateService->getSmsMessage($tenantId, $cityId, $phone, 'CODE',
            $positionId, ['tenant_id' => $tenantId]);

        if (empty($templateText)) {
            return false;
        }

        $smsComponent = Yii::$app->sms_v1;

        return (bool)$smsComponent->sendSms($tenantId, $cityId, $phone, $templateText);
    }

}