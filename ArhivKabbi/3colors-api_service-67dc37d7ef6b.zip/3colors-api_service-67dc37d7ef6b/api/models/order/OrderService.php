<?php

namespace app\models\order;

use api\common\models\Order;
use yii\base\Object;
use yii\helpers\ArrayHelper;

class OrderService extends Object
{

    public static function getOrder($tenant_id, $order_id)
    {
        $order_data = \Yii::$app->redis_orders_active->executeCommand('HGET', [$tenant_id, $order_id]);
        $order_data = unserialize($order_data);

        if ($order_data) {
            $result = [
                'order_id'       => (int)ArrayHelper::getValue($order_data, 'order_id'),
                'tenant_id'      => (int)ArrayHelper::getValue($order_data, 'tenant_id'),
                'city_id'        => (int)ArrayHelper::getValue($order_data, 'city_id'),
                'address'        => (string)ArrayHelper::getValue($order_data, 'address'),
                'time_to_client' => (int)ArrayHelper::getValue($order_data, 'time_to_client'),
                'currency_id'    => (int)ArrayHelper::getValue($order_data, 'currency_id'),
                'order_time'     => (int)ArrayHelper::getValue($order_data, 'order_time'),
                'position_id'    => (int)ArrayHelper::getValue($order_data, 'position_id'),
                'client'         => [
                    'lang' => ArrayHelper::getValue($order_data, 'client.lang', 'en'),
                ],
                'tariff'         => [
                    'class_id' => !empty($order_data['tariff']['class_id']) ? (int)$order_data['tariff']['class_id'] : '',
                ],
                'worker'         => [
                    'phone'          => ArrayHelper::getValue($order_data, 'worker.phone', ''),
                    'tenant_company' => [
                        'name'  => ArrayHelper::getValue($order_data, 'worker.tenant_company.name', ''),
                        'phone' => ArrayHelper::getValue($order_data, 'worker.tenant_company.phone', ''),
                    ],
                ],
                'car'            => [
                    'name'       => ArrayHelper::getValue($order_data, 'car.name', ''),
                    'color'      => ArrayHelper::getValue($order_data, 'car.color', ''),
                    'gos_number' => ArrayHelper::getValue($order_data, 'car.gos_number', ''),
                    'brand'      => ArrayHelper::getValue($order_data, 'car.brand', ''),
                    'model'      => ArrayHelper::getValue($order_data, 'car.model', ''),
                ],
            ];
        } else {
            $order_data = Order::find()
                ->where([
                    'order_id'  => $order_id,
                    'tenant_id' => $tenant_id,
                ])
                ->with('client', 'tariff', 'car', 'car.color', 'worker', 'tenantCompany')
                ->asArray()
                ->one();

            $result = [
                'order_id'       => (int)ArrayHelper::getValue($order_data, 'order_id'),
                'tenant_id'      => (int)ArrayHelper::getValue($order_data, 'tenant_id'),
                'city_id'        => (int)ArrayHelper::getValue($order_data, 'city_id'),
                'address'        => (string)ArrayHelper::getValue($order_data, 'address'),
                'time_to_client' => (int)ArrayHelper::getValue($order_data, 'time_to_client'),
                'currency_id'    => (int)ArrayHelper::getValue($order_data, 'currency_id'),
                'order_time'     => (int)ArrayHelper::getValue($order_data, 'order_time'),
                'position_id'    => (int)ArrayHelper::getValue($order_data, 'position_id'),
                'client'         => [
                    'lang' => (string)ArrayHelper::getValue($order_data, 'client.lang', 'en'),
                ],
                'tariff'         => [
                    'class_id' => (int)ArrayHelper::getValue($order_data, 'tariff.class_id', 'en'),
                ],
                'worker'         => [
                    'phone'          => (int)ArrayHelper::getValue($order_data, 'worker.phone', ''),
                    'tenant_company' => [
                        'name'  => ArrayHelper::getValue($order_data, 'tenant_company.name', ''),
                        'phone' => ArrayHelper::getValue($order_data, 'tenant_company.phone', ''),
                    ],
                ],
                'car'            => [
                    'name'       => ArrayHelper::getValue($order_data, 'car.name', ''),
                    'color'      => ArrayHelper::getValue($order_data, 'car.color.name', ''),
                    'gos_number' => ArrayHelper::getValue($order_data, 'car.gos_number', ''),
                    'brand'      => ArrayHelper::getValue($order_data, 'car.brand', ''),
                    'model'      => ArrayHelper::getValue($order_data, 'car.model', ''),
                ],
            ];
        }

        if ($order_data) {
            return $result;
        }

        return null;
    }
}