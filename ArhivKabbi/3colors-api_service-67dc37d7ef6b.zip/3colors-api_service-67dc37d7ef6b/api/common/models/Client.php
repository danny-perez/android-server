<?php

namespace api\common\models;

use Yii;

/**
 * This is the model class for table "tbl_client".
 *
 * @property string $client_id
 * @property string $tenant_id
 * @property string $city_id
 * @property string $photo
 * @property string $last_name
 * @property string $name
 * @property string $second_name
 * @property string $email
 * @property integer $black_list
 * @property integer $priority
 * @property string $create_time
 * @property integer $active
 * @property string $success_order
 * @property string $fail_driver_order
 * @property string $fail_client_order
 * @property string $birth
 * @property integer $password
 *
 * @property Tenant $tenant
 * @property ClientHasBonus[] $clientHasBonuses
 * @property ClientBonus[] $bonuses
 * @property ClientHasCompany[] $clientHasCompanies
 * @property ClientCompany[] $companies
 * @property ClientPhone[] $clientPhones
 * @property ClientReview[] $clientReviews
 * @property ClientReviewRaiting[] $clientReviewRaitings
 * @property OrderChange[] $orderChanges
 * @property OrderHistory[] $orderHistories
 */
class Client extends \yii\db\ActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tbl_client';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id'], 'required'],
            [['tenant_id', 'city_id', 'black_list', 'priority', 'active', 'success_order', 'fail_worker_order', 'fail_client_order', 'password'], 'integer'],
            [['create_time', 'birth'], 'safe'],
            [['photo'], 'string', 'max' => 255],
            [['last_name', 'name', 'second_name'], 'string', 'max' => 45],
            [['email'], 'string', 'max' => 20]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'client_id'         => 'Client ID',
            'tenant_id'         => 'Tenant ID',
            'city_id'           => 'City ID',
            'photo'             => 'Photo',
            'last_name'         => 'Last Name',
            'name'              => 'Name',
            'second_name'       => 'Second Name',
            'email'             => 'Email',
            'black_list'        => 'Black List',
            'priority'          => 'Priority',
            'create_time'       => 'Create Time',
            'active'            => 'Active',
            'success_order'     => 'Success Order',
            'fail_driver_order' => 'Fail Driver Order',
            'fail_client_order' => 'Fail Client Order',
            'birth'             => 'Birth',
            'password'          => 'Password',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientHasBonuses()
    {
        return $this->hasMany(ClientHasBonus::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBonuses()
    {
        return $this->hasMany(ClientBonus::className(), ['bonus_id' => 'bonus_id'])->viaTable('tbl_client_has_bonus', ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientHasCompanies()
    {
        return $this->hasMany(ClientHasCompany::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCompanies()
    {
        return $this->hasMany(ClientCompany::className(), ['company_id' => 'company_id'])->viaTable('tbl_client_has_company', ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientPhones()
    {
        return $this->hasMany(ClientPhone::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientReviews()
    {
        return $this->hasMany(ClientReview::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientReviewRaitings()
    {
        return $this->hasMany(ClientReviewRaiting::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderChanges()
    {
        return $this->hasMany(OrderChange::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderHistories()
    {
        return $this->hasMany(OrderHistory::className(), ['client_id' => 'client_id']);
    }

    public static function findByClientId($client_id, $select = [])
    {
        $clientPhone = ClientPhone::find()
                ->where(['client_id' => $client_id])
                ->with(['client' => function($query) use($select) {
                        $query->select($select);
                    }])
                ->one();
        return $clientPhone->client;
    }

    /**
     * Обновление счетчиков клиента
     * @param type $clientId
     * @param type $status_id
     */
    public static function updateClientOrderCounters($clientId, $status_id)
    {
        $client = Client::find()
            ->where(['client_id' => $clientId])
            ->one();
        if(!$client) {
            return false;
        }
        if(in_array($status_id, OrderStatus::getCompletedStatusId())) {
            $client->success_order++;
            return $client->save();
        }

        if(in_array($status_id, OrderStatus::getRejectedStatusIdByClient())) {
            $client->fail_client_order++;
            return $client->save();
        }

        if(in_array($status_id, OrderStatus::getRejectedStatusIdByWorker())) {
            $client->fail_worker_order++;
            return $client->save();
        }

        if(in_array($status_id, OrderStatus::getRejectedStatusIdByDispatcher())) {
            $client->fail_dispatcher_order++;
            return $client->save();
        }

        return false;
    }

    

    private static function t($category, $message, $params = [], $language = null)
    {
        return Yii::t($category, $message, $params, $language);
    }

}
