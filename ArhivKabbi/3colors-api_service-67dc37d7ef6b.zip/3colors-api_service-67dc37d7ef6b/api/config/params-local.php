<?php

return [
    'adminEmail'              => 'sup1@gootax.pro',
    'gootaxUrl'               => 'https://uatgootax.ru',
    'iosDriverPushTypeServer' => 'production',
    'iosClientPushTypeServer' => 'sandbox',
    'az_geocoder_accuracy'    => 0.0006,
    'version'                 => require __DIR__ . '/version.php',
];
