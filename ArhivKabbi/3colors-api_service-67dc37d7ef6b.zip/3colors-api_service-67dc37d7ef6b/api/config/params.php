<?php

return [
    'adminEmail'              => 'sup1@gootax.pro',
    'gootaxUrl'               => "https://gootax.pro",
    'iosDriverPushTypeServer' => 'production', //sandbox   -тип сервера для ios водительского приложения
    'iosClientPushTypeServer' => 'production',
    'az_geocoder_accuracy'    => 0.0006,
    'version'                 => require __DIR__ . '/version.php',
];
