# Gootax api_pbx

## 1.0.6 (28.11.2017)

- [#3120](https://red.gootax.pro/issues/3120) - Добавили tags, .nvmrc, package.json, метод status,метод version. Вынесли конфигурацию в темплейт ансибл.

