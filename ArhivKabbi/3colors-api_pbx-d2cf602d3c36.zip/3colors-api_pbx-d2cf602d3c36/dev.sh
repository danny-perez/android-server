#!/bin/sh
#используется для запуска в режиме девелопера
NODE_ENV=dev exec node /opt/voip-api/observer.js
