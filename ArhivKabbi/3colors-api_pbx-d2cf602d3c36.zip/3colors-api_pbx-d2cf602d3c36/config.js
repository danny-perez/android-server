'use strict';
var bunyan = require('bunyan');
var bsyslog = require('bunyan-syslog');
var ver = 'v1.0.7';

function myConfig(typeConfig) {
    if (typeConfig == "dev") {
        return new ConfigDev();
    } else {
        return new ConfigProd();
    }

}

function ConfigDev() {
    this.ver = ver;
    this.pbxes =
        [
            {
                id: "media1",
                addr: "127.168.99.133",
                port: "5038",
                user: "api",
                secret: "megasecret", //ami
                dbhost: "db.taxi.lcl",
                dbuser: "asterisk",
                dbpassword: "Jsnkj349Kskerdf",
                database: "asterisk",
                //если данное поле заполнено, медиа сервер считается выделенным под данных арендаторов
                tenant: ['68', '444']
            }
            ,
            {
                id: "media2",
                addr: "176.9.125.157",
                port: "5038",
                user: "api",
                secret: "megasecret",
                dbhost: "176.9.125.157",
                dbuser: "asterisk",
                dbpassword: "yohKahquiruVo8a",
                database: "asterisk",
                tenant: []
            }
        ];
    this.restserver = {port: 8088};
    this.restclient = {host: "va.uat.taxi.lcl", port: 80, protocol: "http://"};
    this.debug = true;
    this.proxy =
        [
            {
                id: "sp1",
                host: "sp1.uatgootax.ru",
                port: 5060,
                protocol: "http://",
                dbhost: "db.taxi.lcl",
                dbuser: "kamailio",
                dbpassword: "MNkdoei4iNsjeoFr",
                database: "kamailio"

            },
            {
                id: "sp2",
                host: "sp1.gootax.pro",
                port: 5060,
                protocol: "http://",
                dbhost: "db.taxi.lcl",
                dbuser: "kamailio",
                dbpassword: "MNkdoei4iNsjeoFr",
                database: "kamailio"
            }
        ];
    this.defaultDB = 'sp1.uatgootax.ru';
    this.qtimeout = 30;
    this.ctimeout = 8;
    this.servertype = "dev";
    this.mail_support_login = "sup1@gootax.pro";
    this.mail_support_service = "Yandex";
    this.mail_support_password = "D376gr)98hnfd_1";
    this.domain = "v2.uatgootax.ru";
    this.loglvl = "INFO";
    this.log = bunyan.createLogger({
        name: 'observer.js',
        streams: [
            {
                level: 'info',
                stream: process.stdout            // log INFO and above to stdout
            },
            {

                //   type: 'rotating-file',
                level: 'info',
                //period: '1d',
                path: './log/bunyan.log'  // log ERROR and above to a file
            },
            {
                level: 'info',
                type: 'raw',
                stream: bsyslog.createBunyanStream({
                    type: 'sys',
                    facility: bsyslog.local0,
                    name: 'api_pbx'
                })
            }
        ]
    });

    this.log.level("INFO");


}

function ConfigProd() {
    this.ver = ver;
    this.domain = 'v1.gootax.pro';
    this.servertype = "prod";
    this.pbxes =
        [
            {
                id: "media1",
                addr: "127.0.0.1",
                port: "5038",
                user: "api",
                secret: "megasecret",
                dbhost: "127.0.0.1",
                dbuser: "node",
                dbpassword: "Phe4ShiZeic2ye7",
                database: "asterisk",
                tenant: []
            },
            {
                id: "media2", addr: "62.212.235.118", port: "5038", user: "api", secret: "secret***333dfasd",
                dbuser: "node",
                dbpassword: "Phe4ShiZeic2ye7",
                tenant: []
            }, //azetaxi

            {
                id: "media3", addr: "37.26.63.168", port: "5038", user: "api", secret: "secret***333dfasd",
                dbuser: "node",
                dbpassword: "Phe4ShiZeic2ye7", tenant: []
            } //taxim

        ];
    this.restserver = {port: 8088};
    this.restclient = {host: "va2.gootax.pro", port: 8086, protocol: "https://"};
    this.debug = true;
    this.proxy =
        [

            {
                host: "sp2.gootax.pro",
                port: 5060,
                protocol: "http://",
                dbhost: "sp2.gootax.pro",
                dbuser: "node",
                dbpassword: "Phe4ShiZeic2ye7",
                database: "kamailio"
            }
        ];
    //из этой БД берутся юзеры и загружаются в астериск
    this.defaultDB = 'sp2.gootax.pro';
    this.qtimeout = 150;
    this.ctimeout = 8;
    this.servertype = "prod";
    this.mail_support_login = "sup1@gootax.pro";
    this.mail_support_service = "Yandex";
    this.mail_support_password = "D376gr)98hnfd_1";
    this.loglvl = "DEBUG";
    this.log = bunyan.createLogger({
        name: 'observer.js',
        streams: [
            {
                level: 'info',
                stream: process.stdout            // log INFO and above to stdout
            },
            {
                level: 'info',
                path: './log/bunyan.log'  // log ERROR and above to a file
            },
            {
                level: 'info',
                type: 'raw',
                stream: bsyslog.createBunyanStream({
                    type: 'sys',
                    facility: bsyslog.local0,
                    name: 'api_pbx'
                })
            }
        ]
    });

    this.log.level("INFO");
}


module.exports = myConfig;
