
#### Suggester

- [overview](http://www.elasticsearch.org/blog/you-complete-me/)

- [context suggester](http://www.elasticsearch.org/guide/en/elasticsearch/reference/current/suggester-context.html)
  - [category context](http://www.elasticsearch.org/guide/en/elasticsearch/reference/current/suggester-context.html#suggester-context-category)
  - [geo location context](http://www.elasticsearch.org/guide/en/elasticsearch/reference/current/suggester-context.html#suggester-context-geo)
  - [geohash precision](http://www.elasticsearch.org/guide/en/elasticsearch/reference/current/search-aggregations-bucket-geohashgrid-aggregation.html#_cell_dimensions_at_the_equator)