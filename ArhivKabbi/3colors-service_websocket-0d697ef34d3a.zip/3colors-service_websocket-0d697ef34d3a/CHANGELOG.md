# Gootax - service_websocket

## 2.1.7 (22.01.2017)
- обновлен .nvmrc: node v6.12.3

## 2.1.6 (25.10.2017)
- [#3864](https://red.gootax.pro/issues/3864) - добавлен файл .nvmrc с node.js v6.11.4