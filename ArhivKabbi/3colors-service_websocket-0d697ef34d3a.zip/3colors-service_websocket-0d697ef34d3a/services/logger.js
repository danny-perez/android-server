'use strict';
module.exports = require('./syslogLogger');





