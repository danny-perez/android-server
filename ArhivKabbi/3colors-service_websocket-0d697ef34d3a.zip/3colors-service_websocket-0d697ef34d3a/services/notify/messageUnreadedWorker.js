'use strict';
const ChatModel = require('../mongoose').ChatModel;
const logger = require('../logger');
const chatLogger = logger.chatLogger;
const nodemailer = require('nodemailer');
const sqlManager = require('../sqlManager');
const lib = require("../lib");
const config = lib.getConfig();
const mail_support_login = config.MAIL_SUPPORT_LOGIN;
const mail_support_password = config.MAIL_SUPPORT_PASSWORD;
const mail_support_service = config.MAIL_SUPPORT_PROVIDER;
const emailTemplate = require('./messageUnreadedTemplate');

module.exports = function (messageUuid) {
    const checkTimeout = 30;// 10 sec to check message is read
    chatLogger('info', `Email worker for message: ${messageUuid} will be call after ${checkTimeout} seconds`);
    setTimeout(() => {
        ChatModel.findOne({
            'uuid': messageUuid,
            'is_readed': false
        }).exec((err, message) => {
            if (err) {
                chatLogger('error', 'email worker error:');
                chatLogger('error', err);
            } else {
                if (message) {
                    chatLogger('info', `message: ${messageUuid} is unread:`);
                    chatLogger('info', message);
                    runEmailNotifyer(message);
                } else {
                    chatLogger('info', `message: ${messageUuid} is read`);
                }
            }
        });
    }, checkTimeout * 1000, messageUuid)
};

function runEmailNotifyer(message) {
    const tenantId = message.tenant_id;
    const tenantDomain = message.tenant_domain;
    const cityId = message.city_id;
    const workerCallsing = message.sender_id;
    let workerLastName = message.sender_f;
    let workerName = message.sender_i;
    let workerPatronymicName = message.sender_o;
    if (typeof workerName === "string" && workerName.length > 0) {
        workerName = workerName[0].toUpperCase();
    }
    if (typeof workerPatronymicName === "string" && workerPatronymicName.length > 0) {
        workerPatronymicName = workerPatronymicName[0].toUpperCase();
    }
    const workerFio = `${workerLastName} ${workerName}. ${workerPatronymicName}.`;
    const sendTime = message.sender_time;
    const msgText = message.message;
    const senderRole = lib.capitalizeFirstLetter(message.sender_role);
    sqlManager.getNotifyUsersData(tenantId, cityId)
        .then(userssArr => {
            if (Array.isArray(userssArr)) {
                for (let user of userssArr) {
                    const email = user.email;
                    const clientName = user.first_name;
                    let lang = user.lang;
                    const langArr = lang.split('-');
                    lang = langArr[0];
                    let cityName = user.name;
                    let cityTranslatedColumnName = 'name_' + lang;
                    if (user[cityTranslatedColumnName]) {
                        cityName = user[cityTranslatedColumnName];
                    }
                    const tempalte = emailTemplate({
                        tenantDomain: tenantDomain,
                        clientName: clientName,
                        workerCallsing: workerCallsing,
                        workerFio: workerFio,
                        msgText: msgText,
                        sendTime: sendTime,
                        lang: lang,
                        cityName: cityName,
                        senderRole: senderRole
                    });
                    const transporter = nodemailer.createTransport({
                        service: mail_support_service,
                        auth: {
                            user: mail_support_login,
                            pass: mail_support_password
                        }
                    });
                    const mailOptions = {
                        from: mail_support_login, // sender address
                        to: email, // list of receivers
                        subject: 'Gootax: Непрочитанные сообщения в чате',
                        html: tempalte
                    };
                    // send mail with defined transport object
                    transporter.sendMail(mailOptions, (err, info) => {
                        if (err) {
                            chatLogger('error', err.message);
                        } else {
                            chatLogger('info', 'Email notify message sent: ' + info.response);
                        }
                    });
                }

            }
        })
        .catch(err => {
            chatLogger('error', err.message);
        });
}