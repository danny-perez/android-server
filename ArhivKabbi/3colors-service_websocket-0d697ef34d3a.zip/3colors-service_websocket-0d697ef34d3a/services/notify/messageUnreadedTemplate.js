'use strict';


module.exports = function (params) {
    return `<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
   <head>
      <title>E-mail template</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <!--[if !mso]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!--<![endif]-->
      <style type="text/css">
         .ReadMsgBody { width: 100%; background-color: #f9f7f7; }
         .ExternalClass { width: 100%; background-color: #f9f7f7; }
         body { width: 100%; background-color: #f9f7f7; margin: 0; padding: 10px 0; -webkit-font-smoothing: antialiased; font-family: Arial, Times, serif }
         table { border-collapse: collapse !important; mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
         a{color: #1867a3;}
         @-ms-viewport{ width: device-width; }
         @media only screen and (max-width: 639px){
         .wrapper{ width:100%!important;  padding: 0 !important; }
         }
         @media only screen and (max-width: 480px){
         body { width: 640px!important; min-width: 640px!important;}
         }
      </style>
   </head>
   <body marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" style="background-color:#f9f7f7;  font-family:Arial,serif; margin:0; padding:0 0; min-width: 100%; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;">
      <!--[if !mso]><!-- -->
      <img style="min-width:640px; display:block; margin:0; padding:0" class="mobileOff" width="640" height="1" src="http://work.crystal-web.ru/gootax_mail/images/spacer.gif">
      <!--<![endif]-->
      <table class="container" width="100%" cellpadding="0" cellspacing="0" border="0" align="center" bgcolor="#f9f7f7" st-sortable="body1" style="background-color:#f9f7f7;">
         <tr>
            <td height="20" style="font-size:10px; line-height:10px;"> </td>
            <!-- Spacer -->
         </tr>
         <tr>
            <td width="100%" valign="top" align="center">
               <table width="640" class="container" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="body" style="border-width: 1px; border-color: #e0dede; border-style: solid;">
                  <tr>
                     <td width="100%" valign="top" align="center">
                        <!-- START HEADER -->
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="header">
                           <tr>
                              <td width="100%" valign="top" align="center">
                                 <!-- Start Wrapper  -->
                                 <table width="640" cellpadding="0" cellspacing="0" border="0" class="wrapper" bgcolor="#FFFFFF">
                                    <tr>
                                       <td align="center">
                                          <!-- Start Container  -->
                                          <table width="640" cellpadding="0" cellspacing="0" border="0" class="container">
                                             <tr>
                                                <td height="20" style="font-size:10px; line-height:10px;"> </td>
                                                <!-- Spacer -->
                                             </tr>
                                             <tr>
                                                <td width="320" class="mobile" style="padding-left:15px;">
                                                   <img src="http://work.crystal-web.ru/gootax_mail/images/logo.png" width="200" height="50" style="margin:0; padding:0; border:none; display:block;" border="0" class="centerClass" alt="" st-image="image" />
                                                </td>
                                                <td height="10" style="font-size:10px; line-height:10px;" class="mobileOn"></td>
                                                <td width="320" class="mobile" style="font-family:arial; font-size:14px; line-height:18px;" align="left">
                                                   <table width="320" class="container" cellpadding="0" cellspacing="0" border="0" align="center">
                                                      <tr>
                                                         <td align="left" style="font-family:Verdana, Arial, sans serif; font-size: 14px; color: #4d4d4d; line-height:18px; padding:0 20px;">
                                                            Облачная система для автоматизации такси, курьеров, услуг
                                                         </td>
                                                      </tr>
                                                   </table>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td height="20" style="font-size:10px; line-height:10px;"> </td>
                                                <!-- Spacer -->
                                             </tr>
                                          </table>
                                          <!-- Start Container  -->
                                       </td>
                                    </tr>
                                 </table>
                                 <!-- End Wrapper  -->
                              </td>
                           </tr>
                        </table>
                        <!-- END HEADER -->
                        <!-- START TITLE + TEXT -->
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="title+text">
                           <tr>
                              <td width="100%" valign="top" align="center">
                                 <!-- Start Wrapper -->
                                 <table width="640" cellpadding="0" cellspacing="0" align="center" border="0" class="wrapper" bgcolor="#daf6ef">
                                    <tbody>
                                       <tr>
                                          <td align="center" bgcolor="#daf6ef">
                                             <!-- Start Container -->
                                             <table width="640" cellpadding="0" cellspacing="0" align="center" border="0" class="container">
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td align="center" class="mobile" style="font-family:arial, sans-serif; font-size:20px; line-height:26px; font-weight:bold;" st-title="title+text">
                                                      Здравствуйте, ${params.clientName}!
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td align="left" style="font-family:Verdana, Arial, sans serif; font-size: 16px; color: #4d4d4d; line-height:18px; padding:0 20px;" st-content="title+text">
                                                      Получено сообщение из чата Гутакса
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                             </table>
                                             <!-- End Container -->
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                                 <!-- End Wrapper -->
                              </td>
                           </tr>
                        </table>
                        <!-- END TITLE + TEXT -->
                        <!-- START 1 IMAGE + TEXT COLUMN -->
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="1-image+text-column">
                           <tr>
                              <td width="100%" valign="top" align="center">
                                 <!-- Start Wrapper -->
                                 <table width="640" cellpadding="0" cellspacing="0" align="center" border="0" class="wrapper" bgcolor="#ffffff">
                                    <tbody>
                                       <tr>
                                          <td align="center" bgcolor="#ffffff">
                                             <!-- Start Container -->
                                             <table width="640" cellpadding="0" cellspacing="0" align="center" border="0" class="container">
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td align="left" style="font-family:arial, sans-serif; font-size:16px; line-height:20px; padding:0 20px;" st-title="1-image+text-column">
                                                      <b>${params.workerFio}</b>&nbsp;&nbsp;&nbsp;&nbsp;
                                                      <font color="#696969">
                                                         ${params.workerCallsing}
                                                         &nbsp;&nbsp;&nbsp;&nbsp;
                                                         ${params.senderRole}
                                                         &nbsp;&nbsp;&nbsp;&nbsp;
                                                         ${params.cityName}
                                                         &nbsp;&nbsp;&nbsp;&nbsp;
                                                         ${params.sendTime}
                                                      </font>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td height="10" style="line-height:10px; font-size:10px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td align="left" style="font-family:Verdana, Arial, sans serif; font-size: 16px; color: #000; line-height:18px; padding:0 20px;" st-content="1-image+text-column">
                                                      <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="footer">
                                                         <tr>
                                                            <td width="100%" valign="top" cellpadding="0" cellspacing="0" border="0">
                                                               <!-- Start Wrapper  -->
                                                               <table width="100%">
                                                                  <tr>
                                                                     <td  align="left" style="font-family:arial, sans-serif; font-size:16px; line-height:20px;">
                                                                        ${params.msgText}
                                                                     </td>
                                                                  </tr>
                                                               </table>
                                                               <!-- End Wrapper  -->
                                                            </td>
                                                         </tr>
                                                       </table>
                                                   </td>
                                                </tr>

                       
                                                <tr>
                                                   <td height="40" style="line-height:40px; font-size:40px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td class="mobile" style="font-size:14px; line-height:20px;" align="center">
                                                      <!-- Start Button -->
                                                      <table width="190" cellpadding="0" cellspacing="0" align="center" border="0" bgcolor="#2cbc92" st-button="2-images+text-columns">
                                                         <tr>
                                                            <td width="190" height="40" align="center" valign="middle" style="font-family:arial, sans-serif; font-size: 20px; color: #ffffff; line-height:22px; border-radius:3px;" st-content="2-images+text-columns">
                                                               <a href="https://${params.tenantDomain}.gootax.pro" target="_blank" alias="" style="font-family:arial, sans-serif; text-decoration: none; color: #ffffff;">Перейти в Гутакс</a>
                                                            </td>
                                                         </tr>
                                                      </table>
                                                      <!-- End Button -->
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;"> </td>
                                                   <!-- Spacer -->
                                                </tr>
                                                <tr>
                                                   <td height="20" style="line-height:20px; font-size:20px;">
                                                      <hr style="border-style: solid; border-width: 1px 0 0 0; border-color: #cccccc;"/>
                                                   </td>
                                                   <!-- Spacer -->
                                                </tr>
                                             </table>
                                             <!-- End Container -->
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                                 <!-- End Wrapper -->
                              </td>
                           </tr>
                        </table>
                        <!-- END 1 IMAGE + TEXT COLUMN -->
                        <!-- START FOOTER -->
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" st-sortable="footer">
                           <tr>
                              <td width="100%" valign="top" align="center">
                                 <!-- Start Wrapper  -->
                                 <table width="640" cellpadding="0" cellspacing="0" border="0" class="wrapper" bgcolor="#ffffff">
                                    <tr>
                                       <td align="center">
                                          <!-- Start Container  -->
                                          <table width="640" cellpadding="0" cellspacing="0" border="0" class="container" align="center">
                                             <tr>
                                                <td height="20" style="font-size:10px; line-height:10px;"> </td>
                                                <!-- Spacer -->
                                             </tr>
                                             <tr>
                                                <td width="65" class="mobile" style="font-family:arial; font-size:14px; line-height:18px; color:#000000; padding-left:20px;" st-content="footer">
                                                   <img src="http://work.crystal-web.ru/gootax_mail/images/logo_footer.png" width="27" height="27" style="margin:0; padding:0; border:none; display:block;" border="0" class="centerClass" alt="" st-image="image" />
                                                </td>
                                                <td height="10" style="font-size:10px; line-height:10px;" class="mobileOn"> </td>
                                                <td width="85" class="mobile" style="font-family:arial; font-size:14px; line-height:18px; color:#000000; padding-right:20px;" align="left" st-content="footer">
                                                   <a href="https://gootax.pro" target="_blank" alias="" style="font-size:14px; line-height:18px; color:#1867a3; text-decoration:underline;">
                                                      <nobr>gootax.pro</nobr>
                                                   </a>
                                                </td>
                                                <td height="10" style="font-size:10px; line-height:10px;" class="mobileOn"> </td>
                                                <td width="160" class="mobile" style="font-family:arial; font-size:14px; line-height:18px; color:#000000; padding-right:20px;" align="left" st-content="footer">
                                                   <a href="mailto:support@gootax.pro" target="_blank" alias="" style="font-size:14px; line-height:18px; color:#1867a3; text-decoration:underline;">
                                                      <nobr>support@gootax.pro</nobr>
                                                   </a>
                                                </td>
                                                <td height="10" style="font-size:10px; line-height:10px;" class="mobileOn"> </td>
                                                <td width="170" class="mobile" style="font-family:arial; font-size:16px; line-height:18px; color:#000000; padding-right:20px;" align="left" st-content="footer">
                                                   <nobr>+7(3412)310-930</nobr>
                                                </td>
                                                <td height="10" style="font-size:10px; line-height:10px;" class="mobileOn"> </td>
                                                <td width="160" class="mobile" style="font-family:arial; font-size:16px; line-height:18px; color:#000000; padding-right:20px;" align="left" st-content="footer">
                                                   <table width="160" cellpadding="0" cellspacing="0" border="0" class="container icons">
                                                      <tr>
                                                         <td width="40" style="font-family:arial; font-size:12px; line-height:18px;" align="center">
                                                            <a href="https://www.facebook.com/gootax.pro" target="_blank" alias="" style="font-size:25px; line-height:25px; color:#1867a3; text-decoration:none;">
                                                            <img src="http://work.crystal-web.ru/gootax_mail/images/fb_icon.png" width="25" height="25" style="margin:0; padding:0; border:none; display:block;" border="0" class="centerClass" alt="" st-image="image" />
                                                            </a>
                                                         </td>
                                                         <td width="40" style="font-family:arial; font-size:12px; line-height:18px;" align="center">
                                                            <a href="https://www.linkedin.com/company/gootax" target="_blank" alias="" style="font-size:25px; line-height:25px; color:#1867a3; text-decoration:none;">
                                                            <img src="http://work.crystal-web.ru/gootax_mail/images/li_icon.png" width="25" height="25" style="margin:0; padding:0; border:none; display:block;" border="0" class="centerClass" alt="" st-image="image" />
                                                            </a>
                                                         </td>
                                                         <td width="40" style="font-family:arial; font-size:12px; line-height:18px;" align="center">
                                                            <a href="https://vk.com/gootax" target="_blank" alias="" style="font-size:25px; line-height:25px; color:#1867a3; text-decoration:none;">
                                                            <img src="http://work.crystal-web.ru/gootax_mail/images/vk_icon.png" width="25" height="25" style="margin:0; padding:0; border:none; display:block;" border="0" class="centerClass" alt="" st-image="image" />
                                                            </a>
                                                         </td>
                                                      </tr>
                                                   </table>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td height="20" style="font-size:10px; line-height:10px;"> </td>
                                                <!-- Spacer -->
                                             </tr>
                                          </table>
                                          <!-- Start Container  -->
                                       </td>
                                    </tr>
                                 </table>
                                 <!-- End Wrapper  -->
                              </td>
                           </tr>
                        </table>
                        <!-- END FOOTER -->
                     </td>
                  </tr>
               </table>
            </td>
         </tr>
      </table>
      <!-- END FULL-TEXT -->
   </body>
</html>`

}
