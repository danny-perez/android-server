<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ReferralBonusForOrderFixture extends ActiveFixture
{
    public $tableName = '{{%referral_bonus_for_order}}';

    public $depends = [
        OrderFixture::class,
        ClientFixture::class,
        TenantFixture::class,
    ];

}