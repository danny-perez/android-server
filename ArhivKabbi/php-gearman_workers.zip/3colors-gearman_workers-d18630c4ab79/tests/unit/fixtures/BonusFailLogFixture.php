<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class BonusFailLogFixture extends ActiveFixture
{
    public $tableName = '{{%bonus_fail_log}}';

    public $depends = [
        ClientFixture::class,
        TenantFixture::class,
        ClientBonusFixture::class,
        ClientBonusGootaxFixture::class,
        OrderFixture::class,
        OrderDetailCostFixture::class,
    ];

}