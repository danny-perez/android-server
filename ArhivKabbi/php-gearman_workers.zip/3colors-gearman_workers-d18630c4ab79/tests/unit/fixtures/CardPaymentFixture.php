<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class CardPaymentFixture extends ActiveFixture
{
    public $tableName = '{{%card_payment}}';

    public $depends = [
        OrderFixture::class,
    ];

}