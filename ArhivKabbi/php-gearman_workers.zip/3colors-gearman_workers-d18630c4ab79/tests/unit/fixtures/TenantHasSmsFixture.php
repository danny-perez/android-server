<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class TenantHasSmsFixture extends ActiveFixture
{
    public $modelClass = '\console\modules\sms\models\TenantHasSms';

    public $depends = [
        TenantFixture::class,
    ];

}