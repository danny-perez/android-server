<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class CityFixture extends ActiveFixture
{
    public $tableName = '{{%city}}';
}