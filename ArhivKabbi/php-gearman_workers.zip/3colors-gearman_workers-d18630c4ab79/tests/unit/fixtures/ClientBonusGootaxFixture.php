<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientBonusGootaxFixture extends ActiveFixture
{
    public $modelClass = 'console\components\billing\models\ClientBonusGootax';

    public $depends = [
        ClientBonusFixture::class,
    ];
}