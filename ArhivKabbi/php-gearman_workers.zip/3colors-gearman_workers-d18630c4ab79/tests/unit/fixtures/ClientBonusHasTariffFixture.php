<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientBonusHasTariffFixture extends ActiveFixture
{
    public $tableName = '{{%client_bonus_has_tariff}}';

    public $depends = [
        ClientBonusFixture::class,
    ];
}
