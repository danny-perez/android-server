<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class DepositFromBankCardFixture extends ActiveFixture
{
    public $tableName = '{{%deposit_from_bank_card}}';

    public $depends = [
        TransactionFixture::class,
    ];

}