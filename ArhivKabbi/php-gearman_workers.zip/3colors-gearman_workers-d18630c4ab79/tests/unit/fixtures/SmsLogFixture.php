<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class SmsLogFixture extends ActiveFixture
{
    public $tableName = '{{%sms_log}}';

    public $depends = [
        TenantFixture::class,
    ];
}