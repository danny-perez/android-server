<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class OrderDetailCostFixture extends ActiveFixture
{
    public $tableName = '{{%order_detail_cost}}';

    public $depends = [
        OrderFixture::class,
    ];

}