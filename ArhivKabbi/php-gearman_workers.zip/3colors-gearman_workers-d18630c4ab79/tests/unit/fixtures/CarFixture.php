<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class CarFixture extends ActiveFixture
{
    public $tableName = '{{%car}}';

    public $depends = [
        TenantFixture::class,
        CityFixture::class,
    ];
}