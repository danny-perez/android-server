<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientCompanyFixture extends ActiveFixture
{
    public $tableName = '{{%client_company}}';

    public $depends = [
        TenantFixture::class,
        CityFixture::class,
    ];
}