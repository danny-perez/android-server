<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class WorkerHasCityFixture extends ActiveFixture
{
    public $tableName = '{{%worker_has_city}}';

    public $depends = [
        WorkerFixture::class,
        CityFixture::class,
    ];
}