<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class OrderFixture extends ActiveFixture
{
    public $tableName = '{{%order}}';

    public $depends = [
        CityFixture::class,
    ];
}