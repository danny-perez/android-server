<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class CurrencyFixture extends ActiveFixture
{
    public $tableName = '{{%currency}}';
}