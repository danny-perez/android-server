<?php

return [
    'standart' => [
        'bonus_id'   => 1,
        'tariff_id'  => 2,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    'standart blocked' => [
        'bonus_id'   => 2,
        'tariff_id'  => 3,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    'standart check bonus app' => [
        'bonus_id'   => 11,
        'tariff_id'  => 4,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    'standart check bonus app for 10 bonus and 50 bonus_app and min_cost = 0' => [
        'bonus_id'   => 10,
        'tariff_id'  => 4,
        'created_at' => time(),
        'updated_at' => time(),
    ],
];
