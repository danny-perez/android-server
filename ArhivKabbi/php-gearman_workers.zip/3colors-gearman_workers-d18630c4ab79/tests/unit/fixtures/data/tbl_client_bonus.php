<?php

return [
    'standart' => [
        'bonus_id'        => 1,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => 'standart',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    'standart blocked' => [
        'bonus_id'        => 2,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => 'standart blocked',
        'created_at'      => time(),
        'updated_at'      => time(),
        'blocked'         => 1,
    ],

    'standart with bonus app' => [
        'bonus_id'        => 11,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => 'standart with bonus app',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '15%' => [
        'bonus_id'        => 4,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '15%',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '12.5%' => [
        'bonus_id'        => 5,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '12.5%',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '20.25bonus' => [
        'bonus_id'        => 6,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '20.25bonus',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '100bonus' => [
        'bonus_id'        => 7,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '100bonus',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '15.25%bonus_app' => [
        'bonus_id'        => 8,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '15.25%bonus_app',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '100.25bonus_app' => [
        'bonus_id'        => 9,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '100.25bonus_app',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],

    '10 bonus and 50 bonus_app and min_cost = 0' => [
        'bonus_id'        => 10,
        'bonus_system_id' => 1,
        'city_id'         => 26068,
        'class_id'        => 2,
        'tenant_id'       => 1,
        'name'            => '10 bonus and 50 bonus_app and min_cost = 0',
        'created_at'      => time(),
        'updated_at'      => time(),
    ],
];
