<?php

return [
    [
        'id'   => 1,
        'name' => 'Gootax',
    ],

    [
        'id'   => 2,
        'name' => 'UDS Game',
    ],
];