<?php

return [
    'ELECSNET transaction' => [
        'transaction_id'           => 1,
        'type_id'                  => 1,
        'sender_acc_id'            => 4,
        'receiver_acc_id'          => 1,
        'sum'                      => 100,
        'payment_method'           => 'TERMINAL_ELECSNET',
        'date'                     => '2015-08-01 05:29:50',
        'city_id'                  => 26068,
        'terminal_transact_number' => '1',
        'terminal_transact_date'   => '20160114',
    ],

    'MILLION transaction' => [
        'transaction_id'           => 2,
        'type_id'                  => 1,
        'sender_acc_id'            => 4,
        'receiver_acc_id'          => 1,
        'sum'                      => 100,
        'payment_method'           => 'TERMINAL_MILLION',
        'date'                     => '2015-08-01 05:29:50',
        'city_id'                  => 26068,
        'terminal_transact_number' => '1',
        'terminal_transact_date'   => '20160201',
    ],

    'deposit from card transaction' => [
        'transaction_id'  => 3,
        'type_id'         => 1,
        'sender_acc_id'   => 2,
        'receiver_acc_id' => 3,
        'sum'             => 100,
        'payment_method'  => 'CARD',
        'city_id'         => 26068,
    ],
];
