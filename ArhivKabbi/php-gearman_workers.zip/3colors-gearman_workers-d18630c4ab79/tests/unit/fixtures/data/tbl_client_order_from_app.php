<?php

return [
    'client' => [
        'client_id'    => 2,
        'device'       => 'ANDROID',
        'device_token' => '123',
        'order_time'   => 1449001800, // 01.12.2015 20:30 utc
    ],

    '2' => [
        'client_id'    => 3,
        'device'       => 'ANDROID',
        'device_token' => '12345',
        'order_time'   => 1448976600, // 01.12.2015 13:30 utc
    ],
];
