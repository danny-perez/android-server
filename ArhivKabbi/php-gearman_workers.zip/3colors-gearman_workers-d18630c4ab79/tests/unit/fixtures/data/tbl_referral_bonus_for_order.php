<?php

return [
    'only referral bonus to referrer' => [
        'id'             => 1,
        'order_id'       => 56,
        'referrer_id'    => 1,
        'referrer_bonus' => 50,
        'referral_id'    => 5,
        'referral_bonus' => 0,
        'completed'      => false,
    ],

    'only referral bonus to referral' => [
        'id'             => 2,
        'order_id'       => 57,
        'referrer_id'    => 1,
        'referrer_bonus' => 0,
        'referral_id'    => 5,
        'referral_bonus' => 50,
        'completed'      => false,
    ],

    'only referral bonus to referrer and referral' => [
        'id'             => 3,
        'order_id'       => 58,
        'referrer_id'    => 1,
        'referrer_bonus' => 20,
        'referral_id'    => 5,
        'referral_bonus' => 50,
        'completed'      => false,
    ],

];