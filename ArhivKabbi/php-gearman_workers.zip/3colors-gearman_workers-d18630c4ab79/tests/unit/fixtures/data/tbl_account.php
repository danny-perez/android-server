<?php

return [
    'gootax account' => [
        'account_id'  => 1,
        'acc_kind_id' => 6,
        'acc_type_id' => 1,
        'owner_id'    => null,
        'tenant_id'   => null,
        'balance'     => 100,
        'currency_id' => 1,
    ],

    'worker for tenant 3' => [
        'account_id'  => 2,
        'acc_kind_id' => 2,
        'acc_type_id' => 2,
        'owner_id'    => 3,
        'tenant_id'   => 3,
        'balance'     => 300,
        'currency_id' => 1,
    ],

    'tenant3' => [
        'account_id'  => 3,
        'acc_kind_id' => 5,
        'acc_type_id' => 1,
        'owner_id'    => 3,
        'tenant_id'   => 3,
        'balance'     => 0,
        'currency_id' => 1,
    ],

    'worker for tenant 1' => [
        'account_id'  => 4,
        'acc_kind_id' => 2,
        'acc_type_id' => 2,
        'owner_id'    => 1,
        'tenant_id'   => 1,
        'balance'     => 300,
        'currency_id' => 1,
    ],

    'client personal account' => [
        'account_id'  => 5,
        'acc_kind_id' => 3,
        'acc_type_id' => 2,
        'owner_id'    => 1,
        'tenant_id'   => 1,
        'balance'     => 150,
        'currency_id' => 1,
    ],

    'client with no money on personal account' => [
        'account_id'  => 6,
        'acc_kind_id' => 3,
        'acc_type_id' => 2,
        'owner_id'    => 6,
        'tenant_id'   => 1,
        'balance'     => 0,
        'currency_id' => 1,
    ],

    'company corp account' => [
        'account_id'  => 7,
        'acc_kind_id' => 4,
        'acc_type_id' => 2,
        'owner_id'    => 1,
        'tenant_id'   => 1,
        'balance'     => 200,
        'currency_id' => 1,
    ],

    'company with no money on corp account' => [
        'account_id'  => 8,
        'acc_kind_id' => 4,
        'acc_type_id' => 2,
        'owner_id'    => 2,
        'tenant_id'   => 1,
        'balance'     => 0,
        'currency_id' => 1,
    ],

    'client bonus' => [
        'account_id'  => 9,
        'acc_kind_id' => 7,
        'acc_type_id' => 2,
        'owner_id'    => 1,
        'tenant_id'   => 1,
        'balance'     => 100,
        'currency_id' => 1,
    ],

    'company with credit' => [
        'account_id'  => 10,
        'acc_kind_id' => 4,
        'acc_type_id' => 2,
        'owner_id'    => 3,
        'tenant_id'   => 1,
        'balance'     => -100,
        'currency_id' => 1,
    ],

    'company with credit and not enough money for payment' => [
        'account_id'  => 11,
        'acc_kind_id' => 4,
        'acc_type_id' => 2,
        'owner_id'    => 4,
        'tenant_id'   => 1,
        'balance'     => -300,
        'currency_id' => 1,
    ],

    'blocked company account' => [
        'account_id'  => 12,
        'acc_kind_id' => 4,
        'acc_type_id' => 2,
        'owner_id'    => 5,
        'tenant_id'   => 1,
        'balance'     => 1000,
        'currency_id' => 1,
    ],

    'tenant4' => [
        'account_id'  => 50,
        'acc_kind_id' => 5,
        'acc_type_id' => 1,
        'owner_id'    => 4,
        'tenant_id'   => 4,
        'balance'     => 0,
        'currency_id' => 1,
    ],

    'client with no money on personal account but has bonus' => [
        'account_id'  => 51,
        'acc_kind_id' => 7,
        'acc_type_id' => 2,
        'owner_id'    => 6,
        'tenant_id'   => 1,
        'balance'     => 200,
        'currency_id' => 1,
    ],
];
