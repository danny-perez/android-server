<?php

return [
    'econom' => [
        'tariff_id' => 1,
        'tenant_id' => 1,
        'class_id'  => 1,
        'name'      => 'econom',
        'block'     => 0,
    ],

    'standart' => [
        'tariff_id' => 2,
        'tenant_id' => 1,
        'class_id'  => 2,
        'name'      => 'standart',
        'block'     => 0,
    ],

    'standart blocked' => [
        'tariff_id' => 3,
        'tenant_id' => 1,
        'class_id'  => 2,
        'name'      => 'standart',
        'block'     => 0,
    ],

    'standart bonus app' => [
        'tariff_id' => 4,
        'tenant_id' => 1,
        'class_id'  => 2,
        'name'      => 'standart',
        'block'     => 0,
    ],

    'standart tenant3' => [
        'tariff_id' => 5,
        'tenant_id' => 3,
        'class_id'  => 2,
        'name'      => 'standart',
        'block'     => 0,
    ],
];