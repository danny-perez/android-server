<?php

return [
    'worker1' => [
        'worker_id'             => 1,
        'tenant_id'             => 1,
        'callsign'              => 1,
        'phone'                 => '79999999999',
        'lang'                  => 'en',
        'device'                => 'ANDROID',
        'device_token'          => 'device token',
        'last_name'             => 'Testerov',
        'second_name'           => 'Testerovich',
        'name'                  => 'Tester',
        'yandex_account_number' => '410000000000000',
    ],

    'worker2' => [
        'worker_id' => 2,
        'tenant_id' => 3,
        'callsign'  => 2,
        'phone'     => '79999999999',
        'lang'      => 'en',
        'device'    => 'ANDROID',
    ],

    'worker3' => [
        'worker_id'    => 3,
        'tenant_id'    => 1,
        'callsign'     => 3,
        'phone'        => '79999999999',
        'lang'         => 'ru',
        'device'       => 'ANDROID',
        'device_token' => 'device token',
        'last_name'    => 'Test',
        'second_name'  => 'Test',
        'name'         => 'Test',
    ],
];
