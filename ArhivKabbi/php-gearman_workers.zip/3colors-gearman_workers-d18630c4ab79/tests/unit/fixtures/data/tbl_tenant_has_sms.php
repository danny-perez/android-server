<?php

return [
    'tenant1' => [
        'id'        => '1',
        'server_id' => '1',
        'tenant_id' => '1',
        'login'     => 'login',
        'password'  => 'password',
        'active'    => '1',
        'sign'      => 'test1',
    ],

    'tenant2' => [
        'id'        => '2',
        'server_id' => '1',
        'tenant_id' => '1',
        'login'     => 'login',
        'password'  => 'password',
        'active'    => '1',
        'sign'      => 'test2',
    ],
];
