<?php

return [
    'card payment' => [
        'id'         => 1,
        'order_id'   => 39,
        'pan'        => '522222****2227',
        'created_at' => '12321323',
        'updated_at' => '12312312',
    ],

    'card payment (with bonus payment)' => [
        'id'         => 2,
        'order_id'   => 40,
        'pan'        => '522222****2227',
        'created_at' => '12321323',
        'updated_at' => '12312312',
    ],
];
