<?php

return [
    'tenant1' => [
        'tenant_id'     => 1,
        'contact_phone' => '79999999999',
        'domain'        => 'test',
        'email'         => 'test@test.ru',
    ],

    'tenant3' => [
        'tenant_id'     => 3,
        'contact_phone' => '79999999999',
        'domain'        => 'test3',
        'email'         => 'test@test.ru',
    ],

    'tenant4' => [
        'tenant_id'     => 4,
        'contact_phone' => '79999999999',
        'domain'        => 'test4',
        'email'         => 'test@test.ru',
    ],
];