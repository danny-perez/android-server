<?php

return [
    'worker1' => [
        'worker_id'   => 1,
        'city_id'     => 26068,
        'last_active' => 1,
    ],

    'worker2' => [
        'worker_id'   => 2,
        'city_id'     => 26068,
        'last_active' => 1,
    ],

    'worker3' => [
        'worker_id'   => 3,
        'city_id'     => 26068,
        'last_active' => 1,
    ],
];
