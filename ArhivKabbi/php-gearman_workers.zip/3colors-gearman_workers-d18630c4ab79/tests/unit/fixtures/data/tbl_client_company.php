<?php

return [
    'company with money on balance' => [
        'company_id'    => 1,
        'tenant_id'     => 1,
        'city_id'       => 26068,
        'name'          => 'first company',
        'legal_address' => 'Izhevsk',
    ],

    'company with not money on balance' => [
        'company_id'    => 2,
        'tenant_id'     => 1,
        'city_id'       => 26068,
        'name'          => 'second company',
        'legal_address' => 'Izhevsk',
    ],

    'client company with credit' => [
        'company_id'    => 3,
        'tenant_id'     => 1,
        'city_id'       => 26068,
        'name'          => 'third company',
        'legal_address' => 'Izhevsk',
        'credits'       => 200,
    ],

    'client company with credit and not enough money for payment' => [
        'company_id'    => 4,
        'tenant_id'     => 1,
        'city_id'       => 26068,
        'name'          => 'fourth company',
        'legal_address' => 'Izhevsk',
        'credits'       => 200,
    ],

    'blocked client company' => [
        'company_id'    => 5,
        'tenant_id'     => 1,
        'city_id'       => 26068,
        'name'          => 'fifth company',
        'legal_address' => 'Izhevsk',
        'block'         => 1,
    ],
];
