<?php

return [
    'tariff1' => [
        'tariff_id' => 1,
        'city_id'   => 26068,
    ],

    'tariff2' => [
        'tariff_id' => 2,
        'city_id'   => 26068,
    ],

    'tariff3' => [
        'tariff_id' => 3,
        'city_id'   => 26068,
    ],

    'tariff5' => [
        'tariff_id' => 5,
        'city_id'   => 26068,
    ],
];