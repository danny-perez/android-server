<?php

return [
    'not a bonus tariff' => [
        'detail_id'    => 1,
        'order_id'     => 2,
        'summary_cost' => 100,
    ],

    'smaller summay cost' => [
        'detail_id'    => 2,
        'order_id'     => 3,
        'summary_cost' => 50,
    ],

    'safe bonus tariff' => [
        'detail_id'    => 3,
        'order_id'     => 4,
        'summary_cost' => 250,
    ],

    'check round bonus value' => [
        'detail_id'    => 4,
        'order_id'     => 5,
        'summary_cost' => 125.15,
    ],

    'check blocked bonus tariff' => [
        'detail_id'    => 5,
        'order_id'     => 6,
        'summary_cost' => 200,
    ],

    'order for company account' => [
        'detail_id'    => 6,
        'order_id'     => 7,
        'summary_cost' => 200,
    ],

    'first order from app' => [
        'detail_id'    => 7,
        'order_id'     => 8,
        'summary_cost' => 200,
    ],

    'second order from app' => [
        'detail_id'    => 8,
        'order_id'     => 9,
        'summary_cost' => 150,
    ],

    'order execution' => [
        'detail_id'    => 9,
        'order_id'     => 10,
        'summary_cost' => 150,
    ],

    'for no bonus payment (cash)' => [
        'detail_id'    => 10,
        'order_id'     => 11,
        'summary_cost' => 100,
        'commission'   => 5,
    ],

    'for partial bonus payment (cash)' => [
        'detail_id'    => 11,
        'order_id'     => 12,
        'summary_cost' => 100,
        'bonus'        => 50,
        'commission'   => 5,
    ],

    'for full bonus payment (cash)' => [
        'detail_id'    => 12,
        'order_id'     => 13,
        'summary_cost' => 100,
        'bonus'        => 100,
        'commission'   => 5,
    ],

    'for no bonus payment (personal account)' => [
        'detail_id'    => 13,
        'order_id'     => 14,
        'summary_cost' => 100,
        'commission'   => 5,
    ],

    'for partial bonus payment (personal account)' => [
        'detail_id'    => 14,
        'order_id'     => 15,
        'summary_cost' => 100,
        'bonus'        => 50,
        'commission'   => 5,
    ],

    'for full bonus payment (personal account)' => [
        'detail_id'    => 15,
        'order_id'     => 16,
        'summary_cost' => 100,
        'bonus'        => 100,
        'commission'   => 5,
    ],

    'not enough bonus for payment (cash)' => [
        'detail_id'    => 16,
        'order_id'     => 17,
        'summary_cost' => 400,
        'bonus'        => 200,
    ],

    'no money for payment (personal account)' => [
        'detail_id'    => 17,
        'order_id'     => 18,
        'summary_cost' => 200,
    ],

    'not enough money for payment (personal account)' => [
        'detail_id'    => 18,
        'order_id'     => 19,
        'summary_cost' => 500,
        'commission'   => 5,
    ],

    'for no bonus payment (corp account) must be only money payment' => [
        'detail_id'    => 20,
        'order_id'     => 20,
        'summary_cost' => 100,
        'commission'   => 5,
    ],

    'for partial bonus payment (corp account) must be only money payment' => [
        'detail_id'    => 21,
        'order_id'     => 21,
        'summary_cost' => 100,
        'bonus'        => 50,
    ],

    'for full bonus payment (corp account) must be only money payment' => [
        'detail_id'    => 22,
        'order_id'     => 22,
        'summary_cost' => 100,
        'bonus'        => 100,
    ],

    'not enough money for payment (corp account)' => [
        'detail_id'    => 23,
        'order_id'     => 23,
        'summary_cost' => 500,
        'commission'   => 5,
    ],

    'no money for payment (corp account)' => [
        'detail_id'    => 24,
        'order_id'     => 24,
        'summary_cost' => 500,
    ],

    'summary_cost not set' => [
        'detail_id'    => 25,
        'order_id'     => 25,
        'summary_cost' => -100,
    ],

    'first order from app device token exists invalid order time' => [
        'detail_id'    => 26,
        'order_id'     => 26,
        'summary_cost' => 200,
    ],

    'first order from app device token exists valid order time' => [
        'detail_id'    => 27,
        'order_id'     => 27,
        'summary_cost' => 200,
    ],

    'invalid bonus value' => [
        'detail_id'    => 28,
        'order_id'     => 28,
        'summary_cost' => 100,
        'bonus'        => 101,
    ],

    'payment already exists' => [
        'detail_id'    => 29,
        'order_id'     => 29,
        'summary_cost' => 100,
    ],

    'no payment method' => [
        'detail_id'    => 30,
        'order_id'     => 30,
        'summary_cost' => 100,
    ],

    'worker account not found' => [
        'detail_id'    => 31,
        'order_id'     => 31,
        'summary_cost' => 100,
    ],

    'system account not found' => [
        'detail_id'    => 32,
        'order_id'     => 32,
        'summary_cost' => 100,
    ],

    'client account not found' => [
        'detail_id'    => 33,
        'order_id'     => 33,
        'summary_cost' => 100,
    ],

    'no money for personal payment' => [
        'detail_id'    => 34,
        'order_id'     => 34,
        'summary_cost' => 10000,
    ],

    'not specified currency transaction' => [
        'detail_id'    => 35,
        'order_id'     => 35,
        'summary_cost' => 100,
    ],

    'card operation not supported' => [
        'detail_id'    => 36,
        'order_id'     => 36,
        'summary_cost' => 100,
    ],

    'refill bonus with summary_cost = 0' => [
        'detail_id'    => 37,
        'order_id'     => 37,
        'summary_cost' => 0,
    ],

    'summary_cost = 0' => [
        'detail_id'    => 38,
        'order_id'     => 38,
        'summary_cost' => 0,
    ],

    'card payment' => [
        'detail_id'    => 39,
        'order_id'     => 39,
        'summary_cost' => 200,
        'commission'   => 5,
    ],

    'card payment with write-off bonus' => [
        'detail_id'    => 40,
        'order_id'     => 40,
        'summary_cost' => 200,
        'bonus'        => 50,
        'commission'   => 5,
    ],

    'surcharge - for no bonus payment (cash)' => [
        'detail_id'    => 45,
        'order_id'     => 45,
        'summary_cost' => 100,
        'commission'   => 5,
        'surcharge'    => 50,
    ],

    'surcharge - for partial bonus payment (cash)' => [
        'detail_id'    => 46,
        'order_id'     => 46,
        'summary_cost' => 100,
        'bonus'        => 50,
        'commission'   => 5,
        'surcharge'    => 50,
    ],

    'surcharge - for full bonus payment (cash)' => [
        'detail_id'    => 47,
        'order_id'     => 47,
        'summary_cost' => 100,
        'bonus'        => 100,
        'commission'   => 5,
        'surcharge'    => 50,
    ],

    'surcharge (incorrect value) - for no bonus payment (cash)' => [
        'detail_id'    => 48,
        'order_id'     => 48,
        'summary_cost' => 100,
        'commission'   => 5,
        'surcharge'    => -50,
    ],

    'tax - for no bonus payment (cash)' => [
        'detail_id'    => 49,
        'order_id'     => 49,
        'summary_cost' => 100,
        'commission'   => 5,
        'tax'          => 10,
    ],

    'tax - for no bonus payment (personal account)' => [
        'detail_id'    => 50,
        'order_id'     => 50,
        'summary_cost' => 100,
        'commission'   => 5,
        'tax'          => 10,
    ],

    'tax - for partial bonus payment (personal account)' => [
        'detail_id'    => 51,
        'order_id'     => 51,
        'summary_cost' => 100,
        'bonus'        => 50,
        'commission'   => 5,
        'tax'          => 10,
    ],

    'tax - for full bonus payment (personal account)' => [
        'detail_id'    => 52,
        'order_id'     => 52,
        'summary_cost' => 100,
        'bonus'        => 100,
        'commission'   => 5,
        'tax'          => 10,
    ],

    'tax + surcharge - for no bonus payment (cash)' => [
        'detail_id'    => 53,
        'order_id'     => 53,
        'summary_cost' => 100,
        'commission'   => 5,
        'surcharge'    => 50,
        'tax'          => 10,
    ],

    'company with credit (corp account)' => [
        'detail_id'    => 54,
        'order_id'     => 54,
        'summary_cost' => 100,
    ],

    'company with credit and not enough money for payment (corp account)' => [
        'detail_id'    => 55,
        'order_id'     => 55,
        'summary_cost' => 100,
    ],

    'only referral bonus to referrer' => [
        'detail_id'    => 56,
        'order_id'     => 56,
        'summary_cost' => 0,
    ],

    'only referral bonus to referral' => [
        'detail_id'    => 57,
        'order_id'     => 57,
        'summary_cost' => 0,
    ],

    'only referral bonus to referrer and referral' => [
        'detail_id'    => 58,
        'order_id'     => 58,
        'summary_cost' => 0,
    ],

    'blocked company account' => [
        'detail_id'    => 59,
        'order_id'     => 59,
        'summary_cost' => 100,
    ],

    'for full bonus payment (personal account with empty balance)' => [
        'detail_id'    => 60,
        'order_id'     => 60,
        'summary_cost' => 100,
        'bonus'        => 100,
        'commission'   => 5,
    ],
];
