<?php

return [
    [
        'id'               => 1,
        'transaction_id'   => 3,
        'request_id'       => 'already processed request_id',
        'payment_order_id' => '123',
        'pan'              => '44xx55',
    ],
];