<?php

return [
    'car1' => [
        'car_id'     => 1,
        'tenant_id'  => 1,
        'class_id'   => 1,
        'city_id'    => 26068,
        'name'       => 'car 1',
        'gos_number' => '123123',
        'owner'      => 'WORKER',
    ],
];