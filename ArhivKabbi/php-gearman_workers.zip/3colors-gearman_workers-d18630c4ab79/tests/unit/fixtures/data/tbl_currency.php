<?php

return [
    [
        'currency_id' => 1,
        'type_id'     => 1,
        'name'        => 'Russian ruble',
        'code'        => 'RUB',
        'symbol'      => '₽',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 2,
        'type_id'     => 1,
        'name'        => 'American Dollar',
        'code'        => 'USD',
        'symbol'      => '$',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 3,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'AZN',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 4,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'RSD',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 6,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'BYR',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 9,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'EUR',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 10,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'KZT',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],

    [
        'currency_id' => 11,
        'type_id'     => 1,
        'name'        => '',
        'code'        => 'MDL',
        'symbol'      => '',
        'minor_unit'  => 2,
    ],
];
