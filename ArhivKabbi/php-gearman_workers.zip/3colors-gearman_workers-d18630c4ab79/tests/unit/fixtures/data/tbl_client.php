<?php

return [
    'client1' => [
        'client_id'    => 1,
        'tenant_id'    => 1,
        'city_id'      => 26068,
        'active'       => 1,
        'lang'         => 'ru',
        'last_name'    => 'Testerov',
        'second_name'  => 'Testerovich',
        'name'         => 'Tester',
        'device'       => 'ANDROID',
        'device_token' => 'device token',
        'app_id'       => 1,
    ],

    'client first order from app' => [
        'client_id'    => 2,
        'tenant_id'    => 1,
        'city_id'      => 26068,
        'active'       => 1,
        'device'       => 'ANDROID',
        'device_token' => 'device token',
        'app_id'       => 1,
    ],

    'client3' => [
        'client_id' => 3,
        'tenant_id' => 3,
        'city_id'   => 26068,
        'active'    => 1,
        //        'device'       => 'ANDROID',
        //        'device_token' => 'device token',
        'app_id'    => 1,
    ],

    'client with bonus' => [
        'client_id'    => 5,
        'tenant_id'    => 1,
        'city_id'      => 26068,
        'active'       => 1,
        'device'       => 'ANDROID',
        'device_token' => 'device token client5',
        'app_id'       => 1,
    ],

    'client with no money on personal account but has bonus' => [
        'client_id' => 6,
        'tenant_id' => 1,
        'city_id'   => 26068,
        'active'    => 1,
        'lang'      => 'ru',
        'app_id'    => 1,
    ],

];
