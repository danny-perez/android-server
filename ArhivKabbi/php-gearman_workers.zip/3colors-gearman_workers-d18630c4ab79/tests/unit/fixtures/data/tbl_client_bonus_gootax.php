<?php

return [
    'standart' => [
        'id'         => 1,
        'bonus_id'   => 1,
        'bonus'      => 10,
        'min_cost'   => 100,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    'standart blocked' => [
        'id'         => 2,
        'bonus_id'   => 2,
        'bonus'      => 10,
        'min_cost'   => 100,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    'standart with bonus app' => [
        'id'         => 11,
        'bonus_id'   => 11,
        'bonus'      => 10,
        'min_cost'   => 100,
        'bonus_app'  => 5,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    '15%' => [
        'id'         => 4,
        'bonus_id'   => 4,
        'bonus'      => 15,
        'bonus_type' => 'PERCENT',
        'min_cost'   => 100,
        'bonus_app'  => 5,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    '12.5%' => [
        'id'         => 5,
        'bonus_id'   => 5,
        'bonus'      => 12.5,
        'bonus_type' => 'PERCENT',
        'min_cost'   => 100,
        'bonus_app'  => 10,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    '20.25bonus' => [
        'id'         => 6,
        'bonus_id'   => 6,
        'bonus'      => 20.25,
        'bonus_type' => 'BONUS',
        'min_cost'   => 100,
        'bonus_app'  => 10,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    '100bonus' => [
        'id'         => 7,
        'bonus_id'   => 7,
        'bonus'      => 100,
        'bonus_type' => 'BONUS',
        'min_cost'   => 100,
        'bonus_app'  => 10,
        'created_at' => time(),
        'updated_at' => time(),
    ],

    '15.25%bonus_app' => [
        'id'             => 8,
        'bonus_id'       => 8,
        'bonus'          => 0,
        'bonus_type'     => 'PERCENT',
        'min_cost'       => 100,
        'bonus_app'      => 15.25,
        'bonus_app_type' => 'PERCENT',
        'created_at'     => time(),
        'updated_at'     => time(),
    ],

    '100.25bonus_app' => [
        'id'             => 9,
        'bonus_id'       => 9,
        'bonus'          => 0,
        'bonus_type'     => 'PERCENT',
        'min_cost'       => 100,
        'bonus_app'      => 100.25,
        'bonus_app_type' => 'BONUS',
        'created_at'     => time(),
        'updated_at'     => time(),
    ],

    '10 bonus and 50 bonus_app and min_cost = 0' => [
        'id'             => 10,
        'bonus_id'       => 10,
        'bonus'          => 10,
        'bonus_type'     => 'BONUS',
        'min_cost'       => 0,
        'bonus_app'      => 50,
        'bonus_app_type' => 'BONUS',
        'created_at'     => time(),
        'updated_at'     => time(),
    ],
];
