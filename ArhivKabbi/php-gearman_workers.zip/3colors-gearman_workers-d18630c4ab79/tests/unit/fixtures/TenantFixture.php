<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class TenantFixture extends ActiveFixture
{
    public $tableName = '{{%tenant}}';
}