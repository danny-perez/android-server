<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientFixture extends ActiveFixture
{
    public $tableName = '{{%client}}';

    public $depends = [
        TenantFixture::class,
        CityFixture::class,
    ];
}