<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class TransactionFixture extends ActiveFixture
{
    public $tableName = '{{%transaction}}';

    public $depends = [
        AccountFixture::class,
        OrderFixture::class,
        TenantFixture::class,
        CityFixture::class,
    ];
}