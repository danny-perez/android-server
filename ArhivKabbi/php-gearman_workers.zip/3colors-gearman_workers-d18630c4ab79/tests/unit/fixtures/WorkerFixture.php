<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class WorkerFixture extends ActiveFixture
{
    public $tableName = '{{%worker}}';

    public $depends = [
        TenantFixture::class,
    ];
}