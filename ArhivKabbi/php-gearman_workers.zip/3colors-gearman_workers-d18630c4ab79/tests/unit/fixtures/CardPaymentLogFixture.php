<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class CardPaymentLogFixture extends ActiveFixture
{
    public $tableName = '{{%card_payment_log}}';

    public $depends = [
        TenantFixture::class,
        OrderFixture::class,
        ClientFixture::class,
        WorkerFixture::class,
    ];

}