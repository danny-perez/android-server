<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class AccountFixture extends ActiveFixture
{
    public $tableName = '{{%account}}';

    public $depends = [
        CurrencyFixture::class,
        ClientFixture::class,
        ClientCompanyFixture::class,
        WorkerFixture::class,
        TenantFixture::class,
    ];
}