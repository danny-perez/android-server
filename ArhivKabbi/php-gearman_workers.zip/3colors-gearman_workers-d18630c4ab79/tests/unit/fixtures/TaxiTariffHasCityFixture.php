<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class TaxiTariffHasCityFixture extends ActiveFixture
{
    public $tableName = '{{%taxi_tariff_has_city}}';

    public $depends = [
        TaxiTariffFixture::class,
        CityFixture::class,
    ];
}