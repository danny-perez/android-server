<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class TaxiTariffFixture extends ActiveFixture
{
    public $tableName = '{{%taxi_tariff}}';

    public $depends = [
        TenantFixture::class,
    ];
}