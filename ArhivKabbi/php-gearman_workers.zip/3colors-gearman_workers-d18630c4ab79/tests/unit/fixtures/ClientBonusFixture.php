<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientBonusFixture extends ActiveFixture
{
    public $modelClass = 'console\components\billing\models\ClientBonus';

    public $depends = [
        CityFixture::class,
    ];
}