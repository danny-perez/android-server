<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class WorkerBalanceNotificationFixture extends ActiveFixture
{
    public $tableName = '{{%worker_balance_notification}}';

    public $depends = [
        TenantFixture::class,
    ];
}