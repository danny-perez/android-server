<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class OperationFixture extends ActiveFixture
{
    public $tableName = '{{%operation}}';

    public $depends = [
        AccountFixture::class,
        TransactionFixture::class,
    ];
}