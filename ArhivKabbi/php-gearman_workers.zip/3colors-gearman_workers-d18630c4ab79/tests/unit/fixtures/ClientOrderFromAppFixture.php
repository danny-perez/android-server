<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class ClientOrderFromAppFixture extends ActiveFixture
{
    public $tableName = '{{%client_order_from_app}}';

    public $depends = [
        ClientFixture::class,
    ];
}