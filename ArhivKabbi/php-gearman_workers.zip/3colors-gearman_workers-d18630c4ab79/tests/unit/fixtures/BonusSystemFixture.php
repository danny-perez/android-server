<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class BonusSystemFixture extends ActiveFixture
{
    public $modelClass = 'console\components\billing\models\BonusSystem';
}