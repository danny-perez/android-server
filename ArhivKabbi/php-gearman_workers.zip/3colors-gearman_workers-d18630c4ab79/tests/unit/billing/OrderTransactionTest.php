<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use credit\CreditServiceFactory;
use console\components\billing\transactions\Transaction;
use console\components\billing\Account;
use console\components\billing\models\Order;
use console\components\billing\Operation;
use tests\unit\billing\models\OrderTransaction;
use tests\unit\billing\models\PushNotificationManager;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CardPaymentFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\ReferralBonusForOrderFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;
use yii\db\Query;

class OrderTransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'workers'               => WorkerFixture::class,
            'workerHasCity'         => WorkerHasCityFixture::class,
            'clientCompany'         => ClientCompanyFixture::class,
            'accounts'              => AccountFixture::class,
            'orders'                => OrderFixture::class,
            'orderDetailCost'       => OrderDetailCostFixture::class,
            'transactions'          => TransactionFixture::class,
            'operations'            => OperationFixture::class,
            'clientOrderFromApp'    => ClientOrderFromAppFixture::class,
            'clientBonuses'         => ClientBonusFixture::class,
            'clientBonusGootax'     => ClientBonusGootaxFixture::class,
            'clientBonusHasTariffs' => ClientBonusHasTariffFixture::class,
            'cardPayments'          => CardPaymentFixture::class,
            'referralBonus'         => ReferralBonusForOrderFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction;
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }


    private function getActiveRecordBalance($activeRecord)
    {
        return empty($activeRecord) ? 0 : (float)$activeRecord->balance;
    }

    private function refreshActiveRecord($activeRecord)
    {
        if (!empty($activeRecord)) {
            $activeRecord->refresh();
        }
    }


    public function orderPaymentData()
    {
        return [
            'refill bonus with summary_cost = 0' => [
                37,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 0,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 300,
                    'system_bonus'     => 60,
                    'client_bonus'     => 160,
                ],
            ],

            'no bonus payment (cash)' => [
                11,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -5,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 295,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'partial bonus payment (cash)' => [
                12,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 45,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 345,
                    'system_bonus'     => -50,
                    'client_bonus'     => 50,
                ],
            ],

            'full bonus payment (cash)' => [
                13,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 95,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => -100,
                    'client_bonus'     => 0,
                ],
            ],

            'no bonus payment (personal account)' => [
                14,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -5,
                    'client'           => 50,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'partial bonus payment (personal account)' => [
                15,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 45,
                    'client'           => 100,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => -50,
                    'client_bonus'     => 50,
                ],
            ],

            'full bonus payment (personal account)' => [
                16,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 95,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => -100,
                    'client_bonus'     => 0,
                ],
            ],

            'full bonus payment (personal account with empty balance)' => [
                60,
                [
                    'old_system'       => 0,
                    'old_client'       => 0,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 200,
                    'system'           => 95,
                    'client'           => 0,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => -100,
                    'client_bonus'     => 100,
                ],
            ],

            'not enough money for payment (personal account)' => [
                19,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -5,
                    'client'           => -350,
                    'company'          => 200,
                    'worker'           => 795,
                    'system_bonus'     => 50,
                    'client_bonus'     => 150,
                ],
            ],

            'no bonus payment (corp account)' => [
                20,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -5,
                    'client'           => 150,
                    'company'          => 100,
                    'worker'           => 395,
                    'system_bonus'     => 0,
                    'client_bonus'     => 100,
                ],
            ],

            'surcharge - no bonus payment (cash)' => [
                45,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 45,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 345,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'surcharge - partial bonus payment (cash)' => [
                46,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 95,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 395,
                    'system_bonus'     => -50,
                    'client_bonus'     => 50,
                ],
            ],

            'surcharge - full bonus payment (cash)' => [
                47,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 145,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 445,
                    'system_bonus'     => -100,
                    'client_bonus'     => 0,
                ],
            ],

            'surcharge (incorrect value) - no bonus payment (cash)' => [
                48,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -5,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 295,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'tax - no bonus payment (cash)' => [
                49,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -15,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 285,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'tax - no bonus payment (personal account)' => [
                50,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => -15,
                    'client'           => 50,
                    'company'          => 200,
                    'worker'           => 385,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'tax - partial bonus payment (personal account)' => [
                51,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 35,
                    'client'           => 100,
                    'company'          => 200,
                    'worker'           => 385,
                    'system_bonus'     => -50,
                    'client_bonus'     => 50,
                ],
            ],

            'tax - full bonus payment (personal account)' => [
                52,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 85,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 385,
                    'system_bonus'     => -100,
                    'client_bonus'     => 0,
                ],
            ],

            'tax+surcharge - no bonus payment (cash)' => [
                53,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => 200,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 35,
                    'client'           => 150,
                    'company'          => 200,
                    'worker'           => 335,
                    'system_bonus'     => 10,
                    'client_bonus'     => 110,
                ],
            ],

            'company with credit(corp balance)' => [
                54,
                [
                    'old_system'       => 0,
                    'old_client'       => 150,
                    'old_company'      => -100,
                    'old_worker'       => 300,
                    'old_system_bonus' => 0,
                    'old_client_bonus' => 100,
                    'system'           => 0,
                    'client'           => 150,
                    'company'          => -200,
                    'worker'           => 400,
                    'system_bonus'     => 0,
                    'client_bonus'     => 100,
                ],
            ],
        ];
    }

    /**
     * @dataProvider orderPaymentData
     */
    public function testOrderPayment($orderId, $expected)
    {
        $order      = Order::findOne($orderId);
        $tenantId   = $order->tenant_id;
        $clientId   = $order->client_id;
        $companyId  = $order->company_id;
        $workerId   = $order->worker_id;
        $currencyId = $order->currency_id;

        $systemAccount      = $this->testTransaction
            ->createAccount(0, $tenantId, Account::SYSTEM_KIND,
                Account::ACTIVE_TYPE, $currencyId);
        $clientAccount      = $this->testTransaction
            ->getAccount($clientId, $tenantId, Account::CLIENT_KIND, $currencyId);
        $companyAccount     = $this->testTransaction
            ->getAccount($companyId, $tenantId, Account::COMPANY_KIND, $currencyId);
        $workerAccount      = $this->testTransaction
            ->getAccount($workerId, $tenantId, Account::WORKER_KIND, $currencyId);
        $clientBonusAccount = $this->testTransaction
            ->getAccount($clientId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);

        $orderTransaction->save();

        $result                     = [];
        $result['old_system']       = $this->getActiveRecordBalance($systemAccount);
        $result['old_client']       = $this->getActiveRecordBalance($clientAccount);
        $result['old_company']      = $this->getActiveRecordBalance($companyAccount);
        $result['old_worker']       = $this->getActiveRecordBalance($workerAccount);
        $result['old_system_bonus'] = 0;
        $result['old_client_bonus'] = $this->getActiveRecordBalance($clientBonusAccount);

        $this->refreshActiveRecord($systemAccount);
        $this->refreshActiveRecord($clientAccount);
        $this->refreshActiveRecord($companyAccount);
        $this->refreshActiveRecord($workerAccount);
        $this->refreshActiveRecord($clientBonusAccount);
        $systemBonusAccount = $this->testTransaction
            ->getAccount(0, $tenantId, Account::SYSTEM_BONUS_KIND, $currencyId);

        $result['system']       = $this->getActiveRecordBalance($systemAccount);
        $result['client']       = $this->getActiveRecordBalance($clientAccount);
        $result['company']      = $this->getActiveRecordBalance($companyAccount);
        $result['worker']       = $this->getActiveRecordBalance($workerAccount);
        $result['system_bonus'] = $this->getActiveRecordBalance($systemBonusAccount);
        $result['client_bonus'] = $this->getActiveRecordBalance($clientBonusAccount);

        $this->assertEquals($expected, $result);
    }

    public function createdTransactionsData()
    {
        return [
            'refill bonus with summary_cost = 0' => [
                37,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 0,
                ],
                [
                    // added empty operations
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 0,
                        'saldo'        => 300,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 0,
                        'saldo'        => 0,
                    ],
                    //
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 60,
                        'saldo'        => 160,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 60,
                        'saldo'        => 60,
                    ],
                ],
            ],

            'no bonus payment (cash)' => [
                11,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 295,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'partial bonus payment (cash)' => [
                12,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => -50,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 200,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 350,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 345,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 45,
                    ],
                ],
            ],

            'full bonus payment (cash)' => [
                13,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => -100,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 250,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 95,
                    ],
                ],
            ],

            'no bonus payment (personal account)' => [
                14,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'partial bonus payment (personal account)' => [
                15,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => -50,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 200,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 45,
                    ],
                ],
            ],

            'full bonus payment (personal account)' => [
                16,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => -100,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 250,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 95,
                    ],
                ],
            ],

            'not enough money for payment (personal account)' => [
                19,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 500,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 500,
                        'saldo'        => -350,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 500,
                        'saldo'        => 800,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 795,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                ],
            ],

            'no bonus payment (corp account) must be only money payment' => [
                20,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 7,
                        'owner_name'   => 'first company',
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                ],
            ],

            'not enough money for payment (corp account)' => [
                23,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 500,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 7,
                        'owner_name'   => 'first company',
                        'sum'          => 500,
                        'saldo'        => -300,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 500,
                        'saldo'        => 800,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 795,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                ],
            ],

            'surcharge - no bonus payment (cash)' => [
                45,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 295,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 345,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 45,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'surcharge - partial bonus payment (cash)' => [
                46,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => -50,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 200,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 350,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 345,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 45,
                    ],
                    [
                        'operation_id' => 9,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 10,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 95,
                    ],
                ],
            ],

            'surcharge - full bonus payment (cash)' => [
                47,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => -100,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 250,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 95,
                    ],
                    [
                        'operation_id' => 9,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 445,
                    ],
                    [
                        'operation_id' => 10,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 145,
                    ],
                ],
            ],

            'surcharge (incorrect value) - no bonus payment (cash)' => [
                48,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 295,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'tax - no bonus payment (cash)' => [
                49,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 295,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 10,
                        'saldo'        => 285,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => -15,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'tax - no bonus payment (personal account)' => [
                50,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 10,
                        'saldo'        => 385,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => -15,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'tax - partial bonus payment (personal account)' => [
                51,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => -50,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 200,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 45,
                    ],
                    [
                        'operation_id' => 9,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 10,
                        'saldo'        => 385,
                    ],
                    [
                        'operation_id' => 10,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 35,
                    ],
                ],
            ],

            'tax - full bonus payment (personal account)' => [
                52,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => -100,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 250,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 100,
                        'saldo'        => 100,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 5,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 100,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 100,
                        'saldo'        => 400,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 395,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => 95,
                    ],
                    [
                        'operation_id' => 9,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 10,
                        'saldo'        => 385,
                    ],
                    [
                        'operation_id' => 10,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 85,
                    ],
                ],
            ],

            'tax+surcharge - no bonus payment (cash)' => [
                53,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 100,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 5,
                        'saldo'        => 295,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 5,
                        'saldo'        => -5,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 10,
                        'saldo'        => 285,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => -15,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 50,
                        'saldo'        => 335,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 52,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 35,
                    ],
                    [
                        'operation_id' => 7,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 10,
                        'saldo'        => 110,
                    ],
                    [
                        'operation_id' => 8,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 10,
                        'saldo'        => 10,
                    ],
                ],
            ],

            'only referral bonus to referrer' => [
                56,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 0,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 0,
                        'saldo'        => 300,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 0,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 50,
                        'saldo'        => 150,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 55,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                ],
            ],

            'only referral bonus to referral' => [
                57,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 0,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 0,
                        'saldo'        => 300,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 0,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 54,
                        'owner_name'   => '',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 55,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                ],
            ],

            'only referral bonus to referrer and referral' => [
                58,
                [
                    'type_id' => Transaction::ORDER_PAYMENT_TYPE,
                    'sum'     => 0,
                ],
                [
                    [
                        'operation_id' => 1,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 4,
                        'owner_name'   => 'Testerov Tester Testerovich (1)',
                        'sum'          => 0,
                        'saldo'        => 300,
                    ],
                    [
                        'operation_id' => 2,
                        'type_id'      => Operation::EXPENSES_TYPE,
                        'account_id'   => 53,
                        'owner_name'   => null,
                        'sum'          => 0,
                        'saldo'        => 0,
                    ],
                    [
                        'operation_id' => 3,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 9,
                        'owner_name'   => 'Testerov Tester Testerovich',
                        'sum'          => 20,
                        'saldo'        => 120,
                    ],
                    [
                        'operation_id' => 4,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 55,
                        'owner_name'   => null,
                        'sum'          => 20,
                        'saldo'        => 20,
                    ],
                    [
                        'operation_id' => 5,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 54,
                        'owner_name'   => '',
                        'sum'          => 50,
                        'saldo'        => 50,
                    ],
                    [
                        'operation_id' => 6,
                        'type_id'      => Operation::INCOME_TYPE,
                        'account_id'   => 55,
                        'owner_name'   => null,
                        'sum'          => 50,
                        'saldo'        => 70,
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider createdTransactionsData
     */
    public function testCreatedTransactions(
        $orderId,
        $expectedTransaction,
        $expectedOperations
    ) {
        $order = Order::findOne($orderId);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);
        $orderTransaction->save();

        $transaction        = TestTransaction::find()
            ->select(['type_id', 'sum'])
            ->where(['order_id' => $orderId])
            ->asArray()
            ->one();
        $transaction['sum'] = (float)$transaction['sum'];

        $this->assertEquals($expectedTransaction, $transaction);

        $operations = Operation::find()
            ->select([
                'operation_id',
                'type_id',
                'account_id',
                'owner_name',
                'sum',
                'saldo',
            ])
            ->asArray()
            ->all();

        for ($i = 0, $l = count($operations); $i < $l; $i++) {
            $expected = empty($expectedOperations[$i]) ? [] : $expectedOperations[$i];

            $operations[$i]['sum']   = (float)$operations[$i]['sum'];
            $operations[$i]['saldo'] = (float)$operations[$i]['saldo'];
            $this->assertEquals($expected, $operations[$i]);
        }
    }


    public function orderPaymentRefillBonusData()
    {
        return [
            'order with refill bonus' => [
                9,
                [
                    'refill_bonus_id' => 11,
                    'refill_bonus'    => 15,
                ],
            ],

            'order without refill bonus' => [
                7,
                [
                    'refill_bonus_id' => null,
                    'refill_bonus'    => null,
                ],
            ],

            'bonus +first order from app' => [
                8,
                [
                    'refill_bonus_id' => 11,
                    'refill_bonus'    => 30,
                ],
            ],

            'refilled bonus with summary_cost = 0' => [
                37,
                [
                    'refill_bonus_id' => 10,
                    'refill_bonus'    => 60,
                ],
            ],
        ];
    }

    /**
     * @dataProvider orderPaymentRefillBonusData
     */
    public function testOrderPaymentRefillBonus($orderId, $expected)
    {
        $order = Order::findOne($orderId);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);
        $orderTransaction->save();
        $order->refresh();

        $this->assertEquals($expected, [
            'refill_bonus_id' => $order->orderDetailCost->refill_bonus_id,
            'refill_bonus'    => (float)$order->orderDetailCost->refill_bonus,
        ]);
    }


    public function orderPaymentExceptionsData()
    {
        return [
            'not found order' => [
                -1,
                '\console\components\billing\exceptions\NotFoundException',
            ],

            'summary_cost < 0' => [
                25,
                '\console\components\billing\exceptions\InvalidSumException',
            ],

            //            // throwing exception was removed
            //            'summary_cost = 0 (without bonus)'               => [
            //                38, '\console\components\billing\exceptions\NoBalanceChangesException',
            //            ],
            //            'no bonus for payment'                 => [
            //                17, '\console\components\billing\exceptions\NoBonusForPaymentException',
            //            ],

            'partial bonus payment (corp account)' => [
                21,
                '\console\components\billing\exceptions\WriteoffBonusInCorpPaymentException',
            ],

            'full bonus payment (corp account)' => [
                22,
                '\console\components\billing\exceptions\WriteoffBonusInCorpPaymentException',
            ],

            'no money for corp payment' => [
                24,
                '\console\components\billing\exceptions\NoMoneyException',
            ],

            'invalid bonus value' => [
                28,
                '\console\components\billing\exceptions\InvalidBonusValueException',
            ],

            'payment allready exists' => [
                29,
                '\console\components\billing\exceptions\PaymentAlreadyExistsException',
            ],

            'no payment method' => [
                //30, '\console\components\billing\exceptions\NotFoundException',
                // message: "Undefined index: "
                30,
                '\yii\base\ErrorException',
            ],

            // exception not throw now (The worker account will be created automatic)
            //            'worker account not found'             => [
            //                31, '\console\components\billing\exceptions\NotFoundException',
            //            ],
            // db exception will be throwed now (The system account will be created automatic)
            //            'system account not found'             => [
            //                32, '\yii\db\Exception',
            //            ],
            // NoMoneyException will be throwed now (The client account will be created automatic)

            'client account not found' => [
                33,
                '\console\components\billing\exceptions\NoMoneyException',
            ],

            'no money for personal payment' => [
                34,
                '\console\components\billing\exceptions\NoMoneyException',
            ],

            'not specified currency transaction' => [
                35,
                '\console\components\billing\exceptions\NotFoundException',
                'Not specified transaction currency',
            ],

            'not enough money for corp payment (company with credit)' => [
                55,
                '\console\components\billing\exceptions\NoMoneyException',
            ],

            'blocked company' => [
                59,
                '\console\components\billing\exceptions\BlockedCompanyException',
            ],
        ];
    }

    /**
     * @dataProvider orderPaymentExceptionsData
     */
    public function testOrderPaymentsExceptions(
        $orderId,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);
        $orderTransaction->save();
    }


    public function orderPaymentPushNotificationsData()
    {
        return [
            'no bonus payment (cash)' => [
                11,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=295',
                ],
            ],

            'partial bonus payment (cash)' => [
                12,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=345',
                ],
            ],

            'full bonus payment (cash)' => [
                13,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=0&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'no bonus payment (personal account)' => [
                14,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=50&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'partial bonus payment (personal account)' => [
                15,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=100&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'full bonus payment (personal account)' => [
                16,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=0&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'not enough money for payment (personal account)' => [
                19,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=-350&bonus_balance=150&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=795',
                ],
            ],

            'no bonus payment (corp account)' => [
                20,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'not enough money for payment (corp account)' => [
                23,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=795',
                ],
            ],

            'surcharge - no bonus payment (cash)' => [
                45,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=345',
                ],
            ],

            'surcharge - partial bonus payment (cash)' => [
                46,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=395',
                ],
            ],

            'surcharge - full bonus payment (cash)' => [
                47,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=0&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=445',
                ],
            ],

            'surcharge (incorrect value) - no bonus payment (cash)' => [
                48,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=295',
                ],
            ],

            'tax - no bonus payment (cash)' => [
                49,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=285',
                ],
            ],

            'tax - no bonus payment (personal account)' => [
                50,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=50&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=385',
                ],
            ],

            'tax - partial bonus payment (personal account)' => [
                51,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=100&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=385',
                ],
            ],

            'tax - full bonus payment (personal account)' => [
                52,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=0&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=385',
                ],
            ],

            'tax+surcharge - no bonus payment (cash)' => [
                53,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=110&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=335',
                ],
            ],

            'only referral bonus to referrer' => [
                56,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=150&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=300',
                ],
            ],

            'only referral bonus to referral' => [
                57,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token%20client5&lang=ru&currency=RUB&balance=0&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=300',
                ],
            ],

            'only referral bonus to referrer and referral' => [
                58,
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token%20client5&lang=ru&currency=RUB&balance=0&bonus_balance=50&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=150&bonus_balance=120&app_id=1',
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=300',
                ],
            ],
        ];
    }

    /**
     * @dataProvider orderPaymentPushNotificationsData
     */
    public function testOrderPaymentPushNotifications($orderId, $expectedNotifications)
    {
        $order = Order::findOne($orderId);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);
        $orderTransaction->save();

        $pushNotificationManager = new PushNotificationManager();
        $pushNotificationManager->sendNotifications($orderTransaction->notifications);
        $this->assertEquals($expectedNotifications, $pushNotificationManager->notifications);
    }

    public function referralBonusData()
    {
        return [
            'only referral bonus to referrer' => [
                56,
                [
                    'old_system_bonus'   => 0,
                    'old_referrer_bonus' => 100,
                    'old_referral_bonus' => 0,
                    'system_bonus'       => 50,
                    'referrer_bonus'     => 150,
                    'referral_bonus'     => 0,
                ],
            ],

            'only referral bonus to referral' => [
                57,
                [
                    'old_system_bonus'   => 0,
                    'old_referrer_bonus' => 100,
                    'old_referral_bonus' => 0,
                    'system_bonus'       => 50,
                    'referrer_bonus'     => 100,
                    'referral_bonus'     => 50,
                ],
            ],

            'only referral bonus to referrer and referral' => [
                58,
                [
                    'old_system_bonus'   => 0,
                    'old_referrer_bonus' => 100,
                    'old_referral_bonus' => 0,
                    'system_bonus'       => 70,
                    'referrer_bonus'     => 120,
                    'referral_bonus'     => 50,
                ],
            ],
        ];
    }

    /**
     * @dataProvider referralBonusData
     */
    public function testReferralBonus($orderId, $expected)
    {
        $order      = Order::findOne($orderId);
        $tenantId   = $order->tenant_id;
        $currencyId = $order->currency_id;

        $bonus = (new Query())
            ->from('{{%referral_bonus_for_order}}')
            ->select(['referrer_id', 'referral_id'])
            ->where(['order_id' => $orderId])
            ->one();

        $referrerId = $bonus['referrer_id'];
        $referralId = $bonus['referral_id'];

        $referrerBonusAccount = $this->testTransaction
            ->getAccount($referrerId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);
        $referralBonusAccount = $this->testTransaction
            ->getAccount($referralId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), ['order_id' => $orderId]);
        $orderTransaction->save();

        $result                       = [];
        $result['old_system_bonus']   = 0;
        $result['old_referrer_bonus'] = $this->getActiveRecordBalance($referrerBonusAccount);
        $result['old_referral_bonus'] = $this->getActiveRecordBalance($referralBonusAccount);

        $referrerBonusAccount = $this->testTransaction
            ->getAccount($referrerId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);
        $referralBonusAccount = $this->testTransaction
            ->getAccount($referralId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);
        $systemBonusAccount   = $this->testTransaction
            ->getAccount(0, $tenantId, Account::SYSTEM_BONUS_KIND, $currencyId);

        $result['system_bonus']   = $this->getActiveRecordBalance($systemBonusAccount);
        $result['referrer_bonus'] = $this->getActiveRecordBalance($referrerBonusAccount);
        $result['referral_bonus'] = $this->getActiveRecordBalance($referralBonusAccount);

        $this->assertEquals($expected, $result);
    }

}