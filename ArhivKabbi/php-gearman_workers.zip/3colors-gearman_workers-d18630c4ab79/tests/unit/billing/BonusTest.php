<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\models\Bonus;
use console\components\billing\models\Order;

use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CarFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TaxiTariffFixture;
use tests\unit\fixtures\TaxiTariffHasCityFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class BonusTest extends Unit
{
    protected $tester;

    /**
     * @var Bonus
     */
    private $bonus;

    public function _fixtures()
    {
        return [
            'cars'                   => CarFixture::class,
            'clientBonuses'          => ClientBonusFixture::class,
            'clientBonusGootax'      => ClientBonusGootaxFixture::class,
            'clientBonusesHasTariff' => ClientBonusHasTariffFixture::class,
            'clientOrderFromApp'     => ClientOrderFromAppFixture::class,
            'clients'                => ClientFixture::class,
            'workers'                => WorkerFixture::class,
            'workerHasCity'          => WorkerHasCityFixture::class,
            'orderDetailCost'        => OrderDetailCostFixture::class,
            'orders'                 => OrderFixture::class,
            'tariffs'                => TaxiTariffFixture::class,
            'tariffHasCity'          => TaxiTariffHasCityFixture::class,
            'tenants'                => TenantFixture::class,
            'accounts'               => AccountFixture::class,
            'transactions'           => TransactionFixture::class,
            'operations'             => OperationFixture::class,
        ];
    }

    protected function _before()
    {
        $this->bonus = new Bonus;
    }

    protected function _after()
    {
        $this->bonus = null;
    }


    /**
     * Return data for calculate bonus
     * @return array
     */
    public function calculateBonusData()
    {
        return [
            'not exists order'                                            => [0, Order::STATUS_ID_COMPLETE_PAID, 0],
            'not executed order'                                          => [1, Order::STATUS_ID_COMPLETE_PAID, 0],
            'not a bonus tariff'                                          => [2, Order::STATUS_ID_COMPLETE_PAID, 0],
            'smaller summary cost'                                        => [3, Order::STATUS_ID_COMPLETE_PAID, 0],
            'safe bonus tariff'                                           => [4, Order::STATUS_ID_COMPLETE_PAID, 25],
            'safe with error status'                                      => [4, Order::STATUS_ID_COMPLETE_NOT_PAID, 0],
            'check round bonus value'                                     => [5, Order::STATUS_ID_COMPLETE_PAID, 12.52],
            'check blocked bonus tariff'                                  => [6, Order::STATUS_ID_COMPLETE_PAID, 0],
            'order for company account'                                   => [7, Order::STATUS_ID_COMPLETE_PAID, 0],
            'first order from app'                                        => [8, Order::STATUS_ID_COMPLETE_PAID, 30],
            'second order from app'                                       => [9, Order::STATUS_ID_COMPLETE_PAID, 15],
            'first order from app device token exists invalid order time' => [26, Order::STATUS_ID_COMPLETE_PAID, 20],
            'first order from app device token exists valid order time'   => [27, Order::STATUS_ID_COMPLETE_PAID, 30],
        ];
    }

    /**
     * @dataProvider calculateBonusData
     */
    public function testCalculateBonus($orderId, $orderStatusId, $expected)
    {
        $this->assertEquals($expected, $this->bonus->calculateOrderBonus($orderId, $orderStatusId));
    }


    /**
     * Return data for test function `getBonus`
     * @return array
     */
    public function getBonusData()
    {
        return [
            '15%'        => ['15%', 1000, 150],
            '12.5%'      => ['12.5%', 100, 12.5],
            '20.25bonus' => ['20.25bonus', 9999, 20.25],
            '100bonus'   => ['100bonus', 1, 100],
        ];
    }

    /**
     * @dataProvider getBonusData
     */
    public function testGetBonus($clientBonusName, $orderCost, $expected)
    {
        $bonusValue = $this->bonus->getBonus(
            $this->tester->grabFixture('clientBonuses', $clientBonusName), $orderCost);
        $this->assertEquals($expected, $bonusValue);
    }


    /**
     * Return data for test function `getBonusApp`
     * @return array
     */
    public function getBonusAppData()
    {
        return [
            '15.25%bonus_app' => ['15.25%bonus_app', 1000, 152.5],
            '100.25bonus_app' => ['100.25bonus_app', 1, 100.25],
        ];
    }

    /**
     * @dataProvider getBonusAppData
     */
    public function testGetBonusApp($clientBonusName, $orderCost, $expected)
    {
        $bonusAppValue = $this->bonus->getBonusApp(
            $this->tester->grabFixture('clientBonuses', $clientBonusName), $orderCost);
        $this->assertEquals($expected, $bonusAppValue);
    }


    /**
     * Return data for check actual date
     * @return array
     */
    public function checkActualDateData()
    {
        return [
            'safe'                     => [null, time(), true],

            // 14.11.2015 saturday
            'saturday true'            => ['Saturday', 1447487269, true],
            'sunday false'             => ['Sunday', 1447487269, false],
            'monday, saturday true'    => ['Monday;Saturday', 1447487269, true],
            '14.11 true'               => ['14.11', 1447487269, true],
            '14.11.2015 true'          => ['14.11.2015', 1447487269, true],
            '14.11, saturday true'     => ['14.11;Saturday', 1447487269, true],
            '15.11;15.11.2015 false'   => ['15.11;15.11.2015', 1447487269, false],

            // 01.02.2015 sunday
            '01.02.2015 true'          => ['01.02.2015', 1422776869, true],
            '01.03;Sunday true'        => ['01.03;Sunday', 1422776869, true],

            // time intervals
            'Friday|08:00-20:00 true'  => ['Friday|08:00-20:00', mktime(10, 0, 0, 9, 30, 2016), true],
            'Friday|10:00-12:00 true'  => ['Friday|10:00-12:00', mktime(10, 0, 0, 9, 30, 2016), true],
            'Friday|10:00-12:00 false' => ['Friday|10:00-12:00', mktime(9, 59, 59, 9, 30, 2016), false],
            'Friday|10:00-20:00 true'  => ['Friday|10:00-20:00', mktime(20, 0, 0, 9, 30, 2016), true],
            'Friday|10:00-20:00 false' => ['Friday|10:00-20:00', mktime(20, 1, 0, 9, 30, 2016), false],

            'Saturday|00:00-23:59 false' => ['Saturday|00:00-23:59', mktime(0, 0, 0, 10, 2, 2016), false],
            'Thursday|00:00-23:59 false' => ['Thursday|00:00-23:59', mktime(23, 59, 59, 9, 28, 2016), false],

            '30.09|08:00-20:00 true'  => ['30.09|08:00-20:00', mktime(10, 0, 0, 9, 30, 2016), true],
            '30.09|08:00-20:00 false' => ['30.09|08:00-20:00', mktime(7, 59, 0, 9, 30, 2016), false],

            '30.09.2016|08:00-20:00 true'  => ['30.09.2016|08:00-20:00', mktime(10, 0, 0, 9, 30, 2016), true],
            '30.09.2016|08:00-20:00 false' => ['30.09.2016|08:00-20:00', mktime(20, 1, 0, 9, 30, 2016), false],

            '30.09.2016|15:30-18:00 false' => ['30.09.2016|15:30-18:00', mktime(15, 19, 30, 9, 30, 2016), false],
        ];
    }

    /**
     * @dataProvider checkActualDateData
     */
    public function testCheckActualDate($actualDate, $orderTime, $expected)
    {
        $this->assertEquals($expected, $this->bonus->checkActualDate($actualDate, $orderTime));
    }

}