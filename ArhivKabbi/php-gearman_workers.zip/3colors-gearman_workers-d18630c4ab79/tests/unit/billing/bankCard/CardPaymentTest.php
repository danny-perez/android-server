<?php

namespace tests\unit\billing\bankCard;

use Codeception\Test\Unit;
use Codeception\Util\Debug;
use console\components\billing\Account;
use console\components\billing\models\Order;
use console\components\curl\exceptions\RestException;
use console\components\curl\RestCurl;
use credit\CreditServiceFactory;
use Ramsey\Uuid\Uuid;
use tests\unit\billing\models\OrderTransaction;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CardPaymentFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class CardPaymentTest extends Unit
{
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'workers'               => WorkerFixture::class,
            'workerHasCity'         => WorkerHasCityFixture::class,
            'clientCompany'         => ClientCompanyFixture::class,
            'accounts'              => AccountFixture::class,
            'orders'                => OrderFixture::class,
            'orderDetailCost'       => OrderDetailCostFixture::class,
            'transactions'          => TransactionFixture::class,
            'operations'            => OperationFixture::class,
            'clientOrderFromApp'    => ClientOrderFromAppFixture::class,
            'clientBonuses'         => ClientBonusFixture::class,
            'clientBonusGootax'     => ClientBonusGootaxFixture::class,
            'clientBonusHasTariffs' => ClientBonusHasTariffFixture::class,
            'cardPayments'          => CardPaymentFixture::class,
            'tenants'               => TenantFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction();
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }

    private function getActiveRecordBalance($activeRecord)
    {
        return empty($activeRecord) ? 0.0 : (float)$activeRecord->balance;
    }

    private function refreshActiveRecord($activeRecord)
    {
        if (!empty($activeRecord)) {
            $activeRecord->refresh();
        }
    }

    protected function getProfileMock($data)
    {
        $mock = $this->getMockBuilder('\console\components\curl\RestCurl')
            ->setMethods(['get'])
            ->getMock();
        $mock->method('get')
            ->willReturn($data);

        return $mock;
    }

    protected function getPaymentMock($callbacks)
    {
        $mock = $this->getMockBuilder('\console\components\billing\models\bankCard\Payment')
            ->setMethods(array_keys($callbacks))
            ->getMock();

        foreach ($callbacks as $method => $callback) {
            $mock->method($method)
                ->will($this->returnCallback($callback));
        }

        return $mock;
    }

    public function cardPaymentData()
    {
        return [
            'successful' => [
                [
                    'order_id' => 39,
                ],
                [],
                [
                    'pay' => function () {
                        return 1;
                    },
                ],
                [
                    'old_system'       => 0.0,
                    'old_client'       => 150.0,
                    'old_company'      => 200.0,
                    'old_worker'       => 300.0,
                    'old_system_bonus' => 0.0,
                    'old_client_bonus' => 100.0,
                    'system'           => 195.0,
                    'client'           => 150.0,
                    'company'          => 200.0,
                    'worker'           => 495.0,
                    'system_bonus'     => 20.0,
                    'client_bonus'     => 120.0,
                ],
            ],

            'successful (with write-off bonus)' => [
                [
                    'order_id' => 40,
                ],
                [],
                [
                    'pay' => function () {
                        return 1;
                    },
                ],
                [
                    'old_system'       => 0.0,
                    'old_client'       => 150.0,
                    'old_company'      => 200.0,
                    'old_worker'       => 300.0,
                    'old_system_bonus' => 0.0,
                    'old_client_bonus' => 100.0,
                    'system'           => 195.0,
                    'client'           => 150.0,
                    'company'          => 200.0,
                    'worker'           => 495.0,
                    'system_bonus'     => -35.0,
                    'client_bonus'     => 65.0,
                ],
            ],

            'successful (writeoff bank commission for the order from worker account)' => [
                [
                    'order_id' => 39,
                ],
                [
                    'commission' => 25,
                ],
                [
                    'pay' => function () {
                        return 1;
                    },
                ],
                [
                    'old_system'       => 0.0,
                    'old_client'       => 150.0,
                    'old_company'      => 200.0,
                    'old_worker'       => 300.0,
                    'old_system_bonus' => 0.0,
                    'old_client_bonus' => 100.0,
                    'system'           => 150.0,
                    'client'           => 150.0,
                    'company'          => 200.0,
                    'worker'           => 450.0,
                    'system_bonus'     => 20.0,
                    'client_bonus'     => 120.0,
                ],
            ],

            'failed payment (don\'t call refund if payment wasn\'t successful)' => [
                [
                    'order_id' => 40,
                ],
                [],
                [
                    'pay' => function () {
                        throw new RestException('Test', '500');
                    },
                ],
                [
                    'old_system'       => 0.0,
                    'old_client'       => 150.0,
                    'old_company'      => 200.0,
                    'old_worker'       => 300.0,
                    'old_system_bonus' => 0.0,
                    'old_client_bonus' => 100.0,
                    'system'           => 0.0,
                    'client'           => 150.0,
                    'company'          => 200.0,
                    'worker'           => 300.0,
                    'system_bonus'     => 0.0,
                    'client_bonus'     => 100.0,
                ],
            ],

            'successful (with profit card)' => [
                [
                    'order_id' => 39,
                ],
                [
                    'secureDeal' => true,
                ],
                [
                    'pay' => function () {
                        return 1;
                    },
                ],
                [
                    'old_system'       => 0.0,
                    'old_client'       => 150.0,
                    'old_company'      => 200.0,
                    'old_worker'       => 300.0,
                    'old_system_bonus' => 0.0,
                    'old_client_bonus' => 100.0,
                    'system'           => -5.0,
                    'client'           => 150.0,
                    'company'          => 200.0,
                    'worker'           => 295.0,
                    'system_bonus'     => 20.0,
                    'client_bonus'     => 120.0,
                ],
            ],
        ];
    }

    /**
     * @dataProvider cardPaymentData
     */
    public function testCardPayment(
        $orderParams,
        $profileData,
        $paymentCallbacks,
        $expected
    ) {
        $order      = Order::findOne($orderParams['order_id']);
        $tenantId   = $order->tenant_id;
        $clientId   = $order->client_id;
        $companyId  = $order->company_id;
        $workerId   = $order->worker_id;
        $currencyId = $order->currency_id;

        $systemAccount = $this->testTransaction
            ->createAccount(0, $tenantId, Account::SYSTEM_KIND, Account::ACTIVE_TYPE, $currencyId);

        $clientAccount = $this->testTransaction
            ->getAccount($clientId, $tenantId, Account::CLIENT_KIND, $currencyId);

        $companyAccount = $this->testTransaction
            ->getAccount($companyId, $tenantId, Account::COMPANY_KIND, $currencyId);

        $workerAccount = $this->testTransaction
            ->getAccount($workerId, $tenantId, Account::WORKER_KIND, $currencyId);

        $clientBonusAccount = $this->testTransaction
            ->getAccount($clientId, $tenantId, Account::CLIENT_BONUS_KIND, $currencyId);

        $dbTransaction = app()->db->beginTransaction();
        try {
            $orderTransaction = new OrderTransaction(new CreditServiceFactory(), $orderParams);

            $orderTransaction->container->setSingleton(
                'profile', $this->getProfileMock($profileData));
            $orderTransaction->container->setSingleton(
                'payment', $this->getPaymentMock($paymentCallbacks));

            $orderTransaction->save();

            $dbTransaction->commit();
        } catch (\Exception $ex) {
            $dbTransaction->rollBack();
            Debug::debug($ex->getMessage());
        }

        $result                     = [];
        $result['old_system']       = $this->getActiveRecordBalance($systemAccount);
        $result['old_client']       = $this->getActiveRecordBalance($clientAccount);
        $result['old_company']      = $this->getActiveRecordBalance($companyAccount);
        $result['old_worker']       = $this->getActiveRecordBalance($workerAccount);
        $result['old_system_bonus'] = 0.0;
        $result['old_client_bonus'] = $this->getActiveRecordBalance($clientBonusAccount);

        $this->refreshActiveRecord($systemAccount);
        $this->refreshActiveRecord($clientAccount);
        $this->refreshActiveRecord($companyAccount);
        $this->refreshActiveRecord($workerAccount);
        $this->refreshActiveRecord($clientBonusAccount);
        $systemBonusAccount = $this->testTransaction
            ->getAccount(0, $tenantId, Account::SYSTEM_BONUS_KIND, $currencyId);

        $result['system']       = $this->getActiveRecordBalance($systemAccount);
        $result['client']       = $this->getActiveRecordBalance($clientAccount);
        $result['company']      = $this->getActiveRecordBalance($companyAccount);
        $result['worker']       = $this->getActiveRecordBalance($workerAccount);
        $result['system_bonus'] = $this->getActiveRecordBalance($systemBonusAccount);
        $result['client_bonus'] = $this->getActiveRecordBalance($clientBonusAccount);

        $this->assertEquals($expected, $result);
    }

    public function cardPaymentExceptionsData()
    {
        return [
            'invalid params of card payment' => [
                [
                    'order_id' => 36,
                ],
                [],
                [
                    'pay' => function () {
                        throw new RestException('error', '404');
                    },
                ],
                [],
                '\console\components\billing\exceptions\InvalidCardPaymentParamsException',
            ],

            'error occured payment' => [
                [
                    'order_id' => 39,
                ],
                [],
                [
                    'pay' => function () {
                        throw new RestException('Error', '500');
                    },
                ],
                [],
                '\console\components\billing\exceptions\CardPaymentFailedException',
            ],
        ];
    }

    /**
     * @dataProvider cardPaymentExceptionsData
     */
    public function testCardPaymentsExceptions(
        $orderParams,
        $profileData,
        $paymentMethods,
        $pushMethods,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage,
            $exceptionCode);

        $orderTransaction = new OrderTransaction(new CreditServiceFactory(), $orderParams);

        $pushNotificationManager = $this->getMockBuilder('\console\components\billing\PushNotificationManager')
            ->setMethods($pushMethods)
            ->getMock();

        $orderTransaction->pushNotificationManager = $pushNotificationManager;

        $orderTransaction->container->setSingleton('profile', $this->getProfileMock($profileData));
        $orderTransaction->container->setSingleton('payment', $this->getPaymentMock($paymentMethods));

        $orderTransaction->save();
    }
}
