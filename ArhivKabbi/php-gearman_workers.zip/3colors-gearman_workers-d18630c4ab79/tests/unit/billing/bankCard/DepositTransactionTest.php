<?php

namespace tests\unit\billing\bankCard;

use Codeception\Test\Unit;
use console\components\billing\models\bankCard\Profile;
use console\components\curl\exceptions\RestException;
use console\components\billing\Account;
use console\components\billing\models\bankCard\DepositFromBankCard;
use console\components\billing\models\bankCard\Payment;
use console\components\billing\transactions\DepositTransaction;
use console\components\billing\transactions\Transaction;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\DepositFromBankCardFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;


class DepositTransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    private $testTransaction;

    public function _fixtures()
    {
        return [
            'accounts'      => AccountFixture::class,
            'clients'       => ClientFixture::class,
            'companies'     => ClientCompanyFixture::class,
            'workers'       => WorkerFixture::class,
            'workerHasCity' => WorkerHasCityFixture::class,
            'tenants'       => TenantFixture::class,
            'operations'    => OperationFixture::class,
            'transactions'  => TransactionFixture::class,
            'deposit'       => DepositFromBankCardFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction();
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }

    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return \PHPUnit_Framework_MockObject_MockObject
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }

    /**
     * @param Account $account
     *
     * @return float
     */
    private function getAccountBalance($account)
    {
        return empty($account) ? 0.0 : (float)$account->balance;
    }

    /**
     * @param Account $account
     */
    private function refreshAccount($account)
    {
        if (!empty($account)) {
            $account->refresh();
        }
    }


    public function commissionForDepositFromBankCardData()
    {
        return [
            '-10%' => [50, -10, 0],
            '0%'   => [50, 0, 0],
            '10%'  => [50, 10, 5],
            '150%' => [50, 200, 50],
        ];
    }

    /**
     * @dataProvider commissionForDepositFromBankCardData
     */
    public function testCommissionForDepositFromBankCard($sum, $commissionPercent, $expected)
    {
        $workerId = 3;

        $params = [
            'type_id'            => Transaction::DEPOSIT_TYPE,
            'payment_method'     => Transaction::CARD_PAYMENT,
            'tenant_id'          => 3,
            'sender_owner_id'    => $workerId,
            'sender_acc_kind_id' => Account::WORKER_KIND,
            'request_id'         => 'request_id_1',
            'pan'                => '44XX55',
            'sum'                => $sum,
            'currency_id'        => 1,
        ];

        $actualCommission = 0;
        $dbTransaction    = app()->db->beginTransaction();
        try {
            $transaction = new DepositTransaction($params);

            $workerAccount = $this->testTransaction->getAccount(
                $params['sender_owner_id'], $params['tenant_id'], $params['sender_acc_kind_id'],
                $params['currency_id']);
            $oldBalance    = $this->getAccountBalance($workerAccount);

            $transaction->container->setSingleton(
                'payment', $this->getCustomMock(Payment::className(), [
                'pay' => function () {
                    return ['orderId' => '123'];
                },
            ]));
            $transaction->container->setSingleton(
                'profile', $this->getCustomMock(Profile::className(), [
                'get' => function () use ($commissionPercent) {
                    return ['commission' => $commissionPercent];
                },
            ]));

            $transaction->save();

            $this->refreshAccount($workerAccount);
            $balance = $this->getAccountBalance($workerAccount);

            $actualCommission = $oldBalance + $sum - $balance;

            $dbTransaction->commit();
        } catch (\Exception $ex) {
            \Yii::error($ex->getMessage());
        }
        $dbTransaction->rollBack();

        $this->assertEquals($expected, $actualCommission);
    }


    public function depositFromBankCardData()
    {
        return [
            'successful' => [
                [
                    'pay' => function () {
                        return ['orderId' => '123'];
                    },
                ],
                true,
            ],

            'failed' => [
                [
                    'pay' => function () {
                        throw new RestException('Test error', '500');
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider depositFromBankCardData
     */
    public function testDepositFromBankCard($callbacks, $expected)
    {
        $params = [
            'type_id'            => Transaction::DEPOSIT_TYPE,
            'payment_method'     => Transaction::CARD_PAYMENT,
            'tenant_id'          => 3,
            'sender_owner_id'    => 3,
            'sender_acc_kind_id' => Account::WORKER_KIND,
            'request_id'         => 'request_id_1',
            'pan'                => '44XX55',
            'sum'                => 50,
            'currency_id'        => 1,
        ];

        $dbTransaction = app()->db->beginTransaction();
        try {
            $transaction = new DepositTransaction($params);

            $transaction->container->setSingleton(
                'payment', $this->getCustomMock(Payment::className(), $callbacks));
            $transaction->container->setSingleton(
                'profile', $this->getCustomMock(Profile::className(), [
                'get' => function () {
                    return ['commission' => 0];
                },
            ]));

            $transaction->save();

            $dbTransaction->commit();
        } catch (\Exception $ex) {
            $dbTransaction->rollBack();
            \Yii::error($ex->getMessage());
        }

        $actual = DepositFromBankCard::find()
            ->where([
                'request_id'     => $params['request_id'],
                'pan'            => $params['pan'],
                'transaction_id' => $transaction->transaction_id,
            ])
            ->exists();

        $this->assertEquals($expected, $actual);
    }


    /**
     * @expectedException \console\components\billing\exceptions\HeldPaymentException
     */
    public function testRequestIdAlreadyProcessed()
    {
        $params = [
            'type_id'            => Transaction::DEPOSIT_TYPE,
            'payment_method'     => Transaction::CARD_PAYMENT,
            'tenant_id'          => 3,
            'sender_owner_id'    => 3,
            'sender_acc_kind_id' => Account::WORKER_KIND,
            'request_id'         => 'already processed request_id',
            'pan'                => '44XX55',
            'sum'                => 50,
            'currency_id'        => 1,
        ];

        $transaction = new DepositTransaction($params);
    }


    public function testDepositTransaction()
    {
        $params = [
            'type_id'            => Transaction::DEPOSIT_TYPE,
            'payment_method'     => Transaction::CARD_PAYMENT,
            'tenant_id'          => 3,
            'sender_owner_id'    => 3,
            'sender_acc_kind_id' => Account::WORKER_KIND,
            'request_id'         => 'request_id',
            'pan'                => '44XX55',
            'sum'                => 50,
            'currency_id'        => 1,
        ];

        $testTransaction = new TestTransaction();

        $systemAccount = $testTransaction->getAccount(
            0, $params['tenant_id'], Account::SYSTEM_KIND, $params['currency_id']);
        $workerAccount = $testTransaction->getAccount(
            $params['sender_owner_id'], $params['tenant_id'], Account::WORKER_KIND, $params['currency_id']);

        $transaction = new DepositTransaction($params);
        $transaction->container->setSingleton(
            'payment', $this->getCustomMock(Payment::className(), [
            'pay' => function () {
                return ['orderId' => '123'];
            },
        ]));
        $transaction->container->setSingleton(
            'profile', $this->getCustomMock(Profile::className(), [
            'get' => function () {
                return ['commission' => 0];
            },
        ]));

        $systemOldBalance = $this->getAccountBalance($systemAccount);
        $workerOldBalance = $this->getAccountBalance($workerAccount);

        $actual = $transaction->save();
        $this->assertTrue($actual, 'Transaction was failed');

        $this->refreshAccount($systemAccount);
        $systemBalance = $this->getAccountBalance($systemAccount);
        $this->refreshAccount($workerAccount);
        $workerBalance = $this->getAccountBalance($workerAccount);

        $this->assertEquals($systemOldBalance + $params['sum'], $systemBalance, 'Error system balance');
        $this->assertEquals($workerOldBalance + $params['sum'], $workerBalance, 'Error worker balance');
    }

}
