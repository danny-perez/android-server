<?php

namespace tests\unit\billing\bankCard;

use Codeception\Test\Unit;
use console\components\billing\models\bankCard\Profile;

class ProfileTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }

    public function testGet()
    {
        $paygateCurl = $this->getCustomMock('\console\components\curl\RestCurl',
            [
                'get' => function ($url) {
                    return $url;
                },
            ]);
        app()->set('paygateCurl', $paygateCurl);

        $tenantId = 1;
        $expected = implode("/",
            [
                rtrim(app()->params['paymentGateApi.url'], '/'),
                Profile::BASE_URL,
                $tenantId,
            ]);

        $this->profile = new Profile();
        $this->assertEquals($expected, $this->profile->get($tenantId));
    }
}
