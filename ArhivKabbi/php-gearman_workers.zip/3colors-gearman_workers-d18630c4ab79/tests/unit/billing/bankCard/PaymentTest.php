<?php

namespace tests\nit\billing\bankCard;

use Codeception\Test\Unit;
use console\components\billing\models\bankCard\CardPaymentLog;
use console\components\billing\models\bankCard\Payment;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CardPaymentFixture;
use tests\unit\fixtures\CardPaymentLogFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class PaymentTest extends Unit
{
    public function _fixtures()
    {
        return [
            'workers'               => WorkerFixture::class,
            'workerHasCity'         => WorkerHasCityFixture::class,
            'clientCompany'         => ClientCompanyFixture::class,
            'accounts'              => AccountFixture::class,
            'tenants'               => TenantFixture::class,
            'orders'                => OrderFixture::class,
            'orderDetailCost'       => OrderDetailCostFixture::class,
            'transactions'          => TransactionFixture::class,
            'operations'            => OperationFixture::class,
            'clientOrderFromApp'    => ClientOrderFromAppFixture::class,
            'clientBonuses'         => ClientBonusFixture::class,
            'clientBonusGootax'     => ClientBonusGootaxFixture::class,
            'clientBonusHasTariffs' => ClientBonusHasTariffFixture::class,
            'cardPayments'          => CardPaymentFixture::class,
            'cardPaymentLogs'       => CardPaymentLogFixture::class,
        ];
    }

    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }

    public function payData()
    {
        return [
            'from client' => [
                [
                    'tenant_id'    => 1,
                    'order_id'     => 4,
                    'order_number' => 123,
                    'client_id'    => 1,
                    'worker_id'    => null,
                    'pan'          => '44XX44',
                    'amount'       => 1000,
                    'currency'     => 643,
                    'params'       => null,
                    'description'  => 'from client card',
                ],
            ],

            'from worker' => [
                [
                    'tenant_id'    => 1,
                    'order_id'     => 4,
                    'order_number' => 123,
                    'client_id'    => null,
                    'worker_id'    => 1,
                    'pan'          => '44XX44',
                    'amount'       => 1000,
                    'currency'     => 643,
                    'params'       => null,
                    'description'  => 'from worker card',
                ],
            ],
        ];
    }

    /**
     * @dataProvider payData
     */
    public function testPay($params)
    {
        $paygateCurl = $this->getCustomMock('\console\components\curl\RestCurl', [
            'post' => function ($url, $params) {
                return [
                    'url'    => $url,
                    'params' => $params,
                ];
            },
        ]);

        app()->set('paygateCurl', $paygateCurl);

        $client = empty($params['worker_id'])
            ? "client_{$params['client_id']}" : "worker_{$params['worker_id']}";

        $expected = [
            'url'    => implode("/", [
                rtrim(app()->params['paymentGateApi.url'], '/'),
                Payment::BASE_URL,
                $params['tenant_id'],
                $client,
            ]),
            'params' => [
                'pan'         => $params['pan'],
                'amount'      => $params['amount'],
                'orderNumber' => $params['order_number'],
                'currency'    => $params['currency'],
                'params'      => $params['params'],
                'description' => $params['description'],
            ],
        ];

        $this->payment = new Payment();

        $result = $this->payment->pay(
            $params['tenant_id'], $params['order_id'], $params['client_id'], $params['worker_id'],
            $params['pan'], null, $params['amount'], $params['order_number'], $params['currency'],
            $params['params'], $params['description']);

        $this->assertEquals($expected, $result);
    }
}
