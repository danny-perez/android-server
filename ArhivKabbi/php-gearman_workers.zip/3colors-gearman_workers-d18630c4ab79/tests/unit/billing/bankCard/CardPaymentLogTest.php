<?php

namespace tests\unit\billing\bankCard;

use Codeception\Test\Unit;
use console\components\billing\models\bankCard\CardPaymentLog;
use tests\unit\fixtures\CardPaymentLogFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;

class CardPaymentLogTest extends Unit
{
    public function _fixtures()
    {
        return [
            'cardPaymentLogs' => CardPaymentLogFixture::class,
            'transactions'    => TransactionFixture::class,
            'tenants'         => TenantFixture::class,
            'orders'          => OrderFixture::class,
        ];
    }

    public function getLogData()
    {
        return [
            'successful pay' => [
                1,
                2,
                1,
                null,
                CardPaymentLog::TYPE_PAY,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                true,
            ],

            'successful refund' => [
                1,
                2,
                1,
                null,
                CardPaymentLog::TYPE_REFUND,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                true,
            ],

            'invalid tenantId' => [
                -1,
                2,
                1,
                null,
                CardPaymentLog::TYPE_REFUND,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                false,
            ],

            'invalid orderId' => [
                1,
                -1,
                1,
                null,
                CardPaymentLog::TYPE_REFUND,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                false,
            ],

            'invalid clientId' => [
                1,
                2,
                -1,
                null,
                CardPaymentLog::TYPE_REFUND,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                false,
            ],

            'successful pay (workerId)' => [
                1,
                2,
                null,
                1,
                CardPaymentLog::TYPE_PAY,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                true,
            ],

            'invalid workerId' => [
                1,
                2,
                null,
                -1,
                CardPaymentLog::TYPE_REFUND,
                'params',
                'response',
                CardPaymentLog::RESULT_OK,
                false,
            ],
        ];
    }

    /**
     * @dataProvider getLogData
     */
    public function testLog(
        $tenantId,
        $orderId,
        $clientId,
        $workerId,
        $type,
        $params,
        $response,
        $result,
        $excepted
    ) {
        CardPaymentLog::log($tenantId, $orderId, $clientId, $workerId, $type, $params,
            $response, $result);

        $isRecordExists = CardPaymentLog::find()
            ->where([
                'tenant_id' => $tenantId,
                'order_id'  => $orderId,
                'client_id' => $clientId,
                'worker_id' => $workerId,
                'type'      => $type,
                'result'    => $result,
            ])->exists();
        $this->assertEquals($excepted, $isRecordExists);
    }

}
