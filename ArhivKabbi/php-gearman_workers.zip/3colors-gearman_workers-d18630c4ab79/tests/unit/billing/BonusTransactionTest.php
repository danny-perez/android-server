<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\Account;
use console\components\billing\transactions\BonusTransaction;
use console\components\billing\Operation;
use console\components\billing\transactions\Transaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;

class BonusTransactionTest extends Unit
{
    /**
     * @var BonusTransaction
     */
    protected $bonusTransaction;

    public function _fixtures()
    {
        return [
            'accounts'     => AccountFixture::class,
            'clients'      => ClientFixture::class,
            'tenants'      => TenantFixture::class,
            'transactions' => TransactionFixture::class,
            'operations'   => OperationFixture::class,
        ];
    }

    protected function _before()
    {
        $this->bonusTransaction = new BonusTransaction;
    }

    protected function _after()
    {
        $this->bonusTransaction = null;
    }

    public function testDoTransactOperation()
    {
        \Yii::configure($this->bonusTransaction, [
            'type_id'         => Transaction::DEPOSIT_TYPE,
            'payment_method'  => Transaction::BONUS_PAYMENT,
            'tenant_id'       => 1,
            'sender_owner_id' => 1,
            'currency_id'     => 1,
            'sum'             => 1000,
        ]);

        $this->bonusTransaction->initData();

        $clientAccount    = Account::findOne([
            'owner_id'    => $this->bonusTransaction->sender_owner_id,
            'tenant_id'   => $this->bonusTransaction->tenant_id,
            'acc_kind_id' => Account::CLIENT_BONUS_KIND,
            'acc_type_id' => Account::PASSIVE_TYPE,
            'currency_id' => $this->bonusTransaction->currency_id,
        ]);
        $clientBalanceOld = $clientAccount->balance;

        $savedTransaction = $this->bonusTransaction->save();

        $this->assertTrue($savedTransaction, 'Save bonus transaction.'
            . implode("\n", $this->bonusTransaction->getFirstErrors()));

        $this->assertNotEmpty($clientAccount, 'Client account does not exists');

        $clientOperation = Operation::findOne([
            'transaction_id' => $this->bonusTransaction->transaction_id,
            'account_id'     => $clientAccount->account_id,
        ]);
        $this->assertNotEmpty($clientOperation, 'Client operation does not exists');
        $clientAccount->refresh();
        $this->assertEquals($clientBalanceOld + $clientOperation->sum,
            $clientAccount->balance,
            'The sum on the balance of the client is wrong');

        $systemAccount = Account::findOne([
            'tenant_id'   => $this->bonusTransaction->tenant_id,
            'acc_kind_id' => Account::SYSTEM_BONUS_KIND,
            'acc_type_id' => Account::ACTIVE_TYPE,
            'currency_id' => $this->bonusTransaction->currency_id,
        ]);
        $this->assertNotEmpty($systemAccount, 'System account does not exists');

        $systemOperation = Operation::findOne([
            'transaction_id' => $this->bonusTransaction->transaction_id,
            'account_id'     => $systemAccount->account_id,
        ]);
        $systemAccount->refresh();
        $this->assertNotEmpty($systemOperation, 'System operation does not exists');
        $this->assertEquals($systemOperation->sum, $systemAccount->balance,
            'The sum on the balance of the system is wrong');

        $this->assertEquals($systemOperation->sum, $clientOperation->sum,
            'The sum of the system operation must be equal to the sum of the client operation');
    }


    /**
     * Return data for testing a exceptions
     * @return array
     */
    public function bonusTransactionExceptionsData()
    {
        return [
            'not specified currency transaction' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'payment_method'     => Transaction::BONUS_PAYMENT,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'comment'            => 'test comment',
                ],
                '\console\components\billing\exceptions\NotFoundException',
                'Not specified transaction currency',
            ],
        ];
    }

    /**
     * @dataProvider bonusTransactionExceptionsData
     */
    public function testBonusTransactionExceptions(
        $transactionData,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        \Yii::configure($this->bonusTransaction, $transactionData);

        $this->bonusTransaction->initData();
        $this->bonusTransaction->save();
    }

}