<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\transactions\Transaction;
use console\components\billing\transactions\WithdrawalTransaction;
use console\components\billing\Account;
use console\components\billing\Operation;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class WithdrawalTransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'accounts'         => AccountFixture::class,
            'clients'          => ClientFixture::class,
            'companies'        => ClientCompanyFixture::class,
            'workers'          => WorkerFixture::class,
            'workerHasCity'    => WorkerHasCityFixture::class,
            'tenants'          => TenantFixture::class,
            'orders'           => OrderFixture::class,
            'orderDetailCosts' => OrderDetailCostFixture::class,
            'transactions'     => TransactionFixture::class,
            'operations'       => OperationFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction();
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }


    /**
     * Return data for testing a exceptions
     * @return array
     */
    public function withdrawalTransactionExceptionsData()
    {
        return [
            //            // throwing exception was removed
            //            'There were no changes in the balance of accounts (withdrawal to client account)' => [
            //                [
            //                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
            //                    'tenant_id'          => 1,
            //                    'sender_owner_id'    => 1,
            //                    'sender_acc_kind_id' => Account::CLIENT_KIND,
            //                    'currency_id'        => 1,
            //                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
            //                    'sum'                => 0,
            //                    'comment'            => 'test comment',
            //                ],
            //                '\console\components\billing\exceptions\NoBalanceChangesException',
            //            ],

            'not specified currency transaction' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\console\components\billing\exceptions\NotFoundException',
                'Not specified transaction currency',
            ],

            'invalid sum of payment' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'currency_id'        => 1,
                    'sum'                => -100,
                    'comment'            => 'test comment',
                ],
                '\console\components\billing\exceptions\InvalidSumException',
                'Invalid sum of payment',
            ],
        ];
    }

    /**
     * @dataProvider withdrawalTransactionExceptionsData
     */
    public function testWithdrawalTransactionExceptions(
        $transactionData,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $withdrawalTransaction = new WithdrawalTransaction($transactionData);
        $withdrawalTransaction->save();
    }


    /**
     * Return data for testing a push notifications of withdrawal transaction
     */
    public function withdrawalTransactionPushNotificationsData()
    {
        return [
            'withdrawal from client account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 3,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'withdrawal from client account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=USD&balance=-100&bonus_balance=0&app_id=1',
                ],
            ],

            'cash out from client account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=50&bonus_balance=100&app_id=1',
                ],
            ],

            'cash out from client account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=USD&balance=-100&bonus_balance=0&app_id=1',
                ],
            ],

            'withdrawal from company account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'withdrawal from company account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'cash out from company account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'cash out from company account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'withdrawal from worker account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=200',
                ],
            ],

            'withdrawal from worker account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=USD&balance=-100',
                ],
            ],

            'cash out from worker account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=200',
                ],
            ],

            'cash out from worker account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=USD&balance=-100',
                ],
            ],

            'withdrawal for tariff from worker account' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_TARIFF_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=200',
                ],
            ],

            'withdrawal for tariff from worker account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::WITHDRAWAL_TARIFF_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=USD&balance=-100',
                ],
            ],
        ];
    }

    /**
     * @dataProvider withdrawalTransactionPushNotificationsData
     */
    public function testWithdrawalTransactionPushNotifications($transactionData, $expectedNotifications)
    {
        $withdrawalTransaction = new WithdrawalTransaction($transactionData);

        $withdrawalTransaction->save();

        $pushNotificationManager = new models\PushNotificationManager;
        $pushNotificationManager->sendNotifications($withdrawalTransaction->notifications);
        $this->assertEquals($expectedNotifications, $pushNotificationManager->notifications);
    }


    /**
     * Return data for testing a withdrawal tenant transaction
     */
    public function withdrawalTenantTransactionData()
    {
        return [
            'withdrawal from tenant account' => [
                [
                    'type_id'         => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'       => 1,
                    'currency_id'     => 1,
                    'payment_method'  => Transaction::WITHDRAWAL_PAYMENT,
                    'isTenantPayment' => true,
                    'city_id'         => 26068,
                    'sum'             => 100,
                    'comment'         => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => -100,
                ],
                [
                    'receiverBalanceOld' => 100,
                    'receiverBalance'    => 0,
                ],
                [
                    [
                        'type_id' => Operation::EXPENSES_TYPE,
                        'sum'     => 100,
                        'saldo'   => -100,
                    ],
                    [
                        'type_id' => Operation::EXPENSES_TYPE,
                        'sum'     => 100,
                        'saldo'   => 0,
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider withdrawalTenantTransactionData
     */
    public function testWithdrawalTenantTransaction(
        $transactionData,
        $senderBalanceExpected,
        $receiverBalanceExpected,
        $operationsExpected
    ) {
        $withdrawalTransaction = new WithdrawalTransaction($transactionData);

        $senderAccount    = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalanceOld = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount    = $this->testTransaction->getAccount(
            0,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalanceOld = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $withdrawalTransaction->save();

        $senderAccount = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalance = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount = $this->testTransaction->getAccount(
            0,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalance = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $this->assertEquals($transactionData['currency_id'],
            $senderAccount->currency_id);
        $this->assertEquals($senderBalanceExpected, [
            'senderBalanceOld' => $senderBalanceOld,
            'senderBalance'    => $senderBalance,
        ]);

        $this->assertEquals($transactionData['currency_id'],
            $receiverAccount->currency_id);
        $this->assertEquals($receiverBalanceExpected, [
            'receiverBalanceOld' => $receiverBalanceOld,
            'receiverBalance'    => $receiverBalance,
        ]);

        $operationsActual = [];
        $operations       = Operation::findAll([
            'transaction_id' => $withdrawalTransaction->transaction_id,
        ]);
        foreach ($operations as $operation) {
            $operationsActual[] = [
                'type_id' => $operation->type_id,
                'sum'     => (float)$operation->sum,
                'saldo'   => (float)$operation->saldo,
            ];
        }

        $this->assertEquals($operationsExpected, $operationsActual);
    }
}