<?php

namespace tests\unit\billing\credit;

use Codeception\Test\Unit;
use credit\CompanyCreditService;
use credit\CreditServiceFactory;

class CreditServiceFactoryTest extends Unit
{
    public function getCreditServiceData()
    {
        return [
            [CreditServiceFactory::TYPE_COMPANY, CompanyCreditService::class],
        ];
    }

    /**
     * @dataProvider getCreditServiceData
     *
     * @param string $type
     * @param string $expectedClass
     */
    public function testGetCreditService($type, $expectedClass)
    {
        $factory   = new CreditServiceFactory();
        $companyId = 1;

        $service = $factory->getCreditService($type, $companyId);
        $this->assertInstanceOf($expectedClass, $service);
    }


    public function getCreditServiceWithIncorrectTypeData()
    {
        return [
            [CreditServiceFactory::TYPE_CLIENT],
            ['incorrect type'],
        ];
    }

    /**
     * @dataProvider getCreditServiceWithIncorrectTypeData
     * @expectedException \credit\UnknownCreditServiceTypeException
     *
     * @param string $incorrectType
     */
    public function testGetCreditServiceWithIncorrectType($incorrectType)
    {
        $factory   = new CreditServiceFactory();
        $companyId = 1;

        $factory->getCreditService($incorrectType, $companyId);
    }
}