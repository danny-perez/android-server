<?php

namespace tests\unit\billing\credit;

use Codeception\Test\Unit;
use credit\CompanyCreditService;
use tests\unit\fixtures\ClientCompanyFixture;

class CompanyCreditServiceTest extends Unit
{
    public function _fixtures()
    {
        return [
            'companies' => ClientCompanyFixture::class,
        ];
    }

    public function getLimitData()
    {
        return [
            [1, 0],
            [2, 0],
            [3, 200],
            [555, 0],
        ];
    }

    /**
     * @dataProvider getLimitData
     *
     * @param int   $companyId
     * @param float $expected
     */
    public function testGetLimit($companyId, $expected)
    {
        $service = new CompanyCreditService();

        $service->setCompanyId($companyId);
        $this->assertEquals($expected, $service->getLimit());
    }
}