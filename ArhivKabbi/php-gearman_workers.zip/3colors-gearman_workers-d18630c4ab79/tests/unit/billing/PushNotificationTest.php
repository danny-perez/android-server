<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\models\PushNotification;

class PushNotificationTest extends Unit
{
    /**
     * Return data for function `generateParams`
     */
    public function generateParamsData()
    {
        return [
            'worker android notification' => [
                [
                    'tenant_id'    => 1,
                    'tenant_login' => 'test',
                    'type_app'     => PushNotification::TYPE_APP_WORKER,
                    'device'       => PushNotification::DEVICE_ANDROID,
                    'token'        => 'sample token',
                    'lang'         => 'ru',
                    'currency'     => 'RUB',
                    'balance'      => 50,
                ],
                'tenant_id=1&tenant_login=test&device=ANDROID&token=sample%20token&lang=ru&currency=RUB&balance=50',
            ],

            'client ios notification' => [
                [
                    'tenant_id'     => 1,
                    'tenant_login'  => 'test',
                    'type_app'      => PushNotification::TYPE_APP_CLIENT,
                    'device'        => PushNotification::DEVICE_IOS,
                    'token'         => 'sample token',
                    'lang'          => 'en',
                    'currency'      => 'USD',
                    'balance'       => 50,
                    'bonus_balance' => 20,
                    'app_id'        => 1,
                ],
                'tenant_id=1&tenant_login=test&device=IOS&token=sample%20token&lang=en&currency=USD&balance=50&bonus_balance=20&app_id=1',
            ],
        ];
    }

    /**
     * @dataProvider generateParamsData
     */
    public function testGenerateParams($notificationData, $expected)
    {
        $bonusBalance = !empty($notificationData['bonus_balance']) ?
            $notificationData['bonus_balance'] : null;
        $appId        = !empty($notificationData['app_id']) ?
            $notificationData['app_id'] : null;

        $notification = new PushNotification(
            $notificationData['tenant_id'], $notificationData['tenant_login'],
            $notificationData['type_app'], $notificationData['device'],
            $notificationData['token'], $notificationData['lang'],
            $notificationData['currency'], $notificationData['balance'],
            $bonusBalance, $appId);

        $this->assertEquals($expected, $notification->generateParams());
    }
}
