<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\transactions\Transaction;
use console\components\billing\transactions\DepositTransaction;
use console\components\billing\Account;
use console\components\billing\Operation;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CardPaymentFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\ReferralBonusForOrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class DepositTransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'accounts'      => AccountFixture::class,
            'clients'       => ClientFixture::class,
            'companies'     => ClientCompanyFixture::class,
            'workers'       => WorkerFixture::class,
            'workerHasCity' => WorkerHasCityFixture::class,
            'tenants'       => TenantFixture::class,
            'operations'    => OperationFixture::class,
            'transactions'  => TransactionFixture::class,

            'clientCompany'         => ClientCompanyFixture::class,
            'orders'                => OrderFixture::class,
            'orderDetailCost'       => OrderDetailCostFixture::class,
            'clientOrderFromApp'    => ClientOrderFromAppFixture::class,
            'clientBonuses'         => ClientBonusFixture::class,
            'clientBonusGootax'     => ClientBonusGootaxFixture::class,
            'clientBonusHasTariffs' => ClientBonusHasTariffFixture::class,
            'cardPayments'          => CardPaymentFixture::class,
            'referralBonus'         => ReferralBonusForOrderFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction();
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }


    /**
     * Return data for testing a deposit transaction
     */
    public function depositTransactionData()
    {
        return [
            'deposit to client account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 150,
                    'senderBalance'    => 250,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 250,
                        'owner_name' => 'Testerov Tester Testerovich',
                    ],
                ],
            ],

            'deposit to client account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => 'Testerov Tester Testerovich',
                    ],
                ],
            ],

            'deposit to company account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 200,
                    'senderBalance'    => 300,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 300,
                        'owner_name' => 'first company',
                    ],
                ],
            ],

            'deposit to company account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => 'first company',
                    ],
                ],
            ],

            'deposit to worker account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 300,
                    'senderBalance'    => 400,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 400,
                        'owner_name' => 'Testerov Tester Testerovich (1)',
                    ],
                ],
            ],

            'deposit to worker account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => 'Testerov Tester Testerovich (1)',
                    ],
                ],
            ],

            'deposit to worker account (ELECSNET)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 1,
                    'payment_method'           => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1234567890',
                    'terminal_transact_date'   => '20150731',
                ],
                [
                    'senderBalanceOld' => 300,
                    'senderBalance'    => 400,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 200,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 400,
                        'owner_name' => 'Testerov Tester Testerovich (1)',
                    ],
                ],
            ],

            'deposit to worker account (account doesnt exist) (ELECSNET)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 3,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 200,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => 'Test Test Test (3)',
                    ],
                ],
            ],

            'deposit to worker account (MILLION)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 1,
                    'payment_method'           => Transaction::TERMINAL_MILLION_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1234567890',
                    'terminal_transact_date'   => '20150731',
                ],
                [
                    'senderBalanceOld' => 300,
                    'senderBalance'    => 400,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 400,
                        'owner_name' => 'Testerov Tester Testerovich (1)',
                    ],
                ],
            ],

            'deposit to worker account (account doesnt exist) (MILLION)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 3,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::TERMINAL_MILLION_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 0,
                    'receiverBalance'    => 100,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => 'Test Test Test (3)',
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider depositTransactionData
     */
    public function testDepositTransaction(
        $transactionData,
        $senderBalanceExpected,
        $receiverBalanceExpected,
        $operationsExpected
    ) {
        $depositTransaction = new DepositTransaction($transactionData);

        $senderAccount    = $this->testTransaction->getAccount(
            $transactionData['sender_owner_id'],
            $transactionData['tenant_id'],
            $transactionData['sender_acc_kind_id'],
            $transactionData['currency_id']);
        $senderBalanceOld = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount    = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::SYSTEM_KIND,
            $transactionData['currency_id']);
        $receiverBalanceOld = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $depositTransaction->save();

        $senderAccount = $this->testTransaction->getAccount(
            $transactionData['sender_owner_id'],
            $transactionData['tenant_id'],
            $transactionData['sender_acc_kind_id'],
            $transactionData['currency_id']);
        $senderBalance = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::SYSTEM_KIND,
            $transactionData['currency_id']);
        $receiverBalance = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $this->assertEquals($transactionData['currency_id'],
            $senderAccount->currency_id);
        $this->assertEquals($senderBalanceExpected, [
            'senderBalanceOld' => $senderBalanceOld,
            'senderBalance'    => $senderBalance,
        ]);

        $this->assertEquals($transactionData['currency_id'],
            $receiverAccount->currency_id);
        $this->assertEquals($receiverBalanceExpected, [
            'receiverBalanceOld' => $receiverBalanceOld,
            'receiverBalance'    => $receiverBalance,
        ]);

        $operationsActual = [];
        $operations       = Operation::findAll(['transaction_id' => $depositTransaction->transaction_id]);
        foreach ($operations as $operation) {
            $operationsActual[] = [
                'type_id'    => $operation->type_id,
                'sum'        => (float)$operation->sum,
                'saldo'      => (float)$operation->saldo,
                'owner_name' => $operation->owner_name,
            ];
        }

        $this->assertEquals($operationsExpected, $operationsActual);
    }


    /**
     * Return data for testing a exceptions
     * @return array
     */
    public function depositTransactionExceptionsData()
    {
        return [
            //            throwing exception was removed
            //            'There were no changes in the balance of accounts (deposit to client account)' => [
            //                [
            //                    'type_id'            => Transaction::DEPOSIT_TYPE,
            //                    'tenant_id'          => 1,
            //                    'sender_owner_id'    => 1,
            //                    'sender_acc_kind_id' => Account::CLIENT_KIND,
            //                    'currency_id'        => 1,
            //                    'payment_method'     => Transaction::CASH_PAYMENT,
            //                    'sum'                => 0,
            //                    'comment'            => 'test comment',
            //                ],
            //                '\console\components\billing\exceptions\NoBalanceChangesException',
            //            ],

            'not specified currency transaction' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\console\components\billing\exceptions\NotFoundException',
                'Not specified transaction currency',
            ],

            'invalid sum of payment' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'currency_id'        => 1,
                    'sum'                => -100,
                    'comment'            => 'test comment',
                ],
                '\console\components\billing\exceptions\InvalidSumException',
                'Invalid sum of payment',
            ],

            'Through the terminal can only be paid in russian rubles (ELECSNET)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 3,
                    'payment_method'           => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1234567890',
                    'terminal_transact_date'   => '20150731',
                ],
                '\yii\base\NotSupportedException',
                'Through the terminal can only be paid in russian rubles',
            ],

            'Through the terminal can only be paid in russian rubles (QIWI)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 3,
                    'payment_method'           => Transaction::TERMINAL_QIWI_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1234567890',
                    'terminal_transact_date'   => '20150731',
                ],
                '\yii\base\NotSupportedException',
                'Through the terminal can only be paid in russian rubles',
            ],

            'Payment has already held (ELECSNET)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 1,
                    'payment_method'           => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1',
                    'terminal_transact_date'   => '20160114',
                ],
                '\console\components\billing\exceptions\HeldPaymentException',
            ],

            'Payment has already held (MILLION)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 1,
                    'payment_method'           => Transaction::TERMINAL_MILLION_PAYMENT,
                    'sum'                      => 500,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1',
                    'terminal_transact_date'   => '20160201',
                ],
                '\console\components\billing\exceptions\HeldPaymentException',
            ],

            'Unsupported payment method (BONUS_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::BONUS_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],

            'Unsupported payment method (WITHDRAWAL_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],

            'Unsupported payment method (WITHDRAWAL_CASH_OUT_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_CASH_OUT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],

            'Unsupported payment method (WITHDRAWAL_TARIFF_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_TARIFF_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],

            'Unsupported payment method (CORP_BALANCE_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CORP_BALANCE_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],

            'Unsupported payment method (PERSONAL_ACCOUNT_PAYMENT)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::PERSONAL_ACCOUNT_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                '\yii\base\NotSupportedException',
            ],
        ];
    }

    /**
     * @dataProvider depositTransactionExceptionsData
     */
    public function testDepositTransactionExceptions(
        $transactionData,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $depositTransaction = new DepositTransaction($transactionData);
        $depositTransaction->save();
    }


    /**
     * Return data for testing a push notification of deposit transaction
     */
    public function depositTransactionPushNotificationsData()
    {
        return [
            'deposit to client account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 3,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'deposit to client account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=USD&balance=100&bonus_balance=0&app_id=1',
                ],
            ],

            'deposit to company account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'deposit to company account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::COMPANY_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [],
            ],

            'deposit to worker account' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=400',
                ],
            ],

            'deposit to worker account (account doesnt exist)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 2,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=USD&balance=100',
                ],
            ],

            'deposit to worker account (ELECSNET)' => [
                [
                    'type_id'                  => Transaction::DEPOSIT_TYPE,
                    'tenant_id'                => 1,
                    'sender_owner_id'          => 1,
                    'sender_acc_kind_id'       => Account::WORKER_KIND,
                    'currency_id'              => 1,
                    'payment_method'           => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                      => 100,
                    'comment'                  => 'test comment',
                    'terminal_transact_number' => '1234567890',
                    'terminal_transact_date'   => '20150731',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=en&currency=RUB&balance=400',
                ],
            ],

            'deposit to worker account (account doesnt exist) (ELECSNET)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 3,
                    'sender_acc_kind_id' => Account::WORKER_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::TERMINAL_ELECSNET_PAYMENT,
                    'sum'                => 100,
                    'comment'            => 'test comment',
                ],
                [
                    'tenant_id=1&tenant_login=test&device=ANDROID&token=device%20token&lang=ru&currency=RUB&balance=100',
                ],
            ],
        ];
    }

    /**
     * @dataProvider depositTransactionPushNotificationsData
     */
    public function testDepositTransactionPushNotifications($transactionData, $expectedNotifications)
    {
        $depositTransaction = new DepositTransaction($transactionData);
        $depositTransaction->save();

        $pushNotificationManager = new models\PushNotificationManager;
        $pushNotificationManager->sendNotifications($depositTransaction->notifications);

        $this->assertEquals($expectedNotifications, $pushNotificationManager->notifications);
    }


    /**
     * Return data for testing a deposit to tenant account transaction
     */
    public function depositTenantTransactionData()
    {
        return [
            'deposit to tenant account' => [
                [
                    'type_id'         => Transaction::DEPOSIT_TYPE,
                    'tenant_id'       => 1,
                    'currency_id'     => 1,
                    'payment_method'  => Transaction::CASH_PAYMENT,
                    'isTenantPayment' => true,
                    'city_id'         => 26068,
                    'sum'             => 100,
                    'comment'         => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 100,
                    'receiverBalance'    => 200,
                ],
                [
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 200,
                        'owner_name' => null,
                    ],
                    [
                        'type_id'    => Operation::INCOME_TYPE,
                        'sum'        => 100,
                        'saldo'      => 100,
                        'owner_name' => null,
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider depositTenantTransactionData
     */
    public function testDepositTenantTransaction(
        $transactionData,
        $senderBalanceExpected,
        $receiverBalanceExpected,
        $operationsExpected
    ) {
        $depositTransaction = new DepositTransaction($transactionData);

        $senderAccount    = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalanceOld = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount    = $this->testTransaction->getAccount(
            null,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalanceOld = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $depositTransaction->save();

        $senderAccount = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalance = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount = $this->testTransaction->getAccount(
            0,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalance = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $this->assertEquals($transactionData['currency_id'],
            $senderAccount->currency_id);
        $this->assertEquals($senderBalanceExpected, [
            'senderBalanceOld' => $senderBalanceOld,
            'senderBalance'    => $senderBalance,
        ]);

        $this->assertEquals($transactionData['currency_id'],
            $receiverAccount->currency_id);
        $this->assertEquals($receiverBalanceExpected, [
            'receiverBalanceOld' => $receiverBalanceOld,
            'receiverBalance'    => $receiverBalance,
        ]);

        $operationsActual = [];
        $operations       = Operation::findall(['transaction_id' => $depositTransaction->transaction_id]);
        foreach ($operations as $operation) {
            $operationsActual[] = [
                'type_id'    => $operation->type_id,
                'sum'        => (float)$operation->sum,
                'saldo'      => (float)$operation->saldo,
                'owner_name' => $operation->owner_name,
            ];
        }

        $this->assertEquals($operationsExpected, $operationsActual);
    }

}