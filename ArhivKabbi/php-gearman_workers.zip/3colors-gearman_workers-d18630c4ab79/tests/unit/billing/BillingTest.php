<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\Account;
use console\components\billing\Operation;
use console\components\billing\transactions\Transaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;

class BillingTest extends Unit
{
    public function _fixtures()
    {
        return [
            'accounts'         => AccountFixture::class,
            'clients'          => ClientFixture::class,
            'tenants'          => TenantFixture::class,
            'orders'           => OrderFixture::class,
            'orderDetailCosts' => OrderDetailCostFixture::class,
            'transactions'     => TransactionFixture::class,
            'operations'       => OperationFixture::class,
        ];
    }

    public function createBonusTransactionData()
    {
        return [
            'bonus income' => [
                [
                    'type_id'         => Transaction::DEPOSIT_TYPE,
                    'tenant_id'       => 1,
                    'sender_owner_id' => 1,
                    'currency_id'     => 1,
                    'sum'             => 100,
                    'payment_method'  => Transaction::BONUS_PAYMENT,
                    'user_created'    => null,
                ],
                Transaction::SUCCESS_RESPONSE,
            ],

            'bonus expenses' => [
                [
                    'type_id'         => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'       => 1,
                    'sender_owner_id' => 1,
                    'currency_id'     => 1,
                    'sum'             => 100,
                    'payment_method'  => Transaction::BONUS_PAYMENT,
                    'user_created'    => null,
                ],
                Transaction::SUCCESS_RESPONSE,
            ],
        ];
    }

    /**
     * @dataProvider createBonusTransactionData
     */
    public function testCreateBonusTransaction($transactionData, $expected)
    {
        $clientAccount    = Account::findOne([
            'tenant_id'   => $transactionData['tenant_id'],
            'owner_id'    => $transactionData['sender_owner_id'],
            'acc_kind_id' => Account::CLIENT_BONUS_KIND,
            'acc_type_id' => Account::PASSIVE_TYPE,
            'currency_id' => $transactionData['currency_id'],
        ]);
        $oldClientBalance = $clientAccount->balance;

        $result = Transaction::createTransaction($transactionData);

        $this->assertEquals($expected, $result, 'Invalid response result');

        $systemAccount    = Account::findOne([
            'tenant_id'   => $transactionData['tenant_id'],
            'acc_kind_id' => Account::SYSTEM_BONUS_KIND,
            'acc_type_id' => Account::ACTIVE_TYPE,
            'currency_id' => $transactionData['currency_id'],
        ]);
        $oldSystemBalance = 0;

        $clientAccount->refresh();

        $operationSum = $transactionData['sum']
            * ($transactionData['type_id'] === Operation::INCOME_TYPE ? 1 : -1);

        $this->assertEquals($oldClientBalance, $clientAccount->balance - $operationSum,
            'Sum of the client balance is incorrect');
        $this->assertEquals($oldSystemBalance, $systemAccount->balance - $operationSum,
            'Sum of the system balance is incorrect');
    }

}