<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\Account;
use console\components\billing\Operation;
use console\components\billing\models\PushNotification;
use console\components\billing\transactions\Transaction;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\CurrencyFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class TransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'workers'       => WorkerFixture::class,
            'workerHasCity' => WorkerHasCityFixture::class,
            'accounts'      => AccountFixture::class,
            'currencies'    => CurrencyFixture::class,
            'transactions'  => TransactionFixture::class,
            'operations'    => OperationFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction;
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }

    /**
     * Return data for get account
     */
    public function getAccountData()
    {
        return [
            'exists account'     => [1, 1, Account::CLIENT_BONUS_KIND, 1, true],
            'not exists account' => [-1, 1, Account::CLIENT_BONUS_KIND, 1, false],
        ];
    }

    /**
     * @dataProvider getAccountData
     */
    public function testGetAccount($ownerId, $tenantId, $kindId, $currencyId, $expected)
    {
        $this->assertEquals($expected,
            !empty($this->testTransaction->getAccount($ownerId, $tenantId, $kindId, $currencyId)));
    }


    /**
     * Return data to test the account creation
     * @return array
     */
    public function createAccountData()
    {
        return [
            'client account' => [
                2,
                1,
                Account::CLIENT_BONUS_KIND,
                Account::PASSIVE_TYPE,
                1,
            ],

            'tenant system account' => [
                0,
                1,
                Account::SYSTEM_BONUS_KIND,
                Account::ACTIVE_TYPE,
                1,
            ],
        ];
    }

    /**
     * @dataProvider createAccountData
     */
    public function testCreateAccount($ownerId, $tenantId, $kindId, $typeId, $currencyId)
    {
        $this->assertNotEmpty($this->testTransaction->createAccount(
            $ownerId, $tenantId, $kindId, $typeId, $currencyId));
    }


    /**
     * Return data to test the exceptions create account
     * @return array
     */
    public function createAccountExceptionsData()
    {
        return [
            'account already exists' => [
                1,
                1,
                Account::CLIENT_BONUS_KIND,
                Account::PASSIVE_TYPE,
                1,
                '\yii\db\IntegrityException',
            ],
        ];
    }

    /**
     * @dataProvider createAccountExceptionsData
     */
    public function testCreateAccountExceptions(
        $ownerId,
        $tenantId,
        $kindId,
        $typeId,
        $currencyId,
        $exceptionName,
        $exceptionMessage = '',
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $this->testTransaction->createAccount(
            $ownerId, $tenantId, $kindId, $typeId, $currencyId);
    }


    /**
     * Return data to test function updatePushNotification
     * @return array
     */
    public function updatePushNotificationData()
    {
        return [
            'empty notifications' => [
                [],
                [],
            ],

            'single notification' => [
                [
                    [
                        'tenantId'    => 1,
                        'tenantLogin' => 'test',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '123',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 150,
                    ],
                ],
                [
                    'test_123_worker' => [
                        'tenantId'    => 1,
                        'tenantLogin' => 'test',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '123',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 150,
                    ],
                ],
            ],

            'multiple notifications' => [
                [
                    [
                        'tenantId'    => 1,
                        'tenantLogin' => 'test',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '123',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 150,
                    ],
                    [
                        'tenantId'    => 2,
                        'tenantLogin' => 'test2',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '345',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 100,
                    ],
                ],
                [
                    'test_123_worker'  => [
                        'tenantId'    => 1,
                        'tenantLogin' => 'test',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '123',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 150,
                    ],
                    'test2_345_worker' => [
                        'tenantId'    => 2,
                        'tenantLogin' => 'test2',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '345',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 100,
                    ],
                ],
            ],

            'multiple notifications (combine)' => [
                [
                    [
                        'tenantId'    => 1,
                        'tenantLogin' => 'test',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '123',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 150,
                    ],
                    [
                        'tenantId'    => 2,
                        'tenantLogin' => 'test2',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '345',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 100,
                    ],
                    [
                        'tenantId'     => 1,
                        'tenantLogin'  => 'test',
                        'typeApp'      => 'worker',
                        'device'       => 'android',
                        'token'        => '123',
                        'lang'         => 'ru',
                        'currency'     => 'RUB',
                        'balance'      => 50,
                        'bonusBalance' => 15,
                    ],
                ],
                [
                    'test_123_worker'  => [
                        'tenantId'     => 1,
                        'tenantLogin'  => 'test',
                        'typeApp'      => 'worker',
                        'device'       => 'android',
                        'token'        => '123',
                        'lang'         => 'ru',
                        'currency'     => 'RUB',
                        'balance'      => 50,
                        'bonusBalance' => 15,
                    ],
                    'test2_345_worker' => [
                        'tenantId'    => 2,
                        'tenantLogin' => 'test2',
                        'typeApp'     => 'worker',
                        'device'      => 'android',
                        'token'       => '345',
                        'lang'        => 'ru',
                        'currency'    => 'RUB',
                        'balance'     => 100,
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider updatePushNotificationData
     */
    public function testUpdatePushNotification($notifications, $expected)
    {
        if (!empty($notifications)) {
            foreach ($notifications as $notification) {
                $this->testTransaction->updatePushNotification(
                    $notification['tenantId'],
                    $notification['tenantLogin'],
                    $notification['typeApp'],
                    $notification['device'],
                    $notification['token'],
                    $notification['lang'],
                    $notification['currency'],
                    isset($notification['balance']) ? $notification['balance'] : null,
                    isset($notification['bonusBalance']) ? $notification['bonusBalance'] : null,
                    isset($notification['appId']) ? $notification['appId'] : null);
            }
        }

        $expectedNotifications = [];
        foreach ($expected as $data) {
            $key                         = $data['tenantLogin'] . '_' . $data['token'] . '_' . $data['typeApp'];
            $notification                = new PushNotification(
                $data['tenantId'],
                $data['tenantLogin'],
                $data['typeApp'],
                $data['device'],
                $data['token'],
                $data['lang'],
                $data['currency'],
                isset($data['balance']) ? $data['balance'] : null,
                isset($data['bonusBalance']) ? $data['bonusBalance'] : null,
                isset($data['appId']) ? $data['appId'] : null);
            $expectedNotifications[$key] = $notification;
        }
        $this->assertEquals($expectedNotifications, $this->testTransaction->notifications);
    }


    /**
     * Return data for testing function `getApplicationType`
     * @return array
     */
    public function getApplicationTypeData()
    {
        return [
            'client' => [
                Account::CLIENT_KIND,
                PushNotification::TYPE_APP_CLIENT,
            ],

            'client bonus' => [
                Account::CLIENT_BONUS_KIND,
                PushNotification::TYPE_APP_CLIENT,
            ],

            'company' => [
                Account::COMPANY_KIND,
                null,
            ],

            'worker' => [
                Account::WORKER_KIND,
                PushNotification::TYPE_APP_WORKER,
            ],
        ];
    }

    /**
     * @dataProvider getApplicationTypeData
     */
    public function testGetApplicationType($accKindId, $expected)
    {
        $this->assertEquals($expected, $this->testTransaction->getApplicationType($accKindId));
    }


    /**
     * Return data to test function `getTenantLogin`
     * @return array
     */
    public function getTenantLoginData()
    {
        return [
            'tenant1' => [
                1,
                'test',
            ],

            'tenant3' => [
                3,
                'test3',
            ],

            'not exists' => [
                -1,
                '',
            ],
        ];
    }

    /**
     * @dataProvider getTenantLoginData
     */
    public function testGetTenantLogin($tenantId, $expected)
    {
        $this->testTransaction->tenant_id = $tenantId;
        $this->assertEquals($expected, $this->testTransaction->getTenantLogin());
    }


    /**
     * Return data to test function `getCurrencyData`
     * @return array
     */
    public function getCurrencyData()
    {
        return [
            'RUB'        => [1, 'RUB'],
            'USD'        => [2, 'USD'],
            'not exists' => [-1, ''],
        ];
    }

    /**
     * @dataProvider getCurrencyData
     */
    public function testGetCurrencyData($currencyId, $expected)
    {
        $this->testTransaction->currency_id = $currencyId;
        $this->assertEquals($expected, $this->testTransaction->getCurrency());
    }


    /**
     * Return data to test function `isOwnerExists`
     */
    public function isOwnerExistsData()
    {
        return [
            'client' => [
                1,
                Account::CLIENT_KIND,
                true,
            ],

            'client (bonus)' => [
                1,
                Account::CLIENT_BONUS_KIND,
                true,
            ],

            'client not exists' => [
                -1,
                Account::CLIENT_KIND,
                false,
            ],

            'company' => [
                1,
                Account::COMPANY_KIND,
                true,
            ],

            'company not exists' => [
                -1,
                Account::COMPANY_KIND,
                false,
            ],

            'worker' => [
                1,
                Account::WORKER_KIND,
                true,
            ],

            'worker not exists' => [
                -1,
                Account::WORKER_KIND,
                false,
            ],
        ];
    }

    /**
     * @dataProvider isOwnerExistsData
     */
    public function testIsOwnerExists($ownerId, $kindId, $expected)
    {
        $this->assertEquals($expected, $this->testTransaction->isOwnerExists($ownerId, $kindId));
    }


    /**
     * Test function `getGootaxBalance`
     */
    public function testGetGootaxBalance()
    {
        $expectedBalance = 100;
        $this->assertEquals($expectedBalance, $this->testTransaction->getGootaxBalance());
    }


    /**
     * Return data to test function `getOperationType`
     */
    public function getOperationTypeData()
    {
        return [
            'withdrawal' => [
                Transaction::WITHDRAWAL_TYPE,
                Operation::EXPENSES_TYPE,
            ],

            'deposit' => [
                Transaction::DEPOSIT_TYPE,
                Operation::INCOME_TYPE,
            ],

            'order payment' => [
                Transaction::ORDER_PAYMENT_TYPE,
                Operation::INCOME_TYPE,
            ],

            'unknown payment' => [
                -1,
                null,
            ],
        ];
    }

    /**
     * @dataProvider getOperationTypeData
     */
    public function testGetOperationType($transactionType, $expected)
    {
        $this->assertEquals($expected, $this->testTransaction->getOperationType($transactionType));
    }


    public function createTransactionData()
    {
        return [
            'There were no changes in the balance of accounts (deposit)' => [
                [
                    'type_id'            => Transaction::DEPOSIT_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::CASH_PAYMENT,
                    'sum'                => 0,
                    'comment'            => 'test comment',
                ],
                Transaction::SUCCESS_RESPONSE,
            ],

            'There were no changes in the balance of accounts (withdrawal)' => [
                [
                    'type_id'            => Transaction::WITHDRAWAL_TYPE,
                    'tenant_id'          => 1,
                    'sender_owner_id'    => 1,
                    'sender_acc_kind_id' => Account::CLIENT_KIND,
                    'currency_id'        => 1,
                    'payment_method'     => Transaction::WITHDRAWAL_PAYMENT,
                    'sum'                => 0,
                    'comment'            => 'test comment',
                ],
                Transaction::SUCCESS_RESPONSE,
            ],
        ];
    }

    /**
     * @dataProvider createTransactionData
     */
    public function testCreateTransaction($transactionData, $expected)
    {
        \Yii::$container->set('\console\components\billing\transactions\OrderTransaction', [
            'class'         => 'tests\codeception\console\unit\billing\models\OrderTransaction',
            'afterRollback' => function () {
                throw new \Exception('test after rollback event');
            },
        ]);
        $result = Transaction::createTransaction($transactionData);
        $this->assertEquals($expected, $result);
    }


    public function truncatedSumData()
    {
        return [
            'valid sum'                      => [1, 1.23, 1.23],
            'invalid sum'                    => [1, 1.2345, 1.23],
            'invalid sum (40.12 ~ 40.11999)' => [1, 40.12, 40.12],
        ];
    }

    /**
     * @dataProvider truncatedSumData
     */
    public function testTruncatedSum($currencyId, $sum, $expected)
    {
        $actual = $this->testTransaction->getTruncatedSum($sum, $currencyId);

        $this->assertEquals($expected, $actual);
    }

}
