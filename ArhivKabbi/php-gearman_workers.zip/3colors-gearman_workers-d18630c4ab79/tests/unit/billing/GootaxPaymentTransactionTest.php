<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\transactions\GootaxPaymentTransaction;
use console\components\billing\transactions\Transaction;
use console\components\billing\Account;
use console\components\billing\Operation;
use tests\unit\billing\models\TestTransaction;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\ClientCompanyFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class GootaxPaymentTransactionTest extends Unit
{
    /**
     * @var TestTransaction
     */
    protected $testTransaction;

    public function _fixtures()
    {
        return [
            'accounts'      => AccountFixture::class,
            'clients'       => ClientFixture::class,
            'companies'     => ClientCompanyFixture::class,
            'workers'       => WorkerFixture::class,
            'workerHasCity' => WorkerHasCityFixture::class,
            'tenants'       => TenantFixture::class,
            'operations'    => OperationFixture::class,
            'transactions'  => TransactionFixture::class,
        ];
    }

    protected function _before()
    {
        $this->testTransaction = new TestTransaction();
    }

    protected function _after()
    {
        $this->testTransaction = null;
    }


    /**
     * Return data for testing a gootax payment transaction
     */
    public function gootaxPaymentTransactionData()
    {
        return [
            'register payment' => [
                [
                    'action'      => GootaxPaymentTransaction::ACTION_REGISTER,
                    'type_id'     => Transaction::GOOTAX_PAYMENT_TYPE,
                    'tenant_id'   => 1,
                    'city_id'     => 26068,
                    'currency_id' => 1,
                    'sum'         => 100,
                    'comment'     => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => -100,
                ],
                [
                    'receiverBalanceOld' => 100,
                    'receiverBalance'    => 0,
                ],
                [
                    [
                        'type_id' => Operation::EXPENSES_TYPE,
                        'sum'     => 100,
                        'saldo'   => -100,
                    ],
                    [
                        'type_id' => Operation::EXPENSES_TYPE,
                        'sum'     => 100,
                        'saldo'   => 0,
                    ],
                ],
            ],

            'refund payment' => [
                [
                    'action'      => GootaxPaymentTransaction::ACTION_REFUND,
                    'type_id'     => Transaction::GOOTAX_PAYMENT_TYPE,
                    'tenant_id'   => 1,
                    'city_id'     => 26068,
                    'currency_id' => 1,
                    'sum'         => 100,
                    'comment'     => 'test comment',
                ],
                [
                    'senderBalanceOld' => 0,
                    'senderBalance'    => 100,
                ],
                [
                    'receiverBalanceOld' => 100,
                    'receiverBalance'    => 200,
                ],
                [
                    [
                        'type_id' => Operation::INCOME_TYPE,
                        'sum'     => 100,
                        'saldo'   => 100,
                    ],
                    [
                        'type_id' => Operation::INCOME_TYPE,
                        'sum'     => 100,
                        'saldo'   => 200,
                    ],
                ],
            ],
        ];
    }

    /**
     * @dataProvider gootaxPaymentTransactionData
     */
    public function testGootaxPaymentTransaction(
        $transactionData,
        $senderBalanceExpected,
        $receiverBalanceExpected,
        $operationsExpected
    ) {
        $gootaxPaymentTransaction = new GootaxPaymentTransaction($transactionData);

        $senderAccount    = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalanceOld = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount    = $this->testTransaction->getAccount(
            0,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalanceOld = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $gootaxPaymentTransaction->save();

        $senderAccount = $this->testTransaction->getAccount(
            0,
            $transactionData['tenant_id'],
            Account::TENANT_KIND,
            $transactionData['currency_id']);
        $senderBalance = empty($senderAccount) ? 0 : $senderAccount->balance;

        $receiverAccount = $this->testTransaction->getAccount(
            0,
            null,
            Account::GOOTAX_KIND,
            $transactionData['currency_id']);
        $receiverBalance = empty($receiverAccount) ? 0 : $receiverAccount->balance;

        $this->assertEquals($transactionData['currency_id'],
            $senderAccount->currency_id);
        $this->assertEquals($senderBalanceExpected, [
            'senderBalanceOld' => $senderBalanceOld,
            'senderBalance'    => $senderBalance,
        ]);

        $this->assertEquals($transactionData['currency_id'],
            $receiverAccount->currency_id);
        $this->assertEquals($receiverBalanceExpected, [
            'receiverBalanceOld' => $receiverBalanceOld,
            'receiverBalance'    => $receiverBalance,
        ]);

        $operationsActual = [];
        $operations       = Operation::findAll(['transaction_id' => $gootaxPaymentTransaction->transaction_id]);
        foreach ($operations as $operation) {
            $operationsActual[] = [
                'type_id' => $operation->type_id,
                'sum'     => (float)$operation->sum,
                'saldo'   => (float)$operation->saldo,
            ];
        }

        $this->assertEquals($operationsExpected, $operationsActual);
    }


    /**
     * Return data for testing a exceptions
     * @return array
     */
    public function gootaxPaymentTransactionExceptionsData()
    {
        return [
            'Not supported action' => [
                [
                    'type_id'     => Transaction::GOOTAX_PAYMENT_TYPE,
                    'tenant_id'   => 1,
                    'currency_id' => 1,
                    'sum'         => 100,
                    'comment'     => 'test comment',
                ],
                'yii\base\NotSupportedException',
            ],
        ];
    }

    /**
     * @dataProvider gootaxPaymentTransactionExceptionsData
     */
    public function testGootaxPaymentTransactionExceptions(
        $transactionData,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $gootaxPaymentTransaction = new GootaxPaymentTransaction($transactionData);
        $gootaxPaymentTransaction->save();
    }

}