<?php

namespace tests\unit\billing;

use Codeception\Test\Unit;
use console\components\billing\models\Bonus;
use console\components\billing\models\Order;
use console\components\billing\models\BonusFailLog;
use tests\unit\fixtures\AccountFixture;
use tests\unit\fixtures\BonusFailLogFixture;
use tests\unit\fixtures\CarFixture;
use tests\unit\fixtures\ClientBonusFixture;
use tests\unit\fixtures\ClientBonusGootaxFixture;
use tests\unit\fixtures\ClientBonusHasTariffFixture;
use tests\unit\fixtures\ClientFixture;
use tests\unit\fixtures\ClientOrderFromAppFixture;
use tests\unit\fixtures\OperationFixture;
use tests\unit\fixtures\OrderDetailCostFixture;
use tests\unit\fixtures\OrderFixture;
use tests\unit\fixtures\TaxiTariffFixture;
use tests\unit\fixtures\TaxiTariffHasCityFixture;
use tests\unit\fixtures\TenantFixture;
use tests\unit\fixtures\TransactionFixture;
use tests\unit\fixtures\WorkerFixture;
use tests\unit\fixtures\WorkerHasCityFixture;

class BonusFailLogTest extends Unit
{
    /**
     * @var Bonus
     */
    private $bonus;

    public function _fixtures()
    {
        return [
            'cars'                   => CarFixture::class,
            'clientBonuses'          => ClientBonusFixture::class,
            'clientBonusGootax'      => ClientBonusGootaxFixture::class,
            'clientBonusesHasTariff' => ClientBonusHasTariffFixture::class,
            'clientOrderFromApp'     => ClientOrderFromAppFixture::class,
            'clients'                => ClientFixture::class,
            'workers'                => WorkerFixture::class,
            'workerHasCity'          => WorkerHasCityFixture::class,
            'orderDetailCost'        => OrderDetailCostFixture::class,
            'orders'                 => OrderFixture::class,
            'tariffs'                => TaxiTariffFixture::class,
            'tariffHasCity'          => TaxiTariffHasCityFixture::class,
            'tenants'                => TenantFixture::class,
            'bonusFailLogs'          => BonusFailLogFixture::class,
            'accounts'               => AccountFixture::class,
            'transactions'           => TransactionFixture::class,
            'operations'             => OperationFixture::class,
        ];
    }

    protected function _before()
    {
        $this->bonus = new Bonus;
    }

    protected function _after()
    {
        $this->bonus = null;
    }

    /**
     * Return data for calculate bonus
     * @return array
     */
    public function calculateBonusData()
    {
        return [
            'first order from app device token exists invalid order time' => [
                26,
                5,
                Order::STATUS_ID_COMPLETE_PAID,
                [
                    'id'           => 1,
                    'order_id'     => 26,
                    'client_id'    => 5,
                    'device'       => 'ANDROID',
                    'device_token' => '12345',
                    'order_time'   => 1450027800,
                    'bonus_id'     => 11,
                    'bonus'        => 10,
                ],
            ],

            'first order from app device token exists valid order time' => [
                27,
                5,
                Order::STATUS_ID_COMPLETE_PAID,
                null,
            ],
        ];
    }

    /**
     * @dataProvider calculateBonusData
     */
    public function testCalculateBonus($orderId, $clientId, $orderStatusId, $expected)
    {
        $this->bonus->calculateOrderBonus($orderId, $orderStatusId);
        $result = BonusFailLog::find()->where(['client_id' => $clientId])
            ->asArray()->one();
        $this->assertEquals($expected, $result);
    }

}