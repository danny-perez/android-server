<?php

namespace tests\unit\billing\models;

use console\components\billing\transactions\Transaction;

class TestTransaction extends Transaction
{
    public $sender_acc_balance;
    public $notificationList;

    public function init()
    {
    }

    protected function doTransactOperation()
    {
    }

    public function createOperation(
        $operationType,
        $accountId,
        $transactionId,
        $sum,
        $accountBalance,
        $comment = '',
        $ownerName = ''
    ) {
        return parent::createOperation($operationType, $accountId, $transactionId,
            $sum, $accountBalance, $comment, $ownerName);
    }

    public function getAccount($ownerId, $tenantId, $kindId, $currencyId)
    {
        return parent::getAccount($ownerId, $tenantId, $kindId, $currencyId);
    }

    public function createAccount($ownerId, $tenantId, $kindId, $typeId, $currencyId)
    {
        return parent::createAccount($ownerId, $tenantId, $kindId, $typeId, $currencyId);
    }

    public function updatePushNotification(
        $tenantId,
        $tenantLogin,
        $typeApp,
        $device,
        $token,
        $lang,
        $currency,
        $balance = null,
        $bonusBalance = null,
        $appId = null
    ) {
        return parent::updatePushNotification($tenantId, $tenantLogin, $typeApp,
            $device, $token, $lang, $currency, $balance, $bonusBalance, $appId);
    }

    public function getTenantLogin()
    {
        return parent::getTenantLogin();
    }

    public function getCurrency()
    {
        return parent::getCurrency();
    }

    public function isOwnerExists($ownerId, $kindId)
    {
        return parent::isOwnerExists($ownerId, $kindId);
    }

    public function getGootaxBalance()
    {
        return parent::getGootaxBalance();
    }

    public function getOperationType($transactionType)
    {
        return parent::getOperationType($transactionType);
    }

    public function getTruncatedSum($sum, $currencyId)
    {
        return parent::getTruncatedSum($sum, $currencyId);
    }
}
