<?php

namespace tests\unit\billing\models;

class OrderTransaction extends \console\components\billing\transactions\OrderTransaction
{
    public $notificationList = [];

    protected function getWorkerCommission()
    {
        return 5;
    }
}