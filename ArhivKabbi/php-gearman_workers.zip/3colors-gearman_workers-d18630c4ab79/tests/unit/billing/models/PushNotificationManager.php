<?php

namespace tests\unit\billing\models;

class PushNotificationManager extends \console\components\billing\PushNotificationManager
{
    public $notifications = [];

    protected function sendNotification($notification)
    {
        $this->notifications[] = $notification->generateParams();
    }
}
