<?php

namespace tests\unit\notification\workerBalance\models;

use Codeception\Test\Unit;
use notification\workerBalance\models\Currency;
use notification\workerBalance\models\Money;
use notification\workerBalance\models\Operation;
use notification\workerBalance\models\Order;
use notification\workerBalance\models\Worker;

/**
 * Class OperationTest
 * @package tests\unit\notification\workerBalance\models
 */
class OperationTest extends Unit
{
    public function generateSignatureData()
    {
        return [
            [1, Operation::OPERATION_TYPE_RECHARGE, '2017-10-29 10:00:00', 'comment', 1, 500, 'RUB', 2, 1, 1, 'CASH'],
            [
                1,
                Operation::OPERATION_TYPE_RECHARGE,
                '2017-10-29 10:00:00',
                null,
                1,
                500,
                'RUB',
                2,
                null,
                null,
                null,
            ],
        ];
    }

    /**
     * @dataProvider generateSignatureData
     */
    public function testGenerateSignature(
        $id,
        $type,
        $date,
        $comment,
        $callsign,
        $amount,
        $currency,
        $minorUnit,
        $orderId,
        $orderNumber,
        $payment
    ) {
        $token = '123456';

        $expected = md5(implode(';', [
            (string)$id,
            $type,
            $date,
            $comment,
            (string)$callsign,
            (string)$amount,
            $currency,
            (string)$minorUnit,
            (string)$orderId,
            (string)$orderNumber,
            (string)$payment,
            $token,
        ]));

        $operation = new Operation($id, $type, $date, $comment, new Worker($callsign),
            new Money($amount, new Currency($currency, $minorUnit)), new Order($orderId, $orderNumber, $payment));

        $this->assertEquals($expected, $operation->generateSignature($token));
    }
}