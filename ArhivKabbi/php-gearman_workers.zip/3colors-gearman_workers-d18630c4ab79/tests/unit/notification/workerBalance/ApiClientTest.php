<?php

namespace tests\unit\notification\workerBalance;

use Codeception\Test\Unit;
use GuzzleHttp\Client;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Response;
use notification\workerBalance\ApiClient;
use notification\workerBalance\exceptions\WorkerBalanceNotificationException;
use notification\workerBalance\models\Currency;
use notification\workerBalance\models\Money;
use notification\workerBalance\models\Operation;
use notification\workerBalance\models\Worker;

/**
 * Class ApiClientTest
 * @package tests\unit\notification\workerBalance
 */
class ApiClientTest extends Unit
{
    public function sendWorkerBalanceNotificationData()
    {
        return [
            [[new Response(200, [], null)]],
        ];
    }

    /**
     * @dataProvider sendWorkerBalanceNotificationData
     */
    public function testSendWorkerBalanceNotification($responses)
    {
        $apiClient = $this->getMockedApiClient($responses);
        $apiClient->sendWorkerBalanceNotification('https://google.com', 'token', $this->generateOperation());

        $this->assertEquals(true, true);
    }


    public function sendWorkerBalanceNotificationErrorData()
    {
        return [
            [
                [new Response(400, [], null)],
                WorkerBalanceNotificationException::class,
            ],
            [
                [new Response(500, [], null)],
                WorkerBalanceNotificationException::class,
            ],
        ];
    }

    /**
     * @dataProvider sendWorkerBalanceNotificationErrorData
     */
    public function testSendWorkerBalanceNotificationError($responses, $expectedException)
    {
        $this->setExpectedException($expectedException);

        $apiClient = $this->getMockedApiClient($responses);
        $apiClient->sendWorkerBalanceNotification('https://google.com', 'token', $this->generateOperation());
    }

    private function generateOperation()
    {
        return new Operation(
            1, Operation::OPERATION_TYPE_RECHARGE, 'date', '', new Worker(1),
            new Money(500, new Currency('RUB', 2)), null);
    }

    private function getMockedApiClient($responses)
    {
        $mock = new MockHandler($responses);
        $httpClient = new Client(['handler' => HandlerStack::create($mock)]);

        return new ApiClient($httpClient);
    }
}