<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use \console\modules\sms\models\smsc\SmscProvider;

class SmscProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }

    public function sendSmsData()
    {
        return [
            'successful sending' => [
                [
                    'sendSms' => function () {
                        return ['error' => '0'];
                    },
                ],
                true,
            ],

            'error sending duplicate request, wait a minute' => [
                [
                    'sendSms' => function () {
                        return ['error' => '9', 'msg' => 'duplicate request, wait a minute'];
                    },
                ],
                false,
            ],

            'error sending invalid number' => [
                [
                    'sendSms' => function () {
                        return ['error' => '7', 'msg' => 'invalid number'];
                    },
                ],
                false,
            ],

            'error sending authorise error' => [
                [
                    'sendSms' => function () {
                        return ['error' => '2', 'msg' => 'authorise error'];
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\smsc\Smsc', $modelMethods);

        $provider       = new SmscProvider();
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }

}
