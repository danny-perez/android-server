<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\IbateleProvider;

class IbateleProviderTest extends Unit
{
    /**
     * @var IbateleProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new IbateleProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'test1' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>'
                . '<RECEIVER AGT_ID="" DATE_REPORT="05.01.2016 13:32:35" /> </output>',
                true,
            ],

            'test2' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>'
                . '<error>Ошибка авторизации</error></output>',
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($xml, $expected)
    {
        $login    = null;
        $password = null;
        $message  = null;
        $target   = null;
        $sender   = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\IbateleSms')
            ->getMock($login, $password);
        $gate->method('send_message')
            ->willReturn($xml);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }


    public function requestBalanceData()
    {
        return [
            'test1' => [
                '{sms: ["4", "4", "7", "7", "5", "7", "7", "7", "7", "7", "7", "5", "15"], money: "4.22"}',
                4.22,
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceData
     */
    public function testRequestBalance($response, $expected = '')
    {
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\IbateleSms')->getMock();
        $gate->method('send_request')->willReturn($response);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->requestBalance($login, $password));
    }


    public function requestBalanceExceptionData()
    {
        return [
            'Error via balance request' => [
                '{"money":{"@attributes":{"currency":""}}}'
                ,
                '\console\modules\sms\exceptions\RequestBalanceException',
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceExceptionData
     */
    public function testRequestBalanceException(
        $response,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\IbateleSms')->getMock();
        $gate->method('send_request')->willReturn($response);
        $this->provider->gate = $gate;
        $this->provider->requestBalance($login, $password);
    }

}
