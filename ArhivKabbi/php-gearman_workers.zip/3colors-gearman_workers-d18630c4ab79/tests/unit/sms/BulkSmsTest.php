<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\bulkSms\BulkSms;

class BulkSmsTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending status code = 200' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = BulkSms::SUCCESSFUL_STATUS;
                        $response->headers['Status-Code'] = 200;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                true,
            ],

            'successful sending status code = 202' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = BulkSms::SUCCESSFUL_STATUS;
                        $response->headers['Status-Code'] = 202;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                true,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($curlMethods, $expected)
    {
        $curl = $this->getCustomMock('\console\components\curl\Curl',
            $curlMethods);
        app()->set('curl', $curl);

        $provider = new BulkSms;
        $result   = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }


    public function sendSmsExceptionsData()
    {
        return [
            'status code = 200, incorrect body message' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 200;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\yii\base\Exception',
            ],

            'status code = 202, incorrect body message' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 202;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\yii\base\Exception',
            ],

            'status code = 401, authorization error' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 401;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\console\modules\sms\models\bulkSms\exceptions\AuthorizationErrorException',
            ],

            'status code = 402, insufficient funds' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 402;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\console\modules\sms\models\bulkSms\exceptions\InsufficientFundsException',
            ],

            'status code = 406, wrong sender' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 406;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\console\modules\sms\models\bulkSms\exceptions\WrongSenderException',
            ],

            'status code = 430, deny sending sms' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 430;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\console\modules\sms\models\bulkSms\exceptions\DenySendingSmsException',
            ],

            'status code = 501, internal error' => [
                [
                    'get' => function () {
                        $response                         = new \stdClass();
                        $response->body                   = 'test';
                        $response->headers['Status-Code'] = 501;
                        $response->headers['Status']      = '';

                        return $response;
                    },
                ],
                '\console\modules\sms\models\bulkSms\exceptions\InternalErrorException',
            ],
        ];
    }

    /**
     * @dataProvider sendSmsExceptionsData
     */
    public function testSendSmsExceptions(
        $curlMethods,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage,
            $exceptionCode);

        $curl = $this->getCustomMock('\console\components\curl\Curl',
            $curlMethods);
        app()->set('curl', $curl);

        $provider = new BulkSms;
        $provider->sendSms(null, null, null, null, null);
    }
}
