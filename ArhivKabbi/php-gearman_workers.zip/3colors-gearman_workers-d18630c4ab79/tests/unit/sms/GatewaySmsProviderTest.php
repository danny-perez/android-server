<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use \console\modules\sms\models\gateway\GatewaySmsProvider;

class GatewaySmsProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending' => [
                [
                    'sendSms' => function () {
                        return ['error' => '0'];
                    },
                ],
                true,
            ],

            'error sending' => [
                [
                    'sendSms' => function () {
                        return ['error' => '1', 'msg' => 'Incorrect login or password'];
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\gateway\GatewaySms',
            $modelMethods);

        $provider       = new GatewaySmsProvider;
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }

}
