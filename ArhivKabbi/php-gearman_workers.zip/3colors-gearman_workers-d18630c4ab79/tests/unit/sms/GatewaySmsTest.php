<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\gateway\GatewaySms;

class GatewaySmsTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending status = 0' => [
                [
                    'post' => function () {
                        $xml = new \Codeception\Util\XmlBuilder();
                        $xml->response
                            ->result
                            ->attr('status', '0')
                            ->id
                            ->val(11111111);

                        return $xml;
                    },
                ],
                [
                    'error' => '0',
                ],
            ],

            'error sending status = 1' => [
                [
                    'post' => function () {
                        $xml = new \Codeception\Util\XmlBuilder();
                        $xml->response
                            ->result
                            ->attr('status', '1')
                            ->val('Incorrect login or password');

                        return $xml;
                    },
                ],
                [
                    'error' => '1',
                    'msg'   => 'Incorrect login or password',
                ],
            ],

        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($curlMethods, $expected)
    {
        $curl = $this->getCustomMock('\console\components\curl\Curl',
            $curlMethods);
        app()->set('curl', $curl);

        $provider = new GatewaySms;
        $result   = $provider->sendSms(null, null, null, null);

        $this->assertEquals($expected, $result);
    }


}
