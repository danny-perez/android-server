<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\MsmSmsProvider;

class MsmProviderTest extends Unit
{
    /**
     * @var MsmSmsProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new MsmSmsProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'test1' => [
                'errno=100&errtext=OK&message_id=1&charge=1',
                true,
            ],

            'test2' => [
                'errno=20&errtext=Invalid msisdn&message_id=0&charge=0',
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($xml, $expected)
    {
        $login    = null;
        $password = null;
        $message  = null;
        $target   = null;
        $sender   = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\MsmSms')
            ->getMock();
        $gate->method('send_message')
            ->willReturn($xml);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }


    public function requestBalanceData()
    {
        return [
            'test1' => [
                'balance=50&date=2015-02-27T19:27:41 ',
                50,
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceData
     */
    public function testRequestBalance($response, $expected)
    {
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\MsmSms')->getMock();
        $gate->method('request_balance')->willReturn($response);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->requestBalance($login, $password));
    }


    public function requestBalanceExceptionData()
    {
        return [
            'Error via balance request' => [
                'errno=20&errtext=Invalid msisdn&message_id=0&charge=0',
                '\console\modules\sms\exceptions\RequestBalanceException',
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceExceptionData
     */
    public function testRequestBalanceException(
        $response,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\MsmSms')->getMock();
        $gate->method('request_balance')->willReturn($response);
        $this->provider->gate = $gate;
        $this->provider->requestBalance($login, $password);
    }

}
