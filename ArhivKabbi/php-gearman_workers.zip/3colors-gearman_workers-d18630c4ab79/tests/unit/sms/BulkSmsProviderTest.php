<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use \console\modules\sms\models\bulkSms\BulkSmsProvider;

class BulkSmsProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending' => [
                [
                    'sendSms' => function () {
                        return true;
                    },
                ],
                true,
            ],

            'authorization error' => [
                [
                    'sendSms' => function () {
                        throw new \console\modules\sms\models\bulkSms\exceptions\AuthorizationErrorException;
                    },
                ],
                false,
            ],

            'insufficient funds' => [
                [
                    'sendSms' => function () {
                        throw new \console\modules\sms\models\bulkSms\exceptions\InsufficientFundsException;
                    },
                ],
                false,
            ],

            'deny sending sms' => [
                [
                    'sendSms' => function () {
                        throw new \console\modules\sms\models\bulkSms\exceptions\DenySendingSmsException;
                    },
                ],
                false,
            ],

            'wrong sender' => [
                [
                    'sendSms' => function () {
                        throw new \console\modules\sms\models\bulkSms\exceptions\WrongSenderException;
                    },
                ],
                false,
            ],

            'internal error' => [
                [
                    'sendSms' => function () {
                        throw new \console\modules\sms\models\bulkSms\exceptions\InternalErrorException;
                    },
                ],
                false,
            ],

            'unknown error' => [
                [
                    'sendSms' => function () {
                        throw new \Exception;
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\bulkSms\BulkSms',
            $modelMethods);

        $provider       = new BulkSmsProvider;
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }


    public function testRequestBalance()
    {
        $provider = new BulkSmsProvider;

        $expected = json_encode('Method does not work');
        $actual   = $provider->requestBalance('test', 'test');

        $this->assertEquals($expected, $actual);
    }
}
