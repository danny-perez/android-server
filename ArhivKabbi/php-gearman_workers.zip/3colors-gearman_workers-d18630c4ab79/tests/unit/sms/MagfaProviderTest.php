<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use \console\modules\sms\models\magfa\MagfaProvider;

class MagfaProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending' => [
                [
                    'sendSms' => function () {
                        return (string)mt_rand(100, 9999999999);
                    },
                ],
                true,
            ],

            'error' => [
                [
                    'sendSms' => function () {
                        return (string)mt_rand(0, 99);
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\magfa\Magfa',
            $modelMethods);

        $provider       = new MagfaProvider();
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }

}
