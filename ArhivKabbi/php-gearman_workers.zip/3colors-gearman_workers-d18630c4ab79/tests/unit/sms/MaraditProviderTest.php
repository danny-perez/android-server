<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\maraditSms\MaraditProvider;
use console\modules\sms\models\maraditSms\MaraditResponse;

class MaraditProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'successful sending' => [
                [
                    'sendSms' => function () {
                        return [
                            'status'  => 'ok',
                            'message' => [
                                'successMessage' => null,
                                'errorMessage'   => null,
                                'obj'            => null,
                                'errorCode'      => null,
                            ],
                        ];
                    },
                ],
                true,
            ],

            'error sending. code -108' => [
                [
                    'sendSms' => function () {
                        return [
                            'status'  => 'ok',
                            'message' => [
                                'successMessage' => null,
                                'errorMessage'   => 'INVALID_HASH',
                                'obj'            => null,
                                'errorCode'      => "-108",
                            ],
                        ];
                    },
                ],
                false,
            ],

            'error sending. connect error' => [
                [
                    'sendSms' => function () {
                        return [
                            'status'  => 'error',
                            'message' => 'Connect error',
                        ];
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\maraditSms\Maradit',
            $modelMethods);

        $provider       = new MaraditProvider;
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }
}
