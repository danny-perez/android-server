<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\EyelineSmsProvider;

class EyelineSmsBelarusTest extends Unit
{
    /**
     * @var EyelineSmsProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new EyelineSmsProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'test1' => [
                'Queued',
                true,
            ],

            'test2' => [
                'Queued',
                true,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($xml, $expected)
    {
        $login    = null;
        $password = null;
        $message  = null;
        $target   = null;
        $sender   = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\EyelineSms')
            ->getMock();
        $gate->method('send_message')
            ->willReturn($xml);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }

}
