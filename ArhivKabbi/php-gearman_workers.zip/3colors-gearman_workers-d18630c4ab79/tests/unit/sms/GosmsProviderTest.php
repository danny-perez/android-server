<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\gosms\GosmsProvider;
use console\modules\sms\models\MsmSmsProvider;

class GosmsProviderTest extends Unit
{
    /**
     * @var MsmSmsProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new GosmsProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'success' => [
                [
                    'error' => 0,
                    'msg'   => '',
                ],
                true,
            ],

            'error' => [
                [
                    'error' => 1,
                    'msg'   => 'Any Error',
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($xml, $expected)
    {
        $login    = null;
        $password = null;
        $message  = null;
        $target   = null;
        $sender   = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\gosms\Gosms')
            ->getMock();
        $gate->method('sendSms')
            ->willReturn($xml);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }
}
