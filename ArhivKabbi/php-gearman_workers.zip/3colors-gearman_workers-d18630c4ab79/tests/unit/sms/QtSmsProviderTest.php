<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\QtSmsProvider;

class QtSmsProviderTest extends Unit
{
    /**
     * @var QtSmsProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new QtSmsProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'test1' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>'
                . '<RECEIVER AGT_ID="" DATE_REPORT="05.01.2016 13:32:35" /> </output>',
                true,
            ],

            'test2' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>'
                . '<RECEIVER AGT_ID="" DATE_REPORT="05.01.2016 13:32:35" />'
                . '<errors><error code="-20107">Ошибка авторизации </error></errors></output>',
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($xml, $expected)
    {
        $login    = null;
        $password = null;
        $message  = null;
        $target   = null;
        $sender   = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\QtSms')
            ->getMock($login, $password);
        $gate->method('post_message')
            ->willReturn($xml);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }


    public function requestBalanceData()
    {
        return [
            'Balance = 0' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>
                <RECEIVER AGT_ID="10110" DATE_REPORT="29.01.2016 10:21:45" />
                <balance>
                <AGT_BALANCE>0</AGT_BALANCE>
                <OVERDRAFT>0</OVERDRAFT></balance></output>',
                0,
            ],

            'Balance = -100' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>
                <RECEIVER AGT_ID="10110" DATE_REPORT="29.01.2016 10:21:45" />
                <balance>
                <AGT_BALANCE>-100</AGT_BALANCE>
                <OVERDRAFT>0</OVERDRAFT></balance></output>',
                -100,
            ],

            'Balance = 100' => [
                '<?xml version="1.0" encoding="UTF-8"?><output>
                <RECEIVER AGT_ID="10110" DATE_REPORT="29.01.2016 10:21:45" />
                <balance>
                <AGT_BALANCE>100</AGT_BALANCE>
                <OVERDRAFT>0</OVERDRAFT></balance></output>',
                100,
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceData
     */
    public function testRequestBalance($response, $expected = '')
    {
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\QtSms')->getMock();
        $gate->method('get_balance')->willReturn($response);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->requestBalance($login, $password));
    }


    public function requestBalanceExceptionData()
    {
        return [
            'Error via balance request' => [
                '<output>' .
                '<errors>' .
                '<error>Invalid password/login</error>' .
                '</errors>' .
                '</output>'
                ,
                '\console\modules\sms\exceptions\RequestBalanceException',
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceExceptionData
     */
    public function testRequestBalanceException(
        $response,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\QtSms')->getMock();
        $gate->method('get_balance')->willReturn($response);
        $this->provider->gate = $gate;
        $this->provider->requestBalance($login, $password);
    }

}
