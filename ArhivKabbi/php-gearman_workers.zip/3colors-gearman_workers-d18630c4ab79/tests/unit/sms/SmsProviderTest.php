<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;

class SmsProviderTest extends Unit
{
    protected function _before()
    {

    }

    protected function _after()
    {

    }

    public function testSendSmsResult()
    {
        $stub = $this->getMockBuilder('\console\modules\sms\models\SmsProviderInterface')
            ->getMock();

        $stub->method('sendSms')
            ->willReturn(false);

        $this->assertFalse($stub->sendSms(null, null, null, null, null, null));
    }

}