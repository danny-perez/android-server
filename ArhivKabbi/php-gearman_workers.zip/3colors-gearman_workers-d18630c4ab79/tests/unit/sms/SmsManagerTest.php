<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use Codeception\Util\Stub;
use console\modules\sms\components\SmsManager;
use tests\unit\fixtures\SmsLogFixture;

class SmsManagerTest extends Unit
{
    public function _fixtures()
    {
        return [
            'smsLog' => SmsLogFixture::class,
        ];
    }

    /**
     *
     * @var SmsManager
     */
    public $smsManager;

    protected function _before()
    {
        $smsProviderFactory = Stub::make('\console\modules\sms\components\SmsProviderFactory', [
            'getProvider'    => function ($serverId) {
                return Stub::make('\console\modules\sms\models\IqSmsProvider', [
                    'sendSms' => function () use ($serverId) {
                        return $serverId == 3;
                    },
                ]);
            },
            'getError'       => null,
            'requestBalance' => 0,

        ]);
        $this->smsManager   = new SmsManager($smsProviderFactory);
    }

    protected function _after()
    {
        $this->smsManager = null;
    }


    public function smsManagerData()
    {
        return [
            'Failed sms sending (sms provider crashed with error)' => [
                [
                    'server'    => [
                        [
                            'server_id' => 1,
                            'login'     => 'test',
                            'password'  => 'test',
                            'sign'      => 'test',
                        ],
                    ],
                    'text'      => 'text',
                    'phone'     => '+79001234567',
                    'tenant_id' => '1',
                ],
                false,
            ],

            'Fails because takes 1st server' => [
                [
                    'server'    => [
                        [
                            'server_id' => 1,
                            'login'     => 'test',
                            'password'  => 'test',
                            'sign'      => 'test',
                        ],
                        [
                            'server_id' => 1,
                            'login'     => 'test',
                            'password'  => 'test',
                            'sign'      => 'test',
                        ],
                    ],
                    'text'      => 'text',
                    'phone'     => '+79001234567',
                    'tenant_id' => '1',
                ],
                false,
            ],

            'Successfull sms sending (server_id = 3)' => [
                [
                    'server'    => [
                        [
                            'server_id' => 3,
                            'login'     => 'test',
                            'password'  => 'test',
                            'sign'      => 'test',
                        ],
                    ],
                    'text'      => 'text',
                    'phone'     => '+79001234567',
                    'tenant_id' => '1',
                ],
                true,
            ],
        ];
    }

    /**
     * @dataProvider smsManagerData
     */
    public function testSmsManager($response, $expected)
    {
        $this->assertEquals($expected, $this->smsManager->sendSms($response));
    }

}