<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\bsg\BsgSmsProvider;

class BsgSmsProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'success' => [
                [
                    'sendSms' => function () {
                        return file_get_contents(__DIR__ . '/data/bsg/1.xml');
                    },
                ],
                true,
            ],

            'invalid login or password' => [
                [
                    'sendSms' => function () {
                        return file_get_contents(__DIR__ . '/data/bsg/2.xml');
                    },
                ],
                false,
            ],

            'invalid phone' => [
                [
                    'sendSms' => function () {
                        return file_get_contents(__DIR__ . '/data/bsg/3.xml');
                    },
                ],
                false,
            ],

            'empty sender' => [
                [
                    'sendSms' => function () {
                        return file_get_contents(__DIR__ . '/data/bsg/4.xml');
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\bsg\BsgSms',
            $modelMethods);

        $provider       = new BsgSmsProvider();
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }
}
