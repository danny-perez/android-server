<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\alphasms\AlphasmsProvider;

class AlphasmsProviderTest extends Unit
{
    /**
     * Getting mock
     *
     * @param string $className
     * @param array  $methods
     * @param array  $args
     *
     * @return mixed
     */
    public function getCustomMock($className, $methods = [], $args = [])
    {
        $mock = $this->getMockBuilder($className)
            ->setMethods(array_keys($methods))
            ->setConstructorArgs($args)
            ->getMock();

        foreach ($methods as $name => $method) {
            $mock->method($name)->will($this->returnCallback($method));
        }

        return $mock;
    }


    public function sendSmsData()
    {
        return [
            'success' => [
                [
                    'sendSms' => function () {
                        return 'id:401938483 sms_count:1';
                    },
                ],
                true,
            ],

            'invalid login or password' => [
                [
                    'sendSms' => function () {
                        return 'errors:Wrong login/password';
                    },
                ],
                false,
            ],

            'invalid phone' => [
                [
                    'sendSms' => function () {
                        return 'errors:Operator not supported';
                    },
                ],
                false,
            ],

            'empty sender' => [
                [
                    'sendSms' => function () {
                        return 'errors:Sender phone should contains only english letters, digits, dot, underscore, dash, space, &';
                    },
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($modelMethods, $expected)
    {
        $model = $this->getCustomMock('\console\modules\sms\models\alphasms\Alphasms', $modelMethods);

        $provider       = new AlphasmsProvider();
        $provider->gate = $model;
        $result         = $provider->sendSms(null, null, null, null, null);

        $this->assertEquals($expected, $result);
    }
}
