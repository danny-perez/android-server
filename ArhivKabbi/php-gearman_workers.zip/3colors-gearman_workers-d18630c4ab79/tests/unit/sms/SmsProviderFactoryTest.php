<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\components\SmsProviderFactory;

class SmsProviderFactoryTest extends Unit
{
    /**
     * @var SmsProviderFactory
     */
    public $smsProviderFactory;

    protected function _before()
    {
        $this->smsProviderFactory = new SmsProviderFactory();
    }

    protected function _after()
    {
        $this->smsProviderFactory = null;
    }

    public function smsFactoryProviderExceptionsData()
    {
        return [
            'Invalid server id' => [
                -1,
                '\console\modules\sms\exceptions\InvalidServerIdException',
            ],
        ];
    }

    /**
     * @dataProvider smsFactoryProviderExceptionsData
     */
    public function testSmsFactoryProviderExceptions(
        $serverId,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);

        $this->smsProviderFactory->getProvider($serverId);
    }


    public function getProviderData()
    {
        return [
            'Server id is 1 (valid)'  => [1],
            'Server id is 2 (valid)'  => [2],
            'Server id is 3 (valid)'  => [3],
            'Server id is 4 (valid)'  => [4],
            'Server id is 5 (valid)'  => [5],
            'Server id is 6 (valid)'  => [6],
            'Server id is 7 (valid)'  => [7],
            'Server id is 8 (valid)'  => [8],
            'Server id is 9 (valid)'  => [9],
            'Server id is 10 (valid)' => [10],
            'Server id is 11 (valid)' => [11],
            'Server id is 12 (valid)' => [12],
            'Server id is 13 (valid)' => [13],
            'Server id is 14 (valid)' => [14],
            'Server id is 15 (valid)' => [15],
            'Server id is 16 (valid)' => [16],
            'Server id is 17 (valid)' => [17],
            'Server id is 18 (valid)' => [18],
        ];
    }

    /**
     * @dataProvider getProviderData
     */
    public function testGetProvider($serverId)
    {
        $this->assertNotNull($this->smsProviderFactory->getProvider($serverId));
    }
}
