<?php

namespace tests\unit\sms;

use Codeception\Test\Unit;
use console\modules\sms\models\IqSmsProvider;

class IqSmsProviderTest extends Unit
{
    /**
     * @var IqSmsProvider
     */
    private $provider;

    protected function _before()
    {
        $this->provider = new IqSmsProvider();
    }

    protected function _after()
    {
        $this->provider = null;
    }


    public function sendSmsData()
    {
        return [
            'accepted messsage'          => [
                [
                    'status'   => 'ok',
                    'messages' => [
                        0 => [
                            'status' => 'accepted',
                        ],
                    ],
                ],
                true,
            ],

            'incorrect sender signature' => [
                [
                    'status'   => 'ok',
                    'messages' => [
                        0 => [
                            'status' => 'incorrect sender signature',
                        ],
                    ],
                ],
                false,
            ],

            'invalid login'              => [
                [
                    'status'      => 'error',
                    'description' => 'invalid auth data',
                ],
                false,
            ],
        ];
    }

    /**
     * @dataProvider sendSmsData
     */
    public function testSendSms($result, $expected)
    {
        $login    = null;
        $password = null;
        $target   = null;
        $sender   = null;
        $message  = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\iqsms_JsonGate')
            ->getMock();
        $gate->method('send_message')
            ->willReturn($result);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->sendSms($login, $password, $message, $target, $sender));
    }


    public function requestBalanceData()
    {
        return [
            'test1' => [
                [
                    'status'  => 'ok',
                    'balance' => [
                        0 => [
                            'balance' => '87.91',
                        ],
                    ],
                ],
                87.91,
            ],
        ];
    }

    /**
     * @dataProvider requestBalanceData
     */
    public function testRequestBalance($response, $expected)
    {
        $login    = null;
        $password = null;
        $gate     = $this->getMockBuilder('\console\modules\sms\models\iqsms_JsonGate')->getMock();
        $gate->method('credits')->willReturn($response);
        $this->provider->gate = $gate;
        $this->assertEquals($expected, $this->provider->requestBalance($login, $password));
    }

}
