-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: db2.taxi.lcl    Database: taxi
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.25-MariaDB-1~wheezy

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_account`
--

DROP TABLE IF EXISTS `tbl_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `acc_kind_id` int(11) NOT NULL,
  `acc_type_id` int(11) NOT NULL,
  `owner_id` int(11) unsigned DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `tenant_id` int(11) unsigned DEFAULT NULL,
  `balance` decimal(20,5) NOT NULL DEFAULT '0.00000',
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `iu_tbl_account` (`owner_id`,`acc_kind_id`,`acc_type_id`,`tenant_id`,`currency_id`),
  KEY `FK_account_idx` (`tenant_id`,`owner_id`),
  KEY `FK_account_tenant_id_idx` (`tenant_id`),
  KEY `FK_account_acc_kind_id` (`acc_kind_id`),
  KEY `FK_account_acc_type_id` (`acc_type_id`),
  KEY `FK_account_currency_id` (`currency_id`),
  CONSTRAINT `FK_account_acc_kind_id` FOREIGN KEY (`acc_kind_id`) REFERENCES `tbl_account_kind` (`kind_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_account_acc_type_id` FOREIGN KEY (`acc_type_id`) REFERENCES `tbl_account_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_account_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_account_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4344 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_account_kind`
--

DROP TABLE IF EXISTS `tbl_account_kind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_account_kind` (
  `kind_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`kind_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_account_type`
--

DROP TABLE IF EXISTS `tbl_account_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_account_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_additional_option`
--

DROP TABLE IF EXISTS `tbl_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_additional_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `additional_option_id` tinyint(3) unsigned NOT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `tariff_type` enum('CURRENT','HOLIDAYS','EXCEPTIONS') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_additional_option_tbl_car_option1_idx` (`additional_option_id`),
  KEY `fk_tbl_additional_option_tbl_taxi_tariff1_idx` (`tariff_id`),
  CONSTRAINT `fk_tbl_additional_option_tbl_car_option1` FOREIGN KEY (`additional_option_id`) REFERENCES `tbl_car_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_additional_option_tbl_taxi_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9029 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_auth_assignment`
--

DROP TABLE IF EXISTS `tbl_admin_auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `tbl_admin_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `tbl_admin_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_auth_item`
--

DROP TABLE IF EXISTS `tbl_admin_auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `tbl_admin_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `tbl_admin_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_auth_item_child`
--

DROP TABLE IF EXISTS `tbl_admin_auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `tbl_admin_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `tbl_admin_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_admin_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `tbl_admin_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_auth_rule`
--

DROP TABLE IF EXISTS `tbl_admin_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_business_plan`
--

DROP TABLE IF EXISTS `tbl_admin_business_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_business_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_registered` int(1) DEFAULT '0',
  `utm_source1` text,
  `utm_medium1` text,
  `utm_campaign1` text,
  `utm_content1` text,
  `utm_term1` text,
  `client_id_go1` text,
  `client_id_ya1` text,
  `ip1` varchar(50) DEFAULT NULL,
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_content` text,
  `utm_term` text,
  `client_id_go` text,
  `client_id_ya` text,
  `ip` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_docpack`
--

DROP TABLE IF EXISTS `tbl_admin_docpack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_docpack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `is_site` tinyint(1) DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `utm_source1` text,
  `utm_medium1` text,
  `utm_campaign1` text,
  `utm_content1` text,
  `utm_term1` text,
  `client_id_go1` text,
  `client_id_ya1` text,
  `ip1` varchar(50) DEFAULT NULL,
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_content` text,
  `utm_term` text,
  `client_id_go` text,
  `client_id_ya` text,
  `ip` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_one_time_job`
--

DROP TABLE IF EXISTS `tbl_admin_one_time_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_one_time_job` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(48) NOT NULL,
  `price` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_sms_server`
--

DROP TABLE IF EXISTS `tbl_admin_sms_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_sms_server` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `server_id` tinyint(3) unsigned NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `sign` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_admin_sms_server_tbl_sms_server1_idx` (`server_id`),
  KEY `server_id_index` (`server_id`),
  KEY `server_id` (`server_id`),
  CONSTRAINT `fk_tbl_admin_sms_server_tbl_sms_server1` FOREIGN KEY (`server_id`) REFERENCES `tbl_sms_server` (`server_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_tariff_additional_option`
--

DROP TABLE IF EXISTS `tbl_admin_tariff_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_tariff_additional_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(48) NOT NULL,
  `price` int(6) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_user`
--

DROP TABLE IF EXISTS `tbl_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(45) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `auth_key` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_asterisk_server`
--

DROP TABLE IF EXISTS `tbl_asterisk_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_asterisk_server` (
  `server_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `default` int(1) NOT NULL DEFAULT '0',
  `host` varchar(100) NOT NULL,
  `port` int(6) NOT NULL,
  `sort` int(6) NOT NULL DEFAULT '100',
  PRIMARY KEY (`server_id`),
  KEY `fk_asterisk_server__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_asterisk_server__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_asterisk_server_default`
--

DROP TABLE IF EXISTS `tbl_asterisk_server_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_asterisk_server_default` (
  `server_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `host` varchar(100) NOT NULL,
  `port` int(6) NOT NULL,
  `sort` int(6) NOT NULL DEFAULT '100',
  PRIMARY KEY (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_auth_assignment`
--

DROP TABLE IF EXISTS `tbl_auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tbl_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_auth_item`
--

DROP TABLE IF EXISTS `tbl_auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `type` (`type`),
  CONSTRAINT `tbl_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `tbl_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_auth_item_child`
--

DROP TABLE IF EXISTS `tbl_auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `tbl_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_auth_rule`
--

DROP TABLE IF EXISTS `tbl_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_auto_geo_service_type`
--

DROP TABLE IF EXISTS `tbl_auto_geo_service_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auto_geo_service_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_label` text,
  `active` tinyint(1) DEFAULT '0',
  `has_key_1` int(1) DEFAULT '0',
  `has_key_2` int(1) DEFAULT '0',
  `key_1_label` varchar(50) DEFAULT NULL,
  `key_2_label` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_autocall_file`
--

DROP TABLE IF EXISTS `tbl_autocall_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_autocall_file` (
  `file_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned DEFAULT NULL,
  `key` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `group` enum('cars','phrases','digits','colors') NOT NULL,
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `key` (`key`),
  UNIQUE KEY `key_2` (`key`),
  KEY `fk_tbl_autocall_file_tbl_tenant1_idx` (`tenant_id`),
  CONSTRAINT `fk_tbl_autocall_file_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_bonus_fail_log`
--

DROP TABLE IF EXISTS `tbl_bonus_fail_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bonus_fail_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `device` varchar(255) NOT NULL,
  `device_token` varchar(255) NOT NULL,
  `order_time` int(11) NOT NULL,
  `bonus_id` int(11) NOT NULL,
  `bonus` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bonus_fail_log__client_id` (`client_id`),
  KEY `fk_bonus_fail_log__order_id` (`order_id`),
  KEY `fk_bonus_fail_log__bonus_id` (`bonus_id`),
  CONSTRAINT `fk_bonus_fail_log__bonus_id` FOREIGN KEY (`bonus_id`) REFERENCES `tbl_client_bonus` (`bonus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bonus_fail_log__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bonus_fail_log__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_bonus_system`
--

DROP TABLE IF EXISTS `tbl_bonus_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bonus_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_call`
--

DROP TABLE IF EXISTS `tbl_call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_call` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniqueid` varchar(60) NOT NULL,
  `tenant_id` int(10) unsigned NOT NULL,
  `order_id` int(10) DEFAULT NULL,
  `worker_id` int(10) DEFAULT NULL,
  `user_opertor_id` int(10) unsigned DEFAULT NULL,
  `type` enum('notify','outcome','income') NOT NULL,
  `source` varchar(20) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `phone_line_id` int(10) unsigned DEFAULT NULL,
  `channel` varchar(50) NOT NULL,
  `destinationchannel` varchar(50) NOT NULL,
  `destinationcontext` varchar(50) DEFAULT NULL,
  `lastapplication` varchar(20) DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `answertime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `duration` int(10) NOT NULL,
  `billableseconds` int(10) NOT NULL,
  `disposition` varchar(50) NOT NULL,
  `amaflags` varchar(50) NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
  `userfield` varchar(200) DEFAULT NULL,
  `create_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tenant` (`tenant_id`),
  KEY `fk_line` (`phone_line_id`),
  KEY `fk_driver` (`worker_id`),
  KEY `fk_userd_disp_id` (`user_opertor_id`),
  CONSTRAINT `fk_call_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_line` FOREIGN KEY (`phone_line_id`) REFERENCES `tbl_phone_line` (`line_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_userd_disp_id` FOREIGN KEY (`user_opertor_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11270 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_call_change_data`
--

DROP TABLE IF EXISTS `tbl_call_change_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_call_change_data` (
  `change_id` int(11) NOT NULL AUTO_INCREMENT,
  `call_id` varchar(60) NOT NULL,
  `clid` varchar(15) DEFAULT NULL,
  `did` varchar(15) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `params` text,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car`
--

DROP TABLE IF EXISTS `tbl_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car` (
  `car_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned DEFAULT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `gos_number` varchar(10) NOT NULL,
  `color` int(11) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `owner` enum('COMPANY','WORKER') DEFAULT NULL,
  `raiting` smallint(6) NOT NULL DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT '1',
  `license` varchar(45) DEFAULT NULL,
  `license_scan` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `group_id` int(10) DEFAULT NULL,
  `callsign` varchar(10) DEFAULT NULL,
  `tenant_company_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`car_id`),
  KEY `class_idx` (`class_id`),
  KEY `fk_tbl_cars_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_car_tbl_city1_idx` (`city_id`),
  KEY `fk_tbl_car_tbl_car_model1_idx` (`name`),
  KEY `FK_car_group_id` (`group_id`),
  KEY `fr_car_car_color_1` (`color`),
  KEY `fk_car__tenant_company` (`tenant_company_id`),
  CONSTRAINT `FK_car_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `class` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_car__tenant_company` FOREIGN KEY (`tenant_company_id`) REFERENCES `tbl_tenant_company` (`tenant_company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_cars_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fr_car_car_color_1` FOREIGN KEY (`color`) REFERENCES `tbl_car_color` (`color_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=519 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_brand`
--

DROP TABLE IF EXISTS `tbl_car_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_brand` (
  `brand_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_class`
--

DROP TABLE IF EXISTS `tbl_car_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_class` (
  `class_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(50) NOT NULL,
  `sort` int(10) NOT NULL DEFAULT '100',
  `type_id` int(11) NOT NULL COMMENT 'PK of tbl_transport_type',
  PRIMARY KEY (`class_id`),
  KEY `fr_car_class_type_id` (`type_id`),
  CONSTRAINT `fr_car_class_type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_transport_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_color`
--

DROP TABLE IF EXISTS `tbl_car_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_color` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_has_option`
--

DROP TABLE IF EXISTS `tbl_car_has_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_has_option` (
  `car_id` int(10) unsigned NOT NULL,
  `option_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`car_id`,`option_id`),
  KEY `fk_tbl_car_has_tbl_car_option_tbl_car_option1_idx` (`option_id`),
  KEY `fk_tbl_car_has_tbl_car_option_tbl_car1_idx` (`car_id`),
  CONSTRAINT `fk_tbl_car_has_tbl_car_option_tbl_car1` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_car_has_tbl_car_option_tbl_car_option1` FOREIGN KEY (`option_id`) REFERENCES `tbl_car_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_has_worker_group_class`
--

DROP TABLE IF EXISTS `tbl_car_has_worker_group_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_has_worker_group_class` (
  `car_id` int(10) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`car_id`,`class_id`),
  KEY `FK_car_driver_group_has_class_class_id` (`class_id`),
  CONSTRAINT `fk_car_has_worker_group_class_car_id` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_car_has_worker_group_class_class_id` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_has_worker_group_tariff`
--

DROP TABLE IF EXISTS `tbl_car_has_worker_group_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_has_worker_group_tariff` (
  `car_id` int(10) unsigned NOT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`car_id`,`tariff_id`),
  KEY `FK_car_driver_group_has_tariff_tariff_id` (`tariff_id`),
  CONSTRAINT `fk_car_has_worker_group_tariff_car_id` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_car_has_worker_group_tariff_tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_worker_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_mileage`
--

DROP TABLE IF EXISTS `tbl_car_mileage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_mileage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(10) unsigned NOT NULL,
  `shift_id` int(10) unsigned NOT NULL,
  `begin_value` double NOT NULL,
  `end_value` double DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shift_id` (`shift_id`),
  CONSTRAINT `fk_car_mileage__shift_id` FOREIGN KEY (`shift_id`) REFERENCES `tbl_worker_shift` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_model`
--

DROP TABLE IF EXISTS `tbl_car_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_model` (
  `model_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` tinyint(3) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`model_id`),
  UNIQUE KEY `brand_id` (`brand_id`,`name`),
  KEY `fk_tbl_car_model_tbl_car_brand1_idx` (`brand_id`),
  KEY `fk_cat_model_type_id` (`type_id`),
  CONSTRAINT `fk_cat_model_type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_transport_type` (`type_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_car_model_tbl_car_brand1` FOREIGN KEY (`brand_id`) REFERENCES `tbl_car_brand` (`brand_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3660 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_car_option`
--

DROP TABLE IF EXISTS `tbl_car_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_option` (
  `option_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `type_id` int(11) NOT NULL COMMENT 'PK of tbl_transport_type',
  `sort` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`option_id`),
  KEY `fr_car_option_type_id` (`type_id`),
  CONSTRAINT `fr_car_option_type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_transport_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_card_payment`
--

DROP TABLE IF EXISTS `tbl_card_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_card_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `pan` varchar(25) NOT NULL,
  `payment_sum` decimal(12,2) DEFAULT NULL,
  `payment_order_id` varchar(36) DEFAULT NULL,
  `payment_status` enum('PAID','REFUNDED') DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `to_pan` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ui_card_payment__order_id` (`order_id`),
  CONSTRAINT `fk_card_payment__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=444 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_card_payment_log`
--

DROP TABLE IF EXISTS `tbl_card_payment_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_card_payment_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `type` enum('PAY','REFUND','ADD CARD','CHECK CARD','REMOVE CARD') NOT NULL,
  `params` text,
  `response` text,
  `result` int(1) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `worker_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_card_payment_log__tenant_id` (`tenant_id`),
  KEY `fk_card_payment_log__client_id` (`client_id`),
  KEY `ui_card_payment_log__order_id` (`order_id`),
  KEY `fk_tbl_card_payment_log__worker_id` (`worker_id`),
  CONSTRAINT `fk_card_payment_log__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_card_payment_log__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_card_payment_log__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_card_payment_log__worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3171 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_check`
--

DROP TABLE IF EXISTS `tbl_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_city`
--

DROP TABLE IF EXISTS `tbl_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_city` (
  `city_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `republic_id` int(11) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `shortname` varchar(100) DEFAULT NULL,
  `lat` varchar(100) DEFAULT NULL,
  `lon` varchar(100) DEFAULT NULL,
  `fulladdress` varchar(200) DEFAULT NULL,
  `fulladdress_reverse` varchar(200) DEFAULT NULL,
  `sort` varchar(45) DEFAULT NULL,
  `city_polygon` text,
  `name_az` varchar(100) DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `name_de` varchar(100) DEFAULT NULL,
  `name_sr` varchar(100) DEFAULT NULL,
  `fulladdress_az` varchar(100) DEFAULT NULL,
  `fulladdress_en` varchar(100) DEFAULT NULL,
  `fulladdress_de` varchar(100) DEFAULT NULL,
  `fulladdress_sr` varchar(100) DEFAULT NULL,
  `search` tinyint(1) DEFAULT NULL,
  `name_ro` varchar(255) DEFAULT NULL,
  `fulladdress_ro` varchar(255) DEFAULT NULL,
  `name_uz` varchar(255) DEFAULT NULL,
  `fulladdress_uz` varchar(255) DEFAULT NULL,
  `name_fi` varchar(100) DEFAULT NULL,
  `fulladdress_fi` varchar(255) DEFAULT NULL,
  `name_fa` varchar(100) DEFAULT NULL,
  `fulladdress_fa` varchar(255) DEFAULT NULL,
  `name_bg` varchar(100) DEFAULT NULL,
  `fulladdress_bg` varchar(255) DEFAULT NULL,
  `name_ar` varchar(100) DEFAULT NULL,
  `fulladdress_ar` varchar(255) DEFAULT NULL,
  `name_tg` varchar(100) DEFAULT NULL,
  `fulladdress_tg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`city_id`),
  UNIQUE KEY `city_id_UNIQUE` (`city_id`),
  KEY `SEC` (`republic_id`,`name`),
  KEY `search` (`search`,`name`),
  KEY `idx_city__name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=211466 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client`
--

DROP TABLE IF EXISTS `tbl_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client` (
  `client_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `second_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `black_list` tinyint(1) NOT NULL DEFAULT '0',
  `priority` smallint(5) unsigned DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT '0',
  `success_order` int(10) unsigned DEFAULT '0',
  `fail_worker_order` int(10) unsigned DEFAULT '0',
  `fail_client_order` int(10) unsigned DEFAULT '0',
  `fail_dispatcher_order` int(10) DEFAULT '0',
  `birth` date DEFAULT NULL,
  `password` int(11) DEFAULT NULL,
  `device` enum('WINFON','ANDROID','IOS') DEFAULT NULL,
  `device_token` text,
  `app_id` int(10) unsigned DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `auth_key` varchar(255) NOT NULL,
  `active_time` int(11) NOT NULL,
  `send_to_email` int(1) DEFAULT '0',
  PRIMARY KEY (`client_id`),
  KEY `fk_tbl_client_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_client_tbl_city2_idx` (`city_id`),
  CONSTRAINT `fk_tbl_client_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_address_history`
--

DROP TABLE IF EXISTS `tbl_client_address_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_address_history` (
  `history_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `house` varchar(255) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lon` varchar(100) NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `fk__tbl_client_address_history__client_id` (`client_id`),
  KEY `fk__tbl_client_address_history__city_id` (`city_id`),
  CONSTRAINT `fk__tbl_client_address_history__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk__tbl_client_address_history__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7182 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_bonus`
--

DROP TABLE IF EXISTS `tbl_client_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_bonus` (
  `bonus_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned DEFAULT NULL,
  `tenant_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `blocked` int(11) DEFAULT '0',
  `position_id` int(11) DEFAULT NULL,
  `bonus_system_id` int(11) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`bonus_id`),
  UNIQUE KEY `ui_client_bonus` (`tenant_id`,`city_id`,`name`),
  KEY `fk_client_bonus__city_id` (`city_id`),
  KEY `fk_client_bonus__class_id` (`class_id`),
  KEY `fk_client_bonus__position_id` (`position_id`),
  KEY `fk_client_bonus__bonus_system_id` (`bonus_system_id`),
  CONSTRAINT `fk_client_bonus__bonus_system_id` FOREIGN KEY (`bonus_system_id`) REFERENCES `tbl_bonus_system` (`id`),
  CONSTRAINT `fk_client_bonus__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_client_bonus__class_id` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_client_bonus__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_client_bonus__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_bonus_gootax`
--

DROP TABLE IF EXISTS `tbl_client_bonus_gootax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_bonus_gootax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bonus_id` int(11) NOT NULL,
  `actual_date` text,
  `bonus_type` enum('BONUS','PERCENT') NOT NULL DEFAULT 'PERCENT',
  `bonus` decimal(10,2) NOT NULL,
  `min_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` enum('FULL','PARTIAL') NOT NULL DEFAULT 'FULL',
  `max_payment_type` enum('BONUS','PERCENT') NOT NULL DEFAULT 'PERCENT',
  `max_payment` decimal(10,2) DEFAULT '0.00',
  `bonus_app_type` enum('BONUS','PERCENT') NOT NULL DEFAULT 'PERCENT',
  `bonus_app` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bonus_id` (`bonus_id`),
  CONSTRAINT `fk_client_bonus_gootax__bonus_id` FOREIGN KEY (`bonus_id`) REFERENCES `tbl_client_bonus` (`bonus_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_bonus_has_tariff`
--

DROP TABLE IF EXISTS `tbl_client_bonus_has_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_bonus_has_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bonus_id` int(11) NOT NULL,
  `tariff_id` int(11) unsigned NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_client_bonus_has_tariff__bonus_id` (`bonus_id`),
  KEY `fk_client_bonus_has_tariff__tariff_id` (`tariff_id`),
  CONSTRAINT `fk_client_bonus_has_tariff__bonus_id` FOREIGN KEY (`bonus_id`) REFERENCES `tbl_client_bonus` (`bonus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_client_bonus_has_tariff__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1046 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_company`
--

DROP TABLE IF EXISTS `tbl_client_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_company` (
  `company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `legal_address` varchar(255) NOT NULL,
  `post_address` varchar(255) DEFAULT NULL,
  `work_phone` varchar(15) DEFAULT NULL,
  `inn` varchar(15) DEFAULT NULL,
  `bookkeeper` varchar(45) DEFAULT NULL,
  `kpp` varchar(10) DEFAULT NULL,
  `ogrn` varchar(20) DEFAULT NULL,
  `site` varchar(45) DEFAULT NULL,
  `director` varchar(45) DEFAULT NULL,
  `director_post` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `contact_last_name` varchar(45) DEFAULT NULL,
  `contact_name` varchar(45) DEFAULT NULL,
  `contact_second_name` varchar(45) DEFAULT NULL,
  `contact_phone` varchar(45) DEFAULT NULL,
  `contact_email` varchar(45) DEFAULT NULL,
  `block` tinyint(1) DEFAULT '0',
  `logo` varchar(255) DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contract_number` int(11) DEFAULT NULL,
  `contract_start_date` date DEFAULT NULL,
  `contract_end_date` date DEFAULT NULL,
  `credits` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`company_id`),
  KEY `fk_tbl_client_company_tbl_tenant1_idx` (`tenant_id`),
  KEY `FK_client_company_city_id` (`city_id`),
  CONSTRAINT `FK_client_company_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_tbl_client_company_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_company_has_tariff`
--

DROP TABLE IF EXISTS `tbl_client_company_has_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_company_has_tariff` (
  `company_id` int(10) unsigned NOT NULL,
  `tariff_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`company_id`,`tariff_id`),
  KEY `fk_tbl_client_company_has_tbl_car_class_tbl_car_class1_idx` (`tariff_id`),
  KEY `fk_tbl_client_company_has_tbl_car_class_tbl_client_company1_idx` (`company_id`),
  CONSTRAINT `fk_tbl_client_company_has_tbl_car_class_tbl_car_class1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_client_company_has_tbl_car_class_tbl_client_company1` FOREIGN KEY (`company_id`) REFERENCES `tbl_client_company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_has_company`
--

DROP TABLE IF EXISTS `tbl_client_has_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_has_company` (
  `client_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `booking` tinyint(1) DEFAULT '0',
  `driving` tinyint(1) DEFAULT '0',
  `role` enum('juridical','physical') NOT NULL DEFAULT 'physical',
  PRIMARY KEY (`client_id`,`company_id`),
  KEY `fk_tbl_client_has_tbl_client_company_tbl_client_company1_idx` (`company_id`),
  KEY `fk_tbl_client_has_tbl_client_company_tbl_client1_idx` (`client_id`),
  CONSTRAINT `fk_tbl_client_has_tbl_client_company_tbl_client1` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_client_has_tbl_client_company_tbl_client_company1` FOREIGN KEY (`company_id`) REFERENCES `tbl_client_company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_order_from_app`
--

DROP TABLE IF EXISTS `tbl_client_order_from_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_order_from_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `device_token` varchar(255) DEFAULT NULL,
  `order_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_client_order_from_app` (`client_id`),
  KEY `fk_client_order_from_app__order_id` (`order_id`),
  KEY `idx_client_order_from_app__device_token` (`device_token`),
  CONSTRAINT `fk_client_order_from_app__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_client_order_from_app__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_phone`
--

DROP TABLE IF EXISTS `tbl_client_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_phone` (
  `phone_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `value` varchar(20) NOT NULL,
  PRIMARY KEY (`phone_id`),
  KEY `fk_tbl_client_phone_tbl_client1_idx` (`client_id`),
  CONSTRAINT `fk_tbl_client_phone_tbl_client1` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2641 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_push_notifications`
--

DROP TABLE IF EXISTS `tbl_client_push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_push_notifications` (
  `push_id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `type` varchar(45) NOT NULL DEFAULT '1',
  `tenant_id` int(5) NOT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`push_id`),
  KEY `FK_client_push_notifications_idx` (`city_id`),
  KEY `fk_client_push_notifications_position_id` (`position_id`),
  CONSTRAINT `FK_client_push_notifications` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_client_push_notifications_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101248 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_review`
--

DROP TABLE IF EXISTS `tbl_client_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_review` (
  `review_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `text` text,
  `rating` float DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_id`),
  KEY `fk_tbl_client_reviews_tbl_client1_idx` (`client_id`),
  KEY `idx_client_review__order_id` (`order_id`),
  CONSTRAINT `fk_tbl_client_reviews_tbl_client1` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_review_raiting`
--

DROP TABLE IF EXISTS `tbl_client_review_raiting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_review_raiting` (
  `raitng_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `one` int(10) unsigned DEFAULT '0',
  `two` int(10) unsigned DEFAULT '0',
  `three` int(10) unsigned DEFAULT '0',
  `four` int(10) unsigned DEFAULT '0',
  `five` int(10) unsigned DEFAULT '0',
  `count` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`raitng_id`),
  KEY `fk_tbl_client_review_raiting_tbl_client1_idx` (`client_id`),
  CONSTRAINT `fk_tbl_client_review_raiting_tbl_client1` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_status_event`
--

DROP TABLE IF EXISTS `tbl_client_status_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_status_event` (
  `event_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_id` tinyint(3) unsigned NOT NULL,
  `tenant_id` int(10) unsigned NOT NULL,
  `group` enum('CALL','APP','WEB','BORDER') NOT NULL,
  `notice` enum('sms','autocall','push','nothing') NOT NULL DEFAULT 'nothing',
  `position_id` int(11) NOT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `fk_tbl_client_status_event_tbl_order_status1_idx` (`status_id`),
  KEY `fk_tbl_client_status_event_tbl_tenant1_idx` (`tenant_id`),
  KEY `tbl_client_status_event__position_id` (`position_id`),
  KEY `tbl_client_status_event__city_id` (`city_id`),
  CONSTRAINT `fk_tbl_client_status_event_tbl_order_status1` FOREIGN KEY (`status_id`) REFERENCES `tbl_order_status` (`status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_client_status_event_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_client_status_event__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `tbl_client_status_event__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=300496 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_client_temp`
--

DROP TABLE IF EXISTS `tbl_client_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_client_temp` (
  `client_temp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `phone` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`client_temp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COMMENT='Временная таблица в которую попадают пользователи при регистрации с мобильных приложений и не подтвердившие  код';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_comment`
--

DROP TABLE IF EXISTS `tbl_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `publication_date` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `fk_comment__post_id` (`post_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `fk_comment__author_id` FOREIGN KEY (`author_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comment__post_id` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_community_auth`
--

DROP TABLE IF EXISTS `tbl_community_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_community_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `source` varchar(255) NOT NULL,
  `source_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_community_auth__user_id` (`user_id`),
  CONSTRAINT `fk_community_auth__user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_community_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_community_user`
--

DROP TABLE IF EXISTS `tbl_community_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_community_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_confirm_token` varchar(255) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '20',
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_community_user__user_id` (`user_id`),
  CONSTRAINT `fk_community_user__user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_conversion`
--

DROP TABLE IF EXISTS `tbl_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_conversion` (
  `conversion_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text,
  `action` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `utm_source1` text,
  `utm_medium1` text,
  `utm_campaign1` text,
  `utm_content1` text,
  `utm_term1` text,
  `client_id_go1` text,
  `client_id_ya1` text,
  `ip1` varchar(50) DEFAULT NULL,
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_content` text,
  `utm_term` text,
  `client_id_go` text,
  `client_id_ya` text,
  `ip` text,
  PRIMARY KEY (`conversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_country`
--

DROP TABLE IF EXISTS `tbl_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_country` (
  `country_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `name_az` varchar(255) DEFAULT NULL,
  `name_de` varchar(255) DEFAULT NULL,
  `name_sr` varchar(255) DEFAULT NULL,
  `name_ro` varchar(255) DEFAULT NULL,
  `name_uz` varchar(255) DEFAULT NULL,
  `name_fi` varchar(255) DEFAULT NULL,
  `name_fa` varchar(255) DEFAULT NULL,
  `name_bg` varchar(255) DEFAULT NULL,
  `name_ar` varchar(255) DEFAULT NULL,
  `name_tg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE KEY `country_id_UNIQUE` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_currency`
--

DROP TABLE IF EXISTS `tbl_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_currency` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `symbol` varchar(255) DEFAULT NULL,
  `numeric_code` int(3) DEFAULT NULL,
  `minor_unit` int(2) DEFAULT NULL,
  PRIMARY KEY (`currency_id`),
  KEY `FK_currency_type_currency` (`type_id`),
  CONSTRAINT `FK_currency_type_currency` FOREIGN KEY (`type_id`) REFERENCES `tbl_currency_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_currency_type`
--

DROP TABLE IF EXISTS `tbl_currency_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_currency_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_client_push_notifications`
--

DROP TABLE IF EXISTS `tbl_default_client_push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_client_push_notifications` (
  `push_id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `type` varchar(45) NOT NULL DEFAULT '1',
  `description` text,
  `position_id` int(11) NOT NULL,
  `params` text,
  PRIMARY KEY (`push_id`),
  UNIQUE KEY `ui_default_client_push_notifications` (`type`,`position_id`),
  KEY `fk_default_client_push_notifications_position_id` (`position_id`),
  CONSTRAINT `fk_default_client_push_notifications_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_client_push_notifications_courier`
--

DROP TABLE IF EXISTS `tbl_default_client_push_notifications_courier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_client_push_notifications_courier` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `description` text NOT NULL,
  `params` text,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `idx_default_client_push_notifications_courier` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_client_status_event`
--

DROP TABLE IF EXISTS `tbl_default_client_status_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_client_status_event` (
  `event_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_id` tinyint(3) unsigned NOT NULL,
  `group` enum('CALL','APP','WEB','BORDER') NOT NULL,
  `notice` enum('sms','autocall','push','nothing') NOT NULL,
  `position_id` int(10) NOT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `ui_default_client_status_event` (`status_id`,`group`,`position_id`),
  KEY `fk_tbl_default_client_status_event_tbl_order_status1_idx` (`status_id`),
  KEY `tbl_default_client_status_event__position_id` (`position_id`),
  CONSTRAINT `fk_tbl_default_client_status_event_tbl_order_status1` FOREIGN KEY (`status_id`) REFERENCES `tbl_order_status` (`status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_default_client_status_event__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1141 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_email_settings`
--

DROP TABLE IF EXISTS `tbl_default_email_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_email_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `activity` tinyint(1) DEFAULT '0',
  `mail_server` int(11) DEFAULT NULL,
  `sender_name` varchar(50) DEFAULT NULL,
  `sender_email` varchar(50) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `template` text,
  `params` text,
  `description` text,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_referral`
--

DROP TABLE IF EXISTS `tbl_default_referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_referral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text_in_client_api` text,
  `title` text,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_settings`
--

DROP TABLE IF EXISTS `tbl_default_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_settings` (
  `name` varchar(100) NOT NULL,
  `value` text,
  `type` enum('general','orders','drivers','cars','system') DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_sms_template`
--

DROP TABLE IF EXISTS `tbl_default_sms_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_sms_template` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `description` text,
  `position_id` int(11) NOT NULL,
  `params` text,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `ui_default_sms_template` (`type`,`position_id`),
  KEY `fk_default_sms_template_position_id` (`position_id`),
  CONSTRAINT `fk_default_sms_template_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=382 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_sms_template_courier`
--

DROP TABLE IF EXISTS `tbl_default_sms_template_courier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_sms_template_courier` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `description` text NOT NULL,
  `params` text,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `idx_default_sms_template_courier` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_default_worker_push_notifications`
--

DROP TABLE IF EXISTS `tbl_default_worker_push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_default_worker_push_notifications` (
  `push_id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` text,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`push_id`),
  KEY `FK_position_id_default_worker_push_notifications` (`position_id`),
  CONSTRAINT `FK_position_id_default_worker_push_notifications` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_demo_tariff`
--

DROP TABLE IF EXISTS `tbl_demo_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_demo_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tariff_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tariff_id` (`tariff_id`),
  CONSTRAINT `fk_tbl_demo_tariff__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_deposit_from_bank_card`
--

DROP TABLE IF EXISTS `tbl_deposit_from_bank_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_deposit_from_bank_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` varchar(255) NOT NULL,
  `pan` varchar(255) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `payment_order_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`),
  KEY `fk_deposit_from_bank_card__transaction_id` (`transaction_id`),
  CONSTRAINT `fk_deposit_from_bank_card__transaction_id` FOREIGN KEY (`transaction_id`) REFERENCES `tbl_transaction` (`transaction_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_discount_for_period`
--

DROP TABLE IF EXISTS `tbl_discount_for_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_discount_for_period` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period` int(3) NOT NULL,
  `percent` int(5) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `period` (`period`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_discount_for_period_history`
--

DROP TABLE IF EXISTS `tbl_discount_for_period_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_discount_for_period_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period` int(3) NOT NULL,
  `percent` int(5) NOT NULL,
  `activated_at` int(11) NOT NULL,
  `deactivated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_document`
--

DROP TABLE IF EXISTS `tbl_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `code` int(10) unsigned NOT NULL,
  PRIMARY KEY (`document_id`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_elecsnet_error_code`
--

DROP TABLE IF EXISTS `tbl_elecsnet_error_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_elecsnet_error_code` (
  `error_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(4) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`error_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_elecsnet_log`
--

DROP TABLE IF EXISTS `tbl_elecsnet_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_elecsnet_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('1','2') NOT NULL,
  `reqid` varchar(255) NOT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `auth_code` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `result` varchar(255) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_email_settings`
--

DROP TABLE IF EXISTS `tbl_email_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_email_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) DEFAULT NULL,
  `individualSettings` tinyint(1) DEFAULT '0',
  `mail_server` int(11) DEFAULT NULL,
  `sender_name` varchar(50) DEFAULT NULL,
  `sender_email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `template` text,
  `params` text,
  `description` text,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_exchange`
--

DROP TABLE IF EXISTS `tbl_exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_exchange` (
  `exchange_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `operation` varchar(45) NOT NULL,
  PRIMARY KEY (`exchange_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_fix_has_option`
--

DROP TABLE IF EXISTS `tbl_fix_has_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fix_has_option` (
  `option_id` int(10) unsigned NOT NULL,
  `fix_id` int(10) unsigned NOT NULL,
  `price_to` decimal(10,0) NOT NULL,
  `price_back` decimal(10,0) NOT NULL,
  PRIMARY KEY (`option_id`,`fix_id`),
  KEY `fk_tbl_fix_option_tariff_has_tbl_fix_tariff_tbl_fix_tariff1_idx` (`fix_id`),
  CONSTRAINT `fk_tbl_fix_option_has_tariff_tbl_option_tariff1` FOREIGN KEY (`option_id`) REFERENCES `tbl_option_tariff` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_fix_option_tariff_has_tbl_fix_tariff_tbl_fix_tariff1` FOREIGN KEY (`fix_id`) REFERENCES `tbl_fix_tariff` (`fix_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_fix_tariff`
--

DROP TABLE IF EXISTS `tbl_fix_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fix_tariff` (
  `fix_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fix_id`),
  KEY `fk_tbl_fix_tariff_tbl_parking1_idx` (`from`),
  KEY `fk_tbl_fix_tariff_tbl_parking2_idx` (`to`),
  CONSTRAINT `fk_tbl_fix_tariff_tbl_parking1` FOREIGN KEY (`from`) REFERENCES `tbl_parking` (`parking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_fix_tariff_tbl_parking2` FOREIGN KEY (`to`) REFERENCES `tbl_parking` (`parking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3487 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_geodata_az`
--

DROP TABLE IF EXISTS `tbl_geodata_az`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_geodata_az` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_az` text,
  `city_en` text,
  `city_ru` text,
  `street_az` text,
  `street_en` text,
  `street_ru` text,
  `label_az` text,
  `label_en` text,
  `label_ru` text,
  `type` text,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `weight` int(10) DEFAULT NULL,
  `house` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1139055 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_holiday`
--

DROP TABLE IF EXISTS `tbl_holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_holiday` (
  `holiday_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `date` varchar(15) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_how_symbols_in_password`
--

DROP TABLE IF EXISTS `tbl_how_symbols_in_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_how_symbols_in_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_kamailio_asterisk_setting`
--

DROP TABLE IF EXISTS `tbl_kamailio_asterisk_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_kamailio_asterisk_setting` (
  `id` varchar(50) NOT NULL,
  `type` enum('kamailio','asterisk') DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `dbhost` varchar(255) DEFAULT NULL,
  `dbuser` varchar(255) DEFAULT NULL,
  `dbpassword` varchar(255) DEFAULT NULL,
  `database` varchar(255) DEFAULT NULL,
  `tenants` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_message`
--

DROP TABLE IF EXISTS `tbl_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_message` (
  `id` int(11) NOT NULL,
  `language` varchar(16) NOT NULL,
  `translation` text NOT NULL,
  PRIMARY KEY (`id`,`language`),
  CONSTRAINT `fk_message_source_message` FOREIGN KEY (`id`) REFERENCES `tbl_source_message` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_meta_tags`
--

DROP TABLE IF EXISTS `tbl_meta_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_meta_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_migration`
--

DROP TABLE IF EXISTS `tbl_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_million_error_code`
--

DROP TABLE IF EXISTS `tbl_million_error_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_million_error_code` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(4) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_million_log`
--

DROP TABLE IF EXISTS `tbl_million_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_million_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `apikey` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `callsign` int(8) DEFAULT NULL,
  `sum` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mobile_app`
--

DROP TABLE IF EXISTS `tbl_mobile_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mobile_app` (
  `app_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(6) NOT NULL DEFAULT '100',
  `active` int(1) NOT NULL DEFAULT '0',
  `api_key` varchar(250) DEFAULT NULL,
  `push_key_android` text,
  `push_key_ios` text,
  `link_android` varchar(250) DEFAULT NULL,
  `link_ios` varchar(250) DEFAULT NULL,
  `page_info` text,
  `confidential` longtext,
  `city_autocompletion` int(1) NOT NULL DEFAULT '1',
  `demo` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`app_id`),
  KEY `fk_mobile_app__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_mobile_app__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mobile_app_demo`
--

DROP TABLE IF EXISTS `tbl_mobile_app_demo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mobile_app_demo` (
  `demo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `sort` int(6) NOT NULL DEFAULT '1',
  `active` int(1) NOT NULL DEFAULT '1',
  `api_key` varchar(250) DEFAULT NULL,
  `push_key_android` text,
  `push_key_ios` text,
  `link_android` varchar(250) DEFAULT NULL,
  `link_ios` varchar(250) DEFAULT NULL,
  `page_info` text,
  `confidential` text,
  `city_autocompletion` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`demo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mobile_app_has_city`
--

DROP TABLE IF EXISTS `tbl_mobile_app_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mobile_app_has_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mobile_app_has_city__app_id` (`app_id`),
  KEY `fk_mobile_app_has_city__city_id` (`city_id`),
  CONSTRAINT `fk_mobile_app_has_city__app_id` FOREIGN KEY (`app_id`) REFERENCES `tbl_mobile_app` (`app_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mobile_app_has_city__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_module`
--

DROP TABLE IF EXISTS `tbl_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_notification`
--

DROP TABLE IF EXISTS `tbl_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notification` (
  `notification_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `addressee` enum('WORKER','CLIENT') NOT NULL,
  `addressee_id` varchar(15) DEFAULT NULL COMMENT 'Если пустое, то отправляет всем',
  `title` varchar(100) NOT NULL,
  `text` varchar(200) NOT NULL,
  `device` varchar(20) NOT NULL DEFAULT '',
  `on_shift` int(1) NOT NULL DEFAULT '0' COMMENT '0-все. 1-на смене. 2-не на смене',
  `blocked` int(11) DEFAULT '0',
  PRIMARY KEY (`notification_id`),
  KEY `fk_notification__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_notification__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_notification_has_city`
--

DROP TABLE IF EXISTS `tbl_notification_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notification_has_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_has_city__notification_id` (`notification_id`),
  KEY `fk_notification_has_city__city_id` (`city_id`),
  CONSTRAINT `fk_notification_has_city__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notification_has_city__notification_id` FOREIGN KEY (`notification_id`) REFERENCES `tbl_notification` (`notification_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_notification_has_class`
--

DROP TABLE IF EXISTS `tbl_notification_has_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notification_has_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_has_class__notification_id` (`notification_id`),
  KEY `fk_notification_has_class__class_id` (`class_id`),
  CONSTRAINT `fk_notification_has_class__class_id` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notification_has_class__notification_id` FOREIGN KEY (`notification_id`) REFERENCES `tbl_notification` (`notification_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_notification_has_position`
--

DROP TABLE IF EXISTS `tbl_notification_has_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notification_has_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) unsigned NOT NULL,
  `position_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_has_position__notification_id` (`notification_id`),
  KEY `fk_notification_has_position__position_id` (`position_id`),
  CONSTRAINT `fk_notification_has_position__notification_id` FOREIGN KEY (`notification_id`) REFERENCES `tbl_notification` (`notification_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notification_has_position__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_offer_info`
--

DROP TABLE IF EXISTS `tbl_offer_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_offer_info` (
  `offer_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `status` enum('voting','in work','introduced','deferred') NOT NULL DEFAULT 'voting',
  `plus` int(11) NOT NULL DEFAULT '0',
  `minus` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`offer_info_id`),
  KEY `idx_offer_info__status` (`status`),
  KEY `fk_offer_info__post_id` (`post_id`),
  CONSTRAINT `fk_offer_info__post_id` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_one_time_service`
--

DROP TABLE IF EXISTS `tbl_one_time_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_one_time_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `code` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `currency_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_one_time_service__currency_id` (`currency_id`),
  CONSTRAINT `fk_one_time_service__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_operation`
--

DROP TABLE IF EXISTS `tbl_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_operation` (
  `operation_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `owner_name` varchar(255) DEFAULT NULL,
  `sum` decimal(20,5) NOT NULL DEFAULT '0.00000',
  `saldo` decimal(20,5) NOT NULL DEFAULT '0.00000',
  PRIMARY KEY (`operation_id`),
  KEY `FK_operation_type_id_account_id_idx` (`type_id`,`account_id`),
  KEY `FK_operation_account_id_idx` (`account_id`),
  KEY `FK_operation_transaction_id` (`transaction_id`),
  CONSTRAINT `FK_operation_account` FOREIGN KEY (`account_id`) REFERENCES `tbl_account` (`account_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_operation_transaction_id` FOREIGN KEY (`transaction_id`) REFERENCES `tbl_transaction` (`transaction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_operation_type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_operation_type` (`type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=52406 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_operation_type`
--

DROP TABLE IF EXISTS `tbl_operation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_operation_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_option_active_date`
--

DROP TABLE IF EXISTS `tbl_option_active_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_option_active_date` (
  `date_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `active_date` varchar(35) DEFAULT NULL,
  `tariff_type` enum('HOLIDAYS','EXCEPTIONS') NOT NULL,
  PRIMARY KEY (`date_id`),
  KEY `fk_tbl_option_active_date_tbl_taxi_tariff1_idx` (`tariff_id`),
  CONSTRAINT `fk_tbl_option_active_date_tbl_taxi_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3629 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_option_tariff`
--

DROP TABLE IF EXISTS `tbl_option_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_option_tariff` (
  `option_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `accrual` enum('DISTANCE','TIME','FIX','MIXED','INTERVAL') NOT NULL,
  `area` enum('CITY','TRACK','RAILWAY','AIRPORT') NOT NULL COMMENT 'Район действия тарифа (Город, Загород и т.д.)',
  `planting_price_day` float DEFAULT '0' COMMENT 'Стоимость посадки',
  `planting_price_night` float DEFAULT '0' COMMENT 'Стоимость посадки',
  `planting_include_day` float unsigned DEFAULT '0',
  `planting_include_night` float unsigned DEFAULT '0',
  `next_km_price_day` text,
  `next_km_price_night` text,
  `min_price_day` float unsigned DEFAULT '0',
  `second_min_price_day` float unsigned DEFAULT '0',
  `min_price_night` float unsigned DEFAULT '0',
  `second_min_price_night` float unsigned DEFAULT '0',
  `supply_price_day` float DEFAULT '0' COMMENT 'Стоимость 1 км до адреса подачи',
  `supply_price_night` float DEFAULT '0' COMMENT 'Стоимость 1 км до адреса подачи',
  `wait_time_day` tinyint(3) unsigned DEFAULT '0' COMMENT 'Бесплатное время ожидания до начала поездки',
  `wait_time_night` tinyint(3) unsigned DEFAULT '0' COMMENT 'Бесплатное время ожидания до начала поездки',
  `wait_driving_time_day` int(11) unsigned DEFAULT '0' COMMENT 'Бесплатное время ожидания во время поездки за 1 раз',
  `wait_driving_time_night` int(11) unsigned DEFAULT '0' COMMENT 'Бесплатное время ожидания во время поездки за 1 раз',
  `wait_price_day` float DEFAULT '0' COMMENT 'Стоимость 1 минуты ожидания',
  `wait_price_night` float DEFAULT '0' COMMENT 'Стоимость 1 минуты ожидания',
  `speed_downtime_day` float unsigned DEFAULT '0' COMMENT 'Скорость при которой вкл. ожидание',
  `speed_downtime_night` float unsigned DEFAULT '0' COMMENT 'Скорость при которой вкл. ожидание',
  `rounding_day` float DEFAULT '0' COMMENT 'Округление',
  `rounding_night` float DEFAULT '0' COMMENT 'Округление',
  `tariff_type` enum('CURRENT','HOLIDAYS','EXCEPTIONS') NOT NULL,
  `allow_day_night` tinyint(1) DEFAULT '0',
  `start_day` varchar(5) DEFAULT '08:00',
  `end_day` varchar(5) DEFAULT '20:00',
  `active` tinyint(1) DEFAULT '1',
  `enabled_parking_ratio` tinyint(1) DEFAULT '1' COMMENT ' Учитывать поправочный коэффициент парковок',
  `calculation_fix` tinyint(1) DEFAULT '0' COMMENT 'Зафиксировать расчет',
  `next_cost_unit_day` varchar(255) DEFAULT NULL COMMENT 'Единица измерения "Стоимость далее"',
  `next_cost_unit_night` varchar(255) DEFAULT NULL COMMENT 'Единица измерения "Стоимость далее"',
  `next_km_price_day_time` float DEFAULT '0' COMMENT 'Стоимость далее при при смешанном типе (Время)',
  `next_km_price_night_time` float DEFAULT '0' COMMENT 'Стоимость далее при при смешанном типе (Время)',
  `planting_include_day_time` int(11) unsigned DEFAULT '0',
  `planting_include_night_time` int(11) unsigned DEFAULT '0',
  `rounding_type_day` enum('FLOOR','ROUND','CEIL') NOT NULL DEFAULT 'ROUND',
  `rounding_type_night` enum('FLOOR','ROUND','CEIL') NOT NULL DEFAULT 'ROUND',
  PRIMARY KEY (`option_id`),
  KEY `fk_tbl_option_tariff_tbl_taxi_tariff1_idx` (`tariff_id`),
  CONSTRAINT `fk_tbl_option_tariff_tbl_taxi_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1451 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `worker_id` int(10) unsigned DEFAULT NULL,
  `car_id` int(10) unsigned DEFAULT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  `user_create` int(10) unsigned DEFAULT NULL,
  `status_id` tinyint(3) unsigned NOT NULL,
  `user_modifed` int(10) unsigned DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `parking_id` int(10) unsigned DEFAULT NULL,
  `address` text NOT NULL,
  `comment` text,
  `predv_price` decimal(10,2) DEFAULT NULL,
  `device` enum('DISPATCHER','IOS','WORKER','WINFON','WEB','ANDROID','CABINET','YANDEX') DEFAULT NULL COMMENT 'Устройство с которого сделан заказ',
  `order_number` int(10) unsigned NOT NULL,
  `payment` enum('CASH','CARD','PERSONAL_ACCOUNT','CORP_BALANCE') DEFAULT 'CASH',
  `show_phone` tinyint(1) DEFAULT '0',
  `create_time` int(10) unsigned DEFAULT NULL,
  `status_time` int(10) unsigned NOT NULL COMMENT 'Время изменения статуса',
  `time_to_client` tinyint(3) unsigned DEFAULT NULL COMMENT 'Время подъезда водителя (мин)',
  `client_device_token` text,
  `app_id` int(10) unsigned DEFAULT NULL,
  `order_time` int(10) unsigned DEFAULT NULL COMMENT 'На какое время заказ',
  `predv_distance` decimal(10,1) DEFAULT NULL,
  `predv_time` smallint(6) DEFAULT NULL,
  `call_warning_id` int(10) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `bonus_payment` int(1) DEFAULT '0',
  `currency_id` int(11) NOT NULL,
  `time_offset` smallint(6) DEFAULT NULL,
  `is_fix` int(1) NOT NULL DEFAULT '0',
  `update_time` int(11) DEFAULT NULL,
  `deny_refuse_order` int(11) DEFAULT '0',
  `position_id` int(11) NOT NULL,
  `promo_code_id` int(11) unsigned DEFAULT NULL,
  `tenant_company_id` int(11) unsigned DEFAULT NULL,
  `mark` int(11) DEFAULT '0',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `ui_order__tenant_id__order_number` (`tenant_id`,`order_number`),
  KEY `fk_tbl_order_tbl_user1_idx` (`user_create`),
  KEY `fk_tbl_order_tbl_user2_idx` (`user_modifed`),
  KEY `fk_tbl_order_tbl_driver1_idx` (`worker_id`),
  KEY `fk_tbl_order_tbl_parking1_idx` (`parking_id`),
  KEY `fk_tbl_order_tbl_user_has_city1_idx` (`city_id`),
  KEY `fk_tbl_order_tbl_car_idx` (`car_id`),
  KEY `fk_tbl_order_tbl_client1_idx` (`client_id`),
  KEY `idx_order__promo_code_id` (`promo_code_id`),
  KEY `fk_order__tenant_company` (`tenant_company_id`),
  CONSTRAINT `fk_order__tenant_company` FOREIGN KEY (`tenant_company_id`) REFERENCES `tbl_tenant_company` (`tenant_company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45743 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_change_data`
--

DROP TABLE IF EXISTS `tbl_order_change_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_change_data` (
  `change_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `change_field` varchar(45) DEFAULT NULL,
  `change_object_id` varchar(45) DEFAULT NULL,
  `change_object_type` varchar(45) DEFAULT NULL,
  `change_subject` varchar(100) DEFAULT NULL,
  `change_val` varchar(300) DEFAULT NULL,
  `change_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`change_id`),
  KEY `index_order_id_from_order_change_data_table` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=325468 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_detail_cost`
--

DROP TABLE IF EXISTS `tbl_order_detail_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_detail_cost` (
  `detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `accrual_city` enum('FIX','TIME','DISTANCE','INTERVAL','MIXED') DEFAULT NULL,
  `accrual_out` enum('FIX','TIME','DISTANCE','INTERVAL','MIXED') DEFAULT NULL,
  `summary_distance` varchar(45) DEFAULT NULL COMMENT 'Суммарное расстояние в км',
  `summary_cost` varchar(45) DEFAULT NULL COMMENT 'Суммарная цена',
  `summary_time` varchar(45) DEFAULT NULL COMMENT 'Суммарное время в минуах',
  `city_time` varchar(45) DEFAULT NULL COMMENT 'Время по городу без простоя',
  `city_distance` varchar(45) DEFAULT NULL COMMENT 'Расстояние поездки по городу',
  `city_cost` varchar(45) DEFAULT NULL COMMENT 'Стоимость по городу без учета простоя',
  `out_city_time` varchar(45) DEFAULT NULL COMMENT 'Время за городом (без простоя)',
  `out_city_distance` varchar(45) DEFAULT NULL COMMENT 'Расстояние за городом',
  `out_city_cost` varchar(45) DEFAULT NULL COMMENT 'Стоимость за городом без учета простоя',
  `city_time_wait` varchar(45) DEFAULT NULL COMMENT 'Время простоя в городе',
  `out_time_wait` varchar(45) DEFAULT NULL COMMENT 'Время простоя за городом',
  `before_time_wait` varchar(45) DEFAULT NULL,
  `additional_cost` varchar(45) DEFAULT NULL COMMENT 'Цена за допки',
  `is_fix` varchar(45) DEFAULT NULL COMMENT 'Фикс тариф? 1,0',
  `city_next_km_price` text,
  `out_next_km_price` text,
  `supply_price` varchar(45) DEFAULT NULL COMMENT 'Стоимость 1 км до адреса подачи',
  `city_wait_time` varchar(45) DEFAULT NULL COMMENT 'Бесплатное время ожидания до начала поездки  в городе',
  `out_wait_time` varchar(45) DEFAULT NULL COMMENT 'Бесплатное время ожидания до начала поездки  за городом',
  `city_wait_driving` varchar(45) DEFAULT NULL COMMENT 'Бесплатное время ожидания во время поездки по городу  за 1 раз в секундах',
  `out_wait_driving` varchar(45) DEFAULT NULL COMMENT 'Бесплатное время ожидания во время поездки за городом  за 1 раз в секундах',
  `city_wait_price` varchar(45) DEFAULT NULL COMMENT 'Стоимость 1 минуты ожидания в городе',
  `out_wait_price` varchar(45) DEFAULT NULL COMMENT 'Стоимость 1 минуты ожидания  за городом',
  `time` int(10) DEFAULT NULL,
  `distance_for_plant` varchar(45) DEFAULT NULL COMMENT 'Расстояние до адреса подача в метрах',
  `planting_price` varchar(45) DEFAULT NULL,
  `planting_include` varchar(45) DEFAULT NULL COMMENT 'Сколько включено единиц в зависимости от accrual и start_point_location',
  `start_point_location` enum('out','in') DEFAULT NULL COMMENT 'где находится точка подачи in/out',
  `city_wait_cost` varchar(255) DEFAULT NULL,
  `out_wait_cost` varchar(255) DEFAULT NULL,
  `distance_for_plant_cost` varchar(255) DEFAULT NULL,
  `before_time_wait_cost` varchar(255) DEFAULT NULL,
  `bonus` varchar(45) DEFAULT NULL,
  `writeoff_bonus_id` int(11) DEFAULT NULL,
  `refill_bonus_id` int(11) DEFAULT NULL,
  `refill_bonus` varchar(45) DEFAULT NULL,
  `city_cost_time` varchar(255) DEFAULT NULL,
  `out_city_cost_time` varchar(255) DEFAULT NULL,
  `planting_include_time` varchar(255) DEFAULT NULL,
  `city_next_km_price_time` varchar(255) DEFAULT NULL,
  `out_next_km_price_time` varchar(255) DEFAULT NULL,
  `city_next_cost_unit` varchar(255) DEFAULT NULL,
  `out_next_cost_unit` varchar(255) DEFAULT NULL,
  `commission` varchar(45) DEFAULT '0',
  `surcharge` varchar(45) DEFAULT NULL COMMENT 'Доплата за заказ',
  `tax` varchar(45) DEFAULT NULL COMMENT 'Налог',
  `promo_discount_value` varchar(255) DEFAULT NULL,
  `promo_discount_percent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`detail_id`),
  KEY `fk_order_detail_cost__writeoff_bonus_id` (`writeoff_bonus_id`) USING BTREE,
  KEY `fk_order_detail_cost__refill_bonus_id` (`refill_bonus_id`) USING BTREE,
  KEY `idx_order_detail_cost__order_id` (`order_id`),
  CONSTRAINT `tbl_order_detail_cost_ibfk_1` FOREIGN KEY (`writeoff_bonus_id`) REFERENCES `tbl_client_bonus` (`bonus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_order_detail_cost_ibfk_2` FOREIGN KEY (`refill_bonus_id`) REFERENCES `tbl_client_bonus` (`bonus_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9368 DEFAULT CHARSET=utf8 COMMENT='Таблица с детализацией поездки';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_has_option`
--

DROP TABLE IF EXISTS `tbl_order_has_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_has_option` (
  `order_id` int(10) unsigned NOT NULL,
  `option_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order_id`,`option_id`),
  KEY `fk_tbl_order_has_tbl_car_option_tbl_car_option1_idx` (`option_id`),
  KEY `order_additional_option_idx` (`option_id`),
  KEY `FK_order_additional_option_idx` (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_status`
--

DROP TABLE IF EXISTS `tbl_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_status` (
  `status_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `status_group` varchar(45) DEFAULT NULL,
  `dispatcher_sees` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_upup`
--

DROP TABLE IF EXISTS `tbl_order_upup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_upup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `upup_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_upup` (`order_id`),
  CONSTRAINT `fk_order_upup` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_order_views`
--

DROP TABLE IF EXISTS `tbl_order_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order_views` (
  `view_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `new` smallint(5) unsigned DEFAULT '0',
  `works` smallint(5) unsigned DEFAULT '0',
  `warning` smallint(5) unsigned DEFAULT '0',
  `pre_order` smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (`view_id`),
  KEY `fk_tbl_order_views_tbl_user1_idx` (`user_id`),
  KEY `fk_tbl_order_views_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_order_views_tbl_city1_idx` (`city_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_tbl_order_views_tbl_city1` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_order_views_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_order_views_tbl_user1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13248 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_page_content`
--

DROP TABLE IF EXISTS `tbl_page_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_page_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(255) NOT NULL,
  `content` text,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_page_content__page` (`page`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_page_content_aud`
--

DROP TABLE IF EXISTS `tbl_page_content_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_page_content_aud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_content_id` int(11) NOT NULL,
  `page` varchar(255) NOT NULL,
  `content` text,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_content_id` (`page_content_id`),
  CONSTRAINT `fk_page_content_aud__page_content_id` FOREIGN KEY (`page_content_id`) REFERENCES `tbl_page_content` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=574 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_parking`
--

DROP TABLE IF EXISTS `tbl_parking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_parking` (
  `parking_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `polygon` longtext NOT NULL,
  `sort` tinyint(3) unsigned DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `in_district` int(10) DEFAULT NULL,
  `out_district` int(10) DEFAULT NULL,
  `in_distr_coefficient_type` enum('PERCENT','MONEY') DEFAULT NULL,
  `out_distr_coefficient_type` enum('PERCENT','MONEY') DEFAULT NULL,
  PRIMARY KEY (`parking_id`),
  KEY `fk_tbl_parking_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_parking_tbl_city1_idx` (`city_id`),
  CONSTRAINT `fk_tbl_parking_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=897 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_parking_order`
--

DROP TABLE IF EXISTS `tbl_parking_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_parking_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `odrer_id` int(10) unsigned NOT NULL,
  `parking_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_parking_order_tbl_parking1_idx` (`parking_id`),
  CONSTRAINT `fk_tbl_parking_order_tbl_parking1` FOREIGN KEY (`parking_id`) REFERENCES `tbl_parking` (`parking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_payment`
--

DROP TABLE IF EXISTS `tbl_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `description` text,
  `purchased_at` int(11) DEFAULT NULL,
  `payment_sum` decimal(12,2) DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `payment_number` varchar(255) NOT NULL,
  `confirmed_at` int(11) DEFAULT NULL,
  `discount` decimal(12,2) DEFAULT NULL,
  `fixed_discount` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_tbl_payment__currency_id` (`currency_id`),
  KEY `fk_tbl_payment__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_tbl_payment__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tbl_payment__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=340 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_payment_for_additional_option`
--

DROP TABLE IF EXISTS `tbl_payment_for_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment_for_additional_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `payment_sum` decimal(12,2) DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `started_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_payment_for_additional_option__payment_id` (`payment_id`),
  KEY `fk_tbl_payment_for_additional_option__currency_id` (`currency_id`),
  KEY `fk_tbl_payment_for_additional_option__option_id` (`option_id`),
  CONSTRAINT `fk_tbl_payment_for_additional_option__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tbl_payment_for_additional_option__option_id` FOREIGN KEY (`option_id`) REFERENCES `tbl_tariff_additional_option` (`id`),
  CONSTRAINT `fk_tbl_payment_for_additional_option__payment_id` FOREIGN KEY (`payment_id`) REFERENCES `tbl_payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=378 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_payment_for_one_time_service`
--

DROP TABLE IF EXISTS `tbl_payment_for_one_time_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment_for_one_time_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `payment_sum` decimal(12,2) DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `executed_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_payment_for_one_time_service__payment_id` (`payment_id`),
  KEY `fk_tbl_payment_for_one_time_service__currency_id` (`currency_id`),
  KEY `fk_tbl_payment_for_one_time_service__service_id` (`service_id`),
  CONSTRAINT `fk_tbl_payment_for_one_time_service__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tbl_payment_for_one_time_service__payment_id` FOREIGN KEY (`payment_id`) REFERENCES `tbl_payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_payment_for_one_time_service__service_id` FOREIGN KEY (`service_id`) REFERENCES `tbl_one_time_service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_payment_for_tariff`
--

DROP TABLE IF EXISTS `tbl_payment_for_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment_for_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `tariff_id` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `payment_sum` decimal(12,2) DEFAULT NULL,
  `currency_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `started_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_payment_for_tariff__payment_id` (`payment_id`),
  KEY `fk_tbl_payment_for_tariff__currency_id` (`currency_id`),
  KEY `fk_tbl_payment_for_tariff__tariff_id` (`tariff_id`),
  CONSTRAINT `fk_tbl_payment_for_tariff__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tbl_payment_for_tariff__payment_id` FOREIGN KEY (`payment_id`) REFERENCES `tbl_payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_payment_for_tariff__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_tariff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=538 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_payment_method`
--

DROP TABLE IF EXISTS `tbl_payment_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment_method` (
  `payment` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_paynet_cancel_transaction`
--

DROP TABLE IF EXISTS `tbl_paynet_cancel_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_paynet_cancel_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_paynet_log`
--

DROP TABLE IF EXISTS `tbl_paynet_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_paynet_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `username` varchar(15) DEFAULT NULL,
  `serviceId` int(11) DEFAULT NULL,
  `callsign` int(8) DEFAULT NULL,
  `sum` varchar(255) DEFAULT NULL,
  `data` text,
  `result` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=558 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_permission`
--

DROP TABLE IF EXISTS `tbl_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_phone_line`
--

DROP TABLE IF EXISTS `tbl_phone_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phone_line` (
  `line_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `phone` varchar(20) NOT NULL,
  `incoming_scenario` text,
  `block` tinyint(1) DEFAULT '0',
  `r_username` varchar(50) NOT NULL,
  `r_domain` varchar(50) NOT NULL,
  `sip_server_local` varchar(255) NOT NULL,
  `auth_proxy` varchar(255) NOT NULL,
  `port` int(5) NOT NULL,
  `realm` varchar(50) NOT NULL,
  `typeServer` enum('kamailio','asterisk') NOT NULL DEFAULT 'kamailio',
  `draft` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`line_id`),
  UNIQUE KEY `phone_UNIQUE` (`phone`),
  KEY `fk_tbl_phone_line_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_phone_line_tbl_taxi_tariff1_idx` (`tariff_id`),
  KEY `fk_tbl_phone_line_tbl_city1_idx` (`city_id`),
  CONSTRAINT `fk_tbl_phone_line_tbl_city1` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_phone_line_tbl_taxi_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_phone_line_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_phone_line_outbound_routing`
--

DROP TABLE IF EXISTS `tbl_phone_line_outbound_routing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phone_line_outbound_routing` (
  `routing_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(6) unsigned NOT NULL DEFAULT '100',
  `active` int(1) unsigned NOT NULL DEFAULT '0',
  `default` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`routing_id`),
  KEY `FK_tenant_id__phone_line_outbound_routing` (`tenant_id`),
  KEY `FK_city_id__phone_line_outbound_routing` (`city_id`),
  CONSTRAINT `FK_city_id__phone_line_outbound_routing` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tenant_id__phone_line_outbound_routing` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_phone_line_outbound_routing_has_taxi_tariff`
--

DROP TABLE IF EXISTS `tbl_phone_line_outbound_routing_has_taxi_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phone_line_outbound_routing_has_taxi_tariff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(10) unsigned NOT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_routing_id__phone_line_outbound_routing_has_taxi_tariff` (`routing_id`),
  KEY `FK_tariff_id__phone_line_outbound_routing_has_taxi_tariff` (`tariff_id`),
  CONSTRAINT `FK_routing_id__phone_line_outbound_routing_has_taxi_tariff` FOREIGN KEY (`routing_id`) REFERENCES `tbl_phone_line_outbound_routing` (`routing_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tariff_id__phone_line_outbound_routing_has_taxi_tariff` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_phone_line_outbound_routing_on_notify`
--

DROP TABLE IF EXISTS `tbl_phone_line_outbound_routing_on_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phone_line_outbound_routing_on_notify` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(10) unsigned NOT NULL,
  `line_id` int(10) unsigned NOT NULL,
  `sort` int(6) unsigned NOT NULL DEFAULT '100',
  `timeout` int(10) unsigned NOT NULL DEFAULT '60',
  `distribution_count` int(10) unsigned NOT NULL DEFAULT '60',
  `distribution_delay` int(10) unsigned NOT NULL DEFAULT '60',
  PRIMARY KEY (`id`),
  KEY `FK_routing_id__phone_line_outbound_routing_on_notify` (`routing_id`),
  KEY `FK_line_id__phone_line_outbound_routing_on_notify` (`line_id`),
  CONSTRAINT `FK_line_id__phone_line_outbound_routing_on_notify` FOREIGN KEY (`line_id`) REFERENCES `tbl_phone_line` (`line_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_routing_id__phone_line_outbound_routing_on_notify` FOREIGN KEY (`routing_id`) REFERENCES `tbl_phone_line_outbound_routing` (`routing_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_phone_line_outbound_routing_on_operator`
--

DROP TABLE IF EXISTS `tbl_phone_line_outbound_routing_on_operator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phone_line_outbound_routing_on_operator` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `routing_id` int(10) unsigned NOT NULL,
  `line_id` int(10) unsigned NOT NULL,
  `sort` int(6) unsigned NOT NULL DEFAULT '100',
  `timeout` int(10) unsigned NOT NULL DEFAULT '60',
  PRIMARY KEY (`id`),
  KEY `FK_routing_id__phone_line_outbound_routing_on_operator` (`routing_id`),
  KEY `FK_line_id__phone_line_outbound_routing_on_operator` (`line_id`),
  CONSTRAINT `FK_line_id__phone_line_outbound_routing_on_operator` FOREIGN KEY (`line_id`) REFERENCES `tbl_phone_line` (`line_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_routing_id__phone_line_outbound_routing_on_operator` FOREIGN KEY (`routing_id`) REFERENCES `tbl_phone_line_outbound_routing` (`routing_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_position`
--

DROP TABLE IF EXISTS `tbl_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_position` (
  `position_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `module_id` int(11) NOT NULL,
  `has_car` tinyint(1) DEFAULT '0',
  `transport_type_id` int(11) DEFAULT NULL COMMENT 'PK of tbl_transport_type',
  PRIMARY KEY (`position_id`),
  KEY `UK_tbl_position_module_id` (`module_id`),
  KEY `fr_position_transport_type_id` (`transport_type_id`),
  CONSTRAINT `FK_tbl_position_tbl_module_id` FOREIGN KEY (`module_id`) REFERENCES `tbl_module` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fr_position_transport_type_id` FOREIGN KEY (`transport_type_id`) REFERENCES `tbl_transport_type` (`type_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_position_field`
--

DROP TABLE IF EXISTS `tbl_position_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_position_field` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` enum('int','string','text','checkbox') DEFAULT NULL,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_position_has_document`
--

DROP TABLE IF EXISTS `tbl_position_has_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_position_has_document` (
  `position_id` int(10) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`position_id`,`document_id`),
  KEY `fk_tbl_position_has_tbl_document_tbl_document1_idx` (`document_id`),
  KEY `fk_tbl_position_has_tbl_document_tbl_position1_idx` (`position_id`),
  CONSTRAINT `fk_tbl_position_has_tbl_document_tbl_document1` FOREIGN KEY (`document_id`) REFERENCES `tbl_document` (`document_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_position_has_tbl_document_tbl_position1` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_position_has_field`
--

DROP TABLE IF EXISTS `tbl_position_has_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_position_has_field` (
  `position_id` int(10) NOT NULL,
  `field_id` int(11) NOT NULL,
  PRIMARY KEY (`position_id`,`field_id`),
  KEY `fk_tbl_position_has_tbl_position_field_tbl_position_field1_idx` (`field_id`),
  KEY `fk_tbl_position_has_tbl_position_field_tbl_position1_idx` (`position_id`),
  CONSTRAINT `fk_tbl_position_has_tbl_position_field_tbl_position1` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_position_has_tbl_position_field_tbl_position_field1` FOREIGN KEY (`field_id`) REFERENCES `tbl_position_field` (`field_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_post`
--

DROP TABLE IF EXISTS `tbl_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `anons` text NOT NULL,
  `content` text,
  `publication_date` int(11) NOT NULL,
  `status` enum('draft','published','in archive') NOT NULL DEFAULT 'draft',
  `author_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `count_comments` int(11) NOT NULL DEFAULT '0',
  `meta_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `fk_post__section_id` (`section_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `fk_post__author_id` FOREIGN KEY (`author_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_post__section_id` FOREIGN KEY (`section_id`) REFERENCES `tbl_section` (`section_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_post_tag`
--

DROP TABLE IF EXISTS `tbl_post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_post_tag` (
  `post_tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`post_tag_id`),
  KEY `fk_post_tag__post_id` (`post_id`),
  KEY `fk_post_tag__tag_id` (`tag_id`),
  CONSTRAINT `fk_post_tag__post_id` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_post_tag__tag_id` FOREIGN KEY (`tag_id`) REFERENCES `tbl_tag` (`tag_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=391 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_price_history`
--

DROP TABLE IF EXISTS `tbl_price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_price_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_type_id` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currency_id` int(11) NOT NULL,
  `activated_at` int(11) NOT NULL,
  `deactivated_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `option_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `tariff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_price_history__currency_id` (`currency_id`),
  KEY `fk_tbl_price_history__entity_type_id` (`entity_type_id`),
  KEY `fk_tbl_price_history__option_id` (`option_id`),
  KEY `fk_tbl_price_history__service_id` (`service_id`),
  KEY `fk_tbl_price_history__tariff_id` (`tariff_id`),
  CONSTRAINT `fk_tbl_price_history__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_price_history__entity_type_id` FOREIGN KEY (`entity_type_id`) REFERENCES `tbl_tariff_entity_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_price_history__option_id` FOREIGN KEY (`option_id`) REFERENCES `tbl_tariff_additional_option` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_price_history__service_id` FOREIGN KEY (`service_id`) REFERENCES `tbl_one_time_service` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_price_history__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo`
--

DROP TABLE IF EXISTS `tbl_promo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo` (
  `promo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `type_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `period_type_id` int(11) NOT NULL,
  `period_start` int(11) unsigned DEFAULT NULL,
  `period_end` int(11) unsigned DEFAULT NULL,
  `action_count_id` int(11) DEFAULT NULL,
  `action_clients_id` int(11) DEFAULT NULL,
  `action_no_other_codes` tinyint(1) NOT NULL,
  `activation_type_id` int(11) NOT NULL,
  `client_bonuses` int(11) DEFAULT NULL,
  `client_discount` int(11) DEFAULT NULL,
  `worker_commission` int(11) DEFAULT NULL,
  `worker_bonuses` int(11) DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL,
  `created_at` tinyint(1) unsigned NOT NULL,
  `updated_at` tinyint(1) unsigned NOT NULL,
  `count_codes` int(11) DEFAULT NULL,
  `count_symbols_in_code` int(11) DEFAULT NULL,
  PRIMARY KEY (`promo_id`),
  KEY `fk_promo__type_id` (`type_id`),
  KEY `fk_promo__position_id` (`position_id`),
  KEY `fk_promo__period_type_id` (`period_type_id`),
  KEY `fk_promo__action_count_id` (`action_count_id`),
  KEY `fk_promo__action_clients_id` (`action_clients_id`),
  KEY `fk_promo__activation_type_id` (`activation_type_id`),
  KEY `idx_promo__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_promo__action_clients_id` FOREIGN KEY (`action_clients_id`) REFERENCES `tbl_promo_action_clients` (`action_clients_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__action_count_id` FOREIGN KEY (`action_count_id`) REFERENCES `tbl_promo_action_count` (`action_count_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__activation_type_id` FOREIGN KEY (`activation_type_id`) REFERENCES `tbl_promo_activation_type` (`activation_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__period_type_id` FOREIGN KEY (`period_type_id`) REFERENCES `tbl_promo_period_type` (`period_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo__type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_promo_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_action_clients`
--

DROP TABLE IF EXISTS `tbl_promo_action_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_action_clients` (
  `action_clients_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`action_clients_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_action_count`
--

DROP TABLE IF EXISTS `tbl_promo_action_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_action_count` (
  `action_count_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`action_count_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_activation_type`
--

DROP TABLE IF EXISTS `tbl_promo_activation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_activation_type` (
  `activation_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`activation_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_bonus_operation`
--

DROP TABLE IF EXISTS `tbl_promo_bonus_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_bonus_operation` (
  `bonus_operation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `client_id` int(11) unsigned DEFAULT NULL,
  `worker_id` int(11) DEFAULT NULL,
  `bonus_subject` enum('client','worker') NOT NULL,
  `completed` int(11) DEFAULT '0',
  `promo_bonus` int(11) NOT NULL,
  `created_at` int(11) unsigned DEFAULT NULL,
  `updated_at` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`bonus_operation_id`),
  KEY `idx_promo_bonus_operation__order_id` (`order_id`),
  KEY `idx_promo_bonus_operation__client_id` (`client_id`),
  KEY `idx_promo_bonus_operation__worker_id` (`worker_id`),
  CONSTRAINT `fk_promo_bonus_operation__client` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_bonus_operation__order` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_bonus_operation__worker` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_client`
--

DROP TABLE IF EXISTS `tbl_promo_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_client` (
  `client_id` int(11) unsigned NOT NULL,
  `code_id` int(11) unsigned NOT NULL,
  `status_code_id` int(11) NOT NULL,
  `status_time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`client_id`,`code_id`),
  KEY `fk_promo_client__code_id` (`code_id`),
  KEY `fk_promo_client__status_code_id` (`status_code_id`),
  CONSTRAINT `fk_promo_client__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_client__code_id` FOREIGN KEY (`code_id`) REFERENCES `tbl_promo_code` (`code_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_client__status_code_id` FOREIGN KEY (`status_code_id`) REFERENCES `tbl_promo_status_code` (`status_code_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_code`
--

DROP TABLE IF EXISTS `tbl_promo_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_code` (
  `code_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `promo_id` int(11) unsigned NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `created_at` int(11) unsigned NOT NULL,
  `updated_at` int(11) unsigned NOT NULL,
  `worker_id` int(10) DEFAULT NULL,
  `car_class_id` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`code_id`),
  KEY `fk_promo_code__promo_id` (`promo_id`),
  KEY `fk_promo_code__car_class_id` (`car_class_id`),
  KEY `idx_promo_code__code` (`code`),
  KEY `idx_promo_code__worker_id` (`worker_id`),
  CONSTRAINT `fk_promo_code__car_class_id` FOREIGN KEY (`car_class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_code__promo_id` FOREIGN KEY (`promo_id`) REFERENCES `tbl_promo` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_code__worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3588 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_has_car_class`
--

DROP TABLE IF EXISTS `tbl_promo_has_car_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_has_car_class` (
  `promo_id` int(11) unsigned NOT NULL,
  `car_class_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`promo_id`,`car_class_id`),
  KEY `fk_promo_has_car_class__car_class_id` (`car_class_id`),
  CONSTRAINT `fk_promo_has_car_class__car_class_id` FOREIGN KEY (`car_class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_has_car_class__promo_id` FOREIGN KEY (`promo_id`) REFERENCES `tbl_promo` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_has_city`
--

DROP TABLE IF EXISTS `tbl_promo_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_has_city` (
  `promo_id` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`promo_id`,`city_id`),
  KEY `fk_promo_has_city__city_id` (`city_id`),
  CONSTRAINT `fk_promo_has_city__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_has_city__promo_id` FOREIGN KEY (`promo_id`) REFERENCES `tbl_promo` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_has_symbol_type`
--

DROP TABLE IF EXISTS `tbl_promo_has_symbol_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_has_symbol_type` (
  `promo_id` int(11) unsigned NOT NULL,
  `symbol_type_id` int(11) NOT NULL,
  PRIMARY KEY (`promo_id`,`symbol_type_id`),
  KEY `fk_promo_has_symbol_type__symbol_type_id` (`symbol_type_id`),
  CONSTRAINT `fk_promo_has_symbol_type__promo_id` FOREIGN KEY (`promo_id`) REFERENCES `tbl_promo` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_promo_has_symbol_type__symbol_type_id` FOREIGN KEY (`symbol_type_id`) REFERENCES `tbl_promo_symbol_type` (`symbol_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_period_type`
--

DROP TABLE IF EXISTS `tbl_promo_period_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_period_type` (
  `period_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`period_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_status_code`
--

DROP TABLE IF EXISTS `tbl_promo_status_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_status_code` (
  `status_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_label` varchar(255) NOT NULL,
  PRIMARY KEY (`status_code_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_symbol_type`
--

DROP TABLE IF EXISTS `tbl_promo_symbol_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_symbol_type` (
  `symbol_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`symbol_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_promo_type`
--

DROP TABLE IF EXISTS `tbl_promo_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_promo_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_raw_order_calc`
--

DROP TABLE IF EXISTS `tbl_raw_order_calc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_raw_order_calc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `raw_cacl_data` text NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_raw_order_calc_order_id` (`order_id`),
  CONSTRAINT `FK_raw_order_calc_order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5954 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_referral`
--

DROP TABLE IF EXISTS `tbl_referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referral` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(5) NOT NULL DEFAULT '100',
  `tenant_id` int(10) unsigned NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `is_active_subscriber_limit` int(1) NOT NULL DEFAULT '0' COMMENT 'Включить лимит приглашенных?',
  `subscriber_limit` int(11) DEFAULT NULL COMMENT 'Лимит приглашенных',
  `type` enum('ON_ORDER','ON_REGISTER') NOT NULL,
  `referral_bonus` decimal(20,5) NOT NULL DEFAULT '0.00000' COMMENT 'Бонус рефералу (кого пригласили)',
  `referral_bonus_type` enum('PERCENT','BONUS') NOT NULL,
  `referrer_bonus` decimal(20,5) NOT NULL DEFAULT '0.00000' COMMENT 'Бонус рефереру (кто пригласил)',
  `referrer_bonus_type` enum('PERCENT','BONUS') NOT NULL,
  `order_count` int(11) DEFAULT NULL COMMENT 'Кол-во поездок. NULL - безлимитно',
  `min_price` decimal(20,5) DEFAULT NULL,
  `text_in_client_api` text NOT NULL COMMENT 'Текст в клиентском прил.',
  `title` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `rand_string` varchar(255) NOT NULL,
  PRIMARY KEY (`referral_id`),
  KEY `fk_referral__tenant_id` (`tenant_id`),
  KEY `fk_referral__city_id` (`city_id`),
  CONSTRAINT `fk_referral__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_referral__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_referral_bonus_for_order`
--

DROP TABLE IF EXISTS `tbl_referral_bonus_for_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referral_bonus_for_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `referrer_id` int(10) unsigned NOT NULL,
  `referrer_bonus` decimal(20,5) NOT NULL DEFAULT '0.00000',
  `referral_id` int(10) unsigned NOT NULL,
  `referral_bonus` decimal(20,5) NOT NULL DEFAULT '0.00000',
  `completed` int(1) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_referral_bonus_for_order` (`order_id`),
  KEY `fk_referral_bonus_for_order__referrer_id` (`referrer_id`),
  KEY `fk_referral_bonus_for_order__referral_id` (`referral_id`),
  CONSTRAINT `fk_referral_bonus_for_order__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_referral_bonus_for_order__referral_id` FOREIGN KEY (`referral_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_referral_bonus_for_order__referrer_id` FOREIGN KEY (`referrer_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_referral_system_members`
--

DROP TABLE IF EXISTS `tbl_referral_system_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referral_system_members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `referral_id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `code` (`code`),
  KEY `referral_system_members__referral_id` (`referral_id`),
  KEY `referral_system_members__client_id` (`client_id`),
  CONSTRAINT `referral_system_members__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `referral_system_members__referral_id` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_referral_system_subscribers`
--

DROP TABLE IF EXISTS `tbl_referral_system_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referral_system_subscribers` (
  `subscriber_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `member_id` int(11) NOT NULL,
  `order_count` int(11) NOT NULL DEFAULT '0' COMMENT 'Кол-во поездок',
  PRIMARY KEY (`subscriber_id`),
  KEY `referral_system_subscribers__member_id` (`member_id`),
  KEY `referral_system_subscribers__client_id` (`client_id`),
  CONSTRAINT `referral_system_subscribers__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `referral_system_subscribers__member_id` FOREIGN KEY (`member_id`) REFERENCES `tbl_referral_system_members` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_republic`
--

DROP TABLE IF EXISTS `tbl_republic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_republic` (
  `republic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` smallint(5) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `shortname` varchar(50) NOT NULL,
  `timezone` float DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `name_az` varchar(100) DEFAULT NULL,
  `name_de` varchar(100) DEFAULT NULL,
  `name_sr` varchar(100) DEFAULT NULL,
  `shortname_en` varchar(50) DEFAULT NULL,
  `shortname_az` varchar(50) DEFAULT NULL,
  `shortname_de` varchar(50) DEFAULT NULL,
  `shortname_sr` varchar(50) DEFAULT NULL,
  `name_uz` varchar(255) DEFAULT NULL,
  `shortname_uz` varchar(255) DEFAULT NULL,
  `name_fi` varchar(100) DEFAULT NULL,
  `shortname_fi` varchar(255) DEFAULT NULL,
  `name_fa` varchar(100) DEFAULT NULL,
  `shortname_fa` varchar(255) DEFAULT NULL,
  `name_bg` varchar(100) DEFAULT NULL,
  `shortname_bg` varchar(255) DEFAULT NULL,
  `name_ar` varchar(100) DEFAULT NULL,
  `shortname_ar` varchar(255) DEFAULT NULL,
  `name_tg` varchar(100) DEFAULT NULL,
  `shortname_tg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`republic_id`),
  UNIQUE KEY `republic_id_UNIQUE` (`republic_id`),
  KEY `fk_tbl_countru_idx` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_routing_service_type`
--

DROP TABLE IF EXISTS `tbl_routing_service_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_routing_service_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_label` text,
  `active` tinyint(1) DEFAULT '0',
  `has_key_1` int(1) DEFAULT '0',
  `has_key_2` int(1) DEFAULT '0',
  `key_1_label` varchar(50) DEFAULT NULL,
  `key_2_label` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_section`
--

DROP TABLE IF EXISTS `tbl_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sms_log`
--

DROP TABLE IF EXISTS `tbl_sms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `login` varchar(48) DEFAULT NULL,
  `phone` varchar(48) NOT NULL,
  `create_time` datetime NOT NULL,
  `signature` varchar(48) DEFAULT NULL,
  `server_id` tinyint(3) unsigned NOT NULL,
  `tenant_id` int(10) unsigned DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `server_id` (`server_id`),
  KEY `fk_sms_log_tenant_id` (`tenant_id`),
  CONSTRAINT `fk_sms_log_server_id` FOREIGN KEY (`server_id`) REFERENCES `tbl_sms_server` (`server_id`),
  CONSTRAINT `fk_sms_log_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8328 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sms_server`
--

DROP TABLE IF EXISTS `tbl_sms_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_server` (
  `server_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `sort` int(10) NOT NULL DEFAULT '100',
  `host` varchar(45) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`server_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sms_template`
--

DROP TABLE IF EXISTS `tbl_sms_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_template` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `type` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`template_id`),
  KEY `fk_tbl_sms_template_tbl_tenant1_idx` (`tenant_id`),
  KEY `FK_sms_template_idx` (`city_id`),
  KEY `fk_sms_template_position_id` (`position_id`),
  CONSTRAINT `FK_sms_template` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_sms_template_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`),
  CONSTRAINT `fk_tbl_sms_template_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101745 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sms_template_courier`
--

DROP TABLE IF EXISTS `tbl_sms_template_courier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_template_courier` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `type` varchar(45) NOT NULL,
  `text` text NOT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`template_id`),
  KEY `FK_sms_template_courier_city_id` (`city_id`),
  KEY `fk_sms_template_courier_position_id` (`position_id`),
  CONSTRAINT `FK_sms_template_courier_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_sms_template_courier_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_source_message`
--

DROP TABLE IF EXISTS `tbl_source_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_source_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(32) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4690 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_subscribe_comment`
--

DROP TABLE IF EXISTS `tbl_subscribe_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_subscribe_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subscribe_comment__community_user_id` (`community_user_id`),
  KEY `fk_subscribe_comment__post_id` (`post_id`),
  CONSTRAINT `fk_subscribe_comment__community_user_id` FOREIGN KEY (`community_user_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscribe_comment__post_id` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_subscribe_offer`
--

DROP TABLE IF EXISTS `tbl_subscribe_offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_subscribe_offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_user_id` int(11) NOT NULL,
  `offer_info_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subscribe_offer__community_user_id` (`community_user_id`),
  KEY `fk_subscribe_offer__offer_info_id` (`offer_info_id`),
  CONSTRAINT `fk_subscribe_offer__community_user_id` FOREIGN KEY (`community_user_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscribe_offer__offer_info_id` FOREIGN KEY (`offer_info_id`) REFERENCES `tbl_offer_info` (`offer_info_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_support`
--

DROP TABLE IF EXISTS `tbl_support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_support` (
  `support_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `priority` varchar(45) NOT NULL,
  `title` varchar(100) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'OPEN',
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`support_id`),
  KEY `fk_tbl_support_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_support_tbl_user1_idx` (`user_id`),
  CONSTRAINT `fk_tbl_support_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_support_tbl_user1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_support_tbl_user2` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=399 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_support_feedback`
--

DROP TABLE IF EXISTS `tbl_support_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_support_feedback` (
  `feedback_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `support_id` int(10) unsigned NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `raiting` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `k_tbL_support_idx` (`support_id`),
  CONSTRAINT `k_tbL_support` FOREIGN KEY (`support_id`) REFERENCES `tbl_support` (`support_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_support_message`
--

DROP TABLE IF EXISTS `tbl_support_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_support_message` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `support_id` int(10) unsigned NOT NULL,
  `support_user_id` int(10) unsigned DEFAULT NULL,
  `message` text NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `fk_tbl_support_message_tbl_support1_idx` (`support_id`),
  KEY `fk_tbl_support_message_tbl_admin_user1_idx` (`support_user_id`),
  CONSTRAINT `fk_tbl_support_message_tbl_admin_user1` FOREIGN KEY (`support_user_id`) REFERENCES `tbl_admin_user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_support_message_tbl_admin_user2` FOREIGN KEY (`support_user_id`) REFERENCES `tbl_admin_user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_support_message_tbl_support1` FOREIGN KEY (`support_id`) REFERENCES `tbl_support` (`support_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=703 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_support_message_photo`
--

DROP TABLE IF EXISTS `tbl_support_message_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_support_message_photo` (
  `photo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`photo_id`),
  KEY `fk_message_idx` (`message_id`),
  CONSTRAINT `fk_message` FOREIGN KEY (`message_id`) REFERENCES `tbl_support_message` (`message_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_symbols_quantity_in_password`
--

DROP TABLE IF EXISTS `tbl_symbols_quantity_in_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_symbols_quantity_in_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tag`
--

DROP TABLE IF EXISTS `tbl_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff`
--

DROP TABLE IF EXISTS `tbl_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `module_id` int(11) NOT NULL,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `default` smallint(1) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `currency_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_tariff__module_id` (`module_id`),
  KEY `fk_tbl_tariff__currency_id` (`currency_id`),
  CONSTRAINT `fk_tbl_tariff__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tbl_tariff__module_id` FOREIGN KEY (`module_id`) REFERENCES `tbl_module` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff_additional_option`
--

DROP TABLE IF EXISTS `tbl_tariff_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff_additional_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `code` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `currency_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_additional_option__currency_id` (`currency_id`),
  CONSTRAINT `fk_additional_option__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff_commission`
--

DROP TABLE IF EXISTS `tbl_tariff_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff_commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(10) unsigned NOT NULL,
  `type` enum('PERCENT','MONEY') NOT NULL DEFAULT 'PERCENT',
  `value` decimal(12,2) DEFAULT NULL,
  `from` decimal(12,2) NOT NULL DEFAULT '0.00',
  `to` decimal(12,2) DEFAULT NULL,
  `kind` enum('FIXED','CASH','CARD','PERSONAL_ACCOUNT','CORP_BALANCE','BORDER') NOT NULL DEFAULT 'FIXED',
  `tax` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tariff_commission__option_id` (`option_id`),
  CONSTRAINT `fk_tariff_commission__option_id` FOREIGN KEY (`option_id`) REFERENCES `tbl_worker_option_tariff` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3653 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff_entity_type`
--

DROP TABLE IF EXISTS `tbl_tariff_entity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff_entity_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff_permission`
--

DROP TABLE IF EXISTS `tbl_tariff_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tariff_id` int(11) NOT NULL,
  `active` smallint(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `permission_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_tbl_tariff_permission__tariff_id__permission_id` (`tariff_id`,`permission_id`),
  KEY `fk_tbl_tariff_permission__permission_id` (`permission_id`),
  CONSTRAINT `fk_tbl_tariff_permission__permission_id` FOREIGN KEY (`permission_id`) REFERENCES `tbl_permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tariff_permission__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tariff_permission_history`
--

DROP TABLE IF EXISTS `tbl_tariff_permission_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tariff_permission_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `activated_at` int(11) NOT NULL,
  `deactivated_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_tariff_permission_history__permission_id` (`permission_id`),
  CONSTRAINT `fk_tbl_tariff_permission_history__permission_id` FOREIGN KEY (`permission_id`) REFERENCES `tbl_tariff_permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_taxi_tariff`
--

DROP TABLE IF EXISTS `tbl_taxi_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_taxi_tariff` (
  `tariff_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned DEFAULT NULL,
  `block` tinyint(1) DEFAULT '0',
  `group_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `sort` smallint(6) DEFAULT '100',
  `auto_downtime` int(1) NOT NULL DEFAULT '1',
  `enabled_site` tinyint(1) DEFAULT '1',
  `enabled_app` tinyint(1) DEFAULT '1',
  `enabled_operator` tinyint(1) DEFAULT '1',
  `enabled_bordur` tinyint(1) DEFAULT '1',
  `enabled_cabinet` int(1) DEFAULT '1',
  `logo` varchar(255) DEFAULT '',
  `position_id` int(10) NOT NULL COMMENT 'PK of table "tbl_position"',
  `type` enum('BASE','COMPANY','COMPANY_CORP_BALANCE','ALL') NOT NULL DEFAULT 'ALL',
  PRIMARY KEY (`tariff_id`),
  KEY `fk_tbl_taxi_tariff_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_taxi_tariff_tbl_car_class1_idx` (`class_id`),
  KEY `FK_taxi_tariff_group_id` (`group_id`),
  KEY `fk_taxi_tariff_has_position_id` (`position_id`),
  CONSTRAINT `FK_taxi_tariff_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_taxi_tariff_group` (`group_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_taxi_tariff_has_position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`),
  CONSTRAINT `fk_tbl_taxi_tariff_tbl_car_class1` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_taxi_tariff_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_taxi_tariff_group`
--

DROP TABLE IF EXISTS `tbl_taxi_tariff_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_taxi_tariff_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `sort` smallint(6) DEFAULT '100',
  PRIMARY KEY (`group_id`),
  KEY `FK_taxi_tariff_group_tenant_id` (`tenant_id`),
  CONSTRAINT `FK_taxi_tariff_group_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_taxi_tariff_has_city`
--

DROP TABLE IF EXISTS `tbl_taxi_tariff_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_taxi_tariff_has_city` (
  `tariff_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`tariff_id`,`city_id`),
  KEY `fk_tbl_taxi_tariff_has_tbl_city_tbl_taxi_tariff1_idx` (`tariff_id`),
  KEY `fk_tbl_taxi_tariff_has_city_tbl_city1_idx` (`city_id`),
  CONSTRAINT `fk_tbl_taxi_tariff_has_tbl_city_tbl_taxi_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_taxi_tariff_has_company`
--

DROP TABLE IF EXISTS `tbl_taxi_tariff_has_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_taxi_tariff_has_company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_taxi_tariff_has_company__company_id` (`company_id`),
  KEY `fk_tbl_taxi_tariff_has_company__tariff_id` (`tariff_id`),
  CONSTRAINT `fk_tbl_taxi_tariff_has_company__company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_client_company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_taxi_tariff_has_company__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_taxi_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant`
--

DROP TABLE IF EXISTS `tbl_tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant` (
  `tenant_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  `full_company_name` varchar(255) DEFAULT NULL,
  `legal_address` varchar(255) DEFAULT NULL,
  `post_address` varchar(255) DEFAULT NULL,
  `contact_name` varchar(45) DEFAULT NULL,
  `contact_second_name` varchar(45) DEFAULT NULL,
  `contact_last_name` varchar(45) DEFAULT NULL,
  `contact_phone` varchar(15) NOT NULL,
  `contact_email` varchar(45) DEFAULT NULL,
  `company_phone` varchar(15) DEFAULT NULL,
  `domain` varchar(15) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `inn` varchar(15) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bookkeeper` varchar(45) DEFAULT NULL,
  `kpp` varchar(10) DEFAULT NULL,
  `ogrn` varchar(45) DEFAULT NULL,
  `site` varchar(45) DEFAULT NULL,
  `archive` timestamp NULL DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `director` varchar(50) DEFAULT NULL,
  `director_position` varchar(45) DEFAULT NULL,
  `status` enum('ACTIVE','BLOCKED','REMOVED') NOT NULL DEFAULT 'ACTIVE',
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_content` text,
  `utm_term` text,
  `client_id_go` text,
  `client_id_ya` text,
  `ip` text,
  PRIMARY KEY (`tenant_id`),
  UNIQUE KEY `domain_UNIQUE` (`domain`),
  KEY `domain` (`domain`,`status`),
  KEY `tenant_id` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=677 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_additional_option`
--

DROP TABLE IF EXISTS `tbl_tenant_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_additional_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `option_id` int(11) NOT NULL,
  `expiry_date` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `started_at` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `payment_for_option_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_tenant_additional_option__tenant_id` (`tenant_id`),
  KEY `fk_tbl_tenant_additional_option__option_id` (`option_id`),
  KEY `fk_tenant_additional_option__payment_for_option_id` (`payment_for_option_id`),
  CONSTRAINT `fk_tbl_tenant_additional_option__option_id` FOREIGN KEY (`option_id`) REFERENCES `tbl_tariff_additional_option` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tenant_additional_option__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_additional_option__payment_for_option_id` FOREIGN KEY (`payment_for_option_id`) REFERENCES `tbl_payment_for_additional_option` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=367 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_admin_tariff`
--

DROP TABLE IF EXISTS `tbl_tenant_admin_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_admin_tariff` (
  `tariff_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `block` int(1) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `price` int(5) NOT NULL,
  `stuff_quantity` int(4) NOT NULL,
  `driver_quantity` int(5) NOT NULL,
  PRIMARY KEY (`tariff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_admin_tariff_changeset`
--

DROP TABLE IF EXISTS `tbl_tenant_admin_tariff_changeset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_admin_tariff_changeset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) NOT NULL,
  `tariff_id_old` int(5) NOT NULL,
  `tariff_id_new` int(5) NOT NULL,
  `option_id_old` int(8) NOT NULL,
  `option_id_new` int(8) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tariff_id_new` (`tariff_id_new`),
  KEY `tariff_id_old` (`tariff_id_old`),
  CONSTRAINT `fk_new_tariff` FOREIGN KEY (`tariff_id_new`) REFERENCES `tbl_tenant_admin_tariff` (`tariff_id`),
  CONSTRAINT `fk_old_tariff` FOREIGN KEY (`tariff_id_old`) REFERENCES `tbl_tenant_admin_tariff` (`tariff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_admin_tariff_expiration_date`
--

DROP TABLE IF EXISTS `tbl_tenant_admin_tariff_expiration_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_admin_tariff_expiration_date` (
  `tenant_id` int(11) NOT NULL AUTO_INCREMENT,
  `expiration_date` datetime NOT NULL,
  `tariff_id` int(5) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_city_has_position`
--

DROP TABLE IF EXISTS `tbl_tenant_city_has_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_city_has_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_tenant_city_has_position` (`tenant_id`,`city_id`,`position_id`),
  KEY `fk_tenant_city_has_position__city_id` (`city_id`),
  KEY `fk_tenant_city_has_position__position_id` (`position_id`),
  CONSTRAINT `fk_tenant_city_has_position__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_city_has_position__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_city_has_position__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1695 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_company`
--

DROP TABLE IF EXISTS `tbl_tenant_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_company` (
  `tenant_company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `block` int(11) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `use_logo_company` int(11) DEFAULT '0',
  PRIMARY KEY (`tenant_company_id`),
  KEY `fk_tenant_company__tenant` (`tenant_id`),
  CONSTRAINT `fk_tenant_company__tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_admin_tariff`
--

DROP TABLE IF EXISTS `tbl_tenant_has_admin_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_admin_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tariff_id` int(5) NOT NULL,
  `tenant_id` int(5) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_admin_tariff_additional_option`
--

DROP TABLE IF EXISTS `tbl_tenant_has_admin_tariff_additional_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_admin_tariff_additional_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(5) NOT NULL,
  `option_id` int(5) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_bonus_system`
--

DROP TABLE IF EXISTS `tbl_tenant_has_bonus_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_bonus_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `bonus_system_id` int(11) NOT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id` (`tenant_id`),
  KEY `fk_tenant_has_bonus_system__bonus_system_id` (`bonus_system_id`),
  CONSTRAINT `fk_tenant_has_bonus_system__bonus_system_id` FOREIGN KEY (`bonus_system_id`) REFERENCES `tbl_bonus_system` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_has_bonus_system__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_car_option`
--

DROP TABLE IF EXISTS `tbl_tenant_has_car_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_car_option` (
  `tenant_id` int(10) unsigned NOT NULL,
  `option_id` tinyint(3) unsigned NOT NULL,
  `value` int(10) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL DEFAULT '0',
  `is_active` smallint(1) DEFAULT '1',
  PRIMARY KEY (`tenant_id`,`option_id`,`city_id`),
  KEY `fk_tbl_tenant_has_tbl_car_option_tbl_car_option1_idx` (`option_id`),
  KEY `fk_tbl_tenant_has_tbl_car_option_tbl_tenant1_idx` (`tenant_id`),
  KEY `tenant_has_car_option_idx` (`tenant_id`,`city_id`),
  CONSTRAINT `fk_tbl_tenant_has_tbl_car_option_tbl_car_option1` FOREIGN KEY (`option_id`) REFERENCES `tbl_car_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tenant_has_tbl_car_option_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_city`
--

DROP TABLE IF EXISTS `tbl_tenant_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_city` (
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(10) unsigned NOT NULL,
  `sort` int(11) DEFAULT '100',
  `block` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`tenant_id`,`city_id`),
  KEY `fk_tbl_tenant_has_tbl_city_tbl_city1_idx` (`city_id`),
  KEY `fk_tbl_tenant_has_tbl_city_tbl_tenant1_idx` (`tenant_id`),
  CONSTRAINT `fk_tbl_tenant_has_tbl_city_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_city` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_extrinsic_dispatcher`
--

DROP TABLE IF EXISTS `tbl_tenant_has_extrinsic_dispatcher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_extrinsic_dispatcher` (
  `user_id` int(11) unsigned NOT NULL,
  `tenant_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`tenant_id`),
  KEY `fk_tenant_has_extrinsic_dispatcher__tenant` (`tenant_id`),
  CONSTRAINT `fk_tenant_has_extrinsic_dispatcher__tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_has_extrinsic_dispatcher__user` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_has_sms`
--

DROP TABLE IF EXISTS `tbl_tenant_has_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_has_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_id` tinyint(3) unsigned NOT NULL,
  `tenant_id` int(10) unsigned NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `sign` varchar(100) NOT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `default` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_tbl_sms_server_has_tbl_tenant_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_sms_server_has_tbl_tenant_tbl_sms_server1_idx` (`server_id`),
  KEY `FK_tenant_has_sms_idx` (`city_id`),
  CONSTRAINT `FK_tenant_has_sms` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_tbl_sms_server_has_tbl_tenant_tbl_sms_server1` FOREIGN KEY (`server_id`) REFERENCES `tbl_sms_server` (`server_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_sms_server_has_tbl_tenant_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_helper`
--

DROP TABLE IF EXISTS `tbl_tenant_helper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_helper` (
  `helper_id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `info` tinyint(1) DEFAULT '0',
  `parking` tinyint(1) DEFAULT '0',
  `worker_tariff` tinyint(1) DEFAULT '0',
  `client_tariff` tinyint(1) DEFAULT '0',
  `car` tinyint(1) DEFAULT '0',
  `worker` tinyint(1) DEFAULT '0',
  `city` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`helper_id`),
  KEY `FK_tenant_helper_idx` (`tenant_id`),
  CONSTRAINT `FK_tenant_helper_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_notification_log`
--

DROP TABLE IF EXISTS `tbl_tenant_notification_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_notification_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `type` enum('EMAIL','SMS') NOT NULL,
  `reason` enum('ADVANCE_NOTICE','TARIFF_EXPIRED_NOTICE') NOT NULL,
  `to` varchar(255) NOT NULL,
  `content` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tenant_notification_log__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_tenant_notification_log__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_payment`
--

DROP TABLE IF EXISTS `tbl_tenant_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(6) DEFAULT NULL,
  `tenant_id` int(5) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `period` int(2) NOT NULL,
  `payment_item` varchar(48) NOT NULL,
  `expiration_date` datetime NOT NULL,
  `payment_activity_begin_date` datetime DEFAULT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_permission`
--

DROP TABLE IF EXISTS `tbl_tenant_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `tenant_tariff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_tenant_permission__permission_id` (`permission_id`),
  KEY `fk_tbl_tenant_permission__tenant_tariff_id` (`tenant_tariff_id`),
  CONSTRAINT `fk_tbl_tenant_permission__permission_id` FOREIGN KEY (`permission_id`) REFERENCES `tbl_tariff_permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tenant_permission__tenant_tariff_id` FOREIGN KEY (`tenant_tariff_id`) REFERENCES `tbl_tenant_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=818 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_setting`
--

DROP TABLE IF EXISTS `tbl_tenant_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_setting` (
  `setting_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` longtext,
  `type` enum('general','orders','drivers','cars','system') DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `tbl_tenant_setting__index_unique` (`tenant_id`,`name`,`city_id`,`position_id`),
  KEY `fk_tbl_tenant_setting_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_tenant_setting_tbl_default_settings1_idx` (`name`),
  KEY `FK_tenant_setting_idx` (`city_id`),
  KEY `fk_tenant_setting__position_id` (`position_id`),
  CONSTRAINT `FK_tenant_setting` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `fk_tbl_tenant_setting_tbl_default_settings1` FOREIGN KEY (`name`) REFERENCES `tbl_default_settings` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tenant_setting_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_setting__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_softphone_config`
--

DROP TABLE IF EXISTS `tbl_tenant_softphone_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_softphone_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `server` varchar(200) NOT NULL,
  `port` int(5) NOT NULL,
  `sort` int(5) NOT NULL DEFAULT '100',
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_tenant_softphone_config_tenant_id` (`tenant_id`),
  CONSTRAINT `FK_tenant_softphone_config_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tenant_tariff`
--

DROP TABLE IF EXISTS `tbl_tenant_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tenant_tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `tariff_id` int(11) NOT NULL,
  `expiry_date` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `started_at` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `payment_for_tariff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_tenant_tariff__tenant_id` (`tenant_id`),
  KEY `fk_tbl_tenant_tariff__tariff_id` (`tariff_id`),
  KEY `fk_tenant_tariff__payment_for_tariff_id` (`payment_for_tariff_id`),
  CONSTRAINT `fk_tbl_tenant_tariff__tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_tenant_tariff__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tenant_tariff__payment_for_tariff_id` FOREIGN KEY (`payment_for_tariff_id`) REFERENCES `tbl_payment_for_tariff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=943 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transaction`
--

DROP TABLE IF EXISTS `tbl_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT NULL,
  `sender_acc_id` int(11) DEFAULT NULL,
  `receiver_acc_id` int(11) NOT NULL,
  `sum_old` float NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` varchar(255) DEFAULT NULL,
  `user_created` int(10) unsigned DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `terminal_transact_number` varchar(255) DEFAULT NULL,
  `terminal_transact_date` varchar(255) DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `sum` decimal(20,5) NOT NULL DEFAULT '0.00000',
  PRIMARY KEY (`transaction_id`),
  KEY `FK_transaction_transaction_type` (`type_id`),
  KEY `FK_transaction_sender_acc_id` (`sender_acc_id`),
  KEY `FK_transaction_receiver_acc_id` (`receiver_acc_id`),
  KEY `fk_tbl_transaction_tbl_user1_idx` (`user_created`),
  KEY `FK_billing_payment_method` (`payment_method`),
  KEY `FK_transaction_city_id_idx` (`city_id`),
  KEY `fk_transaction__order_id` (`order_id`),
  CONSTRAINT `FK_billing_payment_method` FOREIGN KEY (`payment_method`) REFERENCES `tbl_payment_method` (`payment`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `FK_transaction_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`),
  CONSTRAINT `FK_transaction_receiver_acc_id` FOREIGN KEY (`receiver_acc_id`) REFERENCES `tbl_account` (`account_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transaction_sender_acc_id` FOREIGN KEY (`sender_acc_id`) REFERENCES `tbl_account` (`account_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_transaction_transaction_type` FOREIGN KEY (`type_id`) REFERENCES `tbl_transaction_type` (`type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_transaction_tbl_user1` FOREIGN KEY (`user_created`) REFERENCES `tbl_user` (`user_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `fk_transaction__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21524 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transaction_type`
--

DROP TABLE IF EXISTS `tbl_transaction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transaction_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transport_field`
--

DROP TABLE IF EXISTS `tbl_transport_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transport_field` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` enum('int','string','text','enum') NOT NULL,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transport_field_enum`
--

DROP TABLE IF EXISTS `tbl_transport_field_enum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transport_field_enum` (
  `enum_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_has_field_id` int(11) NOT NULL COMMENT 'PK for tbl_transport_type_has_field',
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`enum_id`),
  KEY `fk_transport_field_enum_field_id` (`type_has_field_id`),
  CONSTRAINT `fk_transport_field_enum_field_id` FOREIGN KEY (`type_has_field_id`) REFERENCES `tbl_transport_type_has_field` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transport_type`
--

DROP TABLE IF EXISTS `tbl_transport_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transport_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transport_type_field_value`
--

DROP TABLE IF EXISTS `tbl_transport_type_field_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transport_type_field_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `has_field_id` int(11) NOT NULL,
  `car_id` int(10) unsigned DEFAULT NULL,
  `value_int` int(11) DEFAULT NULL,
  `value_string` varchar(255) DEFAULT NULL,
  `value_text` text,
  PRIMARY KEY (`id`),
  KEY `fk_transport_type_field_value_field_id` (`has_field_id`),
  KEY `fk_transport_type_field_value_car_id` (`car_id`),
  CONSTRAINT `fk_transport_type_field_value_car_id` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_transport_type_field_value_field_id` FOREIGN KEY (`has_field_id`) REFERENCES `tbl_transport_type_has_field` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_transport_type_has_field`
--

DROP TABLE IF EXISTS `tbl_transport_type_has_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_transport_type_has_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_type_id_field_id` (`type_id`,`field_id`),
  KEY `fk_transport_type_has_field_field_id` (`field_id`),
  CONSTRAINT `fk_transport_type_has_field_field_id` FOREIGN KEY (`field_id`) REFERENCES `tbl_transport_field` (`field_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_transport_type_has_field_type_id` FOREIGN KEY (`type_id`) REFERENCES `tbl_transport_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_uds_game_client`
--

DROP TABLE IF EXISTS `tbl_uds_game_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_uds_game_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `profile_id` varchar(20) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`),
  CONSTRAINT `fk_uds_game_client__client_id` FOREIGN KEY (`client_id`) REFERENCES `tbl_client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_uds_game_order`
--

DROP TABLE IF EXISTS `tbl_uds_game_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_uds_game_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `promo_code` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `operation_id` varchar(20) DEFAULT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  CONSTRAINT `fk_uds_game_order__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `position_id` int(10) unsigned NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_confirm` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `second_name` varchar(45) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `birth` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `auth_key` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `active_time` int(11) NOT NULL,
  `ha1` varchar(64) DEFAULT NULL,
  `ha1b` varchar(64) DEFAULT NULL,
  `auth_exp` int(11) DEFAULT NULL COMMENT 'Метка времени после которой не возможна автворизация с продающего сайта по auth_key ',
  `lang` varchar(10) DEFAULT 'en-US',
  `last_session_id` varchar(255) DEFAULT NULL,
  `md5_password` varchar(32) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `chat_email_notify` int(11) DEFAULT NULL,
  `tenant_company_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `domain_idx` (`tenant_id`),
  KEY `fk_tbl_user_tbl_user_position1_idx` (`position_id`),
  KEY `email` (`email`,`active`),
  KEY `fk_user__tenant_company` (`tenant_company_id`),
  CONSTRAINT `domain` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_user_tbl_user_position1` FOREIGN KEY (`position_id`) REFERENCES `tbl_user_position` (`position_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_user__tenant_company` FOREIGN KEY (`tenant_company_id`) REFERENCES `tbl_tenant_company` (`tenant_company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1246 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_default_right`
--

DROP TABLE IF EXISTS `tbl_user_default_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_default_right` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `position_id` int(10) unsigned NOT NULL,
  `permission` varchar(64) NOT NULL,
  `rights` enum('read','write','off') DEFAULT 'off',
  PRIMARY KEY (`id`),
  KEY `fk_tbl_user_default_right_tbl_user_position1_idx` (`position_id`),
  KEY `fk_tbl_user_default_right_tbl_auth_item1_idx` (`permission`)
) ENGINE=InnoDB AUTO_INCREMENT=769 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_dispetcher`
--

DROP TABLE IF EXISTS `tbl_user_dispetcher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_dispetcher` (
  `dispetcher_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `sip_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `host` varchar(100) NOT NULL,
  `ha1` varchar(64) NOT NULL,
  `ha1b` varchar(64) NOT NULL,
  `md5_password` varchar(32) NOT NULL,
  PRIMARY KEY (`dispetcher_id`),
  KEY `fk_user_idx` (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1463 DEFAULT CHARSET=utf8 COMMENT='Таблица диспетчеров';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_has_city`
--

DROP TABLE IF EXISTS `tbl_user_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_has_city` (
  `city_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`city_id`,`user_id`),
  KEY `fk_tbl_city_has_tbl_user_tbl_user1_idx` (`user_id`),
  CONSTRAINT `fk_tbl_city_has_tbl_user_tbl_user1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_position`
--

DROP TABLE IF EXISTS `tbl_user_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_position` (
  `position_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_profile`
--

DROP TABLE IF EXISTS `tbl_user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `community_user_id` int(11) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `automation_program` varchar(255) DEFAULT NULL,
  `community_participation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_profile_id`),
  KEY `fk_user_profile__community_user_id` (`community_user_id`),
  CONSTRAINT `fk_user_profile__community_user_id` FOREIGN KEY (`community_user_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_user_working_time`
--

DROP TABLE IF EXISTS `tbl_user_working_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_working_time` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `start_work` int(10) DEFAULT NULL,
  `end_work` int(10) DEFAULT NULL,
  `pause_data` text,
  `count_income_answered_calls` int(11) DEFAULT NULL COMMENT 'Колв-во  входящих отвечеченных',
  `count_income_noanswered_calls` int(11) DEFAULT NULL COMMENT 'Колв-во  входящих неотвеченных',
  `count_outcome_answered_calls` int(11) DEFAULT NULL COMMENT 'Колв-во  исходящих отвеченных',
  `count_outcome_noanswered_calls` int(11) DEFAULT NULL COMMENT 'Колв-во  исходящих неотвеченных',
  `count_completed_orders` int(11) DEFAULT NULL COMMENT 'Колв-во  завершенных заказов',
  `count_rejected_orders` int(11) DEFAULT NULL COMMENT 'Колв-во  отмененных заказов',
  `summ_completed_arr` varchar(255) DEFAULT NULL COMMENT 'Serrilize массив с суммой завершенных заказов',
  `summ_rejected_arr` varchar(255) DEFAULT NULL COMMENT 'Serrilize массив с суммой отмененных заказов',
  `count_income_calls` int(11) DEFAULT NULL COMMENT 'Количество вх звонков',
  `count_outcome_calls` int(11) DEFAULT NULL COMMENT 'Количество исх звонков',
  `summ_income_calls_time` int(11) DEFAULT NULL COMMENT 'Общее время вх звноков в секундах',
  `summ_outcome_calls_time` int(11) DEFAULT NULL COMMENT 'Общее время исх  звноков в секундах',
  PRIMARY KEY (`id`),
  KEY `fk_tbl_user_working_time_tbl_user1_idx` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=626 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_vote`
--

DROP TABLE IF EXISTS `tbl_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_vote` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_info_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vote` enum('plus','minus') NOT NULL,
  PRIMARY KEY (`vote_id`),
  UNIQUE KEY `idx_vote__offer_info_id__user_id` (`offer_info_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_vote__offer_info_id` FOREIGN KEY (`offer_info_id`) REFERENCES `tbl_offer_info` (`offer_info_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vote__user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_community_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1050 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_waybill`
--

DROP TABLE IF EXISTS `tbl_waybill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_waybill` (
  `waybill_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `waybill_number` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `waybill_type_id` int(10) unsigned NOT NULL,
  `waybill_label` varchar(100) DEFAULT NULL,
  `user_create_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `worker_action` varchar(100) DEFAULT NULL,
  `worker_id` int(10) DEFAULT NULL,
  `car_id` int(10) unsigned DEFAULT NULL,
  `open_time` int(11) DEFAULT NULL,
  `close_time` int(11) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `predv_time` int(11) DEFAULT NULL,
  `predv_distance` decimal(10,1) DEFAULT NULL,
  `predv_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`waybill_id`),
  KEY `fk_waybill__tenant_id` (`tenant_id`),
  KEY `fk_waybill__city_id` (`city_id`),
  KEY `fk_waybill__waybill_type_id` (`waybill_type_id`),
  KEY `fk_waybill__user_create_id` (`user_create_id`),
  KEY `fk_waybill__status_id` (`status_id`),
  KEY `fk_waybill__worker_id` (`worker_id`),
  KEY `fk_waybill__car_id` (`car_id`),
  CONSTRAINT `fk_waybill__car_id` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__status_id` FOREIGN KEY (`status_id`) REFERENCES `tbl_waybill_status` (`status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__user_create_id` FOREIGN KEY (`user_create_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__waybill_type_id` FOREIGN KEY (`waybill_type_id`) REFERENCES `tbl_waybill_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill__worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=806 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_waybill_has_order`
--

DROP TABLE IF EXISTS `tbl_waybill_has_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_waybill_has_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `waybill_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `created_at` int(11) unsigned NOT NULL,
  `updated_at` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_waybill_has_order__waybill_id` (`waybill_id`),
  KEY `fk_waybill_has_order__order_id` (`order_id`),
  CONSTRAINT `fk_waybill_has_order__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill_has_order__waybill_id` FOREIGN KEY (`waybill_id`) REFERENCES `tbl_waybill` (`waybill_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1781 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_waybill_point`
--

DROP TABLE IF EXISTS `tbl_waybill_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_waybill_point` (
  `point_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `waybill_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `address_point` text NOT NULL,
  `comment` text,
  `sort` int(11) unsigned NOT NULL,
  `created_at` int(11) unsigned NOT NULL,
  `updated_at` int(11) unsigned NOT NULL,
  `point_type` enum('start_point','end_point','order_point') NOT NULL DEFAULT 'order_point',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`point_id`),
  KEY `fk_waybill_point__waybill_id` (`waybill_id`),
  KEY `fk_waybill_point__order_id` (`order_id`),
  CONSTRAINT `fk_waybill_point__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_waybill_point__waybill_id` FOREIGN KEY (`waybill_id`) REFERENCES `tbl_waybill` (`waybill_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1770 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_waybill_status`
--

DROP TABLE IF EXISTS `tbl_waybill_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_waybill_status` (
  `status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_waybill_type`
--

DROP TABLE IF EXISTS `tbl_waybill_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_waybill_type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `fk_waybill_type__position_id` (`position_id`),
  CONSTRAINT `fk_waybill_type__position_id` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker`
--

DROP TABLE IF EXISTS `tbl_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker` (
  `worker_id` int(10) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `callsign` mediumint(8) unsigned NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `second_name` varchar(45) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `device` enum('IOS','ANDROID','WINFON') DEFAULT NULL,
  `device_token` text,
  `lang` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `device_info` varchar(255) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `partnership` enum('PARTNER','STAFF') DEFAULT 'PARTNER',
  `birthday` date DEFAULT NULL,
  `block` tinyint(1) DEFAULT '0',
  `activate` int(1) NOT NULL DEFAULT '1',
  `create_time` int(11) DEFAULT NULL,
  `card_number` varchar(45) DEFAULT NULL,
  `created_via` enum('SITE','DISPATCHER') NOT NULL DEFAULT 'DISPATCHER',
  `ya_password` int(8) unsigned DEFAULT NULL,
  `yandex_account_number` varchar(255) DEFAULT NULL,
  `tenant_company_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`worker_id`),
  UNIQUE KEY `idx_worker_ya_pssword` (`ya_password`),
  KEY `fk_tbl_worker_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_worker__tenant_company` (`tenant_company_id`),
  CONSTRAINT `fk_tbl_worker_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker__tenant_company` FOREIGN KEY (`tenant_company_id`) REFERENCES `tbl_tenant_company` (`tenant_company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=971 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_active_aboniment`
--

DROP TABLE IF EXISTS `tbl_worker_active_aboniment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_active_aboniment` (
  `aboniment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `count_active` int(10) DEFAULT NULL,
  `worker_id` int(10) NOT NULL,
  `shift_valid_to` int(11) DEFAULT NULL,
  `expired_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`aboniment_id`),
  KEY `fk_tbl_driver_tariff_idx` (`tariff_id`),
  KEY `fk_worker_active_aboniment_worker_id` (`worker_id`),
  CONSTRAINT `fk_tbl_driver_tariff` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_worker_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_active_aboniment_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=626 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_balance_notification`
--

DROP TABLE IF EXISTS `tbl_worker_balance_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_balance_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `writeoff_notify` int(11) NOT NULL DEFAULT '0',
  `deposit_notify` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_worker_balance_notification__tenant_id` (`tenant_id`),
  CONSTRAINT `fk_worker_balance_notification__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_block`
--

DROP TABLE IF EXISTS `tbl_worker_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_block` (
  `block_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `type_block` enum('pre_order','order') NOT NULL COMMENT 'тип блокировки ',
  `start_block` int(10) unsigned DEFAULT NULL,
  `end_block` int(10) unsigned DEFAULT NULL,
  `is_unblocked` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 - не разблочен, 1 -разблочен',
  `worker_id` int(10) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`block_id`),
  KEY `fk_block_shift_id` (`shift_id`),
  KEY `fk_worker_block_worker_id` (`worker_id`),
  CONSTRAINT `fk_worker_block_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1141 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_document_scan`
--

DROP TABLE IF EXISTS `tbl_worker_document_scan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_document_scan` (
  `scan_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`scan_id`),
  KEY `fk_tbl_worker_document_scan_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_document_scan_tbl_worker_has_document1` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_driver_license`
--

DROP TABLE IF EXISTS `tbl_worker_driver_license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_driver_license` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `series` varchar(20) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `category` varchar(15) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_inn_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_inn_tbl_worker_has_document11` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=473 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_group`
--

DROP TABLE IF EXISTS `tbl_worker_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `class_id` tinyint(3) unsigned DEFAULT NULL,
  `block` tinyint(1) DEFAULT NULL,
  `position_id` int(10) NOT NULL COMMENT 'PK of table "tbl_position"',
  `priority` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `FK_driver_group_tenant_id_idx` (`tenant_id`),
  KEY `FK_driver_group_class_id` (`class_id`),
  KEY `fk_worker_group_has_position` (`position_id`),
  CONSTRAINT `FK_driver_group_class_id` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_driver_group_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_group_has_position` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_group_can_view_client_tariff`
--

DROP TABLE IF EXISTS `tbl_worker_group_can_view_client_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_group_can_view_client_tariff` (
  `group_id` int(11) NOT NULL,
  `class_id` tinyint(3) unsigned NOT NULL,
  KEY `FK_driver_group_can_view_client_tariff_idx` (`group_id`,`class_id`),
  KEY `FK_driver_group_can_view_client_tariff_class_id` (`class_id`),
  CONSTRAINT `FK_driver_group_can_view_client_tariff_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_group_has_city`
--

DROP TABLE IF EXISTS `tbl_worker_group_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_group_has_city` (
  `group_id` int(11) NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  UNIQUE KEY `group_id` (`group_id`,`city_id`),
  KEY `FK_driver_group_has_city_idx` (`group_id`,`city_id`),
  KEY `FK_driver_group_has_city_id` (`city_id`),
  CONSTRAINT `FK_driver_group_has_city_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_driver_group_has_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_group_has_tariff`
--

DROP TABLE IF EXISTS `tbl_worker_group_has_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_group_has_tariff` (
  `group_id` int(11) NOT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  KEY `FK_driver_group_has_tariff_idx` (`group_id`,`tariff_id`),
  KEY `FK_driver_group_has_tariff_id` (`tariff_id`),
  CONSTRAINT `FK_driver_group_has_tariff_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_driver_group_has_tariff_id` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_worker_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_has_car`
--

DROP TABLE IF EXISTS `tbl_worker_has_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_has_car` (
  `has_position_id` int(11) NOT NULL,
  `car_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`has_position_id`,`car_id`),
  KEY `fk_tbl_worker_has_positon_has_tbl_car_tbl_car1_idx` (`car_id`),
  KEY `fk_tbl_worker_has_positon_has_tbl_car_tbl_worker_has_posito_idx` (`has_position_id`),
  CONSTRAINT `fk_tbl_worker_has_positon_has_tbl_car_tbl_car1` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_has_car_position` FOREIGN KEY (`has_position_id`) REFERENCES `tbl_worker_has_position` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_has_city`
--

DROP TABLE IF EXISTS `tbl_worker_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_has_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_id` int(11) NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `last_active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_worker_has_city__worker_id__city_id` (`worker_id`,`city_id`),
  KEY `fk_worker_has_city__city_id` (`city_id`),
  CONSTRAINT `fk_worker_has_city__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_has_city__worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1055 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_has_document`
--

DROP TABLE IF EXISTS `tbl_worker_has_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_has_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_id` int(10) NOT NULL,
  `document_id` int(11) NOT NULL,
  `has_position_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_worker_has_document_worker_id_document_id_has_position_id` (`worker_id`,`document_id`,`has_position_id`),
  KEY `fk_tbl_worker_has_tbl_document_tbl_document1_idx` (`document_id`),
  KEY `fk_tbl_worker_has_tbl_document_tbl_worker1_idx` (`worker_id`),
  KEY `fk_tbl_worker_has_document_tbl_worker_has_position1_idx` (`has_position_id`),
  CONSTRAINT `fk_tbl_worker_has_document_has_position` FOREIGN KEY (`has_position_id`) REFERENCES `tbl_worker_has_position` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_worker_has_tbl_document_tbl_document1` FOREIGN KEY (`document_id`) REFERENCES `tbl_document` (`document_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_worker_has_tbl_document_tbl_worker1` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4013 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_has_position`
--

DROP TABLE IF EXISTS `tbl_worker_has_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_has_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `group_id` int(11) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tbl_worker_has_position_worker_id_position_id` (`worker_id`,`position_id`),
  KEY `fk_tbl_worker_has_positon_tbl_worker1_idx` (`worker_id`),
  KEY `fk_tbl_worker_has_positon_tbl_position1_idx` (`position_id`),
  KEY `fk_worker_has_position_group_id` (`group_id`),
  CONSTRAINT `fk_tbl_worker_has_positon_tbl_position1` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_worker_has_positon_tbl_worker1` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_has_position_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1117 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_inn`
--

DROP TABLE IF EXISTS `tbl_worker_inn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_inn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `number` int(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_inn_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_inn_tbl_worker_has_document1` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_medical_certificate`
--

DROP TABLE IF EXISTS `tbl_worker_medical_certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_medical_certificate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `number` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_ogrnip_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_ogrnip_tbl_worker_has_document10` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=428 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_ogrnip`
--

DROP TABLE IF EXISTS `tbl_worker_ogrnip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_ogrnip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `number` int(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_ogrnip_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_ogrnip_tbl_worker_has_document1` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=612 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_option_discount`
--

DROP TABLE IF EXISTS `tbl_worker_option_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_option_discount` (
  `discount_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `car_option_id` tinyint(3) unsigned NOT NULL COMMENT 'Опция авто',
  `option_id` int(10) unsigned NOT NULL,
  `discount_line_type` enum('PERCENT','MONEY') DEFAULT 'PERCENT',
  `discount_order_type` enum('PERCENT','MONEY') DEFAULT 'PERCENT',
  `discount_line` decimal(10,0) DEFAULT '0',
  `discount_order` decimal(10,0) DEFAULT '0',
  PRIMARY KEY (`discount_id`),
  KEY `fk_tbl_driver_option_discount_tbl_car_option1_idx` (`car_option_id`),
  KEY `fk_tbl_driver_option_discount_tbl_driver_option_tariff1_idx` (`option_id`),
  CONSTRAINT `fk_tbl_driver_option_discount_tbl_car_option1` FOREIGN KEY (`car_option_id`) REFERENCES `tbl_car_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_driver_option_discount_tbl_driver_option_tariff1` FOREIGN KEY (`option_id`) REFERENCES `tbl_worker_option_tariff` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1994 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_option_tariff`
--

DROP TABLE IF EXISTS `tbl_worker_option_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_option_tariff` (
  `option_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tariff_id` int(10) unsigned NOT NULL,
  `tariff_type` enum('CURRENT','HOLIDAYS','EXCEPTIONS') NOT NULL,
  `active_date` text,
  `increase_order_sum` decimal(10,2) DEFAULT NULL,
  `increase_sum_limit` decimal(10,2) DEFAULT NULL,
  `increase_sum_fix` decimal(10,2) DEFAULT NULL,
  `increase_sum_fix_type` enum('PERCENT','MONEY') NOT NULL DEFAULT 'PERCENT',
  `sort` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`option_id`),
  KEY `fk_tbl_driver_option_tariff_tbl_driver_tariff1_idx` (`tariff_id`),
  CONSTRAINT `fk_tbl_driver_option_tariff_tbl_driver_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_worker_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=529 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_osago`
--

DROP TABLE IF EXISTS `tbl_worker_osago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_osago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `series` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_inn_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_inn_tbl_worker_has_document100` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=465 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_passport`
--

DROP TABLE IF EXISTS `tbl_worker_passport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_passport` (
  `passport_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `series` varchar(5) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  `issued` text,
  `registration` text,
  `actual_address` text,
  PRIMARY KEY (`passport_id`),
  KEY `fk_tbl_worker_passport_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_passport_tbl_worker_has_document1` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=572 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_position_field_value`
--

DROP TABLE IF EXISTS `tbl_worker_position_field_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_position_field_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `has_position_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value_int` int(11) DEFAULT NULL,
  `value_string` varchar(255) DEFAULT NULL,
  `value_text` text,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_has_positon_has_tbl_position_field_tbl_positi_idx` (`field_id`),
  KEY `fk_tbl_worker_has_positon_has_tbl_position_field_tbl_worker_idx` (`has_position_id`),
  CONSTRAINT `fk_tbl_worker_has_positon_has_tbl_position_field_tbl_position1` FOREIGN KEY (`field_id`) REFERENCES `tbl_position_field` (`field_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_pts`
--

DROP TABLE IF EXISTS `tbl_worker_pts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_pts` (
  `pts_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) DEFAULT NULL,
  `series` varchar(5) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pts_id`),
  KEY `fk_tbl_worker_pts_tbl_worker_has_document8_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_pts_tbl_worker_has_document8_idx` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_push_notifications`
--

DROP TABLE IF EXISTS `tbl_worker_push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_push_notifications` (
  `push_id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `tenant_id` int(10) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`push_id`),
  KEY `FK_tenant_id_worker_push_notifications` (`tenant_id`),
  KEY `FK_city_id_worker_push_notifications` (`city_id`),
  KEY `FK_position_id_worker_push_notifications` (`position_id`),
  CONSTRAINT `FK_city_id_worker_push_notifications` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_position_id_worker_push_notifications` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tenant_id_worker_push_notifications` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=528 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_refuse_order`
--

DROP TABLE IF EXISTS `tbl_worker_refuse_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_refuse_order` (
  `refuse_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `refuse_time` int(10) NOT NULL,
  `refuse_subject` enum('driver','timer') NOT NULL COMMENT 'timer - не успел принять, driver- сам отказался',
  `worker_id` int(10) NOT NULL,
  PRIMARY KEY (`refuse_id`),
  KEY `fk_shift` (`shift_id`),
  KEY `fk_order` (`order_id`),
  KEY `fk_worker_refuse_order_worker_id` (`worker_id`),
  CONSTRAINT `fk_worker_refuse_order_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2557 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_review_rating`
--

DROP TABLE IF EXISTS `tbl_worker_review_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_review_rating` (
  `rating_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `worker_id` int(10) NOT NULL,
  `one` int(10) unsigned DEFAULT '0',
  `two` int(10) unsigned DEFAULT '0',
  `three` int(10) unsigned DEFAULT '0',
  `four` int(10) unsigned DEFAULT '0',
  `five` int(10) unsigned DEFAULT '0',
  `count` int(10) unsigned DEFAULT '0',
  `position_id` int(10) NOT NULL COMMENT 'PK of table "tbl_position"',
  PRIMARY KEY (`rating_id`),
  KEY `fk_tbl_driver_review_raiting_tbl_driver1_idx` (`worker_id`),
  KEY `fk_worker_review_rating_position` (`position_id`),
  CONSTRAINT `fk_tbl_worker_review_rating_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_review_rating_position` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_shift`
--

DROP TABLE IF EXISTS `tbl_worker_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_shift` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `worker_id` int(11) DEFAULT NULL,
  `car_id` int(10) unsigned DEFAULT NULL,
  `start_work` int(11) NOT NULL,
  `end_work` int(11) DEFAULT NULL,
  `tariff_id` int(10) unsigned NOT NULL,
  `pause_data` text,
  `position_id` int(10) NOT NULL COMMENT 'PK of table "tbl_position"',
  `worker_late_time` int(11) NOT NULL DEFAULT '0',
  `worker_late_count` int(11) NOT NULL DEFAULT '0',
  `completed_order_count` int(11) NOT NULL DEFAULT '0',
  `rejected_order_count` int(11) NOT NULL DEFAULT '0',
  `accepted_order_offer_count` int(11) NOT NULL DEFAULT '0',
  `rejected_order_offer_count` int(11) NOT NULL DEFAULT '0',
  `order_payment_time` int(11) NOT NULL DEFAULT '0',
  `order_payment_count` int(11) NOT NULL DEFAULT '0',
  `shift_end_reason` enum('timer','bad_coords','bad_parking','operator_service','worker_service') DEFAULT NULL,
  `shift_end_event_sender_type` enum('system','user','worker') DEFAULT NULL,
  `shift_end_event_sender_id` int(11) DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `group_priority` int(11) DEFAULT NULL,
  `position_priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_driver_shift_tbl_driver1_idx` (`worker_id`),
  KEY `fk_tbl_tariff_id_idx` (`tariff_id`),
  KEY `start_work` (`start_work`,`end_work`),
  KEY `fk_worker_shift_has_position` (`position_id`),
  KEY `fk_worker_shift__city_id` (`city_id`),
  KEY `fk_worker_shift__group_id` (`group_id`),
  CONSTRAINT `fk_worker_shift__city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_shift__group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_worker_group` (`group_id`),
  CONSTRAINT `fk_worker_shift_has_position` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10286 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_shift_order`
--

DROP TABLE IF EXISTS `tbl_worker_shift_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_shift_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `fk_worker_shift_order__shift_id` (`shift_id`),
  CONSTRAINT `fk_worker_shift_order__order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_shift_order__shift_id` FOREIGN KEY (`shift_id`) REFERENCES `tbl_worker_shift` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62477 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_snils`
--

DROP TABLE IF EXISTS `tbl_worker_snils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_snils` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) NOT NULL,
  `number` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tbl_worker_inn_tbl_worker_has_document1_idx` (`worker_document_id`),
  CONSTRAINT `fk_tbl_worker_inn_tbl_worker_has_document10` FOREIGN KEY (`worker_document_id`) REFERENCES `tbl_worker_has_document` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=540 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_tariff`
--

DROP TABLE IF EXISTS `tbl_worker_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_tariff` (
  `tariff_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `type` enum('ONCE','SUBSCRIPTION') DEFAULT 'ONCE',
  `block` tinyint(1) DEFAULT '0',
  `days` int(10) unsigned DEFAULT NULL,
  `description` text,
  `position_id` int(10) NOT NULL COMMENT 'PK of table "tbl_position"',
  `period_type` enum('INTERVAL','HOURS') NOT NULL,
  `period` varchar(45) NOT NULL,
  `cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subscription_limit_type` enum('SHIFT_COUNT','DAY_COUNT') DEFAULT NULL,
  `tenant_company_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`tariff_id`),
  KEY `fk_tbl_driver_tariff_tbl_tenant1_idx` (`tenant_id`),
  KEY `fk_tbl_driver_tariff_tbl_car_class1_idx` (`class_id`),
  KEY `fk_worker_tariff_has_position` (`position_id`),
  KEY `fk_worker_tariff__tenant_company` (`tenant_company_id`),
  CONSTRAINT `fk_tbl_driver_tariff_tbl_car_class1` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_driver_tariff_tbl_tenant1` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_tariff__tenant_company` FOREIGN KEY (`tenant_company_id`) REFERENCES `tbl_tenant_company` (`tenant_company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_worker_tariff_car_class` FOREIGN KEY (`class_id`) REFERENCES `tbl_car_class` (`class_id`),
  CONSTRAINT `fk_worker_tariff_has_position` FOREIGN KEY (`position_id`) REFERENCES `tbl_position` (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=370 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_worker_tariff_has_city`
--

DROP TABLE IF EXISTS `tbl_worker_tariff_has_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_worker_tariff_has_city` (
  `tariff_id` int(10) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`tariff_id`,`city_id`),
  KEY `fk_tbl_driver_tariff_has_tbl_city_tbl_city1_idx` (`city_id`),
  KEY `fk_tbl_driver_tariff_has_tbl_city_tbl_driver_tariff1_idx` (`tariff_id`),
  CONSTRAINT `fk_tbl_driver_tariff_has_tbl_city_tbl_city1` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_driver_tariff_has_tbl_city_tbl_driver_tariff1` FOREIGN KEY (`tariff_id`) REFERENCES `tbl_worker_tariff` (`tariff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_ya_car`
--

DROP TABLE IF EXISTS `tbl_ya_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ya_car` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `car_id` int(10) unsigned DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `tenant_id` int(10) unsigned DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ya_car_uuid` (`uuid`),
  KEY `fk_ya_car_car_id` (`car_id`),
  KEY `fk_ya_car_city_id` (`city_id`),
  KEY `idx_ya_car_city_id_tenant_id` (`tenant_id`,`city_id`),
  KEY `idx_ya_car_uuid_city_id_tenant_id` (`tenant_id`,`city_id`,`uuid`),
  CONSTRAINT `fk_ya_car_car_id` FOREIGN KEY (`car_id`) REFERENCES `tbl_car` (`car_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ya_car_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ya_car_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1662 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_ya_driver`
--

DROP TABLE IF EXISTS `tbl_ya_driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ya_driver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `worker_id` int(10) DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `tenant_id` int(10) unsigned DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ya_driver_uuid` (`uuid`),
  KEY `fk_ya_driver_worker_id` (`worker_id`),
  KEY `fk_ya_driver_city_id` (`city_id`),
  KEY `idx_ya_driver_city_id_tenant_id` (`tenant_id`,`city_id`),
  KEY `idx_ya_driver_uuid_city_id_tenant_id` (`tenant_id`,`city_id`,`uuid`),
  CONSTRAINT `fk_ya_driver_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ya_driver_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ya_driver_worker_id` FOREIGN KEY (`worker_id`) REFERENCES `tbl_worker` (`worker_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1698 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_ya_order`
--

DROP TABLE IF EXISTS `tbl_ya_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ya_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `city_id` int(11) unsigned DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ya_order_uuid_city_id` (`city_id`,`uuid`),
  KEY `fk_ya_order_order_id` (`order_id`),
  CONSTRAINT `fk_ya_order_city_id` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`city_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ya_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__category`
--

DROP TABLE IF EXISTS `tenant_tariff__category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__order`
--

DROP TABLE IF EXISTS `tenant_tariff__order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(10) unsigned NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `order_date` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_tenant_tariff__order` (`order_number`,`order_date`),
  KEY `fk_tenant_tariff__order__tenant_id` (`tenant_id`),
  KEY `fk_tenant_tariff__order__order_status_id` (`order_status_id`),
  KEY `fk_tenant_tariff__order__currency_id` (`currency_id`),
  CONSTRAINT `fk_tenant_tariff__order__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tenant_tariff__order__order_status_id` FOREIGN KEY (`order_status_id`) REFERENCES `tenant_tariff__order_status` (`id`),
  CONSTRAINT `fk_tenant_tariff__order__tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tbl_tenant` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__order_has_product`
--

DROP TABLE IF EXISTS `tenant_tariff__order_has_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__order_has_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tenant_tariff__order_has_product__order_id` (`order_id`),
  KEY `fk_tenant_tariff__order_has_product__product_id` (`product_id`),
  KEY `fk_tenant_tariff__order_has_product__currency_id` (`currency_id`),
  CONSTRAINT `fk_tenant_tariff__order_has_product__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`),
  CONSTRAINT `fk_tenant_tariff__order_has_product__order_id` FOREIGN KEY (`order_id`) REFERENCES `tenant_tariff__order` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tenant_tariff__order_has_product__product_id` FOREIGN KEY (`product_id`) REFERENCES `tenant_tariff__product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__order_status`
--

DROP TABLE IF EXISTS `tenant_tariff__order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__payment`
--

DROP TABLE IF EXISTS `tenant_tariff__payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `payment_number` int(11) NOT NULL,
  `payment_date` int(11) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  CONSTRAINT `fk_tenant_tariff__payment__order_id` FOREIGN KEY (`order_id`) REFERENCES `tenant_tariff__order` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__price`
--

DROP TABLE IF EXISTS `tenant_tariff__price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_tenant_tariff__price` (`product_id`,`currency_id`),
  KEY `fk_tenant_tariff__price__currency_id` (`currency_id`),
  CONSTRAINT `fk_tenant_tariff__price__currency_id` FOREIGN KEY (`currency_id`) REFERENCES `tbl_currency` (`currency_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tenant_tariff__price__product_id` FOREIGN KEY (`product_id`) REFERENCES `tenant_tariff__product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__product`
--

DROP TABLE IF EXISTS `tenant_tariff__product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `active` int(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tenant_tariff__product__module_id` (`module_id`),
  KEY `fk_tenant_tariff__product__category_id` (`category_id`),
  CONSTRAINT `fk_tenant_tariff__product__category_id` FOREIGN KEY (`category_id`) REFERENCES `tenant_tariff__category` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tenant_tariff__product__module_id` FOREIGN KEY (`module_id`) REFERENCES `tbl_module` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__specification`
--

DROP TABLE IF EXISTS `tenant_tariff__specification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__specification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `specification_type_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_tenant_tariff__specification` (`product_id`,`specification_type_id`),
  KEY `fk_tenant_tariff__specification__specification_type_id` (`specification_type_id`),
  CONSTRAINT `fk_tenant_tariff__specification__product_id` FOREIGN KEY (`product_id`) REFERENCES `tenant_tariff__product` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tenant_tariff__specification__specification_type_id` FOREIGN KEY (`specification_type_id`) REFERENCES `tenant_tariff__specification_type` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_tariff__specification_type`
--

DROP TABLE IF EXISTS `tenant_tariff__specification_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_tariff__specification_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_tenant_tariff__specification_type__category_id` (`category_id`),
  CONSTRAINT `fk_tenant_tariff__specification_type__category_id` FOREIGN KEY (`category_id`) REFERENCES `tenant_tariff__category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worker_pts`
--

DROP TABLE IF EXISTS `worker_pts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_pts` (
  `pts_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_document_id` int(11) DEFAULT NULL,
  `series` varchar(5) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-08 13:41:06
