-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: db2.taxi.lcl    Database: taxi
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.25-MariaDB-1~wheezy

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `tbl_account_kind`
--

LOCK TABLES `tbl_account_kind` WRITE;
/*!40000 ALTER TABLE `tbl_account_kind` DISABLE KEYS */;
INSERT INTO `tbl_account_kind` VALUES (1,'TENANT'),(2,'DRIVER'),(3,'CLIENT'),(4,'COMPANY'),(5,'SYSTEM'),(6,'GOOTAX'),(7,'CLIENT BONUS'),(8,'SYSTEM BONUS'),(9,'CLIENT_BONUS_UDS_GAME'),(10,'SYSTEM_BONUS_UDS_GAME');
/*!40000 ALTER TABLE `tbl_account_kind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_account_type`
--

LOCK TABLES `tbl_account_type` WRITE;
/*!40000 ALTER TABLE `tbl_account_type` DISABLE KEYS */;
INSERT INTO `tbl_account_type` VALUES (1,'ACTIVE'),(2,'PASSIVE');
/*!40000 ALTER TABLE `tbl_account_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_operation_type`
--

LOCK TABLES `tbl_operation_type` WRITE;
/*!40000 ALTER TABLE `tbl_operation_type` DISABLE KEYS */;
INSERT INTO `tbl_operation_type` VALUES (1,'Income'),(2,'Expenses'),(3,'Cash out');
/*!40000 ALTER TABLE `tbl_operation_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_transaction_type`
--

LOCK TABLES `tbl_transaction_type` WRITE;
/*!40000 ALTER TABLE `tbl_transaction_type` DISABLE KEYS */;
INSERT INTO `tbl_transaction_type` VALUES (1,'DEPOSIT'),(2,'WITHDRAWAL'),(3,'ORDER_PAYMENT'),(4,'GOOTAX_PAYMENT'),(5,'BONUS_TRANSFER');
/*!40000 ALTER TABLE `tbl_transaction_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_payment_method`
--

LOCK TABLES `tbl_payment_method` WRITE;
/*!40000 ALTER TABLE `tbl_payment_method` DISABLE KEYS */;
INSERT INTO `tbl_payment_method` VALUES ('BONUS','Bonus'),('CARD','Bank card'),('CASH','Cash'),('CORP_BALANCE','Company account'),('PERSONAL_ACCOUNT','Personal account'),('TERMINAL_ELECSNET','Elecsnet'),('TERMINAL_MILLION','Million'),('TERMINAL_PAYNET','PayNet'),('TERMINAL_QIWI','QIWI'),('WITHDRAWAL','Withdrawal'),('WITHDRAWAL_FOR_CASH_OUT','Cash out'),('WITHDRAWAL_FOR_TARIFF','Withdrawal for tariff');
/*!40000 ALTER TABLE `tbl_payment_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_bonus_system`
--

LOCK TABLES `tbl_bonus_system` WRITE;
/*!40000 ALTER TABLE `tbl_bonus_system` DISABLE KEYS */;
INSERT INTO `tbl_bonus_system` VALUES (1,'Gootax',1472309556,1472309556),(2,'UDS Game',1472309556,1472309556);
/*!40000 ALTER TABLE `tbl_bonus_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tbl_sms_server`
--

LOCK TABLES `tbl_sms_server` WRITE;
/*!40000 ALTER TABLE `tbl_sms_server` DISABLE KEYS */;
INSERT INTO `tbl_sms_server` VALUES (1,'СМС Дисконт',120,'http://iqsms.ru',1),(2,'Ibatele',50,'http://ibatele.com',1),(3,'Sapsan',100,'http://lk.sms-sapsan.ru/',1),(4,'EyeLine Communications Bel',100,'http://eyeline.mobi/',1),(5,'QuickTelecom',60,'http://go.qtelecom.ru',1),(6,'MSM (Азербайджан) ',100,'msm.az',1),(7,'Bulk (Romania)',100,'http://gw1.unifun.com:11480/BulkSMSAPI/Unifun',1),(8,'SMS Gateway (Узбекистан)',100,'http://www.smsg.uz/',1),(9,'Motive.az (Азербайджан)',100,'http://motive.az/',1),(10,'Ibatele (smpp)',51,'http://ibatele.com',1),(11,'Clickatell',100,'clickatell.com',1),(12,'Smsc.ru',100,'http://smsc.ru',1),(13,'GoSMS.cz',100,'http://gosms.cz',1),(14,'bsg.world',100,'http://bsg.world',1),(15,'Magfa.com',100,'https://messaging.magfa.com',1),(16,'АльфаSMS',100,'https://alphasms.ua/',1),(17,'QuickTelecom(Kuban)',101,'http://kuban.qtelecom.ru',1),(18,'PromoSMS',100,'http://promosms.ru/',1),(19,'Megafon.tj (SMPP)',100,'10.241.201.184:2775',1),(20,'Playmobile.uz (Узбекистан)',100,'http://playmobile.uz',1),(21,'Comtass (Sudan - http://comtass.com)',100,'http://comtass.com',1),(22,'MediaSend.kz',100,'https://mediasend.kz',1),(23,'Nikita.am',100,'http://nikita.am/',1),(24,'SmsLine(Беларусь)',100,'https://mobilemarketing.by/',1);
/*!40000 ALTER TABLE `tbl_sms_server` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-08 13:41:06
