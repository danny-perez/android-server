<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
?>

<p><?=t('email', 'Hello', NULL, $data['LANGUAGE'])?>, <?= Html::encode($data['NAME']) ?>!</p>

<p><?=t('email', 'To change your password please follow link', NULL, $data['LANGUAGE'])?>:</p>

<p><?= Html::a($data['URL'], $data['URL']) ?></p>
