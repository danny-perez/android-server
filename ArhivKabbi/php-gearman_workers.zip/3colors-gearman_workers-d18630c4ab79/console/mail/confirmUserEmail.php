<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user app\modules\user\models\User */
?>

<p><?=t('email', 'Hello', null, $data['LANGUAGE'])?>, <?= Html::encode($data['NAME']) ?>!</p>

<p><?=t('email', 'To confirm your registration please follow link', null, $data['LANGUAGE'])?>: <?= Html::a($data['URL'], $data['URL']) ?></p>

<?php if(!empty($data['PASSWORD'])):?>
    <p><?=t('email', 'Your password', null, $data['LANGUAGE'])?>: <?=$data['PASSWORD']?></p>
<?php endif?>

<p><?=t('email', 'If you have not registered on this site, please ignore this message', null, $data['LANGUAGE'])?>.</p>