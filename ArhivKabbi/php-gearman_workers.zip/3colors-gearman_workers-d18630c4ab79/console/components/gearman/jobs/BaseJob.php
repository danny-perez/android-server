<?php

namespace gearman\jobs;

use yii\base\Object;

/**
 * Class BaseJob
 * @package gearman\jobs
 */
abstract class BaseJob extends Object
{
    const ACTION_PING = 'ping';
    const RESULT_PING = 'ok';

    /**
     * @var \GearmanJob
     */
    private $job;

    /**
     * @param array $data
     *
     * @return mixed
     */
    abstract public function execute(array $data);

    /**
     * @return array
     */
    private function getJobData()
    {
        $data = json_decode($this->job->workload(), true);

        return empty($data) ? [] : $data;
    }

    /**
     * @param array $data
     *
     * @return bool
     */
    private function isPingAction(array $data)
    {
        return isset($data['action']) && $data['action'] === self::ACTION_PING;
    }

    /**
     * @param \GearmanJob $job
     *
     * @return mixed
     */
    final public function run(\GearmanJob $job)
    {
        $this->job = $job;
        $data      = $this->getJobData();

        if ($this->isPingAction($data)) {
            return self::RESULT_PING;
        }

        return $this->execute($data);
    }

}