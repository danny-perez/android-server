<?php

namespace gearman\jobs;

use Ramsey\Uuid\Uuid;
use yii\base\Application;
use yii\base\InvalidConfigException;
use yii\base\InvalidParamException;

/**
 * Class EmailJob
 * @package gearman\jobs
 */
class EmailJob extends BaseJob
{
    /**
     * @var Application
     */
    private $application;

    /**
     * EmailJob constructor.
     *
     * @param Application $application
     * @param array       $config
     */
    public function __construct(Application $application, array $config = [])
    {
        parent::__construct($config);

        $this->application = $application;
    }

    /**
     * @param array $data
     *
     * @return mixed|void
     * @throws InvalidParamException
     * @throws InvalidConfigException
     */
    public function execute(array $data)
    {
        $language      = isset($data['DATA']['LANGUAGE']) ? $data['DATA']['LANGUAGE'] : $this->application->language;
        $defaultLayout = $this->application->mailer->htmlLayout;
        $layout        = isset($data['LAYOUT']) ? $data['LAYOUT'] : $defaultLayout;
        $template      = isset($data['TEMPLATE']) ? $data['TEMPLATE'] : null;
        $mailData      = isset($data['DATA']) ? $data['DATA'] : null;
        $to            = isset($data['TO']) ? $data['TO'] : null;
        $subject       = isset($data['SUBJECT']) ? $data['SUBJECT'] : null;
        $files         = isset($data['DATA']['FILES']) ? $data['DATA']['FILES'] : [];

        $this->application->language           = $language;
        $this->application->mailer->htmlLayout = $layout;

        $message = $this->application->mailer->compose($template, ['data' => $mailData])
            ->setFrom([$this->application->params['mail.infoEmail'] => $this->application->name])
            ->setTo($to)
            ->setSubject($subject);

        $attachmentPath = $this->application->params['mail.attachmentPath'];
        foreach ($files as $filename) {
            $filename = \Yii::getAlias($attachmentPath . $filename);
            $message->attach($filename);
        }

        $requestId = array_key_exists('requestId', $data) ? $data['requestId'] : Uuid::uuid4()->toString();
        if ($message->send()) {
            applicationLog("[email] requestId={$requestId} Successful email sending: to={$to}, subject={$subject}");
        } else {
            applicationLog("[email] requestId={$requestId} Email sending error: to={$to}, subject={$subject}");
        }

        $this->application->mailer->htmlLayout = $defaultLayout;
    }

}
