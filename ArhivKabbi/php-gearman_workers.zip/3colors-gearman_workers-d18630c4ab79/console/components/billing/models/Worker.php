<?php

namespace console\components\billing\models;

use console\components\billing\Account;
use Yii;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "tbl_worker".
 *
 * @property integer   $worker_id
 * @property integer   $tenant_id
 * @property integer   $callsign
 * @property string    $password
 * @property string    $last_name
 * @property string    $name
 * @property string    $second_name
 * @property string    $phone
 * @property string    $photo
 * @property string    $device
 * @property string    $device_token
 * @property string    $lang
 * @property string    $description
 * @property string    $device_info
 * @property string    $email
 * @property string    $partnership
 * @property string    $birthday
 * @property integer   $block
 * @property integer   $create_time
 * @property string    $yandex_account_number
 *
 * @property Account[] $accounts
 */
class Worker extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'callsign', 'phone'], 'required'],
            [['tenant_id', 'callsign', 'block', 'create_time'], 'integer'],
            [['device', 'device_token', 'partnership', 'yandex_account_number'], 'string'],
            [['birthday'], 'safe'],
            [['password', 'photo', 'description', 'device_info'], 'string', 'max' => 255],
            [['last_name', 'name', 'second_name', 'email'], 'string', 'max' => 45],
            [['phone'], 'string', 'max' => 15],
            [['lang'], 'string', 'max' => 10],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'worker_id'    => 'Worker ID',
            'tenant_id'    => 'Tenant ID',
            'callsign'     => 'Callsign',
            'password'     => 'Password',
            'last_name'    => 'Last Name',
            'name'         => 'Name',
            'second_name'  => 'Second Name',
            'phone'        => 'Phone',
            'photo'        => 'Photo',
            'device'       => 'Device',
            'device_token' => 'Device Token',
            'lang'         => 'Lang',
            'description'  => 'Description',
            'device_info'  => 'Device Info',
            'email'        => 'Email',
            'partnership'  => 'Partnership',
            'birthday'     => 'Birthday',
            'block'        => 'Block',
            'create_time'  => 'Create Time',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAccounts()
    {
        return $this->hasMany(Account::className(), ['owner_id' => 'worker_id'])
            ->andOnCondition([Account::tableName() . '.acc_kind_id' => Account::WORKER_KIND]);
    }
}
