<?php

namespace credit;

/**
 * Class UnknownCreditServiceTypeException
 * @package credit
 */
class UnknownCreditServiceTypeException extends \Exception
{

}