<?php

namespace referralSystem\exceptions;

/**
 * Class UnknownBonusValueTypeException
 * @package referralSystem\exceptions
 */
class UnknownBonusValueTypeException extends \DomainException
{

}