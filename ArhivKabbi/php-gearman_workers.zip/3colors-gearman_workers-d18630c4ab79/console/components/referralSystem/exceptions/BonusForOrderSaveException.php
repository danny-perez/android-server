<?php

namespace referralSystem\exceptions;

/**
 * Class BonusForOrderSaveException
 * @package referralSystem\exceptions
 */
class BonusForOrderSaveException extends \DomainException
{

}