<?php

namespace console\modules\sms\models\gosms;

use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Psr7\Request;
use Yii;

class Gosms
{
    const BASE_URL = 'https://app.gosms.cz/';

    private $_token = [];
    

    // Получение токена
    private function getToken($login, $password)
    {
        if(empty( $this->_token[$login][$password] )) {
            $curl = app()->curl;
            $params = [
                'client_id' => $login,
                'client_secret' => $password,
                'grant_type' => 'client_credentials',
            ];
            /* @var $response \console\components\curl\CurlResponse */
            $response = $curl->get(self::BASE_URL . 'oauth/v2/token', $params);

            if (!empty($response)) {
                $response = json_decode($response, true);

                if(isset($response['error'])) {
                    return [
                        'error' => 1,
                        'msg' => $response['error']
                    ];
                }

                $this->_token[$login][$password] = $response['access_token'];
                return [
                    'error' => 0,
                    'token' => $this->_token[$login][$password],
                ];
            }
        }
    }

    public function sendSms($login, $password, $text, $phone) {

        $login = explode('-', $login,2);
        list($chanel, $username) = $login;
        $result = $this->getToken($username, $password);

        if($result['error'] == 1) {
            return $result;
        }
        $params = [
            'message' => urldecode($text),
            'recipients' => $phone,
            'channel' => (int)$chanel,
        ];
        $body = json_encode($params);
        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $result['token'],
        ];

        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->request('POST', self::BASE_URL . 'api/v1/messages/', [
                'headers' => $headers,
                'body'  => $body,
            ]);
            return [
                'error' => 0,
                'msg' => '',
            ];
        } catch (ClientException $ex) {
            $resBody  = \GuzzleHttp\json_decode($ex->getResponse()->getBody(), true);
            return [
                'error' => 1,
                'msg' => $resBody['detail'],
            ];
        } catch (\Exception $ex) {
            return [
                'error' => 1,
                'msg' => 'Other'
            ];
        }
    }


}
