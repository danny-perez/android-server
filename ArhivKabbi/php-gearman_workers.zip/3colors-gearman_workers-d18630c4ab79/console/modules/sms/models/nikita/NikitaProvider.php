<?php

namespace console\modules\sms\models\nikita;

use console\modules\sms\models\smsbroker\SmsBrokerProvider;

class NikitaProvider extends SmsBrokerProvider
{
    public function init()
    {
        parent::init();
        $this->gate = new Nikita();
    }
}
