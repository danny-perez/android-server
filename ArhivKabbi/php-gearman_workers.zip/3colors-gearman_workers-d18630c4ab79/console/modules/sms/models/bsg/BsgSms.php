<?php

namespace console\modules\sms\models\bsg;

use Yii;

class BsgSms
{
    const BASE_URL = 'http://app.bsg.hk/xml';

    public function sendSms($login, $password, $text, $phone, $sender)
    {
        $body = '<?xml version = "1.0" encoding = "utf-8"?>
            <request>
            <message type = "sms">
            <sender>' . $sender . '</sender>
            <text>' . $text . '</text>
            <abonent phone = "' . $phone . '" number_sms="1"/>
            </message>
            <security>
            <login value="' . $login . '"/>
            <password value="' . $password . '"/>
            </security>
            </request>';
        return $this->send('', $body);
    }

    public function getBalance($login, $password)
    {
        $body = '<?xml version="1.0" encoding="utf-8"?>
            <request>
            <security>
            <login value="' . $login . '"/>
            <password value="' . $password . '"/>
            </security>
            </request>';
        return $this->send('balance', $body);
    }

    private function send($method, $body)
    {
        $url = self::BASE_URL . '/' . $method;
        $headers = [
            'content-type' => 'text/xml; charset=utf-8',
        ];

        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', $url, [
            'headers' => $headers,
            'body'  => $body,
        ]);

        return $response->getBody();
    }

}
