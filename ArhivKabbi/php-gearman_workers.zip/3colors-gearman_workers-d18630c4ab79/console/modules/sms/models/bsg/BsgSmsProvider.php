<?php

namespace console\modules\sms\models\bsg;


class BsgSmsProvider extends \yii\base\Component implements \console\modules\sms\models\SmsProviderInterface
{

    private $error;
    public $gate;

    public function init()
    {
        $this->gate = new BsgSms();
        parent::init();
    }

    public function sendSms($login, $password, $message, $target, $sender)
    {
        try {
            $response = $this->gate->sendSms($login, $password, $message, $target, $sender);
            $xmlObj = simplexml_load_string($response);
            $xml = (array) $xmlObj;
            if (!empty($xml['error'])) {
                $this->error = $xml['error'];
                return false;
            }
            return !empty($xml['information']) && ($xml['information'] == 'send');
        } catch (\Exception $ex) {
            return false;
        }
    }

    public function requestBalance($login, $password)
    {
        try {
            $response = $this->gate->getBalance($login, $password);
            $xmlObj = simplexml_load_string($response);
            $xml = (array) $xmlObj;
            if (!empty($xml['error'])) {
                $this->error = $xml['error'];
//                return '';
            }
            return $xml['money'];
        } catch (\Exception $ex) {
            return '';
        }
    }

    public function getError()
    {
        return $this->error;
    }

}
