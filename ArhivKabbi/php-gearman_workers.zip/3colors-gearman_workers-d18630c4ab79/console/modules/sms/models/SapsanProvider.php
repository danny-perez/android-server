<?php

namespace console\modules\sms\models;

class SapsanProvider extends IbateleProvider
{

    const SMS_SEND_SERVER_ADDRESS = 'http://lk.sms-sapsan.ru/xml/';
    const SMS_REQUEST_BALANCE_SERVER_ADDRESS = 'http://lk.sms-sapsan.ru/xml/balance.php';

}
