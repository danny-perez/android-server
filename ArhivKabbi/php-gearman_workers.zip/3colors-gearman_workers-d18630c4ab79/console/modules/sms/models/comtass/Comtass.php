<?php

namespace console\modules\sms\models\comtass;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;

class Comtass
{
    const BASE_URL = 'http://196.202.134.90/dsms/webacc.aspx';

    const STATUS_OK = 'OK';
    const STATUS_REJECTED = 'Rejected';
    const STATUS_INVALID = 'Invalid';

    public function sendSms($login, $password, $text, $phone, $sender)
    {
        try {
            $httpClient = new Client([
                'connectionTimeout' => getenv('CURL_CONNECT_TIMEOUT'),
                'timeout'           => getenv('CURL_TIMEOUT'),
            ]);

            $resp = $httpClient->request('GET', self::BASE_URL, [
                'query' => [
                    'user' => $login,
                    'pwd' => $password,
                    'Nums' => $phone,
                    'smstext' => $text,
                    'Sender' => $sender
                ],
            ]);

            return (string)$resp->getBody();
        } catch (ClientException $ex) {
            return 'Undefined';
        }
    }


}