<?php

namespace console\modules\sms\models;

class QtSmsProviderKuban extends QtSmsProvider
{
    public function init()
    {
        parent::init();

        $this->gate = new QtSmsKuban();
    }
}
