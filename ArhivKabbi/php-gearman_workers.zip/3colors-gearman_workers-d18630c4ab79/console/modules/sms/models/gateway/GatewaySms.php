<?php

namespace console\modules\sms\models\gateway;

use Yii;

class GatewaySms
{
    const BASE_URL ='http://91.212.89.137/mobile.php';


    public function sendSms($login,$passw, $text, $phone)
    {
        /* @var $curl \console\components\curl\Curl */
        $curl = app()->curl;

        $params = [
            'login' => $login,
            'passw' => $passw,
            'phone' => $phone,
            'text' => $text
        ];
        /* @var $response \console\components\curl\CurlResponse */
        $response = $curl->post(self::BASE_URL, $params);

        if (!empty($response)) {
            $result = simplexml_load_string($response->body);

            $r['error'] = $result->result['status'];
            if($result->result['status'] == '1')
                $r['msg'] = $result->result;
            return $r;
        }
        return [
            'error' => '1',
            'msg' => 'No connect',
        ];
    }

}
