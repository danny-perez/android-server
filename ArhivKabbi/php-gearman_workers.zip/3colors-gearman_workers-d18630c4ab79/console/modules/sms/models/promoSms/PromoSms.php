<?php

namespace console\modules\sms\models\promoSms;

use GuzzleHttp\Client;

class PromoSms
{
    const BASE_URL = 'http://sms.promosms.ru:26676/smw/aisms';

    public function sendSms($login, $password, $text, $phone, $sender)
    {
        try {
            $httpClient = new Client([
                'connectionTimeout' => getenv('CURL_CONNECT_TIMEOUT'),
                'timeout'           => getenv('CURL_TIMEOUT'),
            ]);

            $resp = $httpClient->request('GET', self::BASE_URL, [
                'query' => [
                    'action' => 'post_sms',
                    'user' => $login,
                    'pass' => $password,
                    'target' => $phone,
                    'message' => $text,
                    'sender' => $sender
                ],
            ]);

            return (string)$resp->getBody();
        } catch (\Exception $ex) {
            return null;
        }
    }


}