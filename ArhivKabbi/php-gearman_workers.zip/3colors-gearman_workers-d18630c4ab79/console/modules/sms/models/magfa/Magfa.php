<?php

namespace console\modules\sms\models\magfa;

use Yii;

class Magfa
{
    const BASE_URL = 'http://sms.magfa.com/magfaHttpService';
    const DOMAIN = 'magfa';

//    private function getQuery($params)
//    {
//        return http_build_query($params);
//    }

    private function sendResponse($params)
    {
        $curl = app()->curl;
        return $curl->get(self::BASE_URL, $params);
    }

    public function sendSms($login, $password, $text, $phone, $sender)
    {
        $params = [
            'service' => 'Enqueue',
            'domain' => self::DOMAIN,
            'username' => $login,
            'password' => $password,
            'from' => $sender,
            'to' => $phone,
            'message' => $text,
        ];
//        return '40467476937'; // успешно
//        return '1'; // не успешно
        return $this->sendResponse($params);
    }


}
