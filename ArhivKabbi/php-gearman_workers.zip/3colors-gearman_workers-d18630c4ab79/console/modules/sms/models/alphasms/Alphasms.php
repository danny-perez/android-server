<?php

namespace console\modules\sms\models\alphasms;

class Alphasms
{
    const BASE_URL = 'https://alphasms.ua/api/http.php';
    const VERSION = 'http';

    private function sendResponse($params)
    {
        $curl = app()->curl;
        return $curl->get(self::BASE_URL, $params);
    }

    public function sendSms($login, $password, $text, $phone, $sender)
    {
        $params = [
            'command' => 'send',
            'version' => self::VERSION,
            'login' => $login,
            'password' => $password,
            'to' => $phone,
            'from' => $sender,
            'message' => $text,
        ];

        return $this->sendResponse($params);
    }

    public function getBalance($login, $password)
    {
        $params = [
            'command' => 'balance',
            'version' => self::VERSION,
            'login' => $login,
            'password' => $password
        ];

        return $this->sendResponse($params);
    }
}