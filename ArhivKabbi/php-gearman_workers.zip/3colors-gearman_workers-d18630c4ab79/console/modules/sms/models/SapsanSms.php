<?php

namespace console\modules\sms\models;


class SapsanSms extends IbateleSms
{

    const SMS_SEND_SERVER_ADDRESS = 'http://lk.sms-sapsan.ru/xml/';
    const BALANCE_REQUEST_SERVER_ADDRESS = 'http://lk.sms-sapsan.ru/xml/balance.php';

}
