<?php

##########################################################
// Класс предназначен для отправки СМС через систему
/* v. 1.6 */

namespace console\modules\sms\models;

class QtSmsKuban extends QtSms
{
    public function __construct()
    {
        $this->hostname = 'kuban.qtelecom.ru';
    }

}
