<?php

namespace console\modules\sms\components;

use console\modules\sms\models\alphasms\AlphasmsProvider;
use console\modules\sms\models\bsg\BsgSmsProvider;
use console\modules\sms\models\comtass\ComtassProvider;
use console\modules\sms\models\gosms\GosmsProvider;
use console\modules\sms\models\magfa\MagfaProvider;
use console\modules\sms\models\mediasend\MediasendProvider;
use console\modules\sms\models\megafonTjSmpp\MegafonTjSmppProvider;
use console\modules\sms\models\nikita\NikitaProvider;
use console\modules\sms\models\promoSms\PromoSmsProvider;
use console\modules\sms\models\QtSmsProviderKuban;
use console\modules\sms\models\smsbroker\SmsBrokerProvider;
use console\modules\sms\models\smsc\SmscProvider;
use Yii;
use console\modules\sms\exceptions\InvalidServerIdException;
use console\modules\sms\models\IqSmsProvider;
use console\modules\sms\models\IbateleProvider;
use console\modules\sms\models\SapsanProvider;
use console\modules\sms\models\EyelineSmsProvider;
use console\modules\sms\models\QtSmsProvider;
use console\modules\sms\models\MsmSmsProvider;
use console\modules\sms\models\bulkSms\BulkSmsProvider;
use console\modules\sms\models\gateway\GatewaySmsProvider;
use console\modules\sms\models\maraditSms\MaraditProvider;
use console\modules\sms\models\ibateleSmpp\IbateleSmppProvider;
use console\modules\sms\models\clickatell\ClickatellProvider;

class SmsProviderFactory
{

    public function getProvider($server_id)
    {
        switch ($server_id) {
            case 1:
                return new IqSmsProvider();

            case 2:
                return new IbateleProvider();

            case 3:
                return new SapsanProvider();

            case 4:
                return new EyelineSmsProvider();

            case 5:
                return new QtSmsProvider();

            case 6:
                return new MsmSmsProvider();

            case 7:
                return new BulkSmsProvider();

            case 8:
                return new GatewaySmsProvider();

            case 9:
                return new MaraditProvider();

            case 10:
                return new IbateleSmppProvider();

            case 11:
                return new ClickatellProvider();

            case 12:
                return new SmscProvider();

            case 13:
                return new GosmsProvider();

            case 14:
                return new BsgSmsProvider();

            case 15:
                return new MagfaProvider();

            case 16:
                return new AlphasmsProvider();

            case 17:
                return new QtSmsProviderKuban();

            case 18:
                return new PromoSmsProvider();

            case 19:
                return new MegafonTjSmppProvider();

            case 20:
                return new SmsBrokerProvider();

            case 21:
                return new ComtassProvider();

            case 22:
                return new MediasendProvider();

            case 23:
                return new NikitaProvider();

            default:
                throw new InvalidServerIdException('Invalid server id: ' . $server_id);
        }
    }
}
