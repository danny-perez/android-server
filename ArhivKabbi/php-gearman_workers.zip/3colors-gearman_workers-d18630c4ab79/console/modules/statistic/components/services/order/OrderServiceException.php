<?php

namespace console\modules\statistic\components\services\order;


class OrderServiceException extends \Exception
{

}