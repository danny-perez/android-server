<?php

namespace notification;

use notification\workerBalance\WorkerBalanceService;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
use Psr\Log\LoggerInterface;
use yii\db\Connection;

/**
 * Class WorkerBalanceConsumer
 * @package notification
 */
class WorkerBalanceConsumer
{
    /**
     * @var MQConnection
     */
    private $connection;

    /**
     * @var WorkerBalanceService
     */
    private $service;

    /**
     * @var LoggerInterface
     */
    private $logger;


    /**
     * WorkerBalanceConsumer constructor.
     *
     * @param MQConnection         $connection
     * @param WorkerBalanceService $service
     * @param LoggerInterface      $logger
     */
    public function __construct(MQConnection $connection, WorkerBalanceService $service, LoggerInterface $logger)
    {
        $this->connection = $connection;
        $this->service = $service;
        $this->logger = $logger;
    }

    public function start()
    {
        $connection = new AMQPStreamConnection($this->connection->getHost(), $this->connection->getPort(),
            $this->connection->getUser(), $this->connection->getPassword(), $this->connection->getVirtualHost());

        $channel = $connection->channel();
        try {
            $channel->exchange_declare(CompleteTransactionProducer::EXCHANGE_COMPLETE_TRANSACTION, 'fanout', false,
                false, false);

            list($queue, ,) = $channel->queue_declare('', false, false, true, false);
            $channel->queue_bind($queue, CompleteTransactionProducer::EXCHANGE_COMPLETE_TRANSACTION);

            $channel->basic_consume($queue, '', false, false, false, false,
                [$this, 'processWorkerBalanceNotification']);

            $this->logger->info("Consumer started:");

            while (count($channel->callbacks)) {
                $channel->wait();
            }
        } catch (\Exception $ex) {
            $this->logger->error("Worker balance consumer error: error={$ex->getMessage()}");
        } finally {
            $this->logger->info('Consumer stopped.');

            $channel->close();
            $connection->close();
        }
    }

    /**
     * @param AMQPMessage $msg
     */
    public function processWorkerBalanceNotification($msg)
    {
        $transactionId = $msg->body;
        try {
            $this->service->process($transactionId);
        } catch (\Exception $ex) {
            $this->logger->error("Process worker balance notification error: transactionId={$transactionId}, error=\"{$ex->getMessage()}\"");
        } finally {
            $this->closeConnection();
        }
    }

    private function closeConnection()
    {
        $db = \Yii::$app->get('db', false);
        if ($db instanceof Connection) {
            $db->close();
        }
    }
}