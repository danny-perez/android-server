Репозиторий gootax.pro

Примечания:
1) в common/config/env.php переключается рабочее окружение проекта
YII_ENV - dev - для локальной разработки
YII_ENV - prod- для production версии

В main ветке всегда должно быть YII_ENV = prod  !!!
