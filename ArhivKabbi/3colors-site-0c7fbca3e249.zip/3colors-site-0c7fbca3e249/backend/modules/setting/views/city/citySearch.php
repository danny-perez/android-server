<?php
use yii\helpers\Html;
/* @var $this yii\web\View */
/* @var $arRepublic app\modules\city\models\Republic */
/* @var $form yii\widgets\ActiveForm */
//
if (!empty($arRepublic)):?>
    <? foreach ($arRepublic as $republic): ?>
        <? foreach ($republic['city'] as $city): ?>
        <?if($city['shortname'] == 'г'):?>
            <?$city['shortname'] = '';?>
        <?endif?>
        <li><a onclick="cityid(id, text);" data ="<?= Html::encode($republic['name']) . ' ' . Html::encode($republic['shortname']) . ' ' . Html::encode($city['name']) . ' ' . Html::encode($city['shortname']) ?>" id = "<?=$city['city_id']?>" data-city="<?= $city['city_id'] ?>">
<?= Html::encode($republic['name']) . ' ' . Html::encode($republic['shortname']) . ' '.  Html::encode($city['shortname']). ' ' . Html::encode($city['name'])?></a></li>
        <? endforeach; ?>
    <? endforeach; ?>
<? endif; ?>

