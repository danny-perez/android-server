<?php

namespace app\modules\setting\models;

use Yii;

/**
 * This is the model class for table "tbl_default_client_push_notifications".
 *
 * @property integer $template_id
 * @property string $text
 * @property string $type
 * @property string $description
 */
class DefaultClientPushNotificationsCourier extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%default_client_push_notifications_courier}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['text', 'type'], 'required'],
            [['description', 'type'], 'string'],
            [['text'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'template_id' => 'Template ID',
            'text' => 'Текст',
            'type' => 'Тип',
            'description' => 'Описание',
        ];
    }
}
