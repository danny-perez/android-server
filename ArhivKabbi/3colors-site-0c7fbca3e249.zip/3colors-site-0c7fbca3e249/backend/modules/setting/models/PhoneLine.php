<?php

namespace app\modules\setting\models;

/**
 * This is the model class for table "tbl_phone_line".
 *
 * @property integer    $line_id
 * @property integer    $tenant_id
 * @property integer    $tariff_id
 * @property integer    $city_id
 * @property string     $phone
 * @property string     $incoming_scenario
 * @property integer    $block
 * @property string     $r_username
 * @property string     $r_domain
 * @property string     $sip_server_local
 * @property string     $auth_proxy
 * @property integer    $port
 * @property string     $realm
 * @property string     $typeServer
 *
 * @property City       $city
 * @property TaxiTariff $tariff
 * @property Tenant     $tenant
 * @property bool       $isExtendedForm
 */
class PhoneLine extends \yii\db\ActiveRecord
{
    const YES = 1;
    const NO = 0;
    const ALL = 2;

    public $domain;
    public $password;
    public $extended_form = 0;

    const EXTENDED = 1;

    const TYPE_SERVER_KAMAILIO = 'kamailio';
    const TYPE_SERVER_ASTERISK = 'asterisk';

    const DEFAULT_PORT = 5060;
    const DEFAULT_SIP_SERVER_LOCAL = 'sp1.uatgootax.ru';

    const SCENARIO_CREATE = 'create';

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tbl_phone_line';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['city_id', 'tariff_id', 'incoming_scenario', 'tenant_id'], 'required'],
            ['extended_form', 'safe'],
            [
                'tenant_id',
                'exist',
                'targetClass' => Tenant::className(),
            ],
            [
                'tenant_id',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('tenant_id');
                },
            ],
            [
                'city_id',
                'exist',
                'targetClass' => TenantHasCity::className(),
                'targetAttribute' => ['city_id', 'tenant_id'],
            ],
            [
                'tariff_id',
                'exist',
                'targetClass' => TaxiTariff::className(),
                'targetAttribute' => ['tariff_id', 'tenant_id'],
            ],

            [
                ['phone', 'r_username', 'r_domain', 'auth_proxy', 'port', 'realm'],
                'required',
                'when'       => [$this, 'isExtendedValidate'],
                'whenClient' => $this->isExtendedJsValidate(),
            ],

            [
                'phone',
                'string',
                'max'        => 20,
                'when'       => [$this, 'isExtendedValidate'],
                'whenClient' => $this->isExtendedJsValidate(),
            ],

            [
                ['r_username', 'r_domain', 'realm', 'password'],
                'string',
                'max'        => 50,
                'when'       => [$this, 'isExtendedValidate'],
                'whenClient' => $this->isExtendedJsValidate(),
            ],
            [
                'auth_proxy',
                'string',
                'max'        => 255,
                'when'       => [$this, 'isExtendedValidate'],
                'whenClient' => $this->isExtendedJsValidate(),
            ],
            [
                'port',
                'integer',
                'max'        => 99999,
                'min'        => 1,
                'when'       => [$this, 'isExtendedValidate'],
                'whenClient' => $this->isExtendedJsValidate(),
            ],

            [['sip_server_local', 'typeServer'], 'required', 'on' => self::SCENARIO_CREATE],
            ['sip_server_local', 'string', 'max' => 255, 'on' => self::SCENARIO_CREATE],
            ['typeServer', 'in', 'range' => self::getSupportedTypeServer(), 'on' => self::SCENARIO_CREATE],

            [
                'phone',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('phone');
                },
            ],
            [
                'r_username',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('r_username');
                },
            ],
            [
                'r_domain',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('r_domain');
                },
            ],
            [
                'auth_proxy',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('auth_proxy');
                },
            ],
            [
                'port',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('port');
                },
            ],
            [
                'realm',
                'filter',
                'filter' => function ($value) {
                    return $this->isExtendedForm ? $value : $this->getOldAttribute('realm');
                },
            ],
        ];
    }

    public function isExtendedValidate($model)
    {
        return $model->isExtendedForm;
    }

    public function isExtendedJsValidate()
    {
        return 'function(attr,value){
                    var model = attr.input.replace("-" + attr.name, "");
                    return $(".js-is-extended-form").val() == "' . self::EXTENDED . '";
                }';
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'line_id'           => 'ID',
            'tenant_id'         => 'ID арендатора',
            'domain'            => 'Домен',
            'tariff_id'         => 'Тариф',
            'city_id'           => 'Филиал',
            'phone'             => 'Телефон',
            'incoming_scenario' => 'Сценарии',
            'block'             => 'Блокировка',
            'extended_form'     => 'Расширенная форма',
        ];
    }

    public function getIsExtendedForm()
    {
        return (int)$this->extended_form === 1;
    }

    public static function getSupportedTypeServer()
    {
        return [
            self::TYPE_SERVER_ASTERISK,
            self::TYPE_SERVER_KAMAILIO,
        ];
    }

    public static function getTypeServerList()
    {
        return [
            self::TYPE_SERVER_ASTERISK => self::TYPE_SERVER_ASTERISK,
            self::TYPE_SERVER_KAMAILIO => self::TYPE_SERVER_KAMAILIO,
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['city_id' => 'city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTariff()
    {
        return $this->hasOne(TaxiTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    public function afterFind()
    {
        parent::afterFind();

        $this->domain = $this->tenant->domain;
        $this->unserializeIncomingScenario();
    }

    public function unserializeIncomingScenario()
    {
        if ($incomingScenario = unserialize($this->incoming_scenario)) {
            $this->incoming_scenario = json_encode($incomingScenario);
        } else {
            $this->incoming_scenario = '';
        }
    }


    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            $this->incoming_scenario = serialize(json_decode($this->incoming_scenario, true));

            if (!$insert) {
                $diff           = array_diff($this->attributes, $this->oldAttributes);
                $diffAttributes = array_keys($diff);

                if (array_intersect($diffAttributes,
                    ['tenant_id', 'tariff_id', 'city_id', 'phone', 'incoming_scenario', 'block'])) {
                    $this->deleteInRedis();
                }
            }

            return true;
        }

        return false;
    }

    public function beforeDelete()
    {
        if (parent::beforeDelete()) {
            $this->deleteInRedis();

            return true;
        }

        return false;
    }

    public function deleteInRedis()
    {
        \Yii::$app->get('redis_phone_scenario')->executeCommand('del', [$this->oldAttributes['phone']]);
    }

    public static function getActiveList(){
        return [self::YES => 'Да', self::NO => 'Нет', self::ALL => 'Все'];
    }
}
