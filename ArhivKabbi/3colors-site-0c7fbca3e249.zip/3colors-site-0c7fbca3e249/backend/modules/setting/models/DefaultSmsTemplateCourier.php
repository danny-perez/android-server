<?php

namespace app\modules\setting\models;

use Yii;

/**
 * This is the model class for table "{{%default_sms_template}}".
 *
 * @property integer $template_id
 * @property string $type
 * @property string $text
 * @property string $description
 */
class DefaultSmsTemplateCourier extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%default_sms_template_courier}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['type', 'text'], 'required'],
            [['text'], 'string'],
            [['type'], 'string', 'max' => 45],
            [['type'], 'unique'],
            [['description'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'template_id' => 'Template ID',
            'type' => 'Тип',
            'text' => 'Текст',
            'description' => 'Описание',
        ];
    }
}
