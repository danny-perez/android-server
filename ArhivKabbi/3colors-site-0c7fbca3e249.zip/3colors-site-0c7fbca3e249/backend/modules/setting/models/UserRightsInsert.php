<?php
/**
 * Created by PhpStorm.
 * User: zigfried123
 * Date: 22.12.2017
 * Time: 13:52
 */

namespace app\modules\setting\models;


class UserRightsInsert extends UserRightsSaveStrategy
{


}