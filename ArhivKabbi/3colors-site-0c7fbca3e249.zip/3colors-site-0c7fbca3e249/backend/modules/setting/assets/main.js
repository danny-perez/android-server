$(document).ready(function () {
    //Активность меню
    var pathname = location.pathname;
    pathname = pathname.split('/');
    var module = pathname[1];
    var action = pathname[2];
    var main_menu_item = $('.first_nav li ul li a');
//    if ($('body section .nav-tabs-custom ul .nav .nav-tabs li a') != undefined && $(location).attr('href').indexOf('#') != -1)
//    {
//        var begin = $(location).attr('href').indexOf('#');
//        var end = $(location).attr('href').length;
//        var tabLink = $(location).attr('href').substr(begin, end);
//        tabToggle($('.tabs_links li a[href=\'' + tabLink + '\']'));
//    }
//    else if ($(location).attr('href').indexOf('#') == -1)
//    {
//        $('#tab_1').addClass('active');
//        $('a.tab_1').closest("li").toggleClass('active');
//    }
    main_menu_item.each(function () {
        var href = $(this).attr('href');
        if (href.indexOf('/' + module + '/' + action) !== -1) {
            $(this).parent().addClass('active').parents('li').addClass('active').addClass('opened');
        }

    });

});
