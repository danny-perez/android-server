<?php

namespace api\models\taxi_tariff;

use api\models\client\ClientHasCompany;
use api\models\tenant\TenantCityHasPosition;
use api\models\transport\car\CarOption;
use Yii;
use api\models\worker\Position;
use api\models\transport\car\CarClass;
use api\models\tenant\Tenant;
use yii\db\Query;
use yii\helpers\ArrayHelper;

/**
 * Class TaxiTariff
 * @package api\models\taxi_tariff
 *
 * @property int $tariff_id
 * @property int $tenant_id
 * @property int $class_id
 * @property int $block
 * @property int $group_id
 * @property string $name
 * @property string $description
 * @property int $sort
 * @property int $enabled_site
 * @property int $enabled_app
 * @property string $logo
 * @property int $position_id
 *
 * @property AdditionalOption[] $options
 */
class TaxiTariff extends \yii\db\ActiveRecord
{

    const CURRENT_TYPE = 'CURRENT';
    const HOLIDAYS_TYPE = 'HOLIDAYS';
    const EXCEPTIONS_TYPE = 'EXCEPTIONS';

    const TYPE_BASE = 'BASE';
    const TYPE_COMPANY = 'COMPANY';
    const TYPE_COMPANY_CORP_BALANCE = 'COMPANY_CORP_BALANCE';
    const TYPE_ALL = 'ALL';

    const ENABLED = 1;
    const BLOCK = 1;
    const NOT_BLOCK = 0;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%taxi_tariff}}';
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClass()
    {
        return $this->hasOne(CarClass::className(), ['class_id' => 'class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(TaxiTariffGroup::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_id']);
    }

    public function getHasCity()
    {
        return $this->hasOne(TaxiTariffHasCity::className(), ['tariff_id' => 'tariff_id']);
    }

    public function getOptions()
    {
        return $this->hasMany(AdditionalOption::className(), ['tariff_id' => 'tariff_id']);
    }

    public function getCompanies()
    {
        return $this->hasMany(TaxiTariffHasCompany::className(), ['tariff_id' => 'tariff_id']);
    }


    public static function getActiveList($clientId, $tenant_id, $city_id, $typeClient, $positionId = null)
    {
        $companies = [];
        if ($clientId) {
            $companies = ClientHasCompany::findAll(['client_id' => $clientId]);
            $companies = ArrayHelper::getColumn($companies, 'company_id');
        }
        $availablePositionIds = TenantCityHasPosition::find()
            ->select('position_id')
            ->where([
                'tenant_id' => $tenant_id,
                'city_id'   => $city_id,
            ])
            ->column();

        $query = self::find()
            ->alias('t')
            ->andFilterWhere(['position_id' => $positionId])
            ->andWhere(['position_id' => $availablePositionIds])
            ->joinWith([
                'hasCity hc'  => function ($query) use ($city_id) {
                    $query->where([
                        'hc.city_id' => $city_id,
                    ]);
                },
                'options.option o',
                'companies c' => function ($query) use ($companies) {
                    $query->onCondition(['c.company_id' => $companies]);
                },
                'options'     => function ($query) {
                    $query->joinWith('option');
                },
            ])
            ->orderBy([
                'sort' => SORT_ASC,
                'name' => SORT_ASC,
            ]);

        $query->andWhere([
            'type' => [self::TYPE_BASE, self::TYPE_ALL],
        ]);

        if ($clientId) {
            $query->orWhere([
                'c.company_id' => $companies,
            ]);
        }

        $query->andWhere([
            't.tenant_id' => $tenant_id,
            't.block'     => 0,
        ]);

        switch ($typeClient) {
            case 'WEB':
                $query->andWhere([
                    'enabled_site' => 1,
                ]);
                break;
            default:
                $query->andWhere([
                    'enabled_app' => 1,
                ]);
        }

        $model = $query->all();

        return $model;
    }

    public static function getFormattedActiveList(
        $clientId,
        $date,
        $lang,
        $tenant_id,
        $city_id,
        $typeClient,
        $positionId = null
    ) {
        return self::getFormattedList($clientId, $date, $lang, $tenant_id, $city_id, $typeClient, $positionId, false);
    }

    public static function getFormattedSimpleActiveList(
        $date,
        $lang,
        $tenant_id,
        $city_id,
        $typeClient,
        $positionId = null
    ) {
        return self::getFormattedList(null, $date, $lang, $tenant_id, $city_id, $typeClient, $positionId, true);
    }

    public static function getFormattedList(
        $clientId,
        $date,
        $lang,
        $tenant_id,
        $city_id,
        $typeClient,
        $positionId,
        $simple = false
    ) {
        $model           = self::getActiveList($clientId, $tenant_id, $city_id, $typeClient, $positionId);
        $domain          = Tenant::getDomain($tenant_id);
        $bonusTariffList = self::getBonusTariffList($tenant_id, $city_id);
        $result          = array_map(function ($item) use (
            $date,
            $lang,
            $domain,
            $city_id,
            $bonusTariffList,
            $simple,
            $clientId
        ) {
            $el = [
                'tariff_id'    => (string)$item->tariff_id,
                'position_id'  => (int)$item->position_id,
                'car_class_id' => $item->class_id,
                'type'         => $item->getTariffTypeByTime($date),
            ];

            if ($simple) {
                return $el;
            }

            $el = array_merge($el, [
                'city_id'            => $city_id,
                'logo_thumb'         => !empty($item->logo) ? app()->params['frontend.protocol'] . '://' . $domain . '.'
                    . app()->params['frontend.domain'] . '/file/show-external-file?filename=thumb_' . $item->logo
                    . '&id=' . $item->tenant_id : '',
                'logo'               => !empty($item->logo) ? app()->params['frontend.protocol'] . '://' . $domain . '.'
                    . app()->params['frontend.domain'] . '/file/show-external-file?filename=' . $item->logo
                    . '&id=' . $item->tenant_id : '',
                'tariff_name'        => empty($item->name) ? t('app', 'Untitled', [], $lang) : (string)$item->name,
                'description'        => (string)$item->description,
                'is_bonus'           => (int)in_array($item->tariff_id, $bonusTariffList),
                'client_type'        => $item->getClientType($clientId),
                'companies'          => $item->getCompanyIds($clientId),
                'additional_options' => array_map(function ($item) use ($lang) {
                    $item->option->name = t(CarOption::SOURCE_CATEGORY, $item->option->name, [], $lang);
                    unset($item->option->type_id);
                    $el = [
                        'id'                   => $item->id,
                        'tariff_id'            => $item->tariff_id,
                        'additional_option_id' => $item->additional_option_id,
                        'price'                => $item->price,
                        'tariff_type'          => $item->tariff_type,
                        'option'               => [
                            'option_id' => $item->option->option_id,
                            'name'      => $item->option->name,
                        ],
                    ];

                    return $el;
                }, $item->options),
            ]);

            return $el;
        }, $model);

        return $result;
    }

    private static function getBonusTariffList($tenantId, $cityId)
    {
        $bonusSystem     = \Yii::createObject(\bonusSystem\BonusSystem::class, [$tenantId]);
        $bonusSystemType = $bonusSystem->getBonusSystemType();

        $tariffs = (new Query())
            ->select('t.tariff_id')
            ->distinct()
            ->from('{{%client_bonus}} c')
            ->innerJoin('{{%client_bonus_has_tariff}} t', 'c.bonus_id = t.bonus_id')
            ->where([
                'c.tenant_id'       => $tenantId,
                'c.city_id'         => $cityId,
                'c.bonus_system_id' => $bonusSystemType->getId(),
            ])
            ->all();

        return is_array($tariffs) ? ArrayHelper::getColumn($tariffs, 'tariff_id') : [];
    }

    /**
     * Получить тип тарифа по времени
     *
     * @param string $date 2014.11.12 11:35:00
     *
     * @return string $tariffType тип тарифа  ENUM('CURRENT', 'HOLIDAYS', 'EXCEPTIONS')
     */
    public function getTariffTypeByTime($date)
    {
        $time           = new \DateTime($date);
        $dateFull       = $time->format('d.m.Y');
        $dateShort      = $time->format('d.m');
        $dayOfWeek      = date('l', strtotime($date));
        $hoursAndMinute = $time->format('H:i');
        $toDay          = [$dayOfWeek, $dateShort, $dateFull];

        $result = self::CURRENT_TYPE;

        $records = OptionActiveDate::find()
            ->where('tariff_id = :tariff_id', [':tariff_id' => $this->tariff_id])
            ->asArray()
            ->all();
        if (!empty($records)) {

            foreach ($records as $record) {

                $date = explode('|', $record['active_date']);

                // Игнорируем если день не совпал
                if (!in_array($date[0], $toDay)) {
                    continue;
                }
                $interval = isset($date[1]) ? explode('-', $date[1]) : ['00:00', '23:59'];

                // Игнорируем если не попали в часовой промежуток
                if ($interval[0] > $hoursAndMinute || $interval[1] < $hoursAndMinute) {
                    continue;
                }

                switch ($record['tariff_type']) {
                    case self::EXCEPTIONS_TYPE :
                        if (self::checkTariffIsActive($this->tariff_id, self::EXCEPTIONS_TYPE)) {
                            return self::EXCEPTIONS_TYPE;
                        }
                        break;
                    case self::HOLIDAYS_TYPE :
                        if (self::checkTariffIsActive($this->tariff_id, self::HOLIDAYS_TYPE)) {
                            $result = self::HOLIDAYS_TYPE;
                        }
                        break;
                }
            }
        }

        return $result;
    }

    public static function checkTariffIsActive($tariffId, $tariffType)
    {
        $isActive = TaxiOption::find()
            ->where('tariff_id= :tariff_id', ['tariff_id' => $tariffId])
            ->andWhere('tariff_type= :tariff_type', ['tariff_type' => $tariffType])
            ->andWhere('active = 1 OR active IS NULL')
            ->asArray()
            ->one();
        if (!empty($isActive)) {
            return true;
        }

        return false;
    }

    public function getClientType($clientId = null)
    {
        $result = [];

        if ($this->type === self::TYPE_BASE || $this->type === self::TYPE_COMPANY || $this->type === self::TYPE_ALL) {
            $result[] = 'base';
        }
        if (($this->type === self::TYPE_COMPANY || $this->type === self::TYPE_COMPANY_CORP_BALANCE || $this->type === self::TYPE_ALL) && $clientId !== null) {
            $result[] = 'company';
        }

        return $result;
    }

    public function getCompanyIds($clientId)
    {


        if ($this->type === self::TYPE_ALL) {
            $companies = ClientHasCompany::find()
                ->alias('h')
                ->where([
                    'h.client_id' => $clientId,
                    'c.block'     => 0,
                ])
                ->joinWith('company c')
                ->all();

            return ArrayHelper::getColumn($companies, 'company_id');
        }

        if (empty($this->companies) || $clientId === null) {
            return [];
        }

        $companies = [];
        foreach ($this->companies as $item) {
            if ($item->company->block != 0) {
                continue;
            }
            $companies[] = $item->company_id;
        }

        return $companies;
    }
}
