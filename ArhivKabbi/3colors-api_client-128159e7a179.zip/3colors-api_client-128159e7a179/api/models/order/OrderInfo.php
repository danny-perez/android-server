<?php

namespace api\models\order;

use api\models\transport\car\Car;
use api\models\worker\Position;
use api\models\worker\WorkerReviewRating;
use yii\base\Exception;
use yii\base\Model;

class OrderInfo extends Model
{
    protected $_dataRedis = [];
    protected $_dataMysql = [];

    public $isTaxiOrder = true;
    public $tenantId;
    public $ordersId = [];
    public $lang;
    public $needCarPhoto;
    public $needWorkerPhoto;

    public function __construct(array $config)
    {
        parent::__construct($config);

        $this->ordersId = empty($config['ordersId']) ? [] : explode(',', $config['ordersId']);

        // Записываем все заказы из редиса в переменную
        $_dataRedis = (array)\Yii::$app->redis_orders_active->executeCommand('hvals', [$this->tenantId]);
        $_dataRedis = array_map(function ($item) {
            return unserialize($item);
        }, $_dataRedis);

        // Выбираем только нужные заказы
        $orderByRedis = [];
        foreach ($_dataRedis as $order) {
            if (!empty($order['order_id']) && in_array($order['order_id'], $this->ordersId, false)) {
                $key                    = $order['order_id'];
                $this->_dataRedis[$key] = $order;
                $orderByRedis[]         = $order['order_id'];
            }
        }

        // Ищем заказы, которые не нашли в редисе
        $orderByMysql = array_diff($this->ordersId, $orderByRedis);
        if (!empty($orderByMysql)) {
            $this->_dataMysql = (array)Order::find()
                ->alias('o')
                ->where([
                    'o.order_id'  => $orderByMysql,
                    'o.tenant_id' => $this->tenantId,
                ])
                ->joinWith([
                    'status st',
                    'worker w',
                ])
                ->indexBy('order_id')
                ->all();
        }
    }

    protected function formatting($data)
    {
        if (empty($data)) {
            return [];
        }

        $newData = [
            'order_number'     => isset($data['order_number']) ? (int)$data['order_number'] : 0,
            'status_id'        => isset($data['status_id']) ? (int)$data['status_id'] : 0,
            'status_group'     => isset($data['status_group']) ? (string)$data['status_group'] : '',
            'status_name'      => isset($data['status_name']) ? (string)$data['status_name'] : '',
            'payment'          => isset($data['payment']) ? (array)$data['payment'] : [],
            'predv_price'      => isset($data['predv_price']) ? (string)$data['predv_price'] : '',
            'car_data'         => isset($data['car_data']) ? (array)$data['car_data'] : [],
            'detail_cost_info' => isset($data['detail_cost_info']) ? (array)$data['detail_cost_info'] : [],
            'order_time'       => isset($data['order_time']) ? (int)$data['order_time'] : 0,
            'time_offset'      => isset($data['time_offset']) ? (int)$data['time_offset'] : 0,
        ];

        return array_merge($data, $newData);
    }

    protected function getInfoInRedis($orderId)
    {
        if (empty($this->_dataRedis[$orderId]) || !is_array($this->_dataRedis[$orderId])) {
            return [];
        }

        try {
            $dataRedis = $this->_dataRedis[$orderId];

            $data = [
                'order_number' => $dataRedis['order_number'],
                'status_id'    => $dataRedis['status']['status_id'],
                'status_group' => $dataRedis['status']['status_group'],
                'status_name'  => OrderStatus::getFilterStatusLabel(
                    $dataRedis['status']['status_id'],
                    $dataRedis['status']['status_group'],
                    $dataRedis['position_id'],
                    $this->isTaxiOrder,
                    $this->lang),
                'payment'      => [
                    'type' => $dataRedis['payment'],
                ],
                'predv_price'  => $dataRedis['predv_price'],
                'order_time'   => $dataRedis['order_time'] - $dataRedis['time_offset'],
                'time_offset'  => $dataRedis['time_offset'],
            ];
            if ($dataRedis['status']['status_group'] != OrderStatus::STATUS_GROUP_0) {
                $data['car_data'] = $this->getCarInfo(
                    $orderId, $dataRedis['worker']['callsign'], $dataRedis['position_id'], $dataRedis['car_id']);
            }

            if (in_array($dataRedis['status']['status_group'],
                    [OrderStatus::STATUS_GROUP_4, OrderStatus::STATUS_GROUP_5])
                && gtoet('1.1.1')
            ) {
                $address         = unserialize($dataRedis['address']);
                $data['address'] = [];
                if (is_array($address)) {
                    foreach ($address as $item) {
                        $data['address'][] = [
                            'city'   => !empty($item['city']) ? $item['city'] : '',
                            'street' => !empty($item['street']) ? $item['street'] : '',
                            'house'  => !empty($item['house']) ? $item['house'] : '',
                            'lat'    => !empty($item['lat']) ? $item['lat'] : '',
                            'lon'    => !empty($item['lon']) ? $item['lon'] : '',
                        ];
                    }
                }
            }

        } catch (Exception $e) {
            $data = [];
        }

        return $this->formatting($data);
    }


    protected function getInfoInMysql($orderId)
    {
        if (empty($this->_dataMysql[$orderId])) {
            return [];
        }

        try {
            $dataMysql = $this->_dataMysql[$orderId];
            $data      = [
                'order_number' => $dataMysql->order_number,
                'status_id'    => $dataMysql->status->status_id,
                'status_group' => $dataMysql->status->status_group,
                'status_name'  => OrderStatus::getFilterStatusLabel(
                    $dataMysql->status->status_id,
                    $dataMysql->status->status_group,
                    $dataMysql->position_id,
                    $this->isTaxiOrder,
                    $this->lang),
                'payment'      => [
                    'type' => $dataMysql->payment,
                ],
                'predv_price'  => $dataMysql->predv_price,
                'order_time'   => $dataMysql->status_time - $dataMysql->time_offset,
                'time_offset'  => $dataMysql->time_offset,
            ];
            if ($dataMysql->status->status_group != OrderStatus::STATUS_GROUP_0) {
                $data['car_data'] = $this->getCarInfo(
                    $orderId, $dataMysql->worker->callsign, $dataMysql->position_id, $dataMysql->car_id);
            }

            $detail_cost_info         = OrderDetailCost::find()
                ->select([
                    "detail_id",
                    "order_id",
                    "accrual_city",
                    "accrual_out",
                    "summary_distance",
                    "summary_cost",
                    "summary_time",
                    "city_time",
                    "city_distance",
                    "city_cost",
                    "out_city_time",
                    "out_city_distance",
                    "out_city_cost",
                    "city_time_wait",
                    "out_time_wait",
                    "before_time_wait",
                    "additional_cost",
                    "is_fix",
                    "city_next_km_price",
                    "out_next_km_price",
                    "supply_price",
                    "city_wait_time",
                    "out_wait_time",
                    "city_wait_driving",
                    "out_wait_driving",
                    "city_wait_price",
                    "out_wait_price",
                    "time",
                    "distance_for_plant",
                    "planting_price",
                    "planting_include",
                    "start_point_location",
                    "city_wait_cost",
                    "before_time_wait_cost",
                    "out_wait_cost",
                ])
                ->where(['order_id' => $orderId])
                ->asArray()
                ->one();
            $data['detail_cost_info'] = $detail_cost_info;

            if (in_array($dataMysql->status->status_group, [OrderStatus::STATUS_GROUP_4, OrderStatus::STATUS_GROUP_5])
                && gtoet('1.1.1')
            ) {
                $address         = unserialize($dataMysql->address);
                $data['address'] = [];
                if (is_array($address)) {
                    foreach ($address as $item) {
                        $data['address'][] = [
                            'city'   => !empty($item['city']) ? $item['city'] : '',
                            'street' => !empty($item['street']) ? $item['street'] : '',
                            'house'  => !empty($item['house']) ? $item['house'] : '',
                            'lat'    => !empty($item['lat']) ? $item['lat'] : '',
                            'lon'    => !empty($item['lon']) ? $item['lon'] : '',
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            $data = [];
        }

        return $this->formatting($data);
    }

    public function getCarInfo($orderId, $callsign, $positionId, $carId)
    {
        $worker = unserialize(\Yii::$app->redis_workers->executeCommand('HGET', [$this->tenantId, $callsign]));

        if (empty($worker)) {
            $carInfo = Car::getCarInfo($carId, $callsign, $this->tenantId, $positionId, $this->lang,
                $this->needCarPhoto,
                $this->needWorkerPhoto, $this->isTaxiOrder);

            return $carInfo;
        }

        if (in_array($this->_dataRedis[$orderId]['status']['status_id'],
            [OrderStatus::STATUS_GET_DRIVER, OrderStatus::STATUS_EXECUTION_PRE], false)) {
            $timeToClient = (int)$this->_dataRedis[$orderId]['update_time']
                + (int)$this->_dataRedis[$orderId]['time_to_client'] * 60 - time();
            $timeToClient = $timeToClient < 0 ? 0 : $timeToClient;
        } else {
            $timeToClient = 0;
        }

        $position = Position::findOne($positionId);

        if ($this->isTaxiOrder) {
            $description = empty($carId)
                ? t('employee', $position->name, [], $this->lang)
                : implode(' ', [
                    $worker['car']['name'],
                    t('car', $worker['car']['color'], [], $this->lang),
                    $worker['car']['gos_number'],
                ]);
        } else {
            $description = t('car', 'courier', [], $this->lang);
        }

        $data = [
            'car_description' => $description,
            'car_lat'         => (float)$worker['geo']['lat'],
            'car_lon'         => (float)$worker['geo']['lon'],
            'speed'           => (float)$worker['geo']['speed'],
            'car_time'        => floor($timeToClient / 60) + 1,
            'degree'          => (float)$worker['geo']['degree'],
            'driver_fio'      => implode(' ', [$worker['worker']['name'], $worker['worker']['second_name']]),
            'driver_phone'    => (string)$worker['worker']['phone'],
            'raiting'         => WorkerReviewRating::getWorkerRating($worker['worker']['worker_id'], $positionId),
            'car_photo'       => $this->needCarPhoto && isset($worker['car']['photo_url']) ? (string)$worker['car']['photo_url'] : '',
            'driver_photo'    => $this->needWorkerPhoto ? (string)$worker['worker']['photo_url'] : '',
        ];

        return $data;
    }


    public function getInfo()
    {
        $data = [];
        foreach ($this->_dataRedis as $key => $order) {
            $data[] = [
                'order_id'   => $key,
                'order_info' => $this->getInfoInRedis($key),
            ];
        }
        foreach ($this->_dataMysql as $key => $order) {
            $data[] = [
                'order_id'   => $key,
                'order_info' => $this->getInfoInMysql($key),
            ];
        }

        return $data;
    }

}