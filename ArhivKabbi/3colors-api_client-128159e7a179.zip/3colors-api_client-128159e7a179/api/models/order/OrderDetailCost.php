<?php

namespace api\models\order;

class OrderDetailCost extends \yii\db\ActiveRecord
{
    public static function tableName()
    {
        return '{{%order_detail_cost}}';
    }

    public function rules()
    {
        return [];
    }
}