<?php

namespace api\models\referralSystem\formatter;

abstract class BaseReplace extends BaseFormatter
{
    protected $object;
}
