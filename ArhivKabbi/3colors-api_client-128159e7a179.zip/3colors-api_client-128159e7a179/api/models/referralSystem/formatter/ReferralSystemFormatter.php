<?php

namespace api\models\referralSystem\formatter;

class ReferralSystemFormatter extends BaseFormatter
{
    public function formatter($value)
    {
        return $value;
    }
}