<?php

namespace api\models\worker;

use Yii;
use api\models\transport\TransportType;

/**
 * This is the model class for table "{{%tbl_position}}".
 *
 * @property integer $id
 * @property string $name
 */
class WorkerReviewRating extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_review_rating}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            ['worker_id', 'required'],
            [['rating_id', 'worker_id', 'one', 'two', 'three', 'four', 'five', 'count', 'position_id'], 'integer']
        ];
    }

    public static function getWorkerRating($worker_id, $position_id)
    {
        $model = self::find()
            ->select(['one', 'two', 'three', 'four', 'five' => 'five', 'count'])
            ->where([
                'worker_id' => $worker_id,
                'position_id' => $position_id
            ])
            ->asArray()
            ->one();
        if ($model) {
            $rating = $model['count'] == 0 ? 0 : ($model['one'] + $model['two'] * 2 + $model['three'] * 3
                    + $model['four'] * 4 + $model['five'] * 5) / $model['count'];
            return round($rating, 1);
        }
        return 0;
    }
}
