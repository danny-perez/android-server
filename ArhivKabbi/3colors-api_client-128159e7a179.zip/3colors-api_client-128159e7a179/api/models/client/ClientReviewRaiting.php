<?php

namespace api\models\client;

use Yii;


class ClientReviewRaiting extends \yii\db\ActiveRecord
{


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%client_review_raiting}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'one', 'two', 'three', 'four', 'five', 'count'], 'integer']
        ];
    }


}
