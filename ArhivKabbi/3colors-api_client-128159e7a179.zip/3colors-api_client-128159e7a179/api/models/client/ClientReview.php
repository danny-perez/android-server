<?php

namespace api\models\client;

use Yii;


class ClientReview extends \yii\db\ActiveRecord
{


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%client_review}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            ['client_id', 'exist', 'targetClass' => '\api\models\client\Client'],
            ['order_id', 'exist', 'targetClass' => '\api\models\order\Order'],
            ['text', 'safe'],
            ['rating', 'in', 'range' => [1,2,3,4,5]],
        ];
    }

    public function setReview($grade)
    {
        $model = ClientReviewRaiting::find()
            ->where(['client_id' => $this->client_id])
            ->one();
        if(!$model) {
            $model = new ClientReviewRaiting();
            $model->client_id = $this->client_id;
        }

        switch($grade) {
            case 1:
                $model->one++;
                break;
            case 2:
                $model->two++;
                break;
            case 3:
                $model->three++;
                break;
            case 4:
                $model->four++;
                break;
            case 5:
                $model->five++;
                break;
        }
        $model->count++;
        return $model->save();
    }
}
