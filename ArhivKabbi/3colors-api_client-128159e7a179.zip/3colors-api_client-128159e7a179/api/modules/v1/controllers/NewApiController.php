<?php


namespace api\modules\v1\controllers;

use api\modules\v1\actions\GetCarsAction;
use api\modules\v1\actions\GetClientHistoryAddressAction;
use api\modules\v1\actions\GetDownloadLinksAction;
use api\modules\v1\actions\GetOrderInfoAction;
use api\modules\v1\actions\GetOrdersInfoAction;
use api\modules\v1\actions\GetOrderRouteAction;
use api\modules\v1\actions\GetTariffsListAction;
use api\modules\v1\actions\GetTariffsTypeAction;
use api\modules\v1\actions\GetTenantCityListAction;
use api\modules\v1\actions\UpdateOrderAction;
use api\modules\v1\actions\UpdateOrderResultAction;
use yii\rest\Controller;
use yii\web\Response;

class NewApiController extends Controller
{
    public function actions()
    {
        return [
            'get_tenant_city_list'       => GetTenantCityListAction::className(),
            'get_tariffs_list'           => GetTariffsListAction::className(),
            'get_tariffs_type'           => GetTariffsTypeAction::className(),
            'get_download_links'         => GetDownloadLinksAction::className(),
            'get_client_history_address' => GetClientHistoryAddressAction::className(),
            'get_order_route'            => GetOrderRouteAction::className(),
            'update_order'               => UpdateOrderAction::className(),
            'update_order_result'        => UpdateOrderResultAction::className(),
            'get_order_info'             => GetOrderInfoAction::className(),
            'get_orders_info'            => GetOrdersInfoAction::className(),
            'get_cars'                   => GetCarsAction::className(),
        ];
    }

    public function actionError()
    {
        return 'error';
    }

    public function actionVersion()
    {
        app()->response->format = Response::FORMAT_RAW;

        return 'v' . app()->params['version'];
    }

    public function actionTest()
    {
        return 'test';
    }
}