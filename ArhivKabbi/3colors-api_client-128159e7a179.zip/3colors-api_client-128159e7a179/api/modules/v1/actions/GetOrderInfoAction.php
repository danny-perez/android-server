<?php

namespace api\modules\v1\actions;

use api\models\order\OrderInfo;
use api\modules\v1\exceptions\BadParamsException;
use api\modules\v1\requests\GetOrderInfoRequest;
use yii\helpers\ArrayHelper;

/**
 * Получить информацию по заказу.
 *
 * Class GetOrderInfoAction
 *
 * @package api\modules\v1\actions
 * @property GetOrderInfoRequest $request
 */
class GetOrderInfoAction extends BaseApiAction
{
    protected function getRequest()
    {
        return new GetOrderInfoRequest();
    }


    protected function execute()
    {
        $model = new OrderInfo([
            'tenantId'        => $this->request->tenantId,
            'ordersId'        => $this->request->orderId,
            'lang'            => $this->request->lang,
            'needCarPhoto'    => $this->request->needCarPhoto,
            'needWorkerPhoto' => $this->request->needDriverPhoto,
        ]);
        $data  = $model->getInfo($this->request->needCarPhoto, $this->request->needDriverPhoto);

        if (empty($data)) {
            throw new BadParamsException();
        }

        $this->response->setContent(['order_info' => ArrayHelper::getValue(reset($data), 'order_info', [])]);
    }

}