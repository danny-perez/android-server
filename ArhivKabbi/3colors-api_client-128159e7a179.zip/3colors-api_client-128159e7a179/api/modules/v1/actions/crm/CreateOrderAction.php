<?php

namespace api\modules\v1\actions\crm;

use api\models\client\Client;
use api\models\tenant\TenantSetting;
use api\modules\v1\actions\BaseApiAction;
use api\modules\v1\components\CityService;
use api\modules\v1\components\ClientService;
use api\modules\v1\components\OrderService;
use api\modules\v1\components\TenantService;
use api\modules\v1\exceptions\BadParamsException;
use api\modules\v1\exceptions\BlackListException;
use api\modules\v1\exceptions\InternalErrorException;
use api\modules\v1\requests\crm\CreateOrderRequest;

/**
 * Получение предварительной стоимости заказа
 *
 * Class CostingOrderAction
 *
 * @package api\modules\v1\actions\crm
 * @property CreateOrderRequest $request
 */
class CreateOrderAction extends BaseApiAction
{
    protected $_clientId;

    protected function getRequest()
    {
        return new CreateOrderRequest();
    }

    protected function beforeExecute()
    {
        if (parent::beforeExecute()) {
            // Если время заказа не задано, то указываем текущее время
            if ($this->request->orderTime === null) {
                $this->request->orderTime = time();

                /** @var CityService $cityService */
                $cityService = app()->get('cityService');

                $offsetTime               = $cityService->getTimeOffset($this->request->cityId);
                $this->request->orderTime += $offsetTime;
            }

            return true;
        }

        return false;
    }


    protected function execute()
    {
        $client = $this->findOrCreateClient();

        if (!$client) {
            throw new InternalErrorException();
        }

        if ($client->isBlocked()) {
            throw new BlackListException();
        }

        /** @var OrderService $orderService */
        /** @var ClientService $clientService */
        /** @var CityService $cityService */
        /** @var TenantService $tenantService */
        $orderService  = app()->get('orderService');
        $clientService = app()->get('clientService');
        $cityService   = app()->get('cityService');
        $tenantService = app()->get('tenantService');

        $statusId = $orderService->getStatus($this->request->orderTime, $this->request->tenantId,
            $this->request->cityId, $this->request->positionId, $this->request->state);

        $currencyId = $tenantService->getCurrency($this->request->tenantId, $this->request->cityId);

        $params = [
            'tenantId' => $this->request->tenantId,
            'cityId'   => $this->request->cityId,
            'tariffId' => $this->request->tariffId,

            'clientId' => $client->client_id,
            'phone'    => $this->request->phone,
            'comment'  => $this->request->comment,
            'payment'  => $this->request->payment,
            'address'  => $this->request->address,
            'cost'     => $this->request->cost,

            'currencyId'   => $currencyId,
            'positionId'   => $this->request->positionId,
            'timeOffset'   => $cityService->getTimeOffset($this->request->cityId),
            'bonusPayment' => $this->request->bonusPayment,

            'statusId'  => $statusId,
            'orderTime' => $this->request->orderTime,

            'additionalOptions' => $this->request->additionalOptions,
            'geoCoderType'      => $this->getGeoCoderType(),
            'lang'              => $this->request->lang,
        ];

        // Если для оплаты требуется наличие организации
        if ($orderService->isCompanyByPayment($this->request->payment)) {

            $params['companyId'] = $this->request->companyId;

            // Если указана неправильная организация
            if (!$clientService->isClientInCompany($client->client_id, $this->request->companyId)) {
                throw new BadParamsException();
            }
        }

        $orderId = $orderService->createOrder($params);

        $this->response->setContent([
            'order_id' => $orderId,
        ]);
    }

    /**
     * Вернуть или создать и вернуть клиента
     * @return Client|null
     */
    protected function findOrCreateClient()
    {
        /** @var ClientService $clientService */
        $clientService = app()->get('clientService');
        $client        = $clientService->findByPhone($this->request->tenantId, $this->request->phone);

        if (!$client) {
            $client = $clientService->createClientByPhone($this->request->tenantId, $this->request->cityId,
                $this->request->phone);
        }

        return $client;
    }

    protected function getGeoCoderType()
    {
        $geoCoderType = TenantSetting::getSettingValue($this->request->tenantId, TenantSetting::SETTING_GEOCODER_TYPE,
            $this->request->cityId, $this->request->positionId);

        return !empty($geoCoderType) ? $geoCoderType : CreateOrderRequest::DEFAULT_GEOCODER_TYPE;
    }

}