<?php

namespace api\exceptions;

use api\components\taxiApiRequest\TaxiErrorCode;

class NeedReauthException extends \Exception
{

    protected $code = TaxiErrorCode::NEED_REAUTH;
    protected $message = 'NEED_REAUTH';

}
