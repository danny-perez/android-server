<?php

$identity = getenv('SYSLOG_IDENTITY') . '-' . require __DIR__ . '/version.php';

\Yii::$container->set(
    \logger\targets\LogTargetInterface::class,
    \logger\targets\SyslogTarget::class,
    [$identity]
);

\Yii::$container->set(
    \logger\LogHandlerFactory::class
);