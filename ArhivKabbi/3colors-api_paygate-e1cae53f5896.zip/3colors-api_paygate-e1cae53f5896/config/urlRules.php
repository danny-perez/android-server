<?php

return [
    [
        'class'         => 'yii\rest\UrlRule',
        'controller'    => ['v0/profile'],
        'only'          => ['create', 'update', 'delete', 'index', 'view'],
        'extraPatterns' => [
            'POST'                 => 'create',
            'PUT {paymentName}'    => 'update',
            'DELETE {paymentName}' => 'delete',
            'GET {paymentName}'    => 'view',
            'GET'                  => 'index',
        ],
        'tokens'        => ['{paymentName}' => '<paymentName:[\\w\\d]*>'],
    ],
    [
        'class'         => 'yii\rest\UrlRule',
        'controller'    => ['v0/card'],
        'only'          => ['index', 'create', 'delete', 'check'],
        'extraPatterns' => [
            'POST {paymentName}/{clientId}'         => 'create',
            'DELETE {paymentName}/{clientId}/{pan}' => 'delete',
            'GET {paymentName}/{clientId}'          => 'index',
            'PUT {paymentName}/{clientId}'          => 'check',
        ],
        'tokens'        => [
            '{paymentName}' => '<paymentName:[\\w\\d]*>',
            '{clientId}'    => '<clientId:[\\w\\d]*>',
            '{pan}'         => '<pan:[|*\\w\\d]*>',
        ],
    ],
    [
        'class'         => 'yii\rest\UrlRule',
        'controller'    => ['v0/payment'],
        'only'          => ['deposit', 'refund', 'status'],
        'extraPatterns' => [
            'POST {paymentName}/{clientId}'           => 'deposit',
            'POST {paymentName}/{clientId}/{orderId}' => 'refund',
            'GET {paymentName}/{clientId}/{orderId}'  => 'status',
        ],
        'tokens'        => [
            '{paymentName}' => '<paymentName:[\\w\\d]*>',
            '{clientId}'    => '<clientId:[\\w\\d]*>',
            '{orderId}'     => '<orderId:[-\\w\\d]*>',
        ],
    ],

    'v0/yandex/order/failed' => 'v0/yandex/order/get-failed',
    'v0/yandex/order/check'  => 'v0/yandex/order/check',
    'v0/yandex/order/aviso'  => 'v0/yandex/order/aviso',

    'v0/stripe/<paymentName:[\\w\\d]+>/<clientId:[\\w\\d]+>/<locale:[\\w\\d]+>' => 'v0/stripe/registry/card',
    'v0/stripe/success/<locale:[\\w\\d]+>'                                      => 'v0/stripe/registry/success',
    'v0/stripe/fail/<locale:[\\w\\d]+>'                                         => 'v0/stripe/registry/fail',

    'v0/paycom/card/<paymentName:[\\w\\d]+>/<clientId:[\\w\\d]+>' => 'v0/paycom/card/index',
    'v0/paycom/card/save'                                         => 'v0/paycom/card/save',
    'v0/paycom/card/success'                                      => 'v0/paycom/card/success',
    'v0/paycom/card/fail'                                         => 'v0/paycom/card/fail',

    'version' => '/api/version',
    'status'  => '/api/status',
];