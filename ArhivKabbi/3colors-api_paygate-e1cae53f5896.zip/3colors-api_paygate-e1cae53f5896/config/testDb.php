<?php

return [
    'class'    => 'yii\db\Connection',
    'dsn'      => getenv('DB_MAIN_TEST_DSN'),
    'username' => getenv('DB_MAIN_TEST_USERNAME'),
    'password' => getenv('DB_MAIN_TEST_PASSWORD'),
    'charset'  => 'utf8',
];