<?php

return [
    'class'    => 'yii\db\Connection',
    'dsn'      => getenv('DB_MAIN_DSN'),
    'username' => getenv('DB_MAIN_USERNAME'),
    'password' => getenv('DB_MAIN_PASSWORD'),
    'charset'  => 'utf8',
];