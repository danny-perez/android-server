<?php

namespace yandex\components\yandex;

use yii\base\Object;

class PaymentService extends Object
{
    
}