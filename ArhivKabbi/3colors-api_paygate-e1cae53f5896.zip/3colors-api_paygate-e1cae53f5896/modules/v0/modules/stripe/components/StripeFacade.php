<?php

namespace stripe\components;

use yii\base\Object;
use stripe\models\Profile;
use stripe\models\Customer;
use stripe\exceptions\NotFoundProfileException;
use stripe\exceptions\NotFoundCustomerException;

class StripeFacade extends Object
{

    private $_profile;

    public function __construct(\stripe\models\Profile $profile = null, $config = [])
    {
        $this->_profile = $profile;
    }

    public function setProfile($paymentName)
    {
        $this->_profile = Profile::findOne(['paymentName' => $paymentName]);
    }

    /**
     *
     * @throws NotFoundProfileException
     * @return \stripe\models\Profile
     */
    public function getProfile()
    {
        if ($this->_profile) {
            return $this->_profile;
        } else {
            throw new NotFoundProfileException('No set profile');
        }
    }

    public function getUrlForRegistryCard($clientId, $locale)
    {
        $url = \Yii::$app->params['my.externalUrl'];

        return sprintf('%sv0/stripe/%s/%s/%s', $url, $this->getProfile()->paymentName, $clientId, $locale);
    }

    /**
     *
     * @param string $orderNumber
     * @param integer $amount
     * @param string  $currency Symbolic code
     * @param string  $clientId
     * @param string  $stripeToken
     * @param string  $description
     *
     * @throws NotFoundCustomerException
     * @return string
     */
    public function charge($orderNumber, $amount, $currency, $clientId, $stripeToken, $description)
    {
        /*@var $customer \stripe\models\Customer */
        if ($customer = Customer::get($clientId, $this->getProfile())) {
            $card = $customer->getCard($stripeToken);

            $charge = $customer->createCharge($card);
            $charge->setAttributes([
                'orderNumber' => $orderNumber,
                'amount'      => $amount,
                'currency'    => $currency,
                'description' => $description,
            ]);

            return $charge->pay();
        }
        throw new NotFoundCustomerException();
    }

    public function refundEntireCharge($clientId, $orderId)
    {
        /*@var $customer \stripe\models\Customer */
        if ($customer = Customer::get($clientId, $this->getProfile())) {
            $charge = $customer->getCharge($orderId);

            $refund = $charge->createRefund();
            $refund->reason = 'requested_by_customer';
            $refund->refund();

            return true;
        }

        return false;
    }

    public function getStatusCharge($clientId, $orderId)
    {
        /*@var $customer \stripe\models\Customer */
        if ($customer = Customer::get($clientId, $this->getProfile())) {
            return $customer->getCharge($orderId);
        }
    }

    public function getCardList($clientId)
    {
        /*@var $customer \stripe\models\Customer */
        if ($customer = Customer::get($clientId, $this->getProfile())) {
            return $customer->getCardList();
        }

        return [];
    }

    public function deleteCard($clientId, $cardToken)
    {
        /*@var $customer \stripe\models\Customer */
        if ($customer = Customer::get($clientId, $this->getProfile())) {
            $card = $customer->getCard($cardToken);
            $card->delete();
        }

        return true;
    }

}