<?php

namespace stripe\components;

use yii\base\Object;
use stripe\models\Charge;
use app\components\exception\ServerErrorHttpException;

class StripeApi extends Object
{
    private $_profile;

    public function __construct(\stripe\models\Profile $profile, $config = [])
    {
        $this->_profile = $profile;
        parent::__construct($config);
    }

    public function init()
    {
        parent::init();
        $this->stripeRequest(function ($key) {
            \Stripe\Stripe::setApiKey($key);
        }, [$this->_profile->privateKey]);
    }

    public function createCustomer(\stripe\models\Customer $customer)
    {
        return $this->stripeRequest(function ($params) {
            return \Stripe\Customer::create($params);
        }, [
            [
                'business_vat_id' => $customer->clientId,
                "description"     => "Customer #{$customer->clientId} for {$this->_profile->paymentName}",
            ],
        ]);
    }

    public function addCardToCustomer(\stripe\models\Card $card, \stripe\models\Customer $customer)
    {
        $this->stripeRequest(function ($params) {
            list ($customerId, $sourceToken) = $params;
            \Stripe\Customer::retrieve($customerId)->sources->create([
                'source' => $sourceToken,
            ]);
        }, [
            [
                $customer->stripeCustomerId,
                $card->stripeToken,
            ],
        ]);
    }

    /**
     * @param \stripe\models\Customer $customer
     *
     * @return \stripe\models\Card[]
     */
    public function getCardList(\stripe\models\Customer $customer)
    {
        $cardList = $this->stripeRequest(function ($customerId) {
            return \Stripe\Customer::retrieve($customerId)->sources->all([
                'object' => 'card',
            ]);
        }, [$customer->stripeCustomerId])->data;

        $result = [];
        foreach ($cardList as $stripeCard) {
            $card = new \stripe\models\Card($customer);
            $card->setAttributes([
                'stripeToken' => $stripeCard->id,
                'clientId'    => $customer->clientId,
                'maskedPan'   => sprintf('****%s', $stripeCard->last4),
            ]);
            $result[] = $card;
        }

        return $result;
    }

    public function deleteCard(\stripe\models\Card $card, \stripe\models\Customer $customer)
    {
        $this->stripeRequest(function ($params) {
            list ($customerId, $sourceToken) = $params;
            $cus = \Stripe\Customer::retrieve($customerId);
            $cus->sources->retrieve($sourceToken)
                ->delete();
        }, [
            [
                $customer->stripeCustomerId,
                $card->stripeToken,
            ],
        ]);
    }

    /**
     *
     * @param \stripe\models\Charge $charge
     *
     * @return string
     */
    public function createCharge(\stripe\models\Charge $charge)
    {
        $charge = $this->stripeRequest(function ($params, $options = null) {
            return \Stripe\Charge::create($params, $options);
        }, [
            [
                'amount'      => $charge->amount,
                'currency'    => $charge->currency,
                'customer'    => $charge->getCustomer()->stripeCustomerId,
                'source'      => $charge->getCard()->stripeToken,
                'description' => $charge->description,
                'metadata'    => ['orderNumber' => $charge->orderNumber],
            ],
            [
                'idempotency_key' => md5($charge->orderNumber),
            ],
        ]);

        return $charge->id;
    }

    public function retrieveCharge(\stripe\models\Customer $customer, $id)
    {
        $charge = $this->stripeRequest(function ($id) {
            return \Stripe\Charge::retrieve($id);
        }, [$id]);
        $card = $customer->getCard($charge->source->id, $charge->source->last4);

        $chargeModel = new Charge($customer, $card);
        $chargeModel->setAttributes([
            'id'          => $charge->id,
            'amount'      => $charge->amount,
            'currency'    => $charge->currency,
            'description' => $charge->description,
            'captured'    => $charge->captured,
        ]);

        return $chargeModel;
    }

    public function createRefund(\stripe\models\Refund $refund)
    {
        $params = [
            'charge' => $refund->getCharge()->id,
            'reason' => $refund->reason,
        ];
        if ($refund->amount) {
            $params['amount'] = $refund->amount;
        }

        $this->stripeRequest(function ($params) {
            \Stripe\Refund::create($params);
        }, [$params]);
    }


    private function stripeRequest($callback, $params = [])
    {
        try {
            return call_user_func_array($callback, $params);
        } catch (\Stripe\Error\Card $e) {
            throw new StripeException('Card error on stripe', $e);
        } catch (\Stripe\Error\RateLimit $e) {
            // Too many requests made to the API too quickly
            throw new StripeException('Repeat request later', $e);
        } catch (\Stripe\Error\InvalidRequest $e) {
            // Invalid parameters were supplied to Stripe's API
            throw new ServerErrorHttpException('Error params on request', $e);
        } catch (\Stripe\Error\Authentication $e) {
            // Authentication with Stripe's API failed
            // (maybe you changed API keys recently)
            throw new StripeException('Error on token stripe', $e);
        } catch (\Stripe\Error\ApiConnection $e) {
            // Network communication with Stripe failed
            throw new StripeException('Not connect to stripe server', $e);
        } catch (\Stripe\Error\Base $e) {
            // Display a very generic error to the user, and maybe send
            // yourself an email
            throw new ServerErrorHttpException('Inner error on stripe', $e);
        } catch (\Exception $e) {
            // Something else happened, completely unrelated to Stripe
            throw new ServerErrorHttpException('Illegal error on stripe', $e);
        }
    }
}