<?php

namespace v0\handlers\card;

use \v0\handlers\base\BaseHandler;
use v0\models\Card;
use yandex\models\Profile;

class CheckNewCardHandler extends BaseHandler
{

    public function run(\yii\di\Container $container)
    {
        // temporary hack for yandex
        if ($container->get('paygateProfile') instanceof Profile
            || $container->get('paygateProfile') instanceof \paycom\models\Profile) {
            $container->get('response')->setStatusCode(202);
        } else {
            Card::check($container->get('request')->post('orderId'));
        }

        parent::run($container);
    }
}