<?php

namespace v0\components\payment\types;

use v0\models\Currency;

class AlphaBank extends BasicPayment
{
    public function init()
    {
        $this->extraPaymentParams = ['features' => 'AUTO_PAYMENT'];
    }

    public function register($paymentOrder, $bindingId = null)
    {
        if (!empty($this->currency) && empty($paymentOrder->currency)) {
            $paymentOrder->currency = (int)$this->currency;
        }

        if ($paymentOrder->validate('currency')) {
            $currency = Currency::findOne([
                'code' => $paymentOrder->currency,
            ]);
            if ($currency) {
                $paymentOrder->currency = $currency->oldCode;
            }
        }

        return parent::register($paymentOrder, $bindingId);
    }
}