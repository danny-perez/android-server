<?php

namespace v0\components\payment\types;

/**
 * Втб
 * @package v0\components\payment\types
 */
class Vtb extends BasicPayment
{
}