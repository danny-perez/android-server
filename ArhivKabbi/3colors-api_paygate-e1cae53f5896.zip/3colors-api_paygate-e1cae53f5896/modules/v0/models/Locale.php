<?php

namespace v0\models;


trait Locale
{
    public $locale;
}