-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: db.taxi.lcl    Database: paygate
-- ------------------------------------------------------
-- Server version	5.6.29-1~dotdeb+7.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `oldCode` int(11) NOT NULL,
  `description` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=976 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kkb_payment_gate_profile`
--

DROP TABLE IF EXISTS `kkb_payment_gate_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kkb_payment_gate_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `merchantId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `merchantName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `certificateId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `privateCertificate` blob NOT NULL,
  `privateCertificatePass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `publicCertificate` blob NOT NULL,
  `isDebug` int(1) NOT NULL DEFAULT '0',
  `cardBindingSum` int(11) NOT NULL DEFAULT '1',
  `commission` float DEFAULT '0',
  `currency` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`),
  UNIQUE KEY `merchantId` (`merchantId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paycom_card`
--

DROP TABLE IF EXISTS `paycom_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paycom_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `clientId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pan` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paycom_card` (`paymentName`,`clientId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paycom_payment`
--

DROP TABLE IF EXISTS `paycom_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paycom_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `clientId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `orderNumber` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `receiptId` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paycom_payment` (`paymentName`,`clientId`),
  KEY `idx_paycom_payment_receiptId` (`receiptId`(255))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paycom_profile`
--

DROP TABLE IF EXISTS `paycom_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paycom_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `apiId` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `isDebug` int(1) NOT NULL DEFAULT '0',
  `commission` float DEFAULT '0',
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_gate_profile`
--

DROP TABLE IF EXISTS `payment_gate_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gate_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `typeId` int(11) NOT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `password` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `commission` float DEFAULT '0',
  `returnUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'finish.html',
  `failUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`),
  KEY `payment_type` (`typeId`),
  CONSTRAINT `payment_type` FOREIGN KEY (`typeId`) REFERENCES `payment_gate_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_gate_type`
--

DROP TABLE IF EXISTS `payment_gate_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gate_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `classname` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sberbank_payment_gate_profile`
--

DROP TABLE IF EXISTS `sberbank_payment_gate_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sberbank_payment_gate_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) NOT NULL,
  `usernameBinding` varchar(32) DEFAULT '',
  `passwordBinding` varchar(255) DEFAULT '',
  `usernamePayment` varchar(32) DEFAULT '',
  `passwordPayment` varchar(255) DEFAULT '',
  `url` varchar(255) NOT NULL,
  `commission` float DEFAULT '0',
  `returnUrl` varchar(255) DEFAULT 'finish.html',
  `failUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stripe_customer`
--

DROP TABLE IF EXISTS `stripe_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profileId` int(11) NOT NULL,
  `clientId` varchar(255) NOT NULL,
  `stripeCustomerId` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_customer` (`profileId`),
  CONSTRAINT `profile_customer` FOREIGN KEY (`profileId`) REFERENCES `stripe_payment_gate_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stripe_payment_gate_profile`
--

DROP TABLE IF EXISTS `stripe_payment_gate_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_payment_gate_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) NOT NULL,
  `publicKey` varchar(255) NOT NULL,
  `privateKey` varchar(255) NOT NULL,
  `commission` float DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_check`
--

DROP TABLE IF EXISTS `tbl_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yandex_order_binding`
--

DROP TABLE IF EXISTS `yandex_order_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yandex_order_binding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shopId` bigint(20) NOT NULL,
  `clientId` varchar(32) NOT NULL,
  `invoiceId` varchar(255) NOT NULL,
  `pan` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yandex_payment`
--

DROP TABLE IF EXISTS `yandex_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yandex_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerNumber` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderNumber` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `baseInvoiceId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destination` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sum` decimal(12,2) DEFAULT NULL,
  `shopId` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shopArticleId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avisoInvoiceId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avisoSum` decimal(12,2) DEFAULT NULL,
  `avisoCurrency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repeatId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repeatStatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repeatError` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repeatTechMessage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repeatProcessedDT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancelId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancelStatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancelError` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancelTechMessage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancelProcessedDT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmStatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmError` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmInvoiceId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmRequestDT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnStatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnError` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnTechMessage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnProcessedDT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gootaxResult` enum('WAITING','SUCCESS','FAIL') COLLATE utf8_unicode_ci DEFAULT 'WAITING',
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  `cardSynonym` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yandex_payment_1` (`orderNumber`,`shopId`),
  KEY `idx_yandex_payment_2` (`paymentName`,`shopId`)
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yandex_payment_gate_profile`
--

DROP TABLE IF EXISTS `yandex_payment_gate_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yandex_payment_gate_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentName` varchar(32) NOT NULL,
  `shopId` int(11) NOT NULL,
  `scid` int(11) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `commission` smallint(3) DEFAULT '0',
  `isDebug` tinyint(1) DEFAULT NULL,
  `certificateContent` blob NOT NULL,
  `certificatePassword` varchar(255) DEFAULT '',
  `keyContent` blob NOT NULL,
  `secureDeal` int(11) NOT NULL DEFAULT '0',
  `secureDealShopId` int(11) DEFAULT NULL,
  `secureDealScid` int(11) DEFAULT NULL,
  `shopArticleId` int(11) DEFAULT NULL,
  `secureDealShopArticleId` int(11) DEFAULT NULL,
  `secureDealPaymentShopId` int(11) DEFAULT NULL,
  `secureDealPaymentScid` int(11) DEFAULT NULL,
  `secureDealPaymentShopArticleId` int(11) DEFAULT NULL,
  `cardBindingSum` int(11) NOT NULL DEFAULT '1',
  `agentId` int(11) DEFAULT NULL,
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  `useReceipt` int(1) DEFAULT '0',
  `product` varchar(128) DEFAULT NULL,
  `vat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paymentName` (`paymentName`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yandex_payment_register`
--

DROP TABLE IF EXISTS `yandex_payment_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yandex_payment_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shopId` int(11) NOT NULL,
  `paymentName` varchar(255) NOT NULL,
  `customerNumber` varchar(255) NOT NULL,
  `orderNumber` varchar(255) NOT NULL,
  `gootaxResult` enum('WAITING','SUCCESSFUL','FAILED') DEFAULT 'WAITING',
  `yandexResult` enum('WAITING','SUCCESSFUL','FAILED') DEFAULT 'WAITING',
  `createdAt` int(11) DEFAULT NULL,
  `updatedAt` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-08 13:27:59
