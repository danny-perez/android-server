<?php

namespace tests\unit\v0\models;

use v0\models\PaymentOrder;
use v0\Module as V0;

class PaymentOrderTest extends \Codeception\Test\Unit
{
    /**
     * @dataProvider validateProvider
     */
    public function testValidateWithWrongParam($attribute, $value)
    {
        $paymentOrder             = new PaymentOrder([
            'pan'         => '1234**5678',
            'amount'      => 1000,
            'orderNumber' => '1',
        ]);
        $paymentOrder->$attribute = $value;
        $this->assertFalse($paymentOrder->validate());
    }

    public function validateProvider()
    {
        return [
            ['pan', str_repeat('1', 21)],           // max length 20
            ['amount', null],                       // required
            ['amount', 99],                         // min 100
            ['orderNumber', null],                  // required
            ['orderNumber', str_repeat('2', 21)],   // max length 20
            ['currency', 0],                       // min 100
            ['currency', 1000],                     // max 999
            ['description', str_repeat('3', 256)],  // max length 256
        ];
    }

    public function testValidateSuccess()
    {
        $paymentOrder = new PaymentOrder([
            'pan'         => '1234**5678',
            'amount'      => 100,
            'orderNumber' => '1',
            'currency'    => 643,
            'description' => 'Test',
        ]);
        $this->assertTrue($paymentOrder->validate());
    }

    public function testValidateMinimalSuccess()
    {
        $paymentOrder = new PaymentOrder([
            'pan'         => '1234**5678',
            'amount'      => 100,
            'orderNumber' => '1',
        ]);
        $this->assertTrue($paymentOrder->validate());
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testRefundWhenErrorStatusOnPay()
    {
        $this->createStubPayment([
            ['status', ['pan' => '1234**5678', 'amount' => 1000, 'actionCode' => 116], $this->once()],
            ['refund', null, $this->never()],
        ]);
        PaymentOrder::refund('1');
    }

    private function createStubPayment($stubs)
    {
        $stub = $this->createMock('v0\components\payment\types\BasicPayment');
        foreach ($stubs as $one) {
            list($method, $return, $calling) = $one;
            $stub->expects($calling)
                ->method($method)
                ->will($this->returnValue($return));
        }
        V0::setComponent('payment', $stub);
    }
}