<?php

namespace tests\unit\v0\models;

use v0\Module as V0;
use v0\models\Card;

class CardTest extends \Codeception\Test\Unit
{
    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testCheckCardofRefundWhenErrorStatusOnPay()
    {
        $this->createStubPayment([
            [
                'status',
                ['pan' => '1234**5678', 'amount' => 1000, 'actionCode' => 116, 'client_id' => 1, 'binding_id' => 1],
                $this->once(),
            ],
            ['refund', null, $this->never()],
        ]);
        $this->createStubCache();
        Card::check('orderId');
    }

    /**
     * @expectedExceptionCode 4
     * @expectedException app\components\exception\CardErrorHttpException
     */
    public function testCheckWhenClientNotSaveBinding()
    {
        $this->createStubPayment([
            [
                'status',
                ['pan' => '1234**5678', 'amount' => 1000, 'actionCode' => 0, 'client_id' => '', 'binding_id' => ''],
                $this->once(),
            ],
            ['refund', true, $this->once()],
        ]);
        $this->createStubCache();
        Card::check('orderId');
    }

    /**
     * @expectedExceptionCode 2
     * @expectedException app\components\exception\NotFoundHttpException
     */
    public function testCheckWhenNotFonundOrderIdInCache()
    {
        $this->createStubPayment([
            [
                'status',
                ['pan' => '1234**5678', 'amount' => 1000, 'actionCode' => 0, 'client_id' => '', 'binding_id' => ''],
                $this->never(),
            ],
            ['refund', true, $this->never()],
        ]);
        Card::check('orderId');
    }

    private function createStubPayment($stubs)
    {
        $stub = $this->createMock('v0\components\payment\types\BasicPayment');
        foreach ($stubs as $one) {
            list($method, $return, $calling) = $one;
            $stub->expects($calling)
                ->method($method)
                ->will($this->returnValue($return));
        }
        V0::setComponent('payment', $stub);
    }

    private function createStubCache()
    {
        $stub = $this->createMock('yii\caching\DbCache');
        $stub->expects($this->any())
            ->method('get')
            ->will($this->returnValue(true));
        V0::setComponent('cache', $stub);
    }
}
