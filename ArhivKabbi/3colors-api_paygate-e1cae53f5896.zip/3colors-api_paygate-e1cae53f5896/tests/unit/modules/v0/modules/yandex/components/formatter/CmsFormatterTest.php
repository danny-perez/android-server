<?php

namespace tests\unit\yandex\components\formatter;

use yandex\components\formatter\CmsFormatter;

class CmsFormatterTest extends \Codeception\Test\Unit
{
    public function testTodoCms()
    {
        $formatter = new CmsFormatter('', '');
        // TODO later
    }

    public function testMimeTypeToPkcs7()
    {
        $formatter = new CmsFormatter('', '');
        $this->assertEquals('application/pkcs7-mime', $formatter->getMimeType());
    }

}