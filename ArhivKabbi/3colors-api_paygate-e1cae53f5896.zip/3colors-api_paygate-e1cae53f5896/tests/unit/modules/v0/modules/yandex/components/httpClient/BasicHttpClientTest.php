<?php

namespace tests\unit\yandex\components\httpClient;

use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Client;
use yandex\components\httpClient\BasicHttpClient;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\Exception\RequestException;

class BasicHttpClientTest extends \Codeception\Test\Unit
{
    public function testGetCorrectlyInformationOnHttpClient()
    {
        $httpClient = $this->getMockClient([
            new Response(200, ['Content-Type' => 'application/json'], '{"content":"data"}'),
        ]);
        $response   = $httpClient->post('http://localhost', 'request data');

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertEquals(['application/json'], $response->getHeader('Content-Type'));
        $this->assertEquals('{"content":"data"}', $response->getBody());
    }

    /**
     * @expectedExceptionCode 255
     * @expectedException \yandex\components\httpClient\HttpClientException
     */
    public function testTimeoutExceptionOnHttpClient()
    {
        $httpClient = $this->getMockClient([
            new ConnectException('Timeout', new Request('http://localhost', '/test')),
        ]);
        $httpClient->post('http://localhost', 'request data');
    }

    /**
     * @expectedExceptionCode 255
     * @expectedException \yandex\components\httpClient\HttpClientException
     */
    public function testClientErrorOnResponseToHttpClient()
    {
        $httpClient = $this->getMockClient([
            new ClientException('Client Exception', new Request('http://localhost', '/test')),
        ]);
        $httpClient->post('http://localhost', 'request data');
    }

    /**
     * @expectedExceptionCode 255
     * @expectedException \yandex\components\httpClient\HttpClientException
     */
    public function testServerErrorOnResposenToHttpClient()
    {
        $httpClient = $this->getMockClient([
            new ServerException('Server Exception', new Request('http://localhost', '/test')),
        ]);
        $httpClient->post('http://localhost', 'request data');
    }

    /**
     * @expectedExceptionCode 255
     * @expectedException \yandex\components\httpClient\HttpClientException
     */
    public function testOtherErrorOnResponseToHttpClient()
    {
        $httpClient = $this->getMockClient([
            new RequestException('Other Exception', new Request('http://localhost', '/test')),
        ]);
        $httpClient->post('http://localhost', 'request data');
    }

    protected function getMockClient($requests = [])
    {
        $mock    = new MockHandler($requests);
        $handler = HandlerStack::create($mock);

        return new BasicHttpClient(new Client(['handler' => $handler]));
    }
}