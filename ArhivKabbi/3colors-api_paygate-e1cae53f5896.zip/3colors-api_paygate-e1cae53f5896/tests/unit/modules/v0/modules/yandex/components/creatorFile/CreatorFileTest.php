<?php

namespace tests\unit\yandex\components\creatorFile;

use yandex\components\creatorFile\CreatorFile;

class CreatorFileTest extends \Codeception\Test\Unit
{
    public function testContentOnTmpFile()
    {
        $creator = new CreatorFile();
        $file    = $creator->createTmpFile('tmp data');

        $this->assertInstanceOf('SplFileInfo', $file);
        $this->assertFileExists($file->getRealPath());
        $this->assertEquals('tmp data', file_get_contents($file->getRealPath()));
    }

}