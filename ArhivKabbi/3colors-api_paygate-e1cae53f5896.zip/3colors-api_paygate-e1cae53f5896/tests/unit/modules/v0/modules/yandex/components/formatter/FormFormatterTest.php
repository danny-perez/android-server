<?php

namespace tests\unit\yandex\components\formatter;

use yandex\components\formatter\FormFormatter;

class FormFormatterTest extends \Codeception\Test\Unit
{
    public function testMimeTypeToFormUrlencode()
    {
        $formatter = new FormFormatter();
        $this->assertEquals('application/x-www-form-urlencoded', $formatter->getMimeType());
    }

    public function testFormFormatterIsFormatter()
    {
        $formatter = new FormFormatter();
        $this->assertInstanceOf('\yandex\components\formatter\Formatter', $formatter);
    }

    public function testConvertArrayToStringUrlencode()
    {
        $formatter = new FormFormatter();
        $this->assertEquals('key1=1&key2=val', $formatter->format(['key1' => 1, 'key2' => 'val']));
    }

}