<?php

namespace tests\unit\sberbank\components\payment;

use sberbank\components\payment\PaymentProcessing;

/**
 * Class PaymentProcessingTest
 * @package tests\unit\sberbank\components\payment
 */
class PaymentProcessingTest extends \Codeception\Test\Unit
{

    public function validateData()
    {
        return [
            'Card declined [actionCode=100]'    => [
                100,
                'sberbank\components\payment\SberbankException',
            ],
            'Expired card [actionCode=101]'     => [
                101,
                'sberbank\components\payment\SberbankException',
            ],
            'Not enough money [actionCode=116]' => [
                116,
                'app\components\exception\NotEnoughMoneyHttpException',
            ],
            'Not allowed [actionCode=120]'      => [
                120,
                'sberbank\components\payment\SberbankException',
            ],
        ];
    }

    /**
     * @dataProvider validateData
     */
    public function testValidate($actionCode, $errorClass)
    {
        $this->expectException($errorClass);

        $processing = new PaymentProcessing();
        $processing->validate($actionCode);
    }


    public function testValidateSuccessPayment()
    {
        $processing = new PaymentProcessing();
        $processing->validate(0);
    }

}