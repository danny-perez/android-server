<?php

namespace tests\unit\yandex\components\formatter;

use yandex\components\formatter\XmlFormatter;

class XmlFormatterTest extends \Codeception\Test\Unit
{
    public function testXmlFormatterIsFormatter()
    {
        $formatter = new XmlFormatter('request');
        $this->assertInstanceOf('\yandex\components\formatter\Formatter', $formatter);
    }

    public function testConvertAssocArrayToXml()
    {
        $formatter = new XmlFormatter('request');
        $this->assertEquals("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
            "<request key1=\"1\" key2=\"string\"/>\n",
            $formatter->format(['key1' => 1, 'key2' => 'string']));
    }

    public function testRootnameOnXML()
    {
        $formatter = new XmlFormatter('root');
        $this->assertEquals("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root/>\n",
            $formatter->format([]));
    }

    public function testMimeTypeToXML()
    {
        $formatter = new XmlFormatter('request');
        $this->assertEquals('application/xml', $formatter->getMimeType());
    }

}