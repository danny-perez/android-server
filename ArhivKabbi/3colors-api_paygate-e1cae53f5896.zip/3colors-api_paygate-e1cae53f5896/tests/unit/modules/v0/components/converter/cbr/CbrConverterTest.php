<?php

namespace tests\unit\v0\components\converter\cbr;

use v0\components\converter\cbr\Cbr;
use v0\components\converter\cbr\CbrConverter;
use V0\Module as V0;

/**
 * Class CbrConverterTest
 * @package tests\unit\v0\components\converter\cbr
 */
class CbrConverterTest extends \Codeception\Test\Unit
{
    private function setResponseStub($value)
    {
        $mock = $this->createMock('v0\components\curl\Curl');
        $mock->expects($this->any())
            ->method('get')
            ->will($this->returnValue($value));
        V0::setComponent('curl', $mock);
    }

    public function convertData()
    {
        return [
            'test RUB' => [643, 12345, 12345],
            'test USD' => [840, 12345, 813472],
            'test EUR' => [978, 12345, 906858],
            'test AZN' => [944, 12345, 545955],
            'test BYR' => [974, 12345, 41],
        ];
    }

    /**
     * @dataProvider convertData
     */
    public function testConvert($currency, $amount, $expected)
    {
        $cbr       = new Cbr();
        $converter = new CbrConverter($cbr);

        $xml = file_get_contents(__DIR__ . '/data/valid.xml');
        $this->setResponseStub($xml);

        $value = $converter->convert($currency, CbrConverter::CODE_RUB, $amount);

        $this->assertEquals($expected, $value, '', 0.01);

    }

    public function convertExceptionsData()
    {
        return [
            'convent to not RUB' => [
                643,
                944,
                1000,
                'app\components\exception\InvalidArgumentException',
            ],
        ];
    }

    /**
     * @dataProvider convertExceptionsData
     */
    public function testConvertExceptions(
        $from,
        $to,
        $amount,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);

        $cbr       = new Cbr();
        $converter = new CbrConverter($cbr);

        $converter->convert($from, $to, $amount);
    }

}