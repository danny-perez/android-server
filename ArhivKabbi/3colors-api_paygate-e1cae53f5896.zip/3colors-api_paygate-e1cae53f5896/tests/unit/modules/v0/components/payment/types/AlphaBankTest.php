<?php

namespace tests\unit\v0\components\payment\types;

use v0\components\payment\types\AlphaBank;
use v0\models\Customer;
use v0\Module as V0;
use v0\models\PaymentOrder;

class AlphaBankTest extends \Codeception\Test\Unit
{
    private $payment;

    protected function setUp()
    {
        parent::setUp();
        $this->payment = new AlphaBank([
            'customer' => new Customer(['clientId' => 'testUser_unit']),
            'username' => '3colors-api',
            'password' => '3colors',
            'url'      => 'https://test.paymentgate.ru/testpayment/rest/',
        ]);
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    public function testGetUrlAndNumberOrderForPayment()
    {
        $this->stubResponse('{"orderId":"6...","formUrl":"https://test.ru"}');
        $order = new PaymentOrder([
            'orderNumber' => 'order id',
            'amount'      => 100,
        ]);
        $this->assertArrayHasKey('url', $this->payment->register($order));
        $this->assertArrayHasKey('order', $this->payment->register($order));
    }

    /**
     * @expectedExceptionCode 1
     * @expectedException app\components\exception\InvalidArgumentException
     */
    public function testExceptionRegisterWhereWrongAmount()
    {
        $order = new PaymentOrder([
            'orderNumber' => 'order id',
            'amount'      => 'wrong_amount',
        ]);
        $this->payment->register($order);
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testExceptionRegisterWhereWrongOrderId()
    {
        $this->stubResponse('{"errorCode":1,"errorMessage":"Error"}');
        $order = new PaymentOrder([
            'orderNumber' => 'wrong order id',
            'amount'      => 1000,
        ]);
        $this->payment->register($order);
    }

    public function testDepositPaymentOrder()
    {
        $this->stubResponse('{"errorCode":0}');
        $this->assertTrue($this->payment->deposit('order id', 100));
    }

    /**
     * @expectedExceptionCode 1
     * @expectedException app\components\exception\InvalidArgumentException
     */
    public function testExceptionDepositOnWrongAmount()
    {
        $this->assertTrue($this->payment->deposit('order id', 10));
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testExceptionDepositWhereWrongOrderId()
    {
        $this->stubResponse('{"errorCode":6,"errorMessage":"Error"}');
        $this->payment->deposit('wrong order id', 1000);
    }

    public function testRefundPaymentOrder()
    {
        $this->stubResponse('{"errorCode":"0","errorMessage":"Успешно"}');
        $this->assertTrue($this->payment->refund('order id', 1000));
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testExceptionRefundWrongOrder()
    {
        $this->stubResponse('{"errorCode":6}');
        $this->assertTrue($this->payment->refund('wrong order id', 1000));
    }

    public function testStatusInPaymentGateway()
    {
        $this->stubResponse('{"errorCode":"0","errorMessage":"Успешно",
            "orderNumber":"replicate_sx5QjqQM","orderStatus":0,"actionCode":116,
            "amount":100,"currency":"810", "bindingInfo":{"clientId":"testUser",
            "bindingId":"fff93e1c-bf70-41ba-bda3-c0120c91942e"}}'
        );
        $status = $this->payment->status('order id');
        $this->assertArrayHasKey('pan', $status);
        $this->assertArrayHasKey('client_id', $status);
        $this->assertArrayHasKey('binding_id', $status);
    }

    public function testStatusInPaymentGatewayWithoutBindingId()
    {
        $this->stubResponse('{"errorCode":"0","errorMessage":"Успешно",
            "orderNumber":"replicate_sx5QjqQM","orderStatus":0,"actionCode":116,
            "amount":100,"currency":"810", "bindingInfo":{"clientId":"testUser"}}'
        );
        $status = $this->payment->status('order id');
        $this->assertArrayHasKey('pan', $status);
        $this->assertArrayHasKey('client_id', $status);
        $this->assertArrayHasKey('binding_id', $status);
        $this->assertNull($status['binding_id']);
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testExceptionStatusWrongOrderId()
    {
        $this->stubResponse('{"errorCode":6,"errorMessage":"Error"}');
        $this->payment->status('wrong order id');
    }

    public function testBindingsOnSuccess()
    {
        $this->stubResponse('{"errorCode":"0","errorMessage":"Успешно",
            "bindings":[{"bindingId":"cc786cb0-3fbe-49da-b012-e1d079ade87c","maskedPan":"411111**1111","expiryDate":"201512"},
            {"bindingId":"61a8b543-d341-4788-ade0-f64e2a82f893","maskedPan":"601100**0004","expiryDate":"201512"}]}'
        );
        $bindings = $this->payment->bindings('client id');
        $this->assertCount(2, $bindings);
        $this->assertArrayHasKey('binding', $bindings[0]);
        $this->assertArrayHasKey('pan', $bindings[0]);
    }

    public function testBindingsWithNotFullResponse()
    {
        $this->stubResponse('{"errorCode":"0",
            "bindings":[{"bindingId":"cc786cb0-3fbe-49da-b012-e1d079ade87c"},
            {"bindingId":"61a8b543-d341-4788-ade0-f64e2a82f893","maskedPan":"601100**0004","expiryDate":"201512"}]}'
        );
        $bindings = $this->payment->bindings('client id');
        $this->assertCount(1, $bindings);
        $this->assertArrayHasKey('binding', $bindings[0]);
        $this->assertArrayHasKey('pan', $bindings[0]);
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testBindingWithWrongClientId()
    {
        $this->stubResponse('{"errorCode":"2","errorMessage":"Информация не найдена"}');
        $this->payment->bindings('wrong client id');
    }

    public function testDeactivedBindingSuccess()
    {
        $this->stubResponse('{"errorCode":"0","errorMessage":"Успешно"}');
        $this->assertTrue($this->payment->unbind('binding-id-1'));
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testDeactivedBindingWnenYetDeactive()
    {
        $this->stubResponse('{"errorCode":"2","errorMessage":"Binging isn\'t active"}');
        $this->payment->unbind('binding-id-1');
    }

    public function testPaymentOrderSuccess()
    {
        $this->stubReponsePayment(
            '{"redirect":"finish.html","info":"Ваш платёж обработан...","errorCode":0}',
            '{"errorCode":"0","errorMessage":"Успешно","orderNumber":"replicate_sx5QjqQM","orderStatus":0,"actionCode":0,"amount":100,"currency":"810"}'
        );
        $this->assertTrue($this->payment->payment('order id in payment', 'binding id'));
    }

    /**
     * @expectedExceptionCode 3
     * @expectedException app\components\exception\ServiceErrorHttpException
     */
    public function testPaymentOrderException()
    {
        $this->stubReponsePayment('{"errorCode":"2","errorMessage":"Заказ с таким номером не найден"}', '');
        $this->payment->payment('wrong order id in payment', 'binding id');
    }

    /**
     * @expectedExceptionCode 16
     * @expectedException app\components\exception\NotEnoughMoneyHttpException
     */
    public function testPaymentNotEnoughMoney()
    {
        $this->stubReponsePayment(
            '{"redirect":"finish.html","info":"Ваш платёж обработан...","errorCode":0}',
            '{"errorCode":"0","errorMessage":"Успешно","orderNumber":"replicate_sx5QjqQM","orderStatus":0,"actionCode":116,"amount":100,"currency":"810", "bindingInfo":{"clientId":"testUser","bindingId":"fff93e1c-bf70-41ba-bda3-c0120c91942e"}}'
        );
        $this->payment->payment('wrong order id in payment', 'binding id');
    }

    private function stubResponse($value)
    {
        $stub = $this->createMock('v0\components\curl\Curl');
        $stub->expects($this->any())
            ->method('post')
            ->will($this->returnValue($value));
        V0::setComponent('curl', $stub);
    }

    private function stubReponsePayment($onCreate, $onStatus)
    {
        $stub = $this->createMock('v0\components\curl\Curl');
        $stub->expects($this->any())
            ->method('post')
            ->will($this->onConsecutiveCalls($onCreate, $onStatus));
        V0::setComponent('curl', $stub);
    }
}