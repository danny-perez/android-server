<?php

namespace tests\unit\v0\components\converter\cbr;

use v0\components\converter\cbr\CachedCbr;
use v0\Module as V0;

/**
 * Class CachedCbrTest
 * @package tests\unit\v0\components\converter\cbr
 */
class CachedCbrTest extends \Codeception\Test\Unit
{
    private function setResponseMock($value, $times = 1)
    {
        $mock = $this->createMock('v0\components\curl\Curl');
        $mock->expects($this->exactly($times))
            ->method('get')
            ->will($this->returnValue($value));
        V0::setComponent('curl', $mock);
    }

    public function testGetCurrencyRates()
    {
        $cache = V0::getComponent('cache');
        $cache->delete(CachedCbr::CACHE_KEY);

        $cbr = new CachedCbr();

        $xml = file_get_contents(__DIR__ . '/data/valid.xml');
        $this->setResponseMock($xml);

        $cbr->getCurrencyRates();
        $cbr->getCurrencyRates();
    }

    public function testGetCurrencyRatesWithRefreshDuration()
    {
        $cache = V0::getComponent('cache');
        $cache->delete(CachedCbr::CACHE_KEY);

        $cbr = new CachedCbr(['refreshDuration' => 0]);

        $xml = file_get_contents(__DIR__ . '/data/valid.xml');
        $this->setResponseMock($xml, 2);

        $cbr->getCurrencyRates();
        sleep(1);
        $cbr->getCurrencyRates();
    }

    public function testGetCurrencyRatesWithRefreshDurationAndInvalidXML()
    {
        $cache = V0::getComponent('cache');
        $cache->delete(CachedCbr::CACHE_KEY);

        $cbr = new CachedCbr(['refreshDuration' => 0]);

        $xml = file_get_contents(__DIR__ . '/data/valid.xml');
        $this->setResponseMock($xml);
        $cbr->getCurrencyRates();

        sleep(1);

        $xml = 'invalid xml';
        $this->setResponseMock($xml);
        $cbr->getCurrencyRates();
    }

}