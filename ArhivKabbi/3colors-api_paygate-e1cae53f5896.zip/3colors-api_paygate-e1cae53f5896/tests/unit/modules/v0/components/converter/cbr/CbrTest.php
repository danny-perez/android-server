<?php

namespace tests\unit\v0\components\converter\cbr;

use v0\components\converter\cbr\Cbr;
use V0\Module as V0;

/**
 * Class CbrTest
 * @package tests\unit\v0\components\converter\cbr
 */
class CbrTest extends \Codeception\Test\Unit
{
    /**
     * @var \UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    private function setResponseStub($value)
    {
        $mock = $this->createMock('v0\components\curl\Curl');
        $mock->expects($this->any())
            ->method('get')
            ->will($this->returnValue($value));
        V0::setComponent('curl', $mock);
    }

    public function getCurrencyRateData()
    {
        return [
            'test USD' => [840, 65.8949, 1],
            'test EUR' => [978, 73.4596, 1],
            'test AZN' => [944, 44.2248, 1],
            'test BYR' => [974, 33.4322, 10000],
        ];
    }

    /**
     * @dataProvider getCurrencyRateData
     */
    public function testGetCurrencyRate($currency, $expectedRate, $expectedNominal)
    {
        $cbr = new Cbr();

        $xml = file_get_contents(__DIR__ . '/data/valid.xml');
        $this->setResponseStub($xml);

        $rate = $cbr->getCurrencyRate($currency);

        $this->assertEquals($expectedRate, $rate->value, '', 0.0001);
        $this->assertEquals($expectedNominal, $rate->nominal, '', 0.0001);
    }

    public function getCurrencyRateExceptionsDate()
    {
        return [
            'invalid file type'     => [
                '/data/invalid_file_type.txt',
                0,
                'app\components\exception\ServerErrorHttpException',
            ],
            'xml file with errors'  => [
                '/data/xml_file_with_errors.xml',
                0,
                'app\components\exception\ServerErrorHttpException',
            ],
            'invalid xml structure' => [
                '/data/invalid_xml_structure.xml',
                0,
                'app\components\exception\InvalidArgumentException',
            ],
            'invalid currency code' => [
                '/data/valid.xml',
                0,
                'app\components\exception\InvalidArgumentException',
            ],
        ];
    }

    /**
     * @dataProvider getCurrencyRateExceptionsDate
     */
    public function testGetCurrencyRateExceptions(
        $xmlFile,
        $currency,
        $exceptionName,
        $exceptionMessage = null,
        $exceptionCode = null
    ) {
        $this->setExpectedException($exceptionName, $exceptionMessage, $exceptionCode);

        $cbr = new Cbr();

        $xml = file_get_contents(__DIR__ . $xmlFile);
        $this->setResponseStub($xml);

        $cbr->getCurrencyRate($currency);
    }
}