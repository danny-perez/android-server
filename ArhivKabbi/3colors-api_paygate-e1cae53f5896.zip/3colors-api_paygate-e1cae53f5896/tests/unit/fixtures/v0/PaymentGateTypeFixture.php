<?php

namespace tests\codeception\fixtures\v0;

use yii\test\ActiveFixture;

class PaymentGateTypeFixture extends ActiveFixture
{
    public $modelClass = 'v0\models\PaymentGateType';

    public $dataFile = '@tests/unit/fixtures/data/v0/paymentGateType.php';
}
