<?php

namespace tests\unit\fixtures\v0;

use yii\test\ActiveFixture;

class PaymentGateProfileFixture extends ActiveFixture
{
    public $modelClass = 'v0\models\PaymentGateProfile';

    public $depends = [
        'tests\unit\fixtures\v0\PaymentGateTypeFixture',
    ];

    public $dataFile = '@tests/unit/fixtures/data/v0/paymentGateProfile.php';
}
