<?php

namespace tests\unit\fixtures\v0\yandex;

use yii\test\ActiveFixture;

class PaymentGateProfileFixture extends ActiveFixture
{
    public $modelClass = 'yandex\models\Profile';

    public $depends = [
        'tests\unit\fixtures\v0\PaymentGateTypeFixture',
    ];

    public $dataFile = '@tests/unit/fixtures/data/v0/yandex/paymentGateProfile.php';
}