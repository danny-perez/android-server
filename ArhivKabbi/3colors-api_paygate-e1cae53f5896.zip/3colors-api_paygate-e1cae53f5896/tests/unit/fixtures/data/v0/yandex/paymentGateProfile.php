<?php

return [
    'yandex' => [
        'id'                  => 15,
        'paymentName'         => 'testPayment',
        'shopId'              => 50454,
        'scid'                => 537894,
        'password'            => 'wkjdnWEFerF25gfeRGDF',
        'commission'          => 0,
        'isDebug'             => 1,
        'certificateContent'  => 'certificate',
        'certificatePassword' => 'password',
        'keyContent'          => 'key content',
    ],
];