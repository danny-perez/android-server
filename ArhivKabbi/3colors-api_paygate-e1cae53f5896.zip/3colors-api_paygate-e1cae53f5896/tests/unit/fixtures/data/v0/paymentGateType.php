<?php

return [
    [
        'id'        => 1,
        'name'      => 'Альфа Банк',
        'classname' => 'AlphaBank',
    ],
];