<?php

return [
    'alpha' => [
        'id'          => 10,
        'paymentName' => 'testPayment',
        'typeId'      => 1,
        'username'    => '3colors-api',
        'password'    => '3colors',
        'url'         => 'https://web.rbsuat.com/ab/rest/',
    ],
];