<?php

namespace Helper;

// here you can define custom actions
// all public methods declared in helper class will be available in $I

class Api extends \Codeception\Module
{
    public function createPaymentGate($I, $name)
    {
        $I->sendPOST('/v0/profiles', [
            'username'    => '3colors_auto-api',
            'password'    => '3colorsauto',
            'url'         => 'https://web.rbsuat.com/ab/rest/',
            'paymentName' => $name,
            'typeId'      => 1,
            'returnUrl'   => '3colors/finish.html',
        ]);
        $I->seeResponseCodeIs(200);
        $I->seeInDatabase('payment_gate_profile', ['paymentName' => $name, 'typeId' => 1]);
    }

    // Only without 3Ds
    public function registryOrderOnPayment($I, $url, $pan)
    {
        $I->sendPOST('https://web.rbsuat.com/ab/rest/processform.do', [
            'MDORDER'          => explode('=', parse_url($url)['query'])[1],
            '$EXPIRY'          => '201912',
            '$PAN'             => $pan,
            'MM'               => '12',
            'YYYY'             => '2019',
            'TEXT'             => 'TEST',
            '$CVC'             => '123',
            'language'         => 'ru',
            'bindingNotNeeded' => 'false',
            'jsonParams'       => '{}',
        ]);
    }

    public function registryCard($I, $payment, $clientId, $pan)
    {
        // Add form for card
        $I->sendPOST("/v0/cards/{$payment}/{$clientId}");
        $I->seeResponseCodeIs(200);
        $orderId = $this->grabOneDataFromResponseByJsonPath($I, '$.orderId');
        $url     = $this->grabOneDataFromResponseByJsonPath($I, '$.url');

        $this->registryOrderOnPayment($I, $url, $pan);

        //Success
        $I->sendPUT("/v0/cards/{$payment}/{$clientId}", ['orderId' => $orderId]);
        $I->seeResponseCodeIs(200);
    }

    public function grabOneDataFromResponseByJsonPath($I, $jsonPath)
    {
        $elements = $I->grabDataFromResponseByJsonPath($jsonPath);

        return array_shift($elements);
    }

}
