<?php

namespace Helper;

// here you can define custom actions
// all public methods declared in helper class will be available in $I

class ApiSberBank extends \Codeception\Module
{
    const URL = 'https://3dsec.sberbank.ru/payment/rest/';

    public function createSberBankPaymentGate($I, $name)
    {
        $I->sendPOST('/v0/profiles', [
            'usernamePayment' => 'gootax2-api',
            'passwordPayment' => 'gootax2',
            'usernameBinding' => 'gootax-api',
            'passwordBinding' => 'gootax',
            'url'             => self::URL,
            'paymentName'     => $name,
            'typeId'          => 2,
            'returnUrl'       => 'payment_success_ru.html',
            'failUrl'         => 'errors_ru.html',
        ]);
        $I->seeResponseCodeIs(200);
        $I->seeInDatabase('sberbank_payment_gate_profile', ['paymentName' => $name]);
    }

    // Only without 3Ds
    public function registrySberBankOrderOnPayment($I, $url, $pan)
    {
        $I->sendPOST(self::URL . 'processform.do', [
            'MDORDER'    => explode('=', parse_url($url)['query'])[1],
            '$EXPIRY'    => '201912',
            '$PAN'       => $pan,
            'MM'         => '12',
            'YYYY'       => '2019',
            'TEXT'       => 'TEST TEST',
            '$CVC'       => '123',
            'language'   => 'ru',
            'jsonParams' => '{}',
        ]);
    }

    public function registrySberBankCard($I, $payment, $clientId, $pan)
    {
        // Add form for card
        $I->sendPOST("/v0/cards/{$payment}/{$clientId}");
        $I->seeResponseCodeIs(200);

        $orderId = $I->grabDataFromResponseByJsonPath('$.orderId');
        $orderId = array_shift($orderId);

        $url = $I->grabDataFromResponseByJsonPath('$.url');
        $url = array_shift($url);

        $this->registrySberBankOrderOnPayment($I, $url, $pan);

        //Success
        $I->sendPUT("/v0/cards/{$payment}/{$clientId}", ['orderId' => $orderId]);
        $I->seeResponseCodeIs(200);
    }


}
