<?php

$I = new ApiTester($scenario);
$I->wantTo('check work of check of addition of the card for the client for yandex cash desk');
$I->haveHttpHeader('Content-Type', 'application/json');

$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_cco1',
    'typeId'             => 4,
    'shopId'             => 504543,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
    'commission'         => '3.5',
]);
$I->seeResponseCodeIs(200);

$I->sendPOST('/v0/cards/yandex_cco1/testUser');
$I->seeResponseCodeIs(200);
$orderId = $I->grabOneDataFromResponseByJsonPath($I, '$.orderId');

// // Request of yandex
$I->deleteHeader('Content-Type');
$I->sendPOST('/v0/yandex/order/check', [
    'requestDatetime'         => '2011-05-04T20:38:00.000+04:00',
    'action'                  => 'checkOrder',
    'md5'                     => '2169A08470B59BAF8427382598D57D06',
    'shopId'                  => 502454,
    'shopArticleId'           => '456',
    'invoiceId'               => '12345698',
    'orderNumber'             => 'card_143yu3', // Fix orderNumber because need to compute md5
    'customerNumber'          => 'testUser',
    'orderCreatedDatetime'    => '2011-05-04T20:38:00.000+04:00',
    'orderSumAmount'          => 87.10,
    'orderSumCurrencyPaycash' => 643,
    'orderSumBankPaycash'     => 1001,
    'shopSumAmount'           => 86.23,
    'shopSumCurrencyPaycash'  => 643,
    'shopSumBankPaycash'      => 1001,
    'paymentPayerCode'        => 42007148320,
    'paymentType'             => 'AC',
    'cdd_pan_mask'            => '444444|4448',
    'rebillingOn'             => 'true',
]);
$I->seeResponseCodeIs(200);
$I->sendPOST('/v0/yandex/order/aviso', [
    'requestDatetime'         => '2011-05-04T20:38:00.000+04:00',
    'action'                  => 'paymentAviso',
    'md5'                     => 'A444DA02F55C22C47DA7DA26967810D0',
    'shopId'                  => 502454,
    'shopArticleId'           => '456',
    'invoiceId'               => '12345698',
    'orderNumber'             => 'card_143yu3',
    'customerNumber'          => 'testUser',
    'orderCreatedDatetime'    => '2011-05-04T20:38:00.000+04:00',
    'orderSumAmount'          => 87.10,
    'orderSumCurrencyPaycash' => 643,
    'orderSumBankPaycash'     => 1001,
    'shopSumAmount'           => 86.23,
    'shopSumCurrencyPaycash'  => 643,
    'shopSumBankPaycash'      => 1001,
    'paymentPayerCode'        => 42007148320,
    'paymentType'             => 'AC',
    'rebillingOn'             => 'true',
]);
$I->seeResponseCodeIs(200);

//Success
$I->haveHttpHeader('Content-Type', 'application/json');
// $I->sendPUT('/v0/cards/yandex_cco1/testUser', ['orderId' => $orderId]);
// $I->seeResponseCodeIs(200);
