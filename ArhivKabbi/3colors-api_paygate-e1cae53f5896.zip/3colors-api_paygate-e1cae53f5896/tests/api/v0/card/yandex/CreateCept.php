<?php

$I = new ApiTester($scenario);
$I->wantTo('check the list of available cards at the client for yandex cash desk');
$I->haveHttpHeader('Content-Type', 'application/json');

$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_cc1',
    'typeId'             => 4,
    'shopId'             => 501454,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
    'commission'         => '3.5',
]);
$I->seeResponseCodeIs(200);

// Success minimal
$I->sendPOST('/v0/cards/yandex_cc1/testUser');
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.url');
$I->seeResponseJsonMatchesJsonPath('$.orderId');