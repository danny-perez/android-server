<?php

$I = new ApiTester($scenario);
$I->wantTo('check work of check of addition of the card for the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createPaymentGate($I, 'cco1');

// Wrong order id
$I->sendPUT('/v0/cards/cco1/testUser', ['orderId' => 'wrong_order_id']);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Add form for card
$I->sendPOST('/v0/cards/cco1/testUser');
$I->seeResponseCodeIs(200);
$orderId = $I->grabOneDataFromResponseByJsonPath($I, '$.orderId');
$url     = $I->grabOneDataFromResponseByJsonPath($I, '$.url');

$I->sendPUT('/v0/cards/wrongPaymentName/testUser', ['orderId' => $orderId]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long client id
$I->sendPUT('/v0/cards/cco1/' . str_repeat('U', 33), ['orderId' => $orderId]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Get errors at payment gate, because empty form for card
$I->sendPUT('/v0/cards/cco1/testUser', ['orderId' => $orderId]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Registry test card
$I->deleteHeader('Content-Type');
$I->sendPOST('https://web.rbsuat.com/ab/rest/processform.do', [
    'MDORDER'          => explode('=', parse_url($url)['query'])[1],
    '$EXPIRY'          => '201912',
    '$PAN'             => '5222222222222227',
    'MM'               => '12',
    'YYYY'             => '2019',
    'TEXT'             => 'TEST',
    '$CVC'             => '123',
    'language'         => 'ru',
    'bindingNotNeeded' => 'false',
    'jsonParams'       => '{}',
]);

//Success
$I->haveHttpHeader('Content-Type', 'application/json');
$I->sendPUT('/v0/cards/cco1/testUser', ['orderId' => $orderId]);
$I->seeResponseCodeIs(200);