<?php

$I = new ApiTester($scenario);
$I->wantTo('check removal of the card of the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createPaymentGate($I, 'cd1');

// Add form for card
$I->deleteHeader('Content-Type');
$I->registryCard($I, 'cd1', 'testUser', '4111111111111117');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong pan
$I->sendDELETE('/v0/cards/cd1/testUser/wrongPan');
$I->seeResponseCodeIs(200);

// Other user
$I->sendDELETE('/v0/cards/cd1/otherUser/411111**1117');
$I->seeResponseCodeIs(200);

// Success
$I->sendDELETE('/v0/cards/cd1/testUser/411111**1117');
$I->seeResponseCodeIs(200);

