<?php

$I = new ApiTester($scenario);
$I->wantTo('check available cards at the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createPaymentGate($I, 'cl1');

// Wrong payment gate
$I->sendGET('/v0/cards/wrongPaymentName/testUser');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Error client id
$I->sendGET('/v0/cards/cl1/wrongUser');
$I->seeResponseCodeIs(200);
$I->seeResponseContainsJson([]);

// Success
$I->sendGET('/v0/cards/cl1/testUser');
$I->seeResponseCodeIs(200);
$I->seeResponseIsJson();
