<?php

$I = new ApiTester($scenario);
$I->wantTo('check the list of available cards at the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createPaymentGate($I, 'cc1');

$I->sendPOST('/v0/cards/wrongPaymentName/testUser');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long client id
$I->sendPOST('/v0/cards/cc1/' . str_repeat('U', 33));
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too small currency
$I->sendPOST('/v0/cards/cc1/testUser', [
    'currency' => 0,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too big currency
$I->sendPOST('/v0/cards/cc1/testUser', [
    'currency' => 1000,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Success minimal
$I->sendPOST('/v0/cards/cc1/testUser');
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.url');
$I->seeResponseJsonMatchesJsonPath('$.orderId');

// Success minimal
$I->sendPOST('/v0/cards/cc1/testUser', [
    'currecny' => 643,
]);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.url');
$I->seeResponseJsonMatchesJsonPath('$.orderId');