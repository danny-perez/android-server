<?php

$I = new ApiTester($scenario);
$I->wantTo('Check refund from the card of the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createPaymentGate($I, 'pr1');

$I->deleteHeader('Content-Type');
$I->registryCard($I, 'pr1', 'testUser', '5222222222222227');
$I->haveHttpHeader('Content-Type', 'application/json');

//@TODO Возавращается ошибка 424:Мерчант не имеет привилегии выполнять AUTO платежи, скорее всего у тестовой учетки запрещена привязка карты
/*$I->sendPOST('/v0/payments/pr1/testUser', [
    'pan'         => '522222**2227',
    'amount'      => 10000,
    'orderNumber' => 'test_' . rand(1000000, 9999999),
]);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.orderId');
$paymentOrderId = $I->grabOneDataFromResponseByJsonPath($I, '$.orderId');*/

// wrong order id
$I->sendPOST('/v0/payments/pr1/testUser/wrongOrderId');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long payment order id
$I->sendPOST('/v0/payments/pr1/testUser/' . str_repeat('O', 41));
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

//@TODO
/*// Success
$I->sendPOST('/v0/payments/pr1/testUser/' . $paymentOrderId);
$I->seeResponseCodeIs(200);

// Repeat refund
$I->sendPOST('/v0/payments/pr1/testUser/' . $paymentOrderId);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();*/
