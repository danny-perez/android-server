<?php

$I = new ApiTester($scenario);
$I->wantTo('check deposit of money from the card of the client');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->createSberBankPaymentGate($I, 'pds1');

$I->deleteHeader('Content-Type');
$I->registrySberBankCard($I, 'pds1', 'testUser', '5555555555555599'); // not use 3ds
$I->haveHttpHeader('Content-Type', 'application/json');

$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => 'wrongPan',
    'amount'      => 10000,
    'orderNumber' => 'test_' . rand(100000, 999999),
    'currency'    => 643,
    'params'      => [],
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseContainsJson();

// Too small amount
$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 99,
    'orderNumber' => 'test_' . rand(100000, 999999),
    'currency'    => 643,
    'params'      => [],
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseContainsJson();

$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 10000,
    'orderNumber' => 'test_' . rand(100000, 999999),
    'currency'    => 'wrongCurrency',
    'params'      => [],
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseContainsJson();

// Too long order number
$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 10000,
    'orderNumber' => str_repeat('O', 21),
    'currency'    => 643,
    'params'      => [],
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseContainsJson();

// Success
$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 10000,
    'orderNumber' => 'test_' . rand(100000, 999999),
    'currency'    => 643,
    'params'      => [],
]);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.orderId');

// Success minimal
$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 10000,
    'orderNumber' => 'test_' . rand(1000000, 9999999),
]);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.orderId');


// Success another currency code
$I->sendPOST('/v0/payments/pds1/testUser', [
    'pan'         => '555555XXXXXX5599',
    'amount'      => 100,
    'orderNumber' => 'test_' . rand(100000, 999999),
    'currency'    => 944,
    'params'      => [],
]);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.orderId');

$paymentOrderId = $I->grabOneDataFromResponseByJsonPath($I, '$.orderId');

$I->sendGET("/v0/payments/pds1/testUser/" . $paymentOrderId);
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$.currency');
$I->canSeeResponseContainsJson(['currency' => 643]);
