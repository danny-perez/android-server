<?php

$I = new ApiTester($scenario);
$I->wantTo('request yandex to check order');

$I->haveHttpHeader('Content-Type', 'application/json');
$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_cho1',
    'typeId'             => 4,
    'shopId'             => 50454,
    'scid'               => 537894,
    'password'           => 'wkjdnWEFerF25gfeRGDF',
    'certificateContent' => 'content',
    'keyContent'         => 'content',
    'commission'         => '3.5',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_cho1',
    'shopId'      => 50454,
    'scid'        => 537894,
]);

$I->deleteHeader('Content-Type');
$I->sendPOST('/v0/yandex/order/check', [
    'orderNumber'             => 'replicate_t3SxcEl6',
    'orderSumAmount'          => '100.00',
    'cdd_exp_date'            => '1219',
    'shopArticleId'           => '249269',
    'paymentPayerCode'        => '4100322062290',
    'cdd_rrn'                 => '',
    'external_id'             => 'deposit',
    'paymentType'             => 'AC',
    'requestDatetime'         => '2016-06-30T15:48:18.294+03:00',
    'depositNumber'           => 'VZAL43fVtf8JZC4PvPc0JCaABx8Z.001f.201606',
    'cps_user_country_code'   => 'PL',
    'orderCreatedDatetime'    => '2016-06-30T15:48:18.170+03:00',
    'sk'                      => 'y4876a0a9da3a7d20a85d1795f490900a',
    'action'                  => 'checkOrder',
    'shopId'                  => '50454',
    'scid'                    => '537894',
    'shopSumBankPaycash'      => '1003',
    'shopSumCurrencyPaycash'  => '10643',
    'rebillingOn'             => 'true',
    'orderSumBankPaycash'     => '1003',
    'cps_region_id'           => '44',
    'orderSumCurrencyPaycash' => '10643',
    'merchant_order_id'       => 'replicate_t3SxcEl6_300616154802_00000_50',
    'unilabel'                => '1f0728c1-0009-5000-8000-000010ebd81f',
    'cdd_pan_mask'            => '444444|4448',
    'customerNumber'          => 'testUser',
    'yandexPaymentId'         => '2570051112565',
    'invoiceId'               => '2000000825543',
    'shopSumAmount'           => '96.50',
    'md5'                     => '98AEEBFB57962DC09628998C2E9F0119',
]);
$I->seeResponseCodeIs(200);
$I->seeHttpHeader('Content-Type', 'application/xml; charset=UTF-8');

$I->seeXmlResponseMatchesXpath('//checkOrderResponse[@code=0][@invoiceId=2000000825543][@shopId=50454][@orderSumAmount=100.00]');