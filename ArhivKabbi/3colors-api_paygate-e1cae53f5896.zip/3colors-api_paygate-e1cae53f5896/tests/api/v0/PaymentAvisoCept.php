<?php

use yandex\models\YandexPayment;

$I = new ApiTester($scenario);
$I->wantTo('request yandex to payment aviso');

$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_pav1',
    'typeId'             => 4,
    'shopId'             => 124354,
    'scid'               => 567394,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_pav1',
    'shopId'      => 124354,
    'scid'        => 567394,
]);

YandexPayment::register('yandex_pav1', 'testUser', 'replicate_t3SxcEl6', '124354', 1);
$I->deleteHeader('Content-Type');
$I->sendPOST('/v0/yandex/order/aviso', [
    'orderNumber'             => 'replicate_t3SxcEl6',
    'orderSumAmount'          => '100.00',
    'cdd_exp_date'            => '1219',
    'shopArticleId'           => '249269',
    'paymentPayerCode'        => '4100322062290',
    'cdd_rrn'                 => '',
    'external_id'             => 'deposit',
    'paymentType'             => 'AC',
    'requestDatetime'         => '2016-06-30T15:48:18.294+03:00',
    'depositNumber'           => 'VZAL43fVtf8JZC4PvPc0JCaABx8Z.001f.201606',
    'cps_user_country_code'   => 'PL',
    'orderCreatedDatetime'    => '2016-06-30T15:48:18.170+03:00',
    'sk'                      => 'y4876a0a9da3a7d20a85d1795f490900a',
    'action'                  => 'checkOrder',
    'shopId'                  => '124354',
    'scid'                    => '537894',
    'shopSumBankPaycash'      => '1003',
    'shopSumCurrencyPaycash'  => '10643',
    'rebillingOn'             => 'true',
    'orderSumBankPaycash'     => '1003',
    'cps_region_id'           => '44',
    'orderSumCurrencyPaycash' => '10643',
    'merchant_order_id'       => 'replicate_t3SxcEl6_300616154802_00000_50',
    'unilabel'                => '1f0728c1-0009-5000-8000-000010ebd81f',
    'cdd_pan_mask'            => '444444|4448',
    'customerNumber'          => 'testUser',
    'yandexPaymentId'         => '2570051112565',
    'invoiceId'               => '2000000825543',
    'shopSumAmount'           => '96.50',
    'md5'                     => '96665E3BA2C55ECF798AA02EA5D7FE54',
]);
$I->canSeeInDatabase('yandex_order_binding', [
    'clientId'  => 'testUser',
    'shopId'    => 124354,
    'invoiceId' => '2000000825543',
    'pan'       => '444444|4448',
]);
$I->seeResponseCodeIs(200);
$I->seeHttpHeader('Content-Type', 'application/xml; charset=UTF-8');

YandexPayment::register('yandex_pav1', 'testUser', 'card_123yu3', '124354', 87.10);
$I->sendPOST('/v0/yandex/order/aviso', [
    'requestDatetime'         => '2011-05-04T20:38:00.000+04:00',
    'action'                  => 'paymentAviso',
    'md5'                     => 'B4D601ECB034263CFACC461694DBC219',
    'shopId'                  => 124354,
    'shopArticleId'           => '456',
    'invoiceId'               => '1234568',
    'orderNumber'             => 'card_123yu3',
    'customerNumber'          => 'testUser',
    'orderCreatedDatetime'    => '2011-05-04T20:38:00.000+04:00',
    'orderSumAmount'          => 87.10,
    'orderSumCurrencyPaycash' => 643,
    'orderSumBankPaycash'     => 1001,
    'shopSumAmount'           => 86.23,
    'shopSumCurrencyPaycash'  => 643,
    'shopSumBankPaycash'      => 1001,
    'paymentPayerCode'        => 42007148320,
    'paymentType'             => 'AC',
    'rebillingOn'             => 1,
]);
$I->seeResponseCodeIs(200);
$I->seeHttpHeader('Content-Type', 'application/xml; charset=UTF-8');

$xml = new \Codeception\Util\XmlBuilder();
$I->seeXmlResponseMatchesXpath('//paymentAvisoResponse[@code=0][@invoiceId=1234568][@shopId=124354][@orderSumAmount=87.10]');