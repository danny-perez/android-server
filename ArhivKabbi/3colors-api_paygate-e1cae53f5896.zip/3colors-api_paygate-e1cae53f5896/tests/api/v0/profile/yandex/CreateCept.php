<?php

$I = new ApiTester($scenario);
$I->wantTo('check creation of a profile at a payment gateway for yandex cash desk');
$I->haveHttpHeader('Content-Type', 'application/json');

// Fullstack Success
$I->sendPOST('v0/profiles', [
    'paymentName'        => 'yandex_cp1',
    'typeId'             => 4,
    'shopId'             => 5045415,
    'scid'               => 537894,
    'password'           => 'pass',
    'commission'         => 5.5,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
    'isDebug'            => 1,
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_cp1',
    'shopId'      => 5045415,
    'scid'        => 537894,
]);

// Minimal success
$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_cp2',
    'typeId'             => 4,
    'shopId'             => 5045416,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_cp1',
    'shopId'      => 5045415,
    'scid'        => 537894,
]);

// Duplicate payment name
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'yandex_cp2',
    'typeId'      => 4,
    'shopId'      => 0001,
    'scid'        => 1002123,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Simple error
$I->sendPOST('/v0/profiles', [
    'paymentName'        => str_repeat('N', 33),
    'typeId'             => 4,
    'shopId'             => 'to_be_integer',
    'scid'               => 'to_be_integer',
    'password'           => str_repeat('P', 256),
    'commission'         => 101, // or less 0
    'certificateContent' => '',
    'keyContent'         => '',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();