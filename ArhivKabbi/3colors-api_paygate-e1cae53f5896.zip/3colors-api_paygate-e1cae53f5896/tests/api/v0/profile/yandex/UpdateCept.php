<?php

$I = new ApiTester($scenario);
$I->wantTo('check update of a profile at a payment gateway for yandex');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendPUT('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_pu1',
    'typeId'             => 4,
    'shopId'             => 5045418,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_pu1',
    'shopId'      => 5045418,
    'scid'        => 537894,
]);

// Simple error
$I->sendPUT('/v0/profiles/yandex_pu1', [
    'paymentName' => str_repeat('N', 33),
    'shopId'      => 'to_be_integer',
    'scid'        => 'to_be_integer',
    'password'    => str_repeat('P', 256),
    'url'         => str_repeat('U', 256),
    'commission'  => 101, // or less 0
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

$I->sendPUT('/v0/profiles/yandex_pu1', [
    'shopId' => 50412,
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_pu1',
    'shopId'      => 50412,
]);

// When delete
$I->sendDELETE('/v0/profiles/yandex_pu1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'yandex_pu1']);
$I->sendPUT('/v0/profiles/yandex_pu1', [
    'shopId' => 50000,
]);
$I->dontSeeResponseCodeIs(200);