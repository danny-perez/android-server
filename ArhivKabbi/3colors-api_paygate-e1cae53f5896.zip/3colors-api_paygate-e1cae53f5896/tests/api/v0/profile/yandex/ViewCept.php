<?php

$I = new ApiTester($scenario);
$I->wantTo('check getting of a profile at a payment gateway for yandex');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendGet('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_pv1',
    'typeId'             => 4,
    'shopId'             => 5045419,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_pv1',
    'shopId'      => 5045419,
    'scid'        => 537894,
]);

// Success
$I->sendGET('/v0/profiles/yandex_pv1');
$I->seeResponseCodeIs(200);
$I->seeResponseIsJson([
    'paymentName' => 'yandex_pv1',
    'shopId'      => 5045419,
    'scid'        => 537894,
    'password'    => '',
    'commission'  => 0,
]);

// When delete
$I->sendDELETE('/v0/profiles/yandex_pv1');
$I->seeResponseCodeIs(200);
$I->sendGET('/v0/profiles/yandex_pv1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();