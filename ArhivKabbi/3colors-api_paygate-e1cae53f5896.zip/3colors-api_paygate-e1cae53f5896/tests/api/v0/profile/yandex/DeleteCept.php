<?php

$I = new ApiTester($scenario);
$I->wantTo('check delete of a profile at a payment gateway for yandex');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendDELETE('v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'        => 'yandex_pd1',
    'typeId'             => 4,
    'shopId'             => 5045417,
    'scid'               => 537894,
    'certificateContent' => 'content',
    'keyContent'         => 'content',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('yandex_payment_gate_profile', [
    'paymentName' => 'yandex_pd1',
    'shopId'      => 5045417,
    'scid'        => 537894,
]);

// Success
$I->sendDELETE('/v0/profiles/yandex_pd1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'yandex_pd1']);

// Repeat delete
$I->sendDELETE('/v0/profiles/yandex_pd1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();
