<?php

$I = new ApiTester($scenario);
$I->wantTo('check update of a profile at a payment gateway for sberbank');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('yandex_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendPUT('v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'     => 'sberbank_pu1',
    'typeId'          => 2,
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName'     => 'sberbank_pu1',
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);

// Simple error
$I->sendPUT('/v0/profiles/sberbank_pu1', [
    'paymentName'     => str_repeat('N', 33),
    'usernameBinding' => str_repeat('N', 33),
    'passwordBinding' => str_repeat('N', 256),
    'usernamePayment' => str_repeat('N', 33),
    'passwordPayment' => str_repeat('N', 256),
    'commission'      => 101, // or less 0
    'url'             => str_repeat('N', 256),
    'returnUrl'       => str_repeat('N', 256),
    'failUrl'         => str_repeat('N', 256),
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

$I->sendPUT('/v0/profiles/sberbank_pu1', [
    'url' => 'https://localhost/update/new',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName' => 'sberbank_pu1',
    'url'         => 'https://localhost/update/new',
]);

// When delete
$I->sendDELETE('/v0/profiles/sberbank_pu1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('sberbank_payment_gate_profile', ['paymentName' => 'sberbank_pu1']);
$I->sendPUT('/v0/profiles/sberbank_pu1', [
    'url' => 'https://localhost/update/new2',
]);
$I->dontSeeResponseCodeIs(200);