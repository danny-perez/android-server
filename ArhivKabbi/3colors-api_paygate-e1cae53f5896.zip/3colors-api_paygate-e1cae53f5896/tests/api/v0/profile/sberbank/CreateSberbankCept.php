<?php

$I = new ApiTester($scenario);
$I->wantTo('check creation of a profile at a payment gateway for sberbank');
$I->haveHttpHeader('Content-Type', 'application/json');

// Fullstack Success
$I->sendPOST('/v0/profiles', [
    'paymentName'     => 'sberbank_cp1',
    'typeId'          => 2,
    'usernameBinding' => 'username1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'username2',
    'passwordPayment' => 'pass2',
    'commission'      => 5.5,
    'url'             => 'https://localhost',
    'returnUrl'       => '/finish.html',
    'failUrl'         => 'error.html',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName'     => 'sberbank_cp1',
    'usernameBinding' => 'username1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'username2',
    'passwordPayment' => 'pass2',
    'commission'      => 5.5,
    'url'             => 'https://localhost',
    'returnUrl'       => '/finish.html',
    'failUrl'         => 'error.html',
]);

// Minimal success
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'sberbank_cp2',
    'typeId'      => 2,
    'url'         => 'https://localhost',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName' => 'sberbank_cp1',
    'url'         => 'https://localhost',
]);

// Duplicate payment name
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'sberbank_cp1',
    'typeId'      => 2,
    'url'         => 'https://localhost/new',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Simple error
$I->sendPOST('/v0/profiles', [
    'paymentName'     => str_repeat('N', 33),
    'typeId'          => 2,
    'usernameBinding' => str_repeat('N', 33),
    'passwordBinding' => str_repeat('N', 256),
    'usernamePayment' => str_repeat('N', 33),
    'passwordPayment' => str_repeat('N', 256),
    'commission'      => 101, // or less 0
    'url'             => str_repeat('N', 256),
    'returnUrl'       => str_repeat('N', 256),
    'failUrl'         => str_repeat('N', 256),
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();