<?php

$I = new ApiTester($scenario);
$I->wantTo('check delete of a profile at a payment gateway for sberbank');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('sberbank_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendDELETE('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'     => 'sberbank_pd1',
    'typeId'          => 2,
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName'     => 'sberbank_pd1',
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);

// Success
$I->sendDELETE('/v0/profiles/sberbank_pd1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('sberbank_payment_gate_profile', ['paymentName' => 'sberbank_pd1']);

// Repeat delete
$I->sendDELETE('/v0/profiles/sberbank_pd1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();
