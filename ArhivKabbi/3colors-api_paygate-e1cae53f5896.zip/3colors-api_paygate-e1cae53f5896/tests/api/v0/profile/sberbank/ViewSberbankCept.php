<?php

$I = new ApiTester($scenario);
$I->wantTo('check getting of a profile at a payment gateway for sberbank');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('sberbank_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendGet('v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName'     => 'sberbank_pv1',
    'typeId'          => 2,
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('sberbank_payment_gate_profile', [
    'paymentName'     => 'sberbank_pv1',
    'url'             => 'https://localhost',
    'usernameBinding' => 'user1',
    'passwordBinding' => 'pass1',
    'usernamePayment' => 'user2',
    'passwordPayment' => 'pass2',
]);

// Success
$I->sendGET('/v0/profiles/sberbank_pv1');
$I->seeResponseCodeIs(200);
$I->seeResponseIsJson([
    'paymentName'     => 'sberbank_pv1',
    'commission'      => 0,
    'usernameBinding' => 'user1',
    'usernamePayment' => 'user2',
    'url'             => 'https://localhost',
    'returnUrl'       => 'payment_success_ru.html',
    'failUrl'         => 'errors_ru.html',
]);

// When delete
$I->sendDELETE('/v0/profiles/sberbank_pv1');
$I->seeResponseCodeIs(200);
$I->sendGET('/v0/profiles/sberbank_pv1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();