<?php

$I = new ApiTester($scenario);
$I->wantTo('check delete of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendDELETE('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'username'    => 'user index',
    'password'    => 'pass index',
    'url'         => 'https://localhost/index',
    'paymentName' => 'd1',
    'typeId'      => 1,
]);
$I->seeResponseCodeIs(200);

// Success
$I->sendDELETE('/v0/profiles/d1');
$I->seeResponseCodeIs(200);

// Repeat delete
$I->sendDELETE('/v0/profiles/d1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();