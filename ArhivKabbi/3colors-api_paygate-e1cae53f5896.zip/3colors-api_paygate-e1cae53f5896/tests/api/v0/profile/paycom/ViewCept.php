<?php

$I = new ApiTester($scenario);
$I->wantTo('check getting of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendGet('/v0/profiles/wrongPaymentName');
//$I->dontSeeResponseCodeIs(200);
//$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_view',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 5,
]);
$I->seeResponseCodeIs(200);

// Success
$I->sendGET('/v0/profiles/paycom_view');
$I->seeResponseCodeIs(200);
$I->seeResponseIsJson([
    'apiId'      => 'id',
    'password'   => 'pass',
    'isDebug'    => 1,
    'typeId'     => 7,
    'commission' => 5,
]);

// When delete
$I->sendDELETE('/v0/profiles/paycom_view');
$I->seeResponseCodeIs(200);
$I->sendGET('/v0/profiles/paycom_view');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();