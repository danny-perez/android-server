<?php

$I = new ApiTester($scenario);
$I->wantTo('check delete of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendDELETE('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_delete',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 5,
]);
$I->seeResponseCodeIs(200);

// Success
$I->sendDELETE('/v0/profiles/paycom_delete');
$I->seeResponseCodeIs(200);

// Repeat delete
$I->sendDELETE('/v0/profiles/paycom_delete');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();