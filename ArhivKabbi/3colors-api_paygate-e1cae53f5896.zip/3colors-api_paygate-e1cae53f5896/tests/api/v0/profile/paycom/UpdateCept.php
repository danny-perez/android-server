<?php

$I = new ApiTester($scenario);
$I->wantTo('check update of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendPUT('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_update',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 5,
]);
$I->seeResponseCodeIs(200);

// typeId can't be updated if diffrent
$I->sendPUT('/v0/profiles/paycom_update', [
    'typeId' => 3,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

$I->sendPUT('/v0/profiles/paycom_update', [
    'typeId' => 7,
]);
$I->seeResponseCodeIs(200);

// update wrong type
$I->sendPUT('/v0/profiles/paycom_update', [
    'typeId' => 'wrong_type',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Empty params
$I->sendPUT('/v0/profiles/paycom_update');
$I->seeResponseCodeIs(200);

// Too big commission
$I->sendPUT('/v0/profiles/paycom_update', [
    'commission' => 101,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too small commission
$I->sendPUT('/v0/profiles/paycom_update', [
    'commission' => -1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Success
$I->sendPUT('/v0/profiles/paycom_update', [
    'apiId'    => 'id2',
    'password' => 'pass2',
    'isDebug'  => 1,
]);
$I->seeResponseCodeIs(200);

// Success duplicate
$I->sendPUT('/v0/profiles/paycom_update', [
    'apiId'    => 'id2',
    'password' => 'pass2',
    'isDebug'  => 1,
]);
$I->seeResponseCodeIs(200);

// When delete
$I->sendDELETE('/v0/profiles/paycom_update');
$I->seeResponseCodeIs(200);
$I->sendPUT('/v0/profiles/paycom_update', [
    'apiId' => 'user delete',
]);
$I->dontSeeResponseCodeIs(200);