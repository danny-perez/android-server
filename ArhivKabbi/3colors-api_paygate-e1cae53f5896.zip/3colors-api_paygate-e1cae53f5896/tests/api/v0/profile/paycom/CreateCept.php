<?php

$I = new ApiTester($scenario);
$I->wantTo('check creation of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Empty request
$I->sendPOST('/v0/profiles');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();


// Too long payment name
$I->sendPOST('/v0/profiles', [
    'paymentName' => str_repeat('A', 33),
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 101,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too big commission
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_create',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 101,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too small commission
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_create',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => -1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Success
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_create',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 5,
]);
$I->seeResponseCodeIs(200);

// Duplicate payment_name
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'paycom_create',
    'apiId'       => 'id',
    'password'    => 'pass',
    'isDebug'     => 1,
    'typeId'      => 7,
    'commission'  => 5,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();