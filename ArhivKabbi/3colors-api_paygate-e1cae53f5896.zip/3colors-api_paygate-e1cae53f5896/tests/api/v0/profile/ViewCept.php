<?php

$I = new ApiTester($scenario);
$I->wantTo('check getting of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendGet('/v0/profiles/wrongPaymentName');
//$I->dontSeeResponseCodeIs(200);
//$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'username'    => 'user index',
    'password'    => 'pass index',
    'url'         => 'https://localhost/index',
    'paymentName' => 'v1',
    'typeId'      => 1,
    'commission'  => 5,
]);
$I->seeResponseCodeIs(200);

// Success
$I->sendGET('/v0/profiles/v1');
$I->seeResponseCodeIs(200);
$I->seeResponseIsJson([
    'username'   => 'user index',
    'password'   => 'pass index',
    'url'        => 'https://localhost/index',
    'typeId'     => 1,
    'commission' => 5,
]);

// When delete
$I->sendDELETE('/v0/profiles/v1');
$I->seeResponseCodeIs(200);
$I->sendGET('/v0/profiles/v1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();