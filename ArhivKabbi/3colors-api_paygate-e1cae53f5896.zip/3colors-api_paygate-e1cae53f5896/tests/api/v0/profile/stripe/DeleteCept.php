<?php

$I = new ApiTester($scenario);
$I->wantTo('check delete of a profile at a payment gateway for stripe');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('stripe_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendDELETE('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'stripe_pd1',
    'typeId'      => 5,
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('stripe_payment_gate_profile', [
    'paymentName' => 'stripe_pd1',
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);

// Success
$I->sendDELETE('/v0/profiles/stripe_pd1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('stripe_payment_gate_profile', ['paymentName' => 'stripe_pd1']);

// Repeat delete
$I->sendDELETE('/v0/profiles/stripe_pd1');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();
