<?php

$I = new ApiTester($scenario);
$I->wantTo('check creation of a profile at a payment gateway for stripe cash desk');
$I->haveHttpHeader('Content-Type', 'application/json');

// Fullstack Success
$I->sendPOST('v0/profiles', [
    'paymentName' => 'stripe_cp1',
    'typeId'      => 5,
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
    'commission'  => '3.5',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('stripe_payment_gate_profile', [
    'paymentName' => 'stripe_cp1',
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);

// Minimal success
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'stripe_cp2',
    'typeId'      => 5,
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('stripe_payment_gate_profile', [
    'paymentName' => 'stripe_cp2',
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);

// Duplicate payment name
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'stripe_cp2',
    'typeId'      => 5,
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Simple error
$I->sendPOST('/v0/profiles', [
    'paymentName' => str_repeat('N', 33),
    'typeId'      => 5,
    'publicKey'   => str_repeat('P', 256),
    'privateKey'  => str_repeat('P', 256),
    'commission'  => 101, // or less 0
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();