<?php

$I = new ApiTester($scenario);
$I->wantTo('check update of a profile at a payment gateway for stripe');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->cantSeeInDatabase('stripe_payment_gate_profile', ['paymentName' => 'wrongPaymentName']);
$I->sendPUT('v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'paymentName' => 'stripe_pu1',
    'typeId'      => 5,
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('stripe_payment_gate_profile', [
    'paymentName' => 'stripe_pu1',
    'publicKey'   => 'pk_test_063DbqbXSeyl5EMV5dlRX1uS',
    'privateKey'  => 'sk_test_L7ugCaJvWt0bWIoLujtpuDkA',
]);

// Simple error
$I->sendPUT('/v0/profiles/stripe_pu1', [
    'paymentName' => str_repeat('N', 33),
    'publicKey'   => str_repeat('P', 256),
    'privateKey'  => str_repeat('P', 256),
    'commission'  => 101, // or less 0
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

$I->sendPUT('/v0/profiles/stripe_pu1', [
    'publicKey' => 'pk_test_123232l5EMV5dlRX1uS',
]);
$I->seeResponseCodeIs(200);
$I->canSeeInDatabase('stripe_payment_gate_profile', [
    'paymentName' => 'stripe_pu1',
    'publicKey'   => 'pk_test_123232l5EMV5dlRX1uS',
]);

// When delete
$I->sendDELETE('/v0/profiles/stripe_pu1');
$I->seeResponseCodeIs(200);
$I->cantSeeInDatabase('stripe_payment_gate_profile', ['paymentName' => 'stripe_pu1']);
$I->sendPUT('/v0/profiles/stripe_pu1', [
    'publicKey' => 'pk_test_123232l5EMV9876RX1uS',
]);
$I->dontSeeResponseCodeIs(200);