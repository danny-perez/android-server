<?php

$I = new ApiTester($scenario);
$I->wantTo('receive all types of payment gateways');
$I->haveHttpHeader('Content-Type', 'application/json');
$I->sendGET('v0/profiles');
$I->seeResponseCodeIs(200);
$I->seeResponseJsonMatchesJsonPath('$..id');
$I->seeResponseJsonMatchesJsonPath('$..name');