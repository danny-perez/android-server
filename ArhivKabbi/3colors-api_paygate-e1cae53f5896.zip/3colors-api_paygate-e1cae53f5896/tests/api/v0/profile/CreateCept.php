<?php

$I = new ApiTester($scenario);
$I->wantTo('check creation of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Empty request
$I->sendPOST('/v0/profiles');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();


// Too long return url
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'returnUrl'   => str_repeat('U', 256),
    'failUrl'     => 'error.html',
]);

// Too long fail url
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'returnUrl'   => 'finish.html',
    'failUrl'     => str_repeat('U', 256),
]);

$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Wrong type
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 'wrong_type',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long username
$I->sendPOST('/v0/profiles', [
    'username'    => str_repeat('U', 33),
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long password
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => str_repeat('P', 33),
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long url
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => str_repeat('URL ', 64),
    'paymentName' => 'c1',
    'typeId'      => 1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long payment name
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => str_repeat('A', 33),
    'typeId'      => 1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too big commission
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'commission'  => 101,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too small commission
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'commission'  => -1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Success
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'commission'  => 5,
    'returnUrl'   => 'finish.html',
    'failUrl'     => 'error.html',
]);
$I->seeResponseCodeIs(200);

// Duplicate payment_name
$I->sendPOST('/v0/profiles', [
    'username'    => 'user',
    'password'    => 'pass',
    'url'         => 'https://localhost',
    'paymentName' => 'c1',
    'typeId'      => 1,
    'commission'  => 5,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Minimal params for successful process
$I->sendPOST('/v0/profiles', [
    'url'         => 'https://localhost',
    'paymentName' => 'c2',
    'typeId'      => 1,
]);
$I->seeResponseCodeIs(200);