<?php

$I = new ApiTester($scenario);
$I->wantTo('check update of a profile at a payment gateway');
$I->haveHttpHeader('Content-Type', 'application/json');

// Wrong payment name
$I->sendPUT('/v0/profiles/wrongPaymentName');
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// create payment
$I->sendPOST('/v0/profiles', [
    'username'    => 'user create',
    'password'    => 'pass create',
    'url'         => 'https://localhost/create',
    'paymentName' => 'u1',
    'typeId'      => 1,
]);
$I->seeResponseCodeIs(200);

// typeId can't be updated if diffrent
$I->sendPUT('/v0/profiles/u1', [
    'typeId' => 3,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

$I->sendPUT('/v0/profiles/u1', [
    'typeId' => 1,
]);
$I->seeResponseCodeIs(200);

// update wrong type
$I->sendPUT('/v0/profiles/u1', [
    'typeId' => 'wrong_type',
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long username
$I->sendPUT('/v0/profiles/u1', [
    'username' => str_repeat('U', 33),
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long password
$I->sendPUT('/v0/profiles/u1', [
    'password' => str_repeat('P', 33),
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too long url
$I->sendPUT('/v0/profiles/u1', [
    'url' => str_repeat('URL ', 64),
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Empty params
$I->sendPUT('/v0/profiles/u1');
$I->seeResponseCodeIs(200);

// Too big commission
$I->sendPUT('/v0/profiles/u1', [
    'commission' => 101,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Too small commission
$I->sendPUT('/v0/profiles/u1', [
    'commission' => -1,
]);
$I->dontSeeResponseCodeIs(200);
$I->seeResponseIsJson();

// Success
$I->sendPUT('/v0/profiles/u1', [
    'username' => 'user update',
    'password' => 'pass update',
    'url'      => 'https://localhost/update',
]);
$I->seeResponseCodeIs(200);

// Success duplicate
$I->sendPUT('/v0/profiles/u1', [
    'username' => 'user update',
    'password' => 'pass update',
    'url'      => 'https://localhost/update',
]);
$I->seeResponseCodeIs(200);

// When delete
$I->sendDELETE('/v0/profiles/u1');
$I->seeResponseCodeIs(200);
$I->sendPUT('/v0/profiles/u1', [
    'username' => 'user delete',
]);
$I->dontSeeResponseCodeIs(200);