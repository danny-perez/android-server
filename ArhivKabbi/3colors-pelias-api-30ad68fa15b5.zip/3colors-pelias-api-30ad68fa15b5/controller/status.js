module.exports = function controller( req, res, next) {
  res.send('status: ok');
};
