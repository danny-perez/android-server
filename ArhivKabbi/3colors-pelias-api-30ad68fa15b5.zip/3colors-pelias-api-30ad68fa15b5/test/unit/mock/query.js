
function setup(){
  return query;
}

function query( clean ){
  return clean;
}

module.exports = setup;