<?php

declare(strict_types=1);

namespace tests\unit\addressHistory\models;

use addressHistory\models\HistoryAddress;
use addressHistory\models\CityId;
use addressHistory\models\Client;
use addressHistory\models\RepositoryInterface;

/**
 * Class ArrayedAddressHistoryRepository
 * @package tests\unit\addressHistory\models
 */
class ArrayedAddressHistoryRepository implements RepositoryInterface
{
    /**
     * @var HistoryAddress[]
     */
    private $history;

    /**
     * ArrayRepository constructor.
     *
     * @param HistoryAddress[] ...$history
     */
    public function __construct(HistoryAddress ...$history)
    {
        $this->history = $history;
    }

    /**
     * @param Client $client
     * @param CityId $cityId
     *
     * @return array
     */
    public function get(Client $client, CityId $cityId): array
    {
        return $this->history;
    }

    /**
     * @param HistoryAddress $historyAddress
     */
    public function delete(HistoryAddress $historyAddress): void
    {
        $address = $historyAddress->getAddress();

        foreach ($this->history as $key => $value) {
            /* @var $value HistoryAddress */
            if ($value->getAddress()->equals($address)) {
                unset($this->history[$key]);
            }
        }
    }

    /**
     * @param HistoryAddress $historyAddress
     */
    public function create(HistoryAddress $historyAddress): void
    {
        array_unshift($this->history, $historyAddress);
    }
}