<?php

declare(strict_types=1);

namespace tests\unit\addressHistory;

use addressHistory\models\Address;
use addressHistory\models\CityId;
use Codeception\Test\Unit;

/**
 * Class AddressTest
 * @package tests\unit\addressHistory
 */
class AddressTest extends Unit
{
    protected function _before()
    {
    }

    protected function _after()
    {
    }

    public function testEquals()
    {
        $cityId = new CityId(1);
        $city   = 'Izhevsk';
        $street = 'Lenina';
        $house  = '1';
        $lat    = '50.123';
        $lon    = '60.123';

        $this->assertTrue((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, $city, $street, $house, $lat, $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address(new CityId(123), $city, $street, $house, $lat, $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, '123', $street, $house, $lat, $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, $city, '123', $house, $lat, $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, $city, $street, '123', $lat, $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, $city, $street, $house, '123', $lon)));

        $this->assertFalse((new Address($cityId, $city, $street, $house, $lat, $lon))
            ->equals(new Address($cityId, $city, $street, $house, $lat, '123')));
    }
}