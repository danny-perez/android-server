<?php

declare(strict_types=1);

namespace tests\unit\addressHistory;

use addressHistory\AddressHistoryService;
use addressHistory\models\Address;
use addressHistory\models\CityId;
use addressHistory\models\Client;
use addressHistory\models\HistoryAddress;
use Codeception\Test\Unit;
use tests\unit\addressHistory\models\ArrayedAddressHistoryRepository;

/**
 * Class AddressHistoryServiceTest
 * @package tests\unit\addressHistory
 */
class AddressHistoryServiceTest extends Unit
{
    /**
     * @var AddressHistoryService
     */
    private $service;

    /**
     * @var Client
     */
    private $client;

    /**
     * @var CityId
     */
    private $cityId;

    protected function _before()
    {
        $this->service = new AddressHistoryService(new ArrayedAddressHistoryRepository());
        $this->client  = new Client(1);
        $this->cityId  = new CityId(1);
    }

    protected function _after()
    {
    }

    public function testSaveUniqueAddresses()
    {
        $address = new Address($this->cityId, 'Izhevsk', 'Lenina', '1', '50.123', '60.123');
        $this->service->save(new HistoryAddress($this->client, $address));
        $this->service->save(new HistoryAddress($this->client, $address));

        $history = $this->service->getHistory($this->client, $this->cityId);

        $this->assertCount(1, $history);
        $this->assertTrue($address->equals(current($history)->getAddress()));
    }

    public function testSaveNotUniqueAddresses()
    {
        $this->service->save(new HistoryAddress($this->client,
            new Address($this->cityId, 'Izhevsk', 'Lenina', '1', '50.123', '60.123')));
        $this->service->save(new HistoryAddress($this->client,
            new Address($this->cityId, 'Moscow', 'Lenina', '1', '50.123', '60.123')));

        $this->assertCount(2, $this->service->getHistory($this->client, $this->cityId));
    }

    public function testAddressLimitInHistory()
    {
        $firstAddress = new Address($this->cityId, 'Izhevsk', 'Lenina', '1', '50.123', '60.123');
        $this->service->save(new HistoryAddress($this->client, $firstAddress));

        for ($i = 0; $i < AddressHistoryService::DEFAULT_HISTORY_LIMIT; $i++) {
            $address = new Address($this->cityId, $i . 'Izhevsk', 'Lenina', '1', '50.123', '60.123');
            $this->service->save(new HistoryAddress($this->client, $address));
        }

        $history = $this->service->getHistory($this->client, $this->cityId);

        $this->assertCount(AddressHistoryService::DEFAULT_HISTORY_LIMIT, $history);
        $this->assertFalse($firstAddress->equals(end($history)->getAddress()));
    }
}