<?php

require __DIR__ . '/../vendor/autoload.php';

$env = new Dotenv\Dotenv(dirname(__DIR__));
$env->load();

define('YII_ENV', 'test');
defined('YII_DEBUG') or define('YII_DEBUG', true);

require_once __DIR__ . '/../vendor/yiisoft/yii2/Yii.php';
require __DIR__ . '/../api/config/bootstrap.php';

Yii::setAlias('@tests', __DIR__);