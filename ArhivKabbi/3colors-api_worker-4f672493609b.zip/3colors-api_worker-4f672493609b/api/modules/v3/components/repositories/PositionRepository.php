<?php

namespace v3\components\repositories;


use app\models\tenant\TenantCityHasPosition;

class PositionRepository
{
    public static function isActivePositionInCity($tenantId, $cityId, $positionId)
    {
        return TenantCityHasPosition::find()
            ->where([
                'tenant_id' => $tenantId,
                'city_id' => $cityId,
                'position_id' => $positionId
            ])
            ->exists();
    }
}