<?php

namespace v3\components;

use addressHistory\AddressHistoryService;
use addressHistory\models\Address;
use addressHistory\models\CityId;
use addressHistory\models\Client;
use addressHistory\models\DBAddressHistoryRepository;
use addressHistory\models\HistoryAddress;
use api\models\order\exceptions\SavingOrderTrackException;
use app\components\gearman\Gearman;
use app\models\address\City;
use app\models\order\Order;
use app\models\order\OrderStatus;
use app\models\order\OrderTrackService;
use app\models\order\OrderUpdateEvent;
use app\models\order\RawOrderCalc;
use app\models\tenant\TenantSetting;
use v3\components\services\filters\order\NameClientFilter;
use yii\base\InvalidConfigException;
use yii\base\Object;
use yii\helpers\ArrayHelper;

/**
 * Class OrderService
 * @package v3\components
 */
class OrderService extends Object
{
    /**
     * Getting order from redis
     *
     * @param int $orderId
     * @param int $tenantId
     *
     * @return array|null
     */
    public function getOrderFromRedis($orderId, $tenantId)
    {
        $order = \Yii::$app->redis_orders_active->executeCommand('HGET', [$tenantId, $orderId]);
        $order = unserialize($order);

        return empty($order) ? null : $order;
    }

    /**
     * Save order to redis
     *
     * @param int   $orderId
     * @param int   $tenantId
     * @param array $order
     *
     * @return bool
     */
    public function saveOrderToRedis($orderId, $tenantId, $order)
    {
        $orderData = serialize($order);
        $result    = \Yii::$app->redis_orders_active->executeCommand('HSET',
            [$tenantId, $orderId, $orderData]);

        return $result == 0 || $result == 1;
    }

    /**
     * Filtering order
     *
     * @param array  $order
     * @param int    $tenantId
     * @param string $language
     * @param array  $workerFromRedis
     *
     * @return array
     */
    public function filterOrder($order, $tenantId, $language, $workerFromRedis)
    {
        $order = Order::filterOrderData($order, $tenantId, $language);
        return (new NameClientFilter($workerFromRedis))->runFilter($order);
    }

    /**
     * @param int   $orderId
     * @param int   $tenantId
     * @param array $address
     *
     * @throws \yii\base\InvalidConfigException
     */
    public function saveAddressToHistory($orderId, $tenantId, array $address)
    {
        $order = $this->getOrderFromRedis($orderId, $tenantId);

        $service = new AddressHistoryService(new DBAddressHistoryRepository());

        foreach ($address as $item) {
            $clientId = $order['client_id'] ?? 0;
            $cityId   = $item['city_id'] ?? 0;

            $city   = $item['city'] ?? '';
            $street = $item['street'] ?? '';
            $house  = $item['house'] ?? '';
            $lat    = $item['lat'] ?? '';
            $lon    = $item['lon'] ?? '';

            $service->save(new HistoryAddress(new Client((int)$clientId), new Address(new CityId((int)$cityId),
                (string)$city, (string)$street, (string)$house, (string)$lat, (string)$lon)));
        }
    }

    /**
     * Getting free orders
     *
     * @param int    $tenantId
     * @param string $workerCallsign
     * @param int    $workerCityId
     * @param int    $parkingId
     *
     * @return array
     */
    public function getFreeOrders($tenantId, $workerCallsign, $workerCityId, $parkingId)
    {
        /**
         * @var $workerService WorkerService
         */
        $workerService = \Yii::$container->get(WorkerService::className());

        $freeOrders = isset($parkingId)
            ? Order::getFreeOrdersAtParking($tenantId, $parkingId)
            : Order::getFreeOrders($tenantId);

        $worker = $workerService->getWorkerFromRedis($tenantId, $workerCallsign);

        $positions = isset($worker['position']['positions']) ? $worker['position']['positions'] : [];
        $classes   = isset($worker['position']['classes']) ? $worker['position']['classes'] : [];
        $hasCar    = isset($worker['position']['has_car']) ? $worker['position']['has_car'] : null;

        $addOptions = isset($worker['car']['carHasOptions'])
            ? ArrayHelper::getColumn($worker['car']['carHasOptions'], 'option_id') : [];

        $result = [];
        if (!empty($freeOrders) && !(empty($classes) && empty($positions))) {
            foreach ($freeOrders as $order) {
                if ($order['city_id'] == $workerCityId) {
                    $classId    = isset($order['tariff']['class']['class_id'])
                        ? $order['tariff']['class']['class_id'] : null;
                    $positionId = isset($order['tariff']['position_id'])
                        ? $order['tariff']['position_id'] : null;

                    if ((!empty($hasCar) && in_array($classId, $classes, false))
                        || (empty($hasCar) && in_array($positionId, $positions, false))
                    ) {
                        $isValidOptions = true;
                        $orderOptions   = isset($order['options'])
                            ? ArrayHelper::getColumn($order['options'], 'option_id') : [];
                        foreach ($orderOptions as $option) {
                            if (!in_array($option, $addOptions, false)) {
                                $isValidOptions = false;
                                break;
                            }
                        }

                        if ($isValidOptions) {
                            $addressFrom = $order['address'];
                            $addressFrom = unserialize($addressFrom);
                            $addressFrom = isset($addressFrom['A']) ? $addressFrom['A'] : null;
                            $createTime  = $order['order_time'];
                            $orderTime   = date('d.m.Y H:i:s', $createTime);

                            $result[] = [
                                'order_id'    => $order['order_id'],
                                'position_id' => $order['position_id'],
                                'order_from'  => $addressFrom,
                                'order_time'  => $orderTime,
                                'payment'     => $order['payment'],
                            ];
                        }
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Getting filtered by distance orders
     *
     * @param int $tenantId
     * @param int $cityId
     * @param float $workerLat
     * @param float $workerLon
     * @param array $orders
     *
     * @return array
     * @throws InvalidConfigException
     */
    public function getFilteredByDistanceOrders($tenantId, $cityId, $workerLat, $workerLon, array $orders)
    {
        /** @var $geoService GeoService */
        $geoService = \Yii::createObject(GeoService::className());

        return array_values(array_filter($orders, function ($order)
        use ($geoService, $tenantId, $cityId, $workerLat, $workerLon) {
            $positionId = isset($order['position_id']) ? $order['position_id'] : null;

            $filterDistance     = TenantSetting::getSettingValue(
                $tenantId, TenantSetting::SETTING_DISTANCE_TO_FILTER_FREE_ORDERS, $cityId, $positionId);
            $filterDistanceInKm = empty($filterDistance) ? 0 : $filterDistance / 1000;

            $orderLat = $order['order_from']['lat'];
            $orderLon = $order['order_from']['lon'];
            $distance = $geoService->getDistance(
                (float)$workerLat,
                (float)$workerLon,
                (float)$orderLat,
                (float)$orderLon
            );

            return $filterDistanceInKm >= $distance;
        }));
    }

    /**
     * Getting free pre-orders
     *
     * @param int $tenantId
     * @param int $workerCallsign
     * @param int $workerCityId
     *
     * @return array
     */
    public function getFreePreOrders($tenantId, $workerCallsign, $workerCityId)
    {
        /**
         * @var $workerService WorkerService
         */
        $workerService = \Yii::$container->get(WorkerService::className());

        $freePreOrders = Order::getFreePredvOrders($tenantId);

        $worker = $workerService->getWorkerFromRedis($tenantId, $workerCallsign);

        $classes = isset($worker['position']['classes']) ? $worker['position']['classes'] : [];
        $positions = isset($worker['position']['positions']) ? $worker['position']['positions'] : [];
        $hasCar = isset($worker['position']['has_car']) ? $worker['position']['has_car'] : null;
        $workerPositionId = isset($worker['position']['position_id']) ? $worker['position']['position_id'] : null;

        $addOptions = isset($worker['car']['carHasOptions'])
            ? ArrayHelper::getColumn($worker['car']['carHasOptions'], 'option_id') : [];
        $timeDiffOfPreOrderVisibility = null;
        $workerCityOffset = City::getTimeOffset($workerCityId);
        $restrictVisibilityOfPreOrder = TenantSetting::getSettingValue($tenantId, TenantSetting::SETTING_RESTRICT_VISIBILITY_OF_PRE_ORDER, $workerCityId, $workerPositionId);
        if ((int)$restrictVisibilityOfPreOrder === 1) {
            $timeOfPreOrderVisibilityInHours = TenantSetting::getSettingValue($tenantId, TenantSetting::SETTING_TIME_OF_PRE_ORDER_VISIBILITY, $workerCityId, $workerPositionId);
            $timeDiffOfPreOrderVisibility = $timeOfPreOrderVisibilityInHours ? $timeOfPreOrderVisibilityInHours * 60 * 60 : null;
        }
        $result = [];
        if (!empty($freePreOrders) && !(empty($classes) && empty($positions))) {
            foreach ($freePreOrders as $preOrder) {
                if ($preOrder['city_id'] == $workerCityId) {
                    if ($timeDiffOfPreOrderVisibility) {
                        $orderTime = $preOrder['order_time'];
                        $nowTime = time() + $workerCityOffset;
                        if ($orderTime - $nowTime > $timeDiffOfPreOrderVisibility) {
                            continue;
                        }
                    }
                    $classId = isset($preOrder['tariff']['class']['class_id'])
                        ? $preOrder['tariff']['class']['class_id'] : null;
                    $positionId = isset($preOrder['tariff']['position_id'])
                        ? $preOrder['tariff']['position_id'] : null;

                    if ((!empty($hasCar) && in_array($classId, $classes, false))
                        || (empty($hasCar) && in_array($positionId, $positions, false))
                    ) {
                        $isValidOptions = true;
                        $orderOptions   = isset($preOrder['options'])
                            ? ArrayHelper::getColumn($preOrder['options'], 'option_id') : [];
                        foreach ($orderOptions as $option) {
                            if (!in_array($option, $addOptions, false)) {
                                $isValidOptions = false;
                                break;
                            }
                        }

                        if ($isValidOptions) {
                            $addressFrom = $preOrder['address'];
                            $addressFrom = unserialize($addressFrom);
                            $addressFrom = isset($addressFrom['A']) ? $addressFrom['A'] : null;
                            $createTime  = $preOrder['order_time'];
                            $orderTime   = date('d.m.Y H:i:s', $createTime);

                            $result[] = [
                                'order_id'   => $preOrder['order_id'],
                                'order_from' => $addressFrom,
                                'order_time' => $orderTime,
                                'payment'    => $preOrder['payment'],
                            ];
                        }
                    }
                }
            }
        }

        return $result;
    }


    /**
     * Getting worker pre-orders
     *
     * @param int $tenantId
     * @param int $workerCallsign
     * @param int $workerCityId
     *
     * @return array
     */
    public function getWorkerPreOrders($tenantId, $workerCallsign, $workerCityId)
    {
        $orders = Order::getWorkerPreOrders($tenantId, $workerCallsign);

        $result = [];
        if (is_array($orders)) {
            foreach ($orders as $order) {
                if ($order['city_id'] == $workerCityId) {
                    $addressFrom = unserialize($order['address']);
                    $addressFrom = isset($addressFrom['A']) ? $addressFrom['A'] : null;
                    $createTime  = $order['order_time'];
                    $orderTime   = date('d.m.Y H:i:s', $createTime);

                    $result[] = [
                        'order_id'   => $order['order_id'],
                        'order_from' => $addressFrom,
                        'order_time' => $orderTime,
                        'payment'    => $order['payment'],
                    ];
                }
            }
        }

        return $result;
    }


    /**
     * Getting list of own orders
     *
     * @param int $tenantId
     * @param int $workerCallsign
     *
     * @return array
     */
    public function getOwnOrders($tenantId, $workerCallsign)
    {
        $orders = Order::getOrdersByWorkerFromRedis($tenantId, $workerCallsign);

        $activeOrders      = [];
        $assignedOrders    = [];
        $assignedPreOrders = [];

        if (is_array($orders)) {
            foreach ($orders as $order) {
                $addressFrom = unserialize($order['address']);
                $addressFrom = isset($addressFrom['A']) ? $addressFrom['A'] : null;
                $createTime  = $order['order_time'];
                $orderTime   = date('d.m.Y H:i:s', $createTime);

                $info = [
                    'order_id'    => $order['order_id'],
                    'order_from'  => $addressFrom,
                    'order_time'  => $orderTime,
                    'payment'     => $order['payment'],
                    'deny_refuse' => in_array($order['status_id'], [
                        OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD,
                        OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD,
                    ], false),
                    'status_id'   => $order['status_id']
                ];

                switch ($order['status_id']) {
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD:
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT:
                    case OrderStatus::STATUS_PRE_WORKER_ACCEPT_ORDER:
                    case OrderStatus::STATUS_WAITING_FOR_PRE_ORDER_CONFIRMATION:
                    case OrderStatus::STATUS_WORKER_IGNORED_PRE_ORDER_CONFIRMATION:
                    case OrderStatus::STATUS_WORKER_REFUSED_PRE_ORDER_CONFIRMATION:
                    case OrderStatus::STATUS_WORKER_ACCEPTED_PRE_ORDER_CONFIRMATION:
                        $assignedPreOrders[] = $info;
                        break;
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD:
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT:
                        $assignedOrders[] = $info;
                        break;
                    default:
                        $activeOrders[] = $info;
                }
            }
        }

        return [
            'activeOrders'      => $activeOrders,
            'assignedOrders'    => $assignedOrders,
            'assignedPreOrders' => $assignedPreOrders,
        ];
    }


    /**
     * Set raw order calc
     *
     * @param int    $orderId
     * @param string $orderCalcData
     *
     * @return bool
     */
    public function setRawOrderCalc($orderId, $orderCalcData)
    {
        $rawOrderCalc = RawOrderCalc::findOne(['order_id' => $orderId]);

        if (!empty($rawOrderCalc)) {
            return true;
        }

        $rawOrderCalc                = new RawOrderCalc();
        $rawOrderCalc->order_id      = $orderId;
        $rawOrderCalc->raw_cacl_data = $orderCalcData;

        $result = $rawOrderCalc->save();
        if (!$result) {
            \Yii::error("Error save Set_order_raw_calc . Order id = " . $orderId . " . Error:");
            \Yii::error($rawOrderCalc->errors);
        }

        return $result;
    }


    /**
     * Getting order route
     *
     * @param int $orderId
     *
     * @return array
     * @throws InvalidConfigException
     */
    public function getOrderRoute($orderId)
    {
        /* @var $service OrderTrackService */
        $service = \Yii::createObject(OrderTrackService::class);

        return $service->getTrack($orderId);
    }


    /**
     * Set order route
     *
     * @param int    $orderId
     * @param string $orderRoute
     *
     * @return bool
     * @throws InvalidConfigException
     */
    public function setOrderRoute($orderId, $orderRoute)
    {
        $data = [
            'orderId'    => $orderId,
            'orderTrack' => $orderRoute,
        ];

        $result = false;
        try {
            \Yii::$app->gearman->doBackground(Gearman::ORDER_TRACK_TASK, $data);
            $result = true;
        } catch (\Exception $ex) {
            \Yii::error("Error save Set_order_route . Order id = " . $orderId . " . Error:");
            \Yii::error($ex->getMessage());
        }

        return $result;
    }


    /**
     * Getting result of order update event
     *
     * @param string $requestId Uuid4
     *
     * @return string
     * @throws InvalidConfigException
     */
    public function getOrderUpdateEventResult($requestId)
    {
        /* @var $event OrderUpdateEvent */
        $event    = \Yii::createObject(OrderUpdateEvent::className());
        $response = $event->getResponse($requestId);

        return empty($response) ? null : $response;
    }
}