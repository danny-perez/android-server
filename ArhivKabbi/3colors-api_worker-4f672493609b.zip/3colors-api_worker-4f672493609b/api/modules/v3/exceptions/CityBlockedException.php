<?php

namespace v3\exceptions;

use yii\base\Exception;

/**
 * Class CityBlockedException
 * @package v3\exceptions
 */
class CityBlockedException extends Exception
{

}