<?php

namespace v3\exceptions;


class ExceptionConfidentialPage extends \Exception
{

}