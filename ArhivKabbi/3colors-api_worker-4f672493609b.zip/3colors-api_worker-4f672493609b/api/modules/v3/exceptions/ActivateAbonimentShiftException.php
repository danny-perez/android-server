<?php

namespace v3\exceptions;

use yii\base\Exception;

/**
 * Class ActivateAbonimentShiftException
 * @package v3\exceptions
 */
class ActivateAbonimentShiftException extends Exception
{

}