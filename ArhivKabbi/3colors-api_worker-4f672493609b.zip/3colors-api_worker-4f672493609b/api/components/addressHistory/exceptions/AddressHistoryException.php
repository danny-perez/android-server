<?php

namespace addressHistory\exceptions;

/**
 * Class AddressHistoryException
 * @package addressHistory\exceptions
 */
class AddressHistoryException extends \DomainException
{

}