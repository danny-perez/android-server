<?php

namespace healthCheck\exceptions;

/**
 * Class HealthCheckException
 * @package healthCheck\exceptions
 */
class HealthCheckException extends \DomainException
{

}