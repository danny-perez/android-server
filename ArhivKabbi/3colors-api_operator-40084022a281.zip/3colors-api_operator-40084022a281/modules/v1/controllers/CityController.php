<?php

namespace app\modules\v1\controllers;


/**
 * City controller for the `v1` module
 */
class CityController extends BaseController
{
    /**
     * Getting user city list
     * @return string
     */
    public function actionIndex()
    {
        return user()->getCityList();
    }
}
