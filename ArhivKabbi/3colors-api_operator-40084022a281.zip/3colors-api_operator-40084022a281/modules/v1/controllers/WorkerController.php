<?php


namespace app\modules\v1\controllers;


use app\behaviors\StopJsonEncode;
use app\components\WorkerApi;
use app\modules\v1\models\position\Position;
use app\modules\v1\models\worker\ActiveWorkers;
use app\modules\v1\models\worker\WorkerActiveSearch;
use app\modules\v1\models\worker\WorkerBlock;
use app\modules\v1\models\worker\WorkerOffline;
use app\modules\v1\models\worker\WorkerView;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\web\BadRequestHttpException;

class WorkerController extends BaseController
{
    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'stopJsonEncode' => [
                'class'   => StopJsonEncode::className(),
                'actions' => ['order-block', 'order-unblock', 'end-work'],
            ],
            'verbs'          => [
                'class'   => VerbFilter::className(),
                'actions' => [
                    'order-block'   => ['post'],
                    'order-unblock' => ['post'],
                    'end-work'      => ['post'],
                ],
            ],
        ]);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionOffline($city_id, $position_id)
    {
        $activeWorkersModel = $this->getActiveWorkersModel($city_id, $position_id);

        return (new WorkerOffline([
            'cityId'          => $city_id,
            'positionId'      => $position_id,
            'activeWorkerIds' => $activeWorkersModel->getList(),
            'tenantId'        => $this->getUserTenantId(),
        ]))->getList();
    }

    /**
     * @return array
     */
    public function actionPositionList()
    {
        return (new Position())->getRootPositionList();
    }

    private function getActiveWorkersModel($city_id, $position_id)
    {
        return new ActiveWorkers([
            'tenantId'    => $this->getUserTenantId(),
            'cityId'      => $city_id,
            'positionId'  => $position_id,
            'allowCityId' => $this->getUserCityIds(),
        ]);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionCounters($city_id, $position_id)
    {
        $activeWorkers = $this->getActiveWorkersModel($city_id, $position_id);
        $offlineWorkers = (new WorkerOffline([
            'cityId'          => $city_id,
            'positionId'      => $position_id,
            'tenantId'        => $this->getUserTenantId(),
            'activeWorkerIds' => $activeWorkers->getList(),
        ]))->getCount();

        return [
            'free'     => $activeWorkers->getByType(ActiveWorkers::FREE_TYPE)->getCount(),
            'on_order' => $activeWorkers->getByType(ActiveWorkers::BUSY_TYPE)->getCount(),
            'offline'  => $offlineWorkers,
        ];
    }

    /**
     * @param int $id Worker ID
     * @param int $position_id Position ID
     * @return array
     */
    public function actionView($id, $position_id)
    {
        return (new WorkerView([
            'workerId'   => $id,
            'positionId' => $position_id,
            'tenantId'   => $this->getUserTenantId(),
        ]))->getData();
    }

    /**
     * @param string $search
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionSearch($search, $city_id, $position_id)
    {
        return (new WorkerActiveSearch([
            'search'      => $search,
            'cityId'      => $city_id,
            'positionId'  => $position_id,
            'allowCityId' => $this->getUserCityIds(),
            'tenantId'    => $this->getUserTenantId(),
        ]))->getData();
    }

    /**
     * @return WorkerApi
     */
    private function getWorkerApiComponent()
    {
        return Yii::$app->workerApi;
    }

    /**
     * @return mixed
     * @throws BadRequestHttpException
     */
    public function actionOrderBlock()
    {
        $callsign = post('callsign');

        if (empty($callsign)) {
            throw new BadRequestHttpException('Empty requred param: callsign');
        }

        $workerComponent = $this->getWorkerApiComponent();
        $tenantLogin = user()->tenant->domain;

        return $workerComponent->orderBlock($callsign, $tenantLogin);
    }

    /**
     * @return mixed
     * @throws BadRequestHttpException
     */
    public function actionOrderUnblock()
    {
        $callsign = post('callsign');

        if (empty($callsign)) {
            throw new BadRequestHttpException('Empty requred param: callsign');
        }

        $workerComponent = $this->getWorkerApiComponent();
        $tenantLogin = user()->tenant->domain;
        $worker = ActiveWorkers::getOne($callsign, $this->getUserTenantId());
        $workerBlockId = (new WorkerBlock(['shiftId' => $worker['worker']['worker_shift_id']]))->getBlockId();

        return $workerComponent->orderUnblock($callsign, $tenantLogin, $workerBlockId);
    }

    /**
     * @return mixed
     * @throws BadRequestHttpException
     */
    public function actionEndWork()
    {
        $callsign = post('callsign');

        if (empty($callsign)) {
            throw new BadRequestHttpException('Empty requred param: callsign');
        }

        $workerComponent = $this->getWorkerApiComponent();
        $tenantLogin = user()->tenant->domain;

        return $workerComponent->endWork($callsign, $tenantLogin);
    }
}