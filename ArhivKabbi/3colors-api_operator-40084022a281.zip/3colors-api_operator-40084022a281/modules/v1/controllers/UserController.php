<?php


namespace app\modules\v1\controllers;


use yii\helpers\Url;

class UserController extends BaseController
{
    public function actionIndex()
    {
        return [
            'name'  => user()->getUserName(),
            'link'  => Url::to(['/tenant/user/update', 'id' => user()->user_id]),
            'photo' => user()->getPhotoUrl(),
            'lang'  => user()->lang,
        ];
    }
}