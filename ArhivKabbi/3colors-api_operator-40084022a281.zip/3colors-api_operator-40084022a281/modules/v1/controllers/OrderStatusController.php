<?php


namespace app\modules\v1\controllers;


use app\modules\v1\models\order\OrderStatus;

class OrderStatusController extends BaseController
{
    /**
     * @param int $status_id
     * @param string $group Group of statuses
     * @return array
     */
    public function actionIndex($status_id = null, $group = null)
    {
        return OrderStatus::getList($status_id, $group);
    }
}