<?php


namespace app\modules\v1\controllers;


use Yii;
use app\modules\v1\models\client\Client;
use app\modules\v1\models\client\ClientRecord;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

class ClientController extends BaseController
{
    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'verbs' => [
                'class'   => VerbFilter::className(),
                'actions' => [
                    'create' => ['post'],
                    'search' => ['get'],
                ],
            ],
        ]);
    }

    /**
     * @param string $phone
     * @param integer $city_id
     * @return array
     */
    public function actionSearch($phone, $city_id)
    {
        return (new Client([
            'phone'    => $phone,
            'tenantId' => $this->getUserTenantId(),
            'cityId'   => $city_id,
        ]))->getData();
    }

    public function actionCreate()
    {
        $client = new ClientRecord(['tenant_id' => $this->getUserTenantId()]);

        if ($client->load(Yii::$app->request->post(), '')) {

            if ($client->save()) {
                return ['client_id' => $client->client_id];
            }

            return ['error' => $client->getFirstErrors()];
        }

        return ['error' => 'Error to load post data'];
    }
}