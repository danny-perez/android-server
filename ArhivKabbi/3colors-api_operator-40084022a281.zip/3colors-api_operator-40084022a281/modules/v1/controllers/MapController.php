<?php


namespace app\modules\v1\controllers;


use app\modules\v1\models\order\list_format\MapFormat;
use app\modules\v1\models\order\Order;
use app\modules\v1\models\worker\WorkerBusy;
use app\modules\v1\models\worker\WorkerFree;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;

class MapController extends BaseController
{
    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'access' => [
                'class'  => AccessControl::className(),
                'except' => ['options'],
                'rules'  => [
                    [
                        'allow' => true,
                        'roles' => ['read_orders'],
                    ],
                ],
            ],
        ]);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionData($city_id, $position_id)
    {
        return [
            'orders' => $this->getActiveOrders($city_id, $position_id),
            'free'   => $this->getFreeWorkers($city_id, $position_id),
            'busy'   => $this->getBusyWorkers($city_id, $position_id),
        ];
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    private function getActiveOrders($city_id, $position_id)
    {
        return (new Order([
            'tenantId'    => $this->getUserTenantId(),
            'positionId'  => $position_id,
            'cityId'      => $city_id,
            'allowCityId' => $this->getUserCityIds(),
            'formatter'   => MapFormat::className(),
        ]))->getList();
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    private function getFreeWorkers($city_id, $position_id)
    {
        return (new WorkerFree([
            'tenantId'    => $this->getUserTenantId(),
            'positionId'  => $position_id,
            'cityId'      => $city_id,
            'allowCityId' => $this->getUserCityIds(),
        ]))->getList();
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    private function getBusyWorkers($city_id, $position_id)
    {
        return (new WorkerBusy([
            'tenantId'    => $this->getUserTenantId(),
            'positionId'  => $position_id,
            'cityId'      => $city_id,
            'allowCityId' => $this->getUserCityIds(),
        ]))->getList();
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionOrders($city_id, $position_id)
    {
        return $this->getActiveOrders($city_id, $position_id);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionFreeWorkers($city_id, $position_id)
    {
        return $this->getFreeWorkers($city_id, $position_id);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionBusyWorkers($city_id, $position_id)
    {
        return $this->getBusyWorkers($city_id, $position_id);
    }
}