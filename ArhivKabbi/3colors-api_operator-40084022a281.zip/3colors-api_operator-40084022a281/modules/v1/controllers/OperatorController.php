<?php

namespace app\modules\v1\controllers;


use app\models\UserDispatcherRepository;
use app\modules\v1\models\order\ActiveOrder;
use app\modules\v1\models\phone_line\PhoneLine;
use app\modules\v1\models\user\UserDispatcher;
use Yii;

class OperatorController extends BaseController
{
    /**
     * Change dispatcher status to free
     */
    public function actionSetFreeStatus()
    {
        $userId = user()->user_id;
        $operatorData = (new UserDispatcherRepository())->getOne($userId);

        if (!$operatorData['on_pause']) {
            return (new UserDispatcher(['userId' => $userId]))->sendStateToPhoneApi('idle');
        }

        return 0;
    }

    public function actionSetBusyStatus()
    {
        return (new UserDispatcher(['userId' => user()->user_id]))->sendStateToPhoneApi('unavailable');
    }

    /**
     * It is calling.
     * @param int $did Phone line number
     * @param int $clid Calling phone number
     * @return array
     */
    public function actionCall($did, $clid)
    {
        $did = trim($did);
        $clid = trim((int)$clid);
        $tenantId = $this->getUserTenantId();
        $orders = (new ActiveOrder(['tenantId' => $tenantId]))->getOrdersIdByPhone($clid);
        $phoneLine = (new PhoneLine(['tenantId' => $tenantId, 'phone' => $did]))->getLine();

        return [
            'orders'    => $orders,
            'city_id'   => $phoneLine->getCity(),
            'tariff_id' => $phoneLine->getTariff(),
        ];
    }
}
