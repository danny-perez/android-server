<?php


namespace app\modules\v1\controllers;

use yii\filters\auth\HttpBasicAuth;
use yii\filters\Cors;
use yii\rest\Controller;

class BaseController extends Controller
{
    public function behaviors()
    {
        $behaviors = parent::behaviors();

        $behaviors['authenticator'] = [
            'class'  => HttpBasicAuth::className(),
            'except' => ['options'],
        ];

        $behaviors['corsFilter'] = [
            'class' => Cors::className(),
            'cors'  => [
                // restrict access to
                'Origin'                           => ['http://work.crystal-web.ru'],
                'Access-Control-Request-Method'    => ['POST', 'GET'],
                'Access-Control-Allow-Credentials' => true,
                'Access-Control-Max-Age'           => 86400,
            ],
        ];

        return $behaviors;
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'options' => [
                'class' => 'yii\rest\OptionsAction',
            ],
        ];
    }

    protected function getUserTenantId()
    {
        return user()->tenant_id;
    }

    /**
     * @return array
     */
    protected function getUserCityIds()
    {
        return user()->getCityIds();
    }
}