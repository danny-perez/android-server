<?php

namespace app\modules\v1\controllers;


use app\modules\v1\models\tariff_client\Options;
use app\modules\v1\models\tariff_client\TariffClient;

class TariffClientController extends BaseController
{
    /**
     * @param int $city_id
     * @param int $position_id
     * @return array
     */
    public function actionList($city_id, $position_id)
    {
        return (new TariffClient([
            'cityId'     => $city_id,
            'positionId' => $position_id,
            'tenantId'   => $this->getUserTenantId(),
        ]))->getList();
    }

    /**
     * @param int $tariff_id
     * @param int $order_time Timestamp of local order time
     * @return array
     */
    public function actionOptionList($tariff_id, $order_time = null)
    {
        return (new Options([
            'tariffId'  => $tariff_id,
            'orderTime' => $order_time,
        ]))->getList();
    }
}