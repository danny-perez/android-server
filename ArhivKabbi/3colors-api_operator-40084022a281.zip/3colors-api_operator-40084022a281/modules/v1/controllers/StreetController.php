<?php


namespace app\modules\v1\controllers;


use app\modules\v1\models\street\Street;

class StreetController extends BaseController
{
    /**
     * Getting street list data for autocomplite
     * @param string $search String search
     * @param string $city_id City Id of branch
     * @param string $lat Latitude of central searching point
     * @param string $lon Longitude of central searching point
     * @param string $action Search action. Ex.: 'autocomplete', 'search'
     * @param null|string $lang language of streets
     * @return array
     */
    public function actionIndex($search, $city_id, $lat, $lon, $action = 'autocomplete', $lang = null)
    {
        $tenant_id = $this->getUserTenantId();

        return (new Street(compact('search', 'city_id', 'lat', 'lon', 'action', 'lang', 'tenant_id')))->getList();
    }
}