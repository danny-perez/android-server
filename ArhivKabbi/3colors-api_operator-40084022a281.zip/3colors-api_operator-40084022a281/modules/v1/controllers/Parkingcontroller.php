<?php


namespace app\modules\v1\controllers;




use app\modules\v1\models\parking\Parking;

class ParkingController extends BaseController
{
    public function actionIndex($city_id)
    {
        return (new Parking([
            'city_id'   => $city_id,
            'tenant_id' => $this->getUserTenantId(),
        ]))->getList();
    }

    /**
     * @param int $city_id
     * @param string $lat
     * @param string $lon
     * @return array
     */
    public function actionGetParkingByCoords($city_id, $lat, $lon)
    {
        return (new Parking())->getParkingByCoords($city_id, $lat, $lon);
    }
}