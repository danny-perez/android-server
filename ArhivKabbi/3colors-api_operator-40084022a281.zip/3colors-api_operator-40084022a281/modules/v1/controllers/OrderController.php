<?php


namespace app\modules\v1\controllers;


use app\behaviors\StopJsonEncode;
use app\components\TaxiRouteAnalyzer;
use app\models\order\OrderEventRepository;
use app\modules\v1\models\city\City;
use app\modules\v1\models\order\Order;
use app\modules\v1\models\order\OrderEvents;
use app\modules\v1\models\order\OrderUpdateEvent;
use Yii;
use yii\helpers\ArrayHelper;
use yii\web\NotFoundHttpException;

/**
 * Class OrderController
 * @package app\modules\v1\controllers
 * @mixin StopJsonEncode
 */
class OrderController extends BaseController
{
    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'stopJsonEncode' => [
                'class'   => StopJsonEncode::className(),
                'actions' => ['check-update-event'],
            ],
        ]);
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @param string $type ("new", "in_hands", "warning", "completed", "rejected")
     * @param null|string $date
     *
     * @return array
     */
    public function actionIndex($city_id, $position_id, $type = 'new', $date = null)
    {
        return (new Order([
            'cityId'      => $city_id,
            'allowCityId' => $this->getUserCityIds(),
            'tenantId'    => $this->getUserTenantId(),
            'positionId'  => $position_id,
            'statusGroup' => $type,
            'date'        => $date,
        ]))->getList();
    }

    /**
     * @param int $city_id
     * @param int $position_id
     * @param null|string $date
     *
     * @return array
     */
    public function actionCounters($city_id, $position_id, $date = null)
    {
        return (new Order([
            'cityId'     => $city_id,
            'tenantId'   => $this->getUserTenantId(),
            'positionId' => $position_id,
            'date'       => $date,
        ]))->getCounts();
    }

    /**
     * @param int $id
     *
     * @return array|null
     * @throws NotFoundHttpException
     */
    public function actionView($id)
    {
        $orderData = (new Order())->getViewData($id);

        if (!$orderData) {
            throw new NotFoundHttpException();
        }

        return $orderData;
    }

    /**
     * @param int $order_number
     * @param int $tenant_id
     *
     * @return array|null
     */
    public function actionViewByNumber($order_number, $tenant_id)
    {
        return (new Order(['tenantId' => $tenant_id]))->getOneByNumber($order_number);
    }

    /**
     * @param int $order_id
     * @param int $city_id
     *
     * @return array
     */
    public function actionEvents($order_id, $city_id)
    {
        return (new OrderEvents(['orderId' => $order_id, 'cityId' => $city_id]))->getData();
    }

    /**
     * @param int $order_id
     *
     * @return false|null|string
     */
    public function actionTrack($order_id)
    {
        return (new Order(['tenantId' => $this->getUserTenantId()]))
            ->getTracking($order_id);
    }

    /**
     * @param int $city_id
     * @param array $address
     * @param int $tariff_id
     * @param array|string $options [1,2,3]|"1,2,3"
     * @param string $order_date Format: 'd.m.Y H:i:s'
     *
     * @return array
     */
    public function actionRouteAnalyze($city_id, $address, $tariff_id, $options = '', $order_date = null)
    {
        $address = json_decode($address, true);

        /** @var TaxiRouteAnalyzer $routeAnalyzer */
        $routeAnalyzer = app()->routeAnalyzer;

        if (empty($order_date)) {
            $offset = (new City(['cityId' => $city_id]))->getTimeOffset();
            $order_date = date('d.m.Y H:i:s', time() + $offset);
        }

        return $routeAnalyzer->analyzeRoute($this->getUserTenantId(), $city_id, $address, $options, $tariff_id,
            $order_date);
    }

    /**
     * @return array
     */
    public function actionCreate()
    {
        return (new Order(['tenantId' => $this->getUserTenantId()]))->create(Yii::$app->request->post());
    }

    /**
     * @param int $order_number
     *
     * @return array
     */
    public function actionUpdate($order_number)
    {
        return (new Order(['tenantId' => $this->getUserTenantId()]))->update($order_number, Yii::$app->request->post());
    }

    /**
     * @param int $order_id
     *
     * @return array
     */
    public function actionUpdateEvent($order_id)
    {
        $uuid = null;
        $fields = Yii::$app->request->post('fields');

        if (!empty($fields) && is_array($fields)) {
            $uuid = (new OrderUpdateEvent([
                'tenantId'       => $this->getUserTenantId(),
                'orderId'        => $order_id,
                'senderId'       => user()->user_id,
                'command'        => OrderUpdateEvent::COMMAND_UPDATE_ORDER_DATA,
                'lastUpdateTime' => Yii::$app->request->post('last_update_time'),
                'lang'           => user()->lang,
            ]))->addEvent($fields);
        }

        return ['uuid' => $uuid];
    }

    /**
     * @param string $uuid
     *
     * @return mixed
     * @throws NotFoundHttpException
     */
    public function actionCheckUpdateEvent($uuid)
    {
        $orderEvent = new OrderUpdateEvent();
        $response = $orderEvent->getResponse($uuid);

        if (!empty($response)) {
            $orderEvent->removeResponse($uuid);
        } else {
            $this->setJsonResponse();
            throw new NotFoundHttpException();
        }

        return $response;
    }

    /**
     * Stop offer to worker
     *
     * @param int $order_id
     */
    public function actionStopOffer($order_id)
    {
        $orderUpdateEvent = new OrderUpdateEvent([
            'tenantId'       => $this->getUserTenantId(),
            'orderId'        => $order_id,
            'senderId'       => user()->user_id,
            'command'        => OrderUpdateEvent::COMMAND_STOP_OFFER,
            'lastUpdateTime' => Yii::$app->request->post('last_update_time'),
            'lang'           => user()->lang,
        ]);
        $orderUpdateEvent->addEvent([]);
    }
}