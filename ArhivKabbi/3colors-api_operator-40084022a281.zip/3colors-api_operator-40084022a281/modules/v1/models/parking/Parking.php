<?php


namespace app\modules\v1\models\parking;


use yii\base\Object;
use app\models\Parking as ParkingRecord;

class Parking extends Object
{
    public $tenant_id;
    public $city_id;

    /**
     * @return array|\yii\db\ActiveRecord[]\
     */
    public function getList()
    {
        return ParkingRecord::find()
            ->where(['tenant_id' => $this->tenant_id])
            ->andWhere(['not in', 'type', ['basePolygon', 'reseptionArea']])
            ->andWhere(['city_id' => $this->city_id])
            ->select(['parking_id', 'name'])
            ->asArray()
            ->all();
    }

    /**
     * Get parking by coords.
     * @param integer $city_id
     * @param float $lat
     * @param float $lon
     * @return array
     */
    public function getParkingByCoords($city_id, $lat, $lon)
    {
        $result = [
            'parking' => null,
            'inside'  => null,
            'error'   => null,
        ];

        //Получение парковки, содержащей кординаты
        $parking = app()->routeAnalyzer->getParkingByCoords(user()->tenant_id, $city_id, $lat, $lon);
        $result['parking'] = $parking['parking'];
        if (!empty($result['parking'])) {
            if (!empty($parking)) {
                $result['inside'] = $parking['inside'];
                $result['coords'] = [
                    'lat' => $lat,
                    'lon' => $lon,
                ];
            } else {
                $result['error'] = 'Адрес вне парковок.';
            }
        } else {
            $result['error'] = 'Не получены парковки.';
        }

        return $result;
    }
}