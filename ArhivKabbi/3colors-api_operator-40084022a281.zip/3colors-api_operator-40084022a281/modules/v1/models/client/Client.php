<?php


namespace app\modules\v1\models\client;


use yii\base\Object;
use app\models\Client as ClientRecord;
use Yii;
use yii\helpers\Url;
use app\components\Formatter;


class Client extends Object
{
    public $phone;
    public $tenantId;
    public $cityId;

    /** @var  ClientRecord */
    private $_client;

    /**
     * @return array
     */
    public function getData()
    {
        $client = $this->search();

        if (empty($client)) {
            return [];
        }

        $clientAccount = $this->getClientAccount($client->client_id);

        $currencySymbol = $clientAccount->getCurrencySymbol();
        $account = $clientAccount->getAccount();
        $bonusAccount = $clientAccount->getBonusAccount();

        /** @var Formatter $formatter */
        $formatter = Yii::$app->formatter;

        return [
            'client_id'     => $client->client_id,
            'name'          => $client->getShortName(),
            'photo'         => $client->photo ? Yii::$app->params['photoAction'] . $client->photo : '',
            'black_list'    => $client->black_list,
            'link'          => Url::to(['/client/base/update', 'id' => $client->client_id]),
            'successOrders' => $client->success_order,
            'failedOrders'  => $client->fail_worker_order + $client->fail_client_order,
            'moneyBalance'  => $formatter->asMoney(+$account->balance, $currencySymbol),
            'bonusBalance'  => $formatter->asMoney(+$bonusAccount->balance, $currencySymbol),
        ];
    }

    /**
     * @return ClientRecord|array|null
     */
    private function search()
    {
        $this->_client = ClientRecord::find()
            ->where(['tenant_id' => $this->tenantId, 'value' => $this->phone])
            ->joinWith(['clientPhones'])
            ->select([
                ClientRecord::tableName() . '.client_id',
                'last_name',
                'name',
                'second_name',
                'black_list',
                'success_order',
                'fail_worker_order',
                'fail_client_order',
                'fail_dispatcher_order',
                'photo',
            ])
            ->one();

        return $this->_client;
    }

    /**
     * @param int $clientId
     * @return ClientAccount
     */
    private function getClientAccount($clientId)
    {
        return new ClientAccount(['tenantId' => $this->tenantId, 'cityId' => $this->cityId, 'clientId' => $clientId]);
    }
}