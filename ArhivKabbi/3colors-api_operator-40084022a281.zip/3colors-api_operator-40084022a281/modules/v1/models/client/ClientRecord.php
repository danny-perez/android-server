<?php


namespace app\modules\v1\models\client;


use app\models\Client;
use app\models\ClientPhone;
use app\models\TenantSetting;
use yii\db\ActiveQuery;

class ClientRecord extends Client
{
    public $phone;

    public function rules()
    {
        return [
            [['tenant_id', 'phone', 'city_id'], 'required'],
            [['tenant_id', 'city_id',], 'integer'],
            [
                ['phone'],
                'filter',
                'filter' => function ($value) {
                    return preg_replace("/[^0-9]/", '', $value);
                },
            ],
            ['phone', 'uniquePhone'],
            [['last_name', 'name', 'second_name'], 'string', 'max' => 45],
            [['email'], 'string', 'max' => 45],
            [['email'], 'email'],
            [['description'], 'string'],
            [['birth'], 'date', 'format' => 'Y-m-d'],
        ];
    }

    public function uniquePhone()
    {
        $query = self::find();

        if ($this->isNewRecord) {
            $query->where(['tenant_id' => $this->tenant_id]);
        } else {
            $query->where('tenant_id = :tenant_id AND ' . self::tableName() . '.client_id != :client_id',
                [':tenant_id' => $this->tenant_id, ':client_id' => $this->client_id]);
        }

        $query->joinWith([
            'clientPhones' => function ($subQuery) {
                /** @var $subQuery ActiveQuery */
                $subQuery->where(['value' => $this->phone]);
            },
        ]);

        if ($query->exists()) {
            $this->addError('phone', t('validator', 'Client with the phone already exists'));
        }
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->password = $this->generatePassword();
            $this->lang = $this->getLangSetting();
        }

        return parent::beforeSave($insert);
    }

    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);

        $this->addPhone();
    }

    private function addPhone()
    {
        (new ClientPhone(['value' => $this->phone]))->link('client', $this);
    }

    /**
     * @return int
     */
    private function generatePassword()
    {
        return rand(100000, 999999);
    }

    /**
     * @return false|null|string
     */
    private function getLangSetting()
    {
        return (new TenantSetting(['cityId' => $this->city_id, 'tenantId' => $this->tenant_id]))
            ->getValue(TenantSetting::LANGUAGE_SETTING);
    }
}