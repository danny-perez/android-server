<?php


namespace app\modules\v1\models\client;

use app\modules\v1\models\currency\Currency;
use yii\base\Object;
use app\models\TenantSetting;
use app\models\Account;

class ClientAccount extends Object
{
    public $clientId;
    public $tenantId;
    public $cityId;

    private $_currencyId;

    /**
     * Get client account
     * @return Account|null
     */
    public function getAccount()
    {
        return Account::findOne([
            'owner_id'    => $this->clientId,
            'tenant_id'   => $this->tenantId,
            'acc_kind_id' => Account::CLIENT_KIND,
            'acc_type_id' => Account::PASSIVE_TYPE,
            'currency_id' => $this->getCurrencyId(),
        ]);
    }

    /**
     * Get client bonus account
     * @return Account|null
     */
    public function getBonusAccount()
    {
        return Account::findOne([
            'owner_id'    => $this->clientId,
            'tenant_id'   => $this->tenantId,
            'acc_kind_id' => Account::CLIENT_BONUS_KIND,
            'acc_type_id' => Account::PASSIVE_TYPE,
            'currency_id' => $this->getCurrencyId(),
        ]);
    }

    /**
     * @return false|null|string
     */
    private function getCurrencyId()
    {
        if (empty($this->_currencyId)) {
            $this->_currencyId = (new TenantSetting(['cityId' => $this->cityId, 'tenantId' => $this->tenantId]))
                ->getValue(TenantSetting::CURRENCY_SETTING);
        }

        return $this->_currencyId;
    }

    /**
     * @return string
     */
    public function getCurrencySymbol()
    {
        return (new Currency(['currencyId' => $this->getCurrencyId()]))->getCurrencySymbol();
    }
}