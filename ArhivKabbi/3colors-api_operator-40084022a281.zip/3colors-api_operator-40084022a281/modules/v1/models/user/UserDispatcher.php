<?php


namespace app\modules\v1\models\user;


use app\components\http_client\YiiHttpClientTrait;
use Yii;
use yii\base\Object;

class UserDispatcher extends Object
{
    use YiiHttpClientTrait;

    public $userId;

    public function init()
    {
        parent::init();

        $this->setHttpClient(Yii::$app->params['phoneApiUrl']);
    }

    public function sendStateToPhoneApi($state)
    {
        return $this->_httpClient->createRequest('GET', 'call/setstate', [
            'agent' => $this->userId,
            'state' => $state,
        ]);
    }
}