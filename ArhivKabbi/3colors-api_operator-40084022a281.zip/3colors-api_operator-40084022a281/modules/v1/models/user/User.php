<?php


namespace app\modules\v1\models\user;


use Yii;
use yii\helpers\ArrayHelper;

class User extends \app\models\User
{
    /**
     * Getting user city map
     * @return array ['city_id => 'name']
     */
    public function getCityList()
    {
        $userCityList = (new UserHasCity(['user_id' => $this->user_id]))->getUserCityList();

        return ArrayHelper::getColumn($userCityList, 'city');
    }

    /**
     * @return array
     */
    public function getCityIds()
    {
        $city_list = $this->getCityList();

        return ArrayHelper::getColumn($city_list, 'city_id');
    }

    public function getUserName()
    {
        return trim($this->last_name . ' ' . $this->name);
    }

    /**
     * @return string
     */
    public function getPhotoUrl()
    {
        return $this->photo ? Yii::$app->params['photoAction'] . $this->photo : '';
    }
}