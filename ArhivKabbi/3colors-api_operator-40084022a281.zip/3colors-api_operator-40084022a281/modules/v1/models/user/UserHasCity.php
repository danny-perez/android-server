<?php


namespace app\modules\v1\models\user;

use app\helpers\Language;
use app\models\UserHasCity as UserHasCityRecord;
use yii\base\Object;

class UserHasCity extends Object
{
    public $user_id;

    /**
     * Getting user city map
     * @return array
     */
    public function getUserCityList()
    {
        $langPrefix = Language::getLanguagePrefix();

        return UserHasCityRecord::find()
            ->where(['user_id' => $this->user_id])
            ->with([
                'city' => function ($query) use ($langPrefix) {
                    $query->select(['city_id', 'name' . $langPrefix, 'lat', 'lon']);
                },
            ])
            ->joinWith([
                'tenantHasCities' => function ($query) {
                    $query->where(['block' => 0]);
                },
            ], false)
            ->orderBy('sort')
            ->asArray()
            ->all();
    }
}