<?php


namespace app\modules\v1\models\tariff_client;


use app\models\CarOption;
use app\models\TaxiTariffHasCity;
use app\modules\v1\models\city\City;
use yii\base\Object;
use yii\helpers\ArrayHelper;

class Options extends Object
{
    public $tariffId;

    /** @var int Timestamp of local order time */
    public $orderTime;

    /**
     * @return array
     */
    public function getRawData()
    {
        $routeAnalyzer = app()->routeAnalyzer;
        $addOptionIds = $routeAnalyzer->addOptions($this->tariffId, date('d.m.Y H:i:s', $this->getOrderTime()));

        return $this->getOptionsById($addOptionIds);
    }

    /**
     * @return int
     */
    private function getOrderTime()
    {
        if (empty($this->orderTime)) {
            $tariffCityId = TaxiTariffHasCity::find()
                ->where(['tariff_id' => $this->tariffId])
                ->select('city_id')
                ->scalar();

            $offset = (new City(['cityId' => $tariffCityId]))->getTimeOffset();

            $this->orderTime = time() + $offset;
        }

        return $this->orderTime;
    }

    /**
     * @return array
     */
    public function getList()
    {
        return ArrayHelper::getColumn($this->getRawData(), function ($item) {
            return [
                'id'   => $item['option_id'],
                'name' => t('car-options', $item['name']),
            ];
        });
    }

    /**
     * @param array|int $optionIds
     * @return array|\yii\db\ActiveRecord[]
     */
    private function getOptionsById($optionIds)
    {
        return CarOption::find()
            ->where(['option_id' => $optionIds])
            ->asArray()
            ->all();
    }
}