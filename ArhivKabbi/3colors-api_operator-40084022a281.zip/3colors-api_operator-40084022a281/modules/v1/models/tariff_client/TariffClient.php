<?php


namespace app\modules\v1\models\tariff_client;


use app\models\TaxiTariff;
use yii\base\Object;
use yii\db\ActiveQuery;
use yii\helpers\ArrayHelper;

class TariffClient extends Object
{
    public $tenantId;
    public $cityId;
    public $positionId;

    /**
     * Getting client tariff raw data list.
     * @return array
     */
    public function getRawData()
    {
        return TaxiTariff::find()
            ->where([
                'tenant_id'   => $this->tenantId,
                'block'       => 0,
                'position_id' => $this->positionId,
            ])
            ->orderBy(['sort' => SORT_ASC, 'name' => SORT_ASC])
            ->joinWith([
                'tariffHasCity' => function (ActiveQuery $query) {
                    $query->andFilterWhere(['city_id' => $this->cityId]);
                },
            ])
            ->asArray()
            ->all();
    }

    /**
     * @return array
     */
    public function getList()
    {
        return ArrayHelper::getColumn($this->getRawData(), function ($item) {
            return [
                'id'   => $item['tariff_id'],
                'name' => isset($item['name']) ? $item['name'] : t('taxi_tariff', 'No name'),
            ];
        });
    }
}