<?php


namespace app\modules\v1\models\street;


use app\components\Autocomplete;
use yii\base\Object;

class Street extends Object
{
    public $search;
    public $city_id;
    public $lat;
    public $lon;
    public $action;
    public $lang;
    public $tenant_id;

    /**
     * Preparing autocomplete data for jquery plugin
     * @param array $dirtyData Autocomplete data
     * @return array
     */
    private function prepareData(array $dirtyData)
    {
        $preparedData = [];

        foreach ($dirtyData as $key => $item) {
            $preparedData[$key] = $item;
            if (!empty($item['address']['city'])) {
                if (isset($item['address']['label']) && !empty($item['address']['label'])) {
                    $preparedData[$key]['label'] = $item['address']['city'] . ', ' . $item['address']['label'];
                } else {
                    $preparedData[$key]['label'] = $item['address']['city'];
                }
            } else {
                $preparedData[$key]['label'] = $item['address']['label'];
            }

            $preparedData[$key]['value'] = $item['address']['label'];
        }

        return $preparedData;
    }

    /**
     * @return array
     */
    public function getList()
    {
        /** @var Autocomplete $autocomlete */
        $autocomlete = app()->autocomplete;
        $autocomlete->action = $this->action;
        $lang = $this->getListLanguage();
        $result = $autocomlete->getStreetList($this->search, $this->city_id, $this->lat, $this->lon, $this->tenant_id,
            $lang);

        $dirtyResult = $result['results'] ?: [];

        return $this->prepareData($dirtyResult);
    }

    /**
     * @return string
     */
    private function getListLanguage()
    {
        return $this->lang ?: app()->language;
    }
}