<?php


namespace app\modules\v1\models\order\list_format;


use app\modules\v1\models\order\list_format\interfaces\OrderFormatListInterface;
use yii\base\Object;

class MapFormat extends Object implements OrderFormatListInterface
{
    /**
     * @param array $data
     * @return array
     */
    public function getFormatList($data)
    {
        $arResult['markers'] = [];
        $arResult['type'] = 'order';

        foreach ($data as $order) {
            //Фильтруем данные
            if (!$this->isValid($order)) {
                continue;
            }

            $arResult['markers'][] = $this->getFormatOne($order);
        }

        return $arResult;
    }

    /**
     * @param array $order
     * @return array
     */
    public function getFormatOne($order)
    {
        $order['address'] = unserialize($order['address']);
        $marker_key_name = 'order_' . $order['order_id'];

        return [
            'key_name'    => $marker_key_name,
            'coords'      => [
                'lat' => $order['address']['A']['lat'],
                'lon' => $order['address']['A']['lon'],
            ],
            'marker_info' => [
                'client_id'   => $order['client_id'],
                'client_name' => trim($order['client']['last_name'] . ' ' . $order['client']['name']),
                'phone'       => $order['phone'],
                'device'      => $order['device'],
            ],
        ];
    }

    /**
     * @param array $order
     * @return bool
     */
    private function isValid($order)
    {
        $address = unserialize($order['address']);

        return !empty($address['A']['lat']) && !empty($address['A']['lon']);
    }
}