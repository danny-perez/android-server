<?php


namespace app\modules\v1\models\order\list_format\interfaces;


interface OrderFormatListInterface
{
    /**
     * @param array $data
     * @return array
     */
    public function getFormatList($data);

    /**
     * @param array $data
     * @return array
     */
    public function getFormatOne($data);
}