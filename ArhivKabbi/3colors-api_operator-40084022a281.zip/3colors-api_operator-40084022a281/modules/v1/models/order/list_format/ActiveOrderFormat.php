<?php


namespace app\modules\v1\models\order\list_format;


use app\components\Formatter;
use app\modules\v1\models\client\ClientAccount;
use app\modules\v1\models\order\list_format\interfaces\OrderFormatListInterface;
use app\modules\v1\models\order\Order;
use app\modules\v1\models\order\OrderTimer;
use app\modules\v1\models\worker\CarColorTrait;
use Yii;
use yii\base\Object;
use yii\helpers\ArrayHelper;

class ActiveOrderFormat extends Object implements OrderFormatListInterface
{
    use CarColorTrait;

    /**
     * @param array $data
     * @return array
     */
    public function getFormatList($data)
    {
        return ArrayHelper::getColumn($data, function ($item) {
            return [
                'order_id'     => $item['order_id'],
                'order_number' => $item['order_number'],
                'order_time'   => $item['order_time'],
                'status_time'  => $item['status_time'] + $item['time_offset'],
                'timer_data'   => $this->getTimerData($item),
                'status'       => [
                    'status_id' => $item['status']['status_id'],
                    'name'      => t('status_event', $item['status']['name']),
                ],
                'client'       => array_merge($item['client'], ['phone' => $item['phone']]),
                'worker'       => $this->getWorkerData($item),
                'address'      => unserialize($item['address']),
                'device'       => $item['device'],
            ];
        });
    }

    /**
     * @param array $data
     * @return array
     */
    public function getFormatOne($data)
    {
        return [
            'order_id'     => $data['order_id'],
            'order_number' => $data['order_number'],
            'order_time'   => $data['order_time'],
            'status_time'  => $data['status_time'] + $data['time_offset'],
            'status'       => [
                'status_id' => $data['status']['status_id'],
                'name'      => t('status_event', $data['status']['name']),
            ],
            'currency'     => $data['currency']['symbol'],
            'device'       => $data['device'],
            'client'       => [
                'client_id'  => $data['client_id'],
                'name'       => trim($data['client']['last_name'] . ' ' . mb_substr($data['client']['name'], 0, 1,
                        "UTF-8") . '.'),
                'phone'      => $data['phone'],
                'photo'      => $data['client']['photo'] ? Yii::$app->params['photoAction'] . $data['client']['photo'] : '',
                'black_list' => $data['client']['black_list'],
                'orders'     => [
                    'success'  => $data['client']['success_order'],
                    'canceled' => [
                        'client'     => $data['client']['fail_client_order'],
                        'worker'     => $data['client']['fail_worker_order'],
                        'dispatcher' => $data['client']['fail_dispatcher_order'],
                    ],
                ],
                'balance'    => $this->getClientAccountData($data['city_id'], $data['tenant_id'], $data['client_id']),
            ],
            'worker'       => $this->getWorkerData($data),
            'address'      => unserialize($data['address']),
            'tariff_id'    => $data['tariff_id'],
            'options'      => $this->getFormatOptions($data['options'] ?: []),
            'payment'      => [
                'type'           => $data['payment'],
                'bonus'          => $data['bonus_payment'],
                'precomputation' => [
                    'price'    => $data['predv_price'],
                    'distance' => $data['predv_distance'],
                    'time'     => $data['predv_time'],
                ],
            ],
        ];
    }

    /**
     * @param array $data
     * @return array|null
     */
    private function getTimerData(array $data)
    {
        return (new OrderTimer([
            'cityId'       => $data['city_id'],
            'tenantId'     => $data['tenant_id'],
            'status_id'    => $data['status_id'],
            'timeOffset'   => $data['time_offset'],
            'timeToClient' => $data['time_to_client'],
            'costData'     => isset($data['costData']) ? $data['costData'] : null,
            'orderTime'    => $data['order_time'],
            'statusTime'   => $data['status_time'],
        ]))->getTimerData();
    }

    /**
     * @param array $item
     * @return array|null
     */
    private function getWorkerData($item)
    {
        if (!empty($item['worker'])) {
            return [
                'worker_id'   => $item['worker']['worker_id'],
                'name'        => trim($item['worker']['last_name'] . ' ' . mb_substr($item['worker']['name'], 0, 1,
                        "UTF-8") . '.'),
                'car'         => isset($item['car']) ? trim($item['car']['name'] . ', ' . $item['car']['gos_number'] . ', ' .
                    $this->getCarColorTextByName($item['car']['color'])) : null,
                'device_info' => $item['worker']['device_info'],
            ];
        }

        return null;
    }

    /**
     * @param int $cityId
     * @param int $tenantId
     * @param int $clientId
     * @return array
     */
    private function getClientAccountData($cityId, $tenantId, $clientId)
    {
        $clientAccount = new ClientAccount([
            'tenantId' => $tenantId,
            'cityId'   => $cityId,
            'clientId' => $clientId,
        ]);

        $currencySymbol = $clientAccount->getCurrencySymbol();
        /** @var Formatter $formatter */
        $formatter = Yii::$app->formatter;
        $moneyAccount = $clientAccount->getAccount();
        $money = is_object($moneyAccount) ? $moneyAccount->balance : 0;
        $bonusAccount = $clientAccount->getBonusAccount();
        $bonus = is_object($bonusAccount) ? $bonusAccount->balance : 0;

        return [
            'currency' => $currencySymbol,
            'money'    => $formatter->asMoney($money, $currencySymbol),
            'bonus'    => $formatter->asMoney($bonus, $currencySymbol),
        ];
    }

    /**
     * @param array $options
     * @return array
     */
    private function getFormatOptions(array $options)
    {
        return ArrayHelper::getColumn($options, function ($item) {
            return ['id' => $item['option_id'], 'name' => t('car-options', $item['name'])];
        });
    }
}