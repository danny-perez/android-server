<?php


namespace app\modules\v1\models\order;


use app\helpers\DateTimeHelper;
use app\models\TenantSetting;
use yii\base\Object;

class OrderTimer extends Object
{
    public $status_id;
    public $cityId;
    public $tenantId;
    public $timeOffset;
    public $costData;
    public $orderTime = 0;
    public $statusTime = 0;
    private $timeToClient = 0;
    private $pickUp;
    /** @var int Time for countdown. */
    private $timerTime = null;

    /**
     * Get timer data.
     * @return array|null
     * ['minutes' => '00', 'seconds' => '44', 'type' => 'down']
     * ['minutes' => '00', 'seconds' => '44', 'type' => 'up']
     */
    public function getTimerData()
    {
        if (!$this->isNeedCountDown()) {
            return null;
        }

        $timerTime = $this->getTimerTime();
        if (is_null($timerTime)) {
            return null;
        }

        $arTime = [
            'minutes' => '00',
            'seconds' => '00',
            'type'    => 'down',
        ];

        if ($this->status_id == OrderStatus::STATUS_NEW) {
            $arTime['minutes'] = $this->getPickUp() / 60;
        }

        $duration = $timerTime - $this->getOrderTimestamp();
        if ($duration > $arTime['minutes']) {
            $parse_time = DateTimeHelper::parse_seconds($duration);
        } elseif ($duration < 0) {
            $duration = $this->getOrderTimestamp() - $timerTime;
            $parse_time = DateTimeHelper::parse_seconds($duration);
            $arTime['type'] = 'up';
        }

        if (!empty($parse_time)) {
            $arTime['minutes'] = $parse_time['minutes'] + $parse_time['hours'] * 60;
            $arTime['seconds'] = $parse_time['seconds'];
        }

        $arTime['minutes'] = $arTime['minutes'] < 10 ? '0' . $arTime['minutes'] : $arTime['minutes'];

        return $arTime;
    }

    public function setTimeToClient($value)
    {
        $this->timeToClient = $value * 60;
    }

    public function getTimeToClient()
    {
        return $this->timeToClient;
    }

    /**
     * Car pick up time.
     * @return integer Time in seconds.
     */
    private function getPickUp()
    {
        if (empty($this->pickUp)) {
            $this->pickUp = (new TenantSetting([
                'cityId'   => $this->cityId,
                'tenantId' => $this->tenantId,
            ]))->getValue(TenantSetting::ORDER_PICK_UP_SETTING);
        }

        return (int)$this->pickUp;
    }

    /**
     * Getting local time.
     * @param integer $time
     * @return integer
     */
    private function getOrderTimestamp($time = null)
    {
        if (is_null($time)) {
            $time = time();
        }

        return $this->timeOffset + $time;
    }

    /**
     * @return int|null
     */
    private function getTimerTime()
    {
        $this->timerTime = null;

        if (in_array($this->status_id, OrderStatus::getNewStatusId())) {
            $this->timerTime = $this->orderTime;
        } elseif (in_array($this->status_id, OrderStatus::getWorkingStatusId())) {
            $this->timerTime = $this->getOrderTimestamp($this->statusTime);
            if (($this->status_id == OrderStatus::STATUS_GET_WORKER || $this->status_id == OrderStatus::STATUS_EXECUTION_PRE)
                && !empty($this->timeToClient)
            ) {
                $this->timerTime += $this->timeToClient;
            } elseif ($this->status_id == OrderStatus::STATUS_WORKER_WAITING) {
                $this->timerTime += $this->getWorkerWaitingTime();
            }
        }

        return $this->timerTime;
    }

    /**
     * Return waiting time, when worker wait for free.
     * @return integer Time in seconds.
     */
    public function getWorkerWaitingTime()
    {
        $waiting_time = 0;
        $tariffAreaKey = isset($this->costData['start_point_location']) && $this->costData['start_point_location'] == 'in' ?
            'tariffDataCity' : 'tariffDataTrack';
        $tariffWaitingTimeKey = isset($this->costData['tariffInfo']['isDay']) && $this->costData['tariffInfo']['isDay'] ?
            'wait_time_day' : 'wait_time_night';

        if (isset($this->costData['tariffInfo'][$tariffAreaKey][$tariffWaitingTimeKey])) {
            $waiting_time = $this->costData['tariffInfo'][$tariffAreaKey][$tariffWaitingTimeKey];
        }

        return $waiting_time * 60;
    }

    /**
     * @return bool
     */
    private function isNeedCountDown()
    {
        return in_array($this->status_id, OrderStatus::getCountdownStatusList());
    }
}