<?php


namespace app\modules\v1\models\order;


use app\models\ClientReview;
use app\models\order\Order;
use app\models\order\OrderRepository;
use app\modules\v1\models\city\City;
use app\modules\v1\models\worker\Worker;
use Yii;
use yii\base\Object;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use app\modules\v1\models\user\User;
use yii\helpers\Html;

class OrderEvents extends Object
{
    public $orderId;
    public $cityId;

    public function getData()
    {
        //Результирующий массив
        $events = [];
        //Получаем события из БД
        $dbEvents = $this->getEvents();
        //Берем из кеша все статусы, формируем карту
        $arStatus = $this->getStatusMap();
        //Кеш запросов
        $arCache       = [];
        $count         = count($dbEvents);
        $orderFinished = false;
        $ignoreOffer = false;

        for ($i = 0; $i < $count; $i++) {
            $text = '';
            //Доп. информация по логу (Расчет стоимости, Отзыв)
            $info  = [];
            $event = $dbEvents[$i];

            if ($this->isCreateOrderEvent($i, $dbEvents)) {
                if (in_array($event['change_val'], [
                    OrderStatus::STATUS_NEW,
                    OrderStatus::STATUS_FREE,
                    OrderStatus::STATUS_MANUAL_MODE,
                ])) {
                    $text = t('order', 'Order create');
                } elseif ($event['change_val'] == OrderStatus::STATUS_EXECUTING) {
                    $events[] = $this->getEventParams(t('order', 'Order was created from bordur'), $event,
                        $info);
                    $text     = $this->firstCharToUppercase($arStatus[$event['change_val']]);
                }
            } elseif ($this->isChangeOrderEvent($event)) {
                if ($this->isDispatcherChangedEvent($event)) {
                    //Пропускаем служебные поля, которые не должен видеть пользователь
                    if ($event['change_field'] === 'client_id') {
                        continue;
                    }

                    $text = t('order', 'Disputcher {name} edited order. That is: {field}', [
                        'name'  => $this->getUserName($event),
                        'field' => $this->getOrderAttributeLabel($event['change_field']),
                    ]);
                } elseif ($this->isChangedStatusEvent($event)) {
                    $orderFinished = $this->isOrderFinished($event);
                    //Статус завершенного заказа
                    if ($this->isOrderCompleted($event)) {
                        if ($this->isOrderPaid($event)) {
                            $text = t('order', 'Order completed (Paid)');
                        } else {
                            $text = t('order', 'Order completed (Not paid)');
                        }
                        $info = $this->getOrderDetailCost($event['order_id']);
                    } elseif ($this->isDriverStatusChanged($event)) {
                        //Пропускаем водительские статусы, т.к. уже вывели эту инфу вместе с водилой.
                        $ignoreOffer = $event['change_val'] == OrderStatus::STATUS_DRIVER_IGNORE_ORDER_OFFER;
                        continue;
                    } else {
                        $text = $this->firstCharToUppercase($arStatus[$event['change_val']]);
                    }
                }
            } elseif ($this->isWorkerChangedEvent($event)) {
                //Формирование кеша для того чтобы не делать лишние запросы на след. эл. массива лога
                if (empty($arCache['worker'][$event['change_object_id']])) {
                    $arCache['worker'][$event['change_object_id']] = $this->getWorkerName($event);
                }

                //Предложение заказа
                if ($event['change_val'] == 'OFFER_ORDER') {
                    $text = t('order', 'Order offer driver: {name}',
                        ['name' => $arCache['worker'][$event['change_object_id']]]);
                } elseif ($event['change_val'] == 'FREE' && !$orderFinished) {
                    $message = $ignoreOffer
                        ? 'Driver {name} ignored order offer' : 'Driver {name} refused';
                    $text = t('order', $message,
                        ['name' => $arCache['worker'][$event['change_object_id']]]);
                } //Исполнитель заблокирован
                elseif ($event['change_val'] == 'BLOCKED') {
                    $text = t('order', 'Driver {name} blocked',
                        ['name' => $arCache['worker'][$event['change_object_id']]]);
                } //Взял заказ
                elseif ($event['change_val'] == 'ON_ORDER') {
                    //Для получения времени подъезда берем следующий эл. массива
                    $nextAfterElement = $dbEvents[$i + 1];
                    $time             = $nextAfterElement['change_field'] == 'time_to_client' ? $nextAfterElement['change_val'] : 0;

                    $text = t('order', 'Driver {name} took the order, will drive in {time} minutes',
                        ['name' => $arCache['worker'][$event['change_object_id']], 'time' => $time]);

                    //Удаляем элементы, т.к. мы их уже обработали
                    if (($dbEvents[$i + 2]['change_field'] == 'status_id')
                        && ($dbEvents[$i + 2]['change_val'] == OrderStatus::STATUS_GET_WORKER
                            || $dbEvents[$i + 2]['change_val'] == OrderStatus::STATUS_EXECUTION_PRE)
                    ) {
                        unset($dbEvents[$i + 2]);
                    }

                    if ($dbEvents[$i + 1]['change_field'] == 'time_to_client') {
                        unset($dbEvents[$i + 1]);
                    }
                    // worker accepted an pre-order
                } elseif ($event['change_val'] == 'ACCEPT_PREORDER') {
                    $text = t('order', 'Driver {name} accepted an pre-order', [
                        'name' => $arCache['worker'][$event['change_object_id']],
                    ]);
                    if ($dbEvents[$i + 1]['change_field'] == 'status_id'
                        && $dbEvents[$i + 1]['change_val'] == OrderStatus::STATUS_PRE_GET_WORKER
                    ) {
                        unset($dbEvents[$i + 1]);
                    }
                    // worker refused an pre-order
                } elseif ($event['change_val'] == 'REFUSE_PREORDER') {
                    $text = t('order', 'Driver {name} refused an pre-order', [
                        'name' => $arCache['worker'][$event['change_object_id']],
                    ]);
                    if ($dbEvents[$i + 1]['change_field'] == 'status_id'
                        && $dbEvents[$i + 1]['change_val'] == OrderStatus::STATUS_PRE_REFUSE_WORKER
                    ) {
                        unset($dbEvents[$i + 1]);
                    }
                }
            } elseif ($this->isOrderHasReview($event)) {
                $clientReview = $this->getClientReview($event);
                $text         = t('order', 'Client {name} add a review about the trip:', [
                    'name' => $this->getClientName($clientReview),
                ]);
                $info         = [
                    'review' => $clientReview->text,
                    'rating' => $clientReview->rating,
                ];
            }

            if (!empty($text)) {
                $events[] = $this->getEventParams(t('status_event', $text), $event, $info);
            }
        }

        return $events;
    }

    /**
     * @return array
     */
    private function getEvents()
    {
        return (new OrderRepository())->getEvents($this->orderId);
    }

    /**
     * @return mixed
     */
    private function getStatusMap()
    {
        return ArrayHelper::map(OrderStatus::getStatusData(), 'status_id', 'name');
    }

    /**
     * @return int
     */
    private function getCityOffset()
    {
        return (new City(['cityId' => $this->cityId]))->getTimeOffset();
    }

    /**
     * The first character of the translation function to uppercase
     *
     * @param string $str
     *
     * @return string
     */
    private function firstCharToUppercase($str)
    {
        $fc = mb_strtoupper(mb_substr($str, 0, 1));

        return $fc . mb_substr($str, 1);
    }

    /**
     * @param int   $index Item index of array
     * @param array $events
     *
     * @return bool
     */
    private function isCreateOrderEvent($index, $events)
    {
        return $index == 0 && $events[$index]['change_object_type'] == 'order' && $events[$index]['change_field'] == 'status_id';
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isChangeOrderEvent($event)
    {
        return $event['change_object_type'] == 'order';
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isChangedStatusEvent($event)
    {
        return $event['change_field'] == 'status_id';
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isDispatcherChangedEvent($event)
    {
        return strpos($event['change_subject'], 'disputcher') !== false;
    }

    /**
     * @param array $event
     *
     * @return int
     */
    private function getUserId($event)
    {
        $arUserPieces = explode('_', $event['change_subject']);

        return end($arUserPieces);
    }

    /**
     * @param array $event
     *
     * @return string
     */
    private function getTimeFormat($event)
    {
        $cityOffset = $this->getCityOffset();

        return implode(" ", [
            Yii::$app->formatter->asDate($cityOffset + $event['change_time'], 'shortDate'),
            t('order', 'on'),
            Yii::$app->formatter->asTime($cityOffset + $event['change_time'], 'short'),
        ]);
    }

    private function getEventParams($text, $event, $info)
    {
        return [
            'text'         => $text,
            'time'         => $this->getTimeFormat($event),
            'type'         => $event['change_object_type'],
            'change_field' => $event['change_field'],
            'info'         => $info,
        ];
    }

    /**
     * @param array $event
     *
     * @return string
     */
    private function getUserName($event)
    {
        $user_id = $this->getUserId($event);
        /** @var User $user */
        $user = User::find()->where(['user_id' => $user_id])->select(['last_name', 'name'])->one();

        if (empty($user)) {
            return '';
        }

        $name = Html::encode($user->getUserName());

        return Html::a($name, ['/tenant/user/update', 'id' => $user_id,]);
    }

    /**
     * @param string $attribute
     *
     * @return string
     */
    private function getOrderAttributeLabel($attribute)
    {
        return (new Order())->getAttributeLabel($attribute);
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isOrderFinished($event)
    {
        return in_array($event['change_val'], OrderStatus::getFinishedStatusId())
        || $event['change_val'] == OrderStatus::STATUS_EXECUTING;
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isOrderCompleted($event)
    {
        return in_array($event['change_val'], OrderStatus::getCompletedStatusId());
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isOrderPaid($event)
    {
        return $event['change_val'] == OrderStatus::STATUS_COMPLETED_PAID;
    }

    /**
     * @param int $orderId
     *
     * @return mixed
     */
    private function getOrderDetailCost($orderId)
    {
        return (new OrderRepository())->getDetailCost($orderId);
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isDriverStatusChanged($event)
    {
        return in_array($event['change_val'], [
            OrderStatus::STATUS_OFFER_ORDER,
            OrderStatus::STATUS_WORKER_REFUSED,
            OrderStatus::STATUS_DRIVER_IGNORE_ORDER_OFFER,
        ]);
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isWorkerChangedEvent($event)
    {
        return $event['change_object_type'] == 'worker';
    }

    /**
     * @param array $event
     *
     * @return bool
     */
    private function isOrderHasReview($event)
    {
        return $event['change_object_type'] == 'review';
    }

    /**
     * @param int   $callsign
     * @param int   $tenantId
     * @param array $select
     *
     * @return \app\models\Worker
     */
    private function getWorkerByCallsign($callsign, $tenantId, $select)
    {
        return (new Worker())->getByCallsign($callsign, $tenantId, $select);
    }

    /**
     * @param array $event
     *
     * @return string
     */
    private function getWorkerName($event)
    {
        $worker = $this->getWorkerByCallsign($event['change_object_id'],
            $event['tenant_id'], ['worker_id', 'last_name', 'name']);

        $name = Html::encode($worker->getFullName());

        return Html::a($name, ['/employee/worker/update', 'id' => $worker['worker_id']]);
    }

    /**
     * @param ClientReview $review
     *
     * @return string
     */
    private function getClientName(ClientReview $review)
    {
        $name = Html::encode($review->client->getFullName());

        return Html::a($name, ['/client/base/update', 'id' => $review->client->client_id]);
    }

    /**
     * @param array $event
     *
     * @return ClientReview|null|ActiveRecord
     */
    private function getClientReview($event)
    {
        return ClientReview::find()
            ->with([
                'client' => function (ActiveQuery $query) {
                    $query->select(['client_id', 'last_name', 'name']);
                },
            ])
            ->where(['review_id' => $event['change_object_id']])
            ->one();
    }
}