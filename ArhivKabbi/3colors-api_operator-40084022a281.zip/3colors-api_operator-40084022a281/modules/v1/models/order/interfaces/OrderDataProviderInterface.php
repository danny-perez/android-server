<?php


namespace app\modules\v1\models\order\interfaces;


interface OrderDataProviderInterface
{
    /**
     * @return array
     */
    public function getList();

    /**
     * @param int $orderId
     * @return array
     */
    public function getOne($orderId);

    /**
     * @return int|array
     */
    public function getCounts();
}