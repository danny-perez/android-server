<?php


namespace app\modules\v1\models\order;


use app\models\order\ActiveOrderRepository;

class ActiveOrder
{
    public $tenantId;

    /**
     * Getting active order by phone.
     * @param string $phone Caller phone.
     * @return array
     */
    public function getOrdersIdByPhone($phone)
    {
        $db_orders = $this->getAll();
        $orders = [];

        foreach ($db_orders as $order) {
            $order = unserialize($order);

            if ($order['phone'] == $phone || $order['worker']['phone'] == $phone) {
                $orders[] = $order['order_id'];
                //Водила звонит, у него может быть только один активный заказ.
                if ($order['worker']['phone'] == $phone) {
                    break;
                }
            }
        }

        return $orders;
    }

    private function getAll()
    {
        return (new ActiveOrderRepository(['tenantId' => $this->tenantId]))->getAll();
    }
}