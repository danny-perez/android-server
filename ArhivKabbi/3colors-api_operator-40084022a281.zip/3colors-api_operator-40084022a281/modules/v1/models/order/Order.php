<?php


namespace app\modules\v1\models\order;

use app\models\order\OrderRepository;
use app\modules\v1\models\order\interfaces\OrderDataProviderInterface;
use app\modules\v1\models\order\list_format\interfaces\OrderFormatListInterface;
use Yii;
use yii\base\NotSupportedException;
use yii\base\Object;
use yii\helpers\ArrayHelper;

class Order extends Object implements OrderDataProviderInterface
{
    public $tenantId;
    public $positionId;
    public $cityId;
    public $statusGroup;
    public $allowCityId;
    public $date;
    /** @var string|array|callable */
    public $formatter = 'app\modules\v1\models\order\list_format\ActiveOrderFormat';

    /**
     * @return array
     * @throws NotSupportedException
     */
    public function getList()
    {
        $data = $this->getRawDataList();

        if (isset($data['message'])) {
            throw new NotSupportedException($data['message']);
        }

        return $this->getFormatter()->getFormatList($data);
    }

    /**
     * @param int $orderId
     *
     * @return array|null
     */
    public function getOne($orderId)
    {
        $data = (new OrderRepository())->getOne($orderId);

        if (!$data) {
            return null;
        }

        return $this->getFormatter()->getFormatOne($data);
    }

    /**
     * @param $orderId
     *
     * @return array
     */
    public function getViewData($orderId)
    {
        $orderData = $this->getOne($orderId);

        if (!$orderData) {
            return null;
        }

        return ArrayHelper::merge($orderData, [
            'fieldList' => $this->getUpdateFieldList($orderId),
        ]);
    }

    /**
     * @param $orderId
     *
     * @return array
     */
    public function getUpdateFieldList($orderId)
    {
        return (new OrderRepository())->getUpdateFieldList($orderId);
    }

    /**
     * @param int $orderNumber
     *
     * @return array|null
     */
    public function getOneByNumber($orderNumber)
    {
        $data = (new OrderRepository(['tenantId' => $this->tenantId]))->getOneByNumber($orderNumber);

        return $this->getFormatter()->getFormatOne($data);
    }

    /**
     * @return array
     */
    public function getCounts()
    {
        return (new OrderRepository([
            'tenantId'   => $this->tenantId,
            'cityId'     => $this->cityId,
            'positionId' => $this->positionId,
            'date'       => $this->date,
        ]))->getCounts();
    }

    /**
     * Getting raw data from order service
     * @return array
     */
    protected function getRawDataList()
    {
        return (new OrderRepository([
            'cityId'      => $this->cityId,
            'tenantId'    => $this->tenantId,
            'positionId'  => $this->positionId,
            'statusGroup' => $this->statusGroup,
            'date'        => $this->date,
            'allowCityId' => $this->allowCityId,
        ]))->getList();
    }

    /**
     * @return OrderFormatListInterface
     */
    protected function getFormatter()
    {
        return Yii::createObject($this->formatter);
    }

    /**
     * @param array $data Post data
     *
     * @return array
     */
    public function create($data)
    {
        $data['tenant_id']    = $this->tenantId;
        $data['user_create']  = user()->user_id;
        $data['user_modifed'] = user()->user_id;

        return (new OrderRepository())->create($data);
    }

    /**
     * Getting order track
     *
     * @param int $orderId
     *
     * @return array
     */
    public function getTracking($orderId)
    {
        return (new OrderRepository())->getTracking($orderId);
    }
}