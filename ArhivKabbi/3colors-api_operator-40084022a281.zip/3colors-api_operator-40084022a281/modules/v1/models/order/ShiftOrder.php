<?php


namespace app\modules\v1\models\order;


use app\models\order\Order;
use yii\db\ActiveQuery;

class ShiftOrder
{
    /**
     * Getting orders by shift period
     * @param integer $workerId
     * @param integer $firstTime
     * @param integer $lastTime
     * @param array|int $positionId
     * @return array
     */
    public function getOrders($workerId, $firstTime, $lastTime, $positionId)
    {
        return Order::find()
            ->where(['between', 'status_time', $firstTime, $lastTime])
            ->andWhere([
                'status_id'   => [OrderStatus::STATUS_COMPLETED_PAID, OrderStatus::STATUS_REJECTED],
                'worker_id'   => $workerId,
                'position_id' => $positionId,
            ])
            ->with([
                'detailCost' => function (ActiveQuery $query) {
                    $query->select(['order_id', 'summary_cost']);
                },
                'currency'   => function (ActiveQuery $query) {
                    $query->select(['currency_id', 'symbol']);
                },
            ])
            ->select(['order_id', 'status_id', 'worker_id', 'status_time', 'currency_id'])
            ->all();
    }
}