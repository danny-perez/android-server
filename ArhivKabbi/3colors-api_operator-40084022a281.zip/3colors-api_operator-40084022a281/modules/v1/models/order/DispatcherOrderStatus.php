<?php


namespace app\modules\v1\models\order;

use app\models\order\OrderStatus as OrderStatusRecord;

class DispatcherOrderStatus
{
    public $statusId;
    
    public function getStatusList()
    {
        return OrderStatusRecord::find()
            ->where(['status_id' => $this->getStatuses()])
            ->orderBy(['status_id' => SORT_DESC])
            ->asArray()
            ->indexBy('status_id')
            ->all();
    }

    /**
     * Getting status set by status_id
     * @return array
     */
    public function getStatuses()
    {
        switch ($this->statusId) {
            case 1;
                $arStatus = [1, 4];
                break;
            case 2;
                $arStatus = [2, 4];
                break;
            case 4;
                $arStatus = [1, 4];
                break;
            case 7:
                $arStatus = [OrderStatus::STATUS_PRE, OrderStatus::STATUS_PRE_GET_WORKER];
                break;
            case 52;
                $arStatus = [1, 4, 52];
                break;
            case OrderStatus::STATUS_GET_WORKER;
                $arStatus = [1, 4, OrderStatus::STATUS_GET_WORKER];
                break;
            case OrderStatus::STATUS_WORKER_WAITING;
                $arStatus = [1, 4, OrderStatus::STATUS_WORKER_WAITING];
                break;
            case OrderStatus::STATUS_CLIENT_IS_NOT_COMING_OUT;
                $arStatus = [1, 4, OrderStatus::STATUS_CLIENT_IS_NOT_COMING_OUT];
                break;
            case OrderStatus::STATUS_FREE_AWAITING;
                $arStatus = [1, 4, OrderStatus::STATUS_FREE_AWAITING];
                break;
            case OrderStatus::STATUS_NONE_FREE_AWAITING;
                $arStatus = [1, 4, OrderStatus::STATUS_NONE_FREE_AWAITING];
                break;
            case 36;
                $arStatus = [1, 4, 36];
                break;
            case OrderStatus::STATUS_WORKER_LATE;
                $arStatus = [1, 4, OrderStatus::STATUS_WORKER_LATE];
                break;
            case OrderStatus::STATUS_EXECUTION_PRE;
                $arStatus = [1, OrderStatus::STATUS_EXECUTION_PRE];
                break;
            default :
                $arStatus = [$this->statusId];
        }

        return $this->statusId != 37 && $this->statusId != 38 ? array_unique(array_merge($arStatus,
            OrderStatus::getRejectedStatusId())) : $arStatus;
    }
}