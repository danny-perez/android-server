<?php


namespace app\modules\v1\models\order;


use app\models\order\OrderEventRepository;
use Ramsey\Uuid\Uuid;
use Yii;
use yii\base\Object;
use yii\helpers\Json;

class OrderUpdateEvent extends Object
{
    const COMMAND_UPDATE_ORDER_DATA = 'update_order_data';
    const COMMAND_STOP_OFFER = 'stop_offer';

    public $tenantId;
    public $orderId;
    public $senderId;
    public $lastUpdateTime;
    public $command;
    public $lang;

    private $_uuid;
    private $_repository;

    public function init()
    {
        parent::init();
        $this->setRepository();
    }

    /**
     * Add order event for update.
     *
     * @param array $data
     *
     * @return string
     */
    public function addEvent(array $data)
    {
        $this->setUuid();
        //        $this->addRequest();
        $this->addEventToQueue($data);

        return $this->getUuid();
    }

    /**
     * @return string
     */
    public function getUuid()
    {
        return $this->_uuid;
    }

    /**
     * Getting response of executing order event
     *
     * @param string $key
     *
     * @return mixed
     */
    public function getResponse($key)
    {
        return $this->getRepository()->get($key);
    }

    public function removeResponse($key)
    {
        return $this->getRepository()->delete($key);
    }

    /**
     * Add event to rabbit queue
     *
     * @param array $data
     *
     * @return mixed
     */
    private function addEventToQueue(array $data)
    {
        $data = $this->prepareData($data);

        return Yii::$app->amqp->send($data, 'order_' . $this->orderId);
    }

    /**
     * @return string
     */
    private function generateUuid()
    {
        $uuid4 = Uuid::uuid4();

        return $uuid4->toString();
    }

    private function setUuid()
    {
        $this->_uuid = $this->generateUuid();
    }

    /**
     * @param array $data
     *
     * @return array
     */
    private function prepareData(array $data)
    {
        return [
            'uuid'             => $this->getUuid(),
            'type'             => 'order_event',
            'timestamp'        => time(),
            'sender_service'   => 'operator_service',
            'command'          => $this->command,
            'order_id'         => $this->orderId,
            'tenant_id'        => $this->tenantId,
            'change_sender_id' => $this->senderId,
            'last_update_time' => $this->lastUpdateTime,
            'lang'             => $this->lang,
            'params'           => $data,
        ];
    }

    /**
     * @return bool
     */
    private function addRequest()
    {
        return $this->getRepository()->set($this->getUuid(), $this->getRequestParams());
    }

    private function getRequestParams()
    {
        $requestParams = [
            'uuid'   => $this->getUuid(),
            'code'   => 0,
            'info'   => 'OK',
            'result' => 0,
        ];

        return Json::encode($requestParams);
    }

    /**
     * @return OrderEventRepository
     */
    private function getRepository()
    {
        if (empty($this->_repository)) {
            $this->setRepository();
        }

        return $this->_repository;
    }

    private function setRepository()
    {
        $this->_repository = new OrderEventRepository();
    }
}