<?php

namespace app\modules\v1\models\car;

use yii\base\Object;
use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use app\models\CarColor as CarColorRecord;

class CarColor extends Object
{
    public $color_id;
    public $name;

    /**
     * For getting car color map
     * @return array [color_id => name]
     */
    public function getColorMap()
    {
        return ArrayHelper::map($this->getList(), 'color_id', 'name');
    }

    /**
     * @return array|ActiveRecord[] the query results. If the query results in nothing, an empty array will be returned.
     */
    public function getList()
    {
        return CarColorRecord::find()->all();
    }

    /**
     * @return string
     */
    public function getTextById()
    {
        $colorMap = $this->getColorMap();

        return $colorMap[$this->color_id] ? t('car', $colorMap[$this->color_id]) : '';
    }

    public function getTextByName()
    {
        return $this->name ? t('car', $this->name) : '';
    }
}