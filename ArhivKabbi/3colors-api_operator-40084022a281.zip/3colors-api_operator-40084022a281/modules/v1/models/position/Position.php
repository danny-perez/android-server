<?php


namespace app\modules\v1\models\position;


use yii\base\Object;
use yii\helpers\ArrayHelper;
use app\models\Position as PositionRecord;

class Position extends Object
{
    /**
     * @return false|array
     */
    public function getList()
    {
        return PositionRecord::find()->asArray()->all();
    }

    /**
     * @return array
     */
    public function getRootPositionList()
    {
        $positionList = $this->getList();
        $rootPositionList = array_filter($positionList, function ($element) {
            return !$element['parent_id'];
        });

        return ArrayHelper::getColumn($rootPositionList, function ($item) {
            return [
                'position_id' => $item['position_id'],
                'name'        => $item['name'],
            ];
        });
    }
}