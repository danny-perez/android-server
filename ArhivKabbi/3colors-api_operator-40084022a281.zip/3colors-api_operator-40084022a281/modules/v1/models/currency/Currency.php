<?php


namespace app\modules\v1\models\currency;


use yii\base\Object;
use yii\caching\TagDependency;
use app\models\Currency as CurrencyRecord;

class Currency extends Object
{
    public $currencyId;

    /**
     * @return string
     */
    public function getCurrencySymbol()
    {
        return app()->db->cache(function ($db) {
            return CurrencyRecord::find()
                ->select('symbol')
                ->where(['currency_id' => $this->currencyId])
                ->scalar();
        }, 2 * 60 * 60, new TagDependency(['tags' => 'currency']));
    }

    /**
     * @return string
     */
    public function getMinorUnit()
    {
        return app()->db->cache(function ($db) {
            return CurrencyRecord::find()
                ->select('minor_unit')
                ->where(['currency_id' => $this->currencyId])
                ->scalar();
        }, 2 * 60 * 60, new TagDependency(['tags' => 'currency']));
    }
}