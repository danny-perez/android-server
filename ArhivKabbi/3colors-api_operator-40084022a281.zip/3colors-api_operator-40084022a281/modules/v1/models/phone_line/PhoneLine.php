<?php


namespace app\modules\v1\models\phone_line;


use yii\base\Object;
use app\models\PhoneLine as PhoneLineRecord;

class PhoneLine extends Object
{
    public $tenantId;
    public $phone;
    private $_phoneLine;

    /**
     * @return null|PhoneLineRecord
     */
    public function getLine()
    {
        if (empty($this->_phoneLine)) {
            $this->_phoneLine = PhoneLineRecord::findOne(['tenant_id' => $this->tenantId, 'phone' => $this->phone]);
        }

        return $this->_phoneLine;
    }

    /**
     * @return null|int
     */
    public function getCityId()
    {
        return is_object($this->_phoneLine) ? $this->_phoneLine->city_id : null;
    }

    /**
     * @return null|int
     */
    public function getTariffId()
    {
        return is_object($this->_phoneLine) ? $this->_phoneLine->tariff_id : null;
    }
}