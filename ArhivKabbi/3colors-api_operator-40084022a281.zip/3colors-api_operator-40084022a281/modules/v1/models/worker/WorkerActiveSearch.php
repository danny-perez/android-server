<?php


namespace app\modules\v1\models\worker;


use app\models\Worker;
use yii\base\Object;
use yii\db\ActiveQuery;

class WorkerActiveSearch extends Object
{
    use ActiveTrait, FreeTrait, CarColorTrait;

    public $search;
    public $cityId;
    public $positionId;
    public $allowCityId;
    public $tenantId;

    /**
     * @return array
     */
    public function getData()
    {
        $cabs = $this->getAllActiveWorkers();
        $arResult = [];

        foreach ($cabs as $cab) {
            $cab = unserialize($cab);

            if (!$this->isFree($cab, false)) {
                continue;
            }

            if ($this->isCabValid($cab)) {
                $arResult[] = [
                    'worker_id' => $cab['worker']['worker_id'],
                    'photo'     => $cab['worker']['photo_url'],
                    'name'      => $this->getShortName($cab['worker']['last_name'], $cab['worker']['name']),
                    'car'       => $this->getCarName($cab['car']['name'], $cab['car']['gos_number'],
                        $cab['car']['color']),
                    'rating'    => $cab['car']['raiting'],
                    'balance'   => $this->getBalance($cab['worker']['worker_id']),
                ];
            }
        }

        return $arResult;
    }

    /**
     * @param array $cab
     * @return bool
     */
    private function isCabValid(array $cab)
    {
        return mb_stripos($cab['worker']['last_name'], $this->search) !== false ||
        mb_stripos($cab['worker']['name'], $this->search) !== false ||
        mb_stripos($cab['worker']['second_name'], $this->search) !== false ||
        stripos($cab['worker']['callsign'], $this->search) !== false ||
        stripos($cab['car']['name'], $this->search) !== false ||
        stripos($cab['car']['gos_number'], $this->search) !== false;
    }

    /**
     * @param string $carName
     * @param string $carNumber
     * @param string $carColor
     * @return string
     */
    private function getCarName($carName, $carNumber, $carColor)
    {
        return trim($carName . ', ' . $carNumber . ', ' . $this->getCarColorTextByName($carColor));
    }

    /**
     * @param string $last_name
     * @param string $name
     * @param null|string $second_name
     * @return string
     */
    private function getShortName($last_name, $name, $second_name = null)
    {
        return trim($last_name . ' ' . $name . ' ' . $second_name);
    }

    /**
     * @param int $workerId
     * @return string
     */
    private function getBalance($workerId)
    {
        $worker = $this->getWorker($workerId);

        return (new WorkerBalance($worker))->getBalanse();
    }

    /**
     * @param int $workerId
     * @return array|null|Worker
     */
    private function getWorker($workerId)
    {
        return Worker::find()
            ->where(['worker_id' => $workerId, 'tenant_id' => $this->tenantId])
            ->select(['worker_id', 'tenant_id'])
            ->with([
                'accounts' => function (ActiveQuery $query) {
                    $query->select(['tenant_id', 'owner_id', 'balance', 'currency_id']);
                },
            ])
            ->one();
    }
}