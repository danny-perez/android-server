<?php


namespace app\modules\v1\models\worker;


use app\modules\v1\models\car\CarColor;
use yii\base\Object;

abstract class WorkerBase extends Object
{
    public $tenantId;
    public $positionId;
    public $cityId;
    public $allowCityId;

    abstract public function getList();
    abstract public function getCount();
}