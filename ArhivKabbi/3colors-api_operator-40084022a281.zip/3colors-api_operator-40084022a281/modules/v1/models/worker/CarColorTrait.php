<?php


namespace app\modules\v1\models\worker;

use app\modules\v1\models\car\CarColor;

trait CarColorTrait
{
    /** @var  CarColor */
    public $carColor;

    /**
     * @param int $colorId
     * @return string
     */
    public function getCarColorTextById($colorId)
    {
        $carColor = $this->getCarColor();
        $carColor->color_id = $colorId;

        return $carColor->getTextById();
    }

    /**
     * @param string $colorName
     * @return string
     */
    public function getCarColorTextByName($colorName)
    {
        $carColor = $this->getCarColor();
        $carColor->name = $colorName;

        return $carColor->getTextByName();
    }

    /**
     * @return CarColor
     */
    private function getCarColor()
    {
        if (empty($this->carColor)) {
            $this->carColor = new CarColor();
        }

        return $this->carColor;
    }
}