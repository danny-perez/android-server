<?php


namespace app\modules\v1\models\worker\interfaces;


interface ShiftInteraface
{
    /**
     * @return int Seconds
     */
    public function getDuration();

    /**
     * @return int Seconds
     */
    public function getPauseDuration();

    /**
     * @return array
     */
    public function getOrdersCountData();
}