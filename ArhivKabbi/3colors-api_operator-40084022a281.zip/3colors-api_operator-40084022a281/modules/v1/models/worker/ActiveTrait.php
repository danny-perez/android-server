<?php


namespace app\modules\v1\models\worker;

use Yii;

trait ActiveTrait
{
    /**
     * @return array
     */
    public function getAllActiveWorkers()
    {
        return Yii::$app->redis_workers->executeCommand('hvals', [$this->tenantId]);
    }
}