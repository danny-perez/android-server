<?php


namespace app\modules\v1\models\worker;


use app\modules\v1\models\order\OrderStatus;
use app\models\WorkerShift as WorkerShiftRecord;
use app\modules\v1\models\order\ShiftOrder;
use app\modules\v1\models\worker\interfaces\ShiftInteraface;

class WorkerShift implements ShiftInteraface
{
    private $_shift;

    public function __construct(WorkerShiftRecord $shift)
    {
        $this->_shift = $shift;
    }

    /**
     * @return int
     */
    public function getDuration()
    {
        $endTime = $this->_shift->end_work ?: time();

        return $endTime - $this->_shift->start_work;
    }

    /**
     * @return int
     */
    public function getPauseDuration()
    {
        $pauseDuration = 0;

        if (!empty($this->_shift->pause_data) && is_array($this->_shift->pause_data)) {
            $cnt = count($this->_shift->pause_data) - 1;
            for ($i = $cnt; $i >= 0; $i--) {
                $pauseEnd = $this->_shift->pause_data[$i]['pause_end'];
                if (empty($pauseEnd)) {
                    if ($i !== $cnt) {
                        continue;
                    }
                    $pauseEnd = time();
                }

                $pauseDuration += $pauseEnd - $this->_shift->pause_data[$i]['pause_start'];
            }
        }

        return $pauseDuration;
    }

    /**
     * @return array
     */
    public function getOrdersCountData()
    {
        $orders = (new ShiftOrder())->getOrders($this->_shift->worker_id, $this->_shift->start_work, time(),
            $this->_shift->position_id);

        $arResult = [
            'completed' => 0,
            'rejected'  => 0,
            'sum'       => 0,
        ];

        if (is_array($orders)) {

            foreach ($orders as $key => $order) {
                if ($order->status_id == OrderStatus::STATUS_COMPLETED_PAID) {
                    $arResult['completed']++;
                    if (!is_array($arResult['sum'])) {
                        $arResult['sum'] = [];
                    }

                    if (!isset($arResult['sum'][$order['currency_id']])) {
                        $arResult['sum'][$order['currency_id']] = ['value' => null, 'currency' => null];
                    }

                    $arResult['sum'][$order['currency_id']]['value'] += $order['detailCost']['summary_cost'];
                    $arResult['sum'][$order['currency_id']]['currency'] = $order['currency']['symbol'];
                } else {
                    $arResult['rejected']++;
                }
            }
        }

        return $arResult;
    }
}