<?php


namespace app\modules\v1\models\worker;

use Yii;
use yii\helpers\ArrayHelper;

class ActiveWorkers extends WorkerBase
{
    const BUSY_TYPE = 'WorkerBusy';
    const FREE_TYPE = 'WorkerFree';

    /** @var array Object repository */
    public $activeObjects = [];

    /**
     * @return array
     */
    public function getList()
    {
        $freeWorkers = $this->getByType(self::FREE_TYPE)->getList();
        $freeIds = $freeWorkers['markers'] ? ArrayHelper::getColumn($freeWorkers['markers'],
            'marker_info.worker_id') : [];

        $busyWorkers = $this->getByType(self::BUSY_TYPE)->getList();
        $busyIds = $busyWorkers['markers'] ? ArrayHelper::getColumn($busyWorkers['markers'],
            'marker_info.worker_id') : [];

        return ArrayHelper::merge($freeIds, $busyIds);
    }

    /**
     * @return int
     */
    public function getCount()
    {
        return count($this->getList());
    }

    /**
     * @param $activeType
     * @return WorkerBase
     */
    public function getByType($activeType)
    {
        if (!isset($this->activeObjects[$activeType])) {
            $this->activeObjects[$activeType] = Yii::createObject([
                'class'       => __NAMESPACE__ . '\\' . $activeType,
                'tenantId'    => $this->tenantId,
                'cityId'      => $this->cityId,
                'positionId'  => $this->positionId,
                'allowCityId' => $this->allowCityId,
            ]);
        }

        return $this->activeObjects[$activeType];
    }

    /**
     * Getting worker on shift by callsign form redis
     * @param integer $callsign
     * @param integer $tenantId
     * @return array|false
     */
    public static function getOne($callsign, $tenantId)
    {
        return unserialize(Yii::$app->redis_workers->executeCommand('hget', [$tenantId, $callsign]));
    }
}