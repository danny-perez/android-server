<?php


namespace app\modules\v1\models\worker;


class WorkerFree extends WorkerBase
{
    use ActiveTrait, CarColorTrait, FreeTrait;

    private $_freeWorkers;

    /**
     * Free workers
     * @return array
     */
    public function getList()
    {
        if (empty($this->_freeWorkers)) {
            $workers = $this->getAllActiveWorkers();

            $arResult['markers'] = [];
            $arResult['type'] = 'free_car';

            foreach ($workers as $cab) {
                $cab = unserialize($cab);

                if (!$this->isFree($cab)) {
                    continue;
                }

                $marker_key_name = 'free_car_' . $cab['worker']['worker_id'];
                $arResult['markers'][] = [
                    'key_name'    => $marker_key_name,
                    'coords'      => [
                        'lat' => $cab['geo']['lat'],
                        'lon' => $cab['geo']['lon'],
                    ],
                    'marker_info' => [
                        'worker_id'   => $cab['worker']['worker_id'],
                        'worker_name' => trim($cab['worker']['last_name'] . ' ' . $cab['worker']['name']),
                        'phone'       => $cab['worker']['phone'],
                        'callsign'    => $cab['worker']['callsign'],
                        'device_info' => $cab['worker']['device_info'],
                        'city_id'     => $cab['worker']['city_id'],
                        'car_id'      => $cab['car']['car_id'],
                        'car_name'    => trim($cab['car']['name'] . ', ' . $cab['car']['gos_number'] . ', ' .
                            $this->getCarColorTextByName($cab['car']['color'])),
                    ],
                    'iconAngle'   => $cab['geo']['degree'],
                ];
            }

            $this->_freeWorkers = $arResult;
        }

        return $this->_freeWorkers;
    }

    /**
     * @return int
     */
    public function getCount()
    {
        $dataList = $this->getList();

        return isset($dataList['markers']) && is_array($dataList['markers']) ? count($dataList['markers']) : 0;
    }
}