<?php


namespace app\modules\v1\models\worker;


use Yii;
use app\models\Worker;
use yii\base\InvalidConfigException;
use yii\base\InvalidParamException;
use yii\base\Object;
use yii\db\ActiveQuery;
use yii\helpers\ArrayHelper;
use yii\web\NotFoundHttpException;

class WorkerView extends Object
{
    public $workerId;
    public $positionId;
    public $tenantId;

    /** @var  Worker */
    private $worker;
    /** @var  array Worker data from redis */
    private $activeWorker;

    public function init()
    {
        parent::init();

        if (empty($this->tenantId)) {
            throw new InvalidConfigException('The field "tenantId" must be configured');
        }

        $this->worker = $this->getWorker();

        if (empty($this->worker)) {
            throw new NotFoundHttpException('Not found worker with id: ' . $this->workerId);
        }

        $this->activeWorker = $this->getActiveWorker();
    }

    public function getData()
    {
        return [
            'worker_id'   => $this->workerId,
            'callsign'    => $this->worker->callsign,
            'status'      => $this->getStatus(),
            'rating'      => $this->getRating(),
            'photo'       => $this->getPhotoUrl(),
            'name'        => $this->worker->getFullName(),
            'coords'      => $this->getLocation(),
            'device_info' => $this->activeWorker ? $this->activeWorker['worker']['device_info'] : null,
            'profile'     => [
                'balance'  => $this->getBalanse(),
                'position' => $this->getPostionList(),
                'car'      => $this->getCarList(),
                'phone'    => $this->worker->phone,
                'email'    => $this->worker->email,
            ],
            'shift'       => $this->getShiftData(),
        ];
    }

    /**
     * @return null|\yii\db\ActiveRecord
     */
    private function getWorker()
    {
        return Worker::find()
            ->where(['worker_id' => $this->workerId, 'tenant_id' => $this->tenantId])
            ->with([
                'shifts'             => function (ActiveQuery $query) {
                    $query->where(['position_id' => $this->positionId, 'end_work' => null]);
                    $query->with([
                        'tariff' => function (ActiveQuery $query) {
                            $query->select(['tariff_id', 'name']);
                        },
                        'car'    => function (ActiveQuery $query) {
                            $query->with('carColor');
                            $query->select(['car_id', 'name', 'gos_number', 'color']);
                        },
                    ]);
                },
                'workerHasPositions' => function (ActiveQuery $query) {
                    $query->select(['worker_id', 'position_id', 'rating']);
                    $query->with([
                        'position' => function (ActiveQuery $subQuery) {
                            $subQuery->select(['position_id', 'name']);
                        },
                    ]);
                    $query->indexBy('position_id');
                },
                'cars.car'           => function (ActiveQuery $query) {
                    $query->with('carColor');
                    $query->select(['car_id', 'name', 'gos_number', 'color']);
                },
                'accounts'           => function (ActiveQuery $query) {
                    $query->select(['tenant_id', 'owner_id', 'balance', 'currency_id']);
                },
            ])
            ->one();
    }

    /**
     * @return string
     */
    public function getBalanse()
    {
        return (new WorkerBalance($this->worker))->getBalanse();
    }

    /**
     * @return string
     */
    public function getPhotoUrl()
    {
        return $this->worker->photo ? Yii::$app->params['photoAction'] . $this->worker->photo : '';
    }

    /**
     * Worker status
     * @return null
     * @throws InvalidParamException
     */
    public function getStatus()
    {
        return isset($this->activeWorker['worker']['status']) ? $this->activeWorker['worker']['status'] : null;
    }

    /**
     * @return array|false
     */
    private function getActiveWorker()
    {
        return ActiveWorkers::getOne($this->worker->callsign, $this->tenantId);
    }

    /**
     * @return null|string
     */
    public function getRating()
    {
        if (isset($this->activeWorker['position']['raiting'])) {
            return $this->activeWorker['position']['raiting'];
        }

        if (isset($this->worker->workerHasPositions[$this->positionId]['rating'])) {
            return $this->worker->workerHasPositions[$this->positionId]['rating'];
        }

        return null;
    }

    /**
     * @return array
     */
    public function getLocation()
    {
        $location = [
            'lat' => null,
            'lon' => null,
        ];

        if (is_array($this->activeWorker['geo'])) {
            $location = [
                'lat' => isset($this->activeWorker['geo']['lat']) ? $this->activeWorker['geo']['lat'] : null,
                'lon' => isset($this->activeWorker['geo']['lon']) ? $this->activeWorker['geo']['lon'] : null,
            ];
        }

        return $location;
    }

    /**
     * @return array
     */
    public function getPostionList()
    {
        return ArrayHelper::getColumn($this->worker->workerHasPositions, function ($item) {
            return [
                'id'   => $item['position_id'],
                'name' => t('employee', $item['position']['name']),
            ];
        });
    }

    /**
     * @return array
     */
    public function getCarList()
    {
        if (!empty($this->worker->cars) && is_array($this->worker->cars)) {
            return ArrayHelper::getColumn($this->worker->cars, function ($item) {
                return [
                    'id'   => $item['car_id'],
                    'name' => $item['car']->getFullName(),
                ];
            });
        }

        return [];
    }

    /**
     * @return array
     */
    public function getShiftData()
    {
        if (!empty($this->worker->shifts)) {
            return ArrayHelper::getColumn($this->worker->shifts, function ($item) {
                $shift = new WorkerShift($item);

                return [
                    'tariff'   => [
                        'id'   => $item['tariff']['tariff_id'],
                        'name' => $item['tariff']['name'],
                    ],
                    'car'      => $item['car']->getFullName(),
                    'duration' => $shift->getDuration(),
                    'pause'    => $shift->getPauseDuration(),
                    'orders'   => $shift->getOrdersCountData(),
                ];
            });
        }

        return [];
    }
}