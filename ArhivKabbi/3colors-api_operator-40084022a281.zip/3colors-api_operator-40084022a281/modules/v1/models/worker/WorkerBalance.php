<?php


namespace app\modules\v1\models\worker;


use app\components\Formatter;
use app\models\Worker;
use app\modules\v1\models\currency\Currency;
use Yii;

class WorkerBalance
{
    private $_worker;

    public function __construct(Worker $worker)
    {
        $this->_worker = $worker;
    }

    /**
     * @return string
     */
    public function getBalanse()
    {
        $summary = [];

        if (is_array($this->_worker['accounts'])) {
            foreach ($this->_worker['accounts'] as $account) {
                $currency = new Currency(['currencyId' => $account['currency_id']]);
                $currencySymbol = $currency->getCurrencySymbol();
                $minorUnit = $currency->getMinorUnit();
                /** @var Formatter $formatter */
                $formatter = Yii::$app->formatter;
                $summary[] = $formatter->asMoney(round(+$account['balance'], $minorUnit), $currencySymbol);
            }
        }

        return implode(', ', $summary);
    }
}