<?php


namespace app\modules\v1\models\worker;

use app\models\Worker;
use yii\db\ActiveQuery;
use yii\helpers\ArrayHelper;

class WorkerOffline extends WorkerBase
{
    /** @var array */
    public $activeWorkerIds = [];

    /**
     * @return int|string
     */
    public function getCount()
    {
        return Worker::find()
            ->where(['tenant_id' => $this->tenantId, 'block' => 0, 'city_id' => $this->cityId])
            ->andFilterWhere(['not in', Worker::tableName() . '.worker_id', $this->activeWorkerIds])
            ->joinWith([
                'workerHasPositions' => function (ActiveQuery $query) {
                    return $query->where(['position_id' => $this->positionId, 'active' => 1]);
                },
            ], false)
            ->count();
    }

    /**
     * @return array
     */
    public function getRawData()
    {
        return Worker::find()
            ->alias('w')
            ->where(['tenant_id' => $this->tenantId, 'block' => 0, 'city_id' => $this->cityId])
            ->andFilterWhere(['not in', 'w.worker_id', $this->activeWorkerIds])
            ->with([
                'cars.car' => function ($query) {
                    $query->select(['car_id', 'name', 'gos_number', 'color']);
                },
                'cars.car.carColor',
            ])
            ->joinWith([
                'workerHasPositions' => function ($query) {
                    return $query->where(['position_id' => $this->positionId, 'active' => 1]);
                },
            ], false)
            ->asArray()
            ->all();
    }

    /**
     * @return array
     */
    public function getList()
    {
        $models = $this->getRawData();

        return ArrayHelper::getColumn($models, function ($item) {
            $arCar = ArrayHelper::getColumn($item['cars'], function ($cars) {
                return trim($cars['car']['name'] . ', ' . $cars['car']['gos_number'] . ', ' . t('car',
                        $cars['car']['carColor']['name']));
            });

            return [
                'worker_id' => $item['worker_id'],
                'name'      => trim($item['last_name'] . ' ' . $item['name']),
                'cars'      => $arCar,
            ];
        });
    }
}