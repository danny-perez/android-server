<?php


namespace app\modules\v1\models\worker;


use yii\base\Object;
use app\models\WorkerBlock as WorkerBlockRecord;

class WorkerBlock extends Object
{
    public $shiftId;

    /**
     * @return false|null|string]
     */
    public function getBlockId()
    {
        return WorkerBlockRecord::find()
            ->where(['shift_id' => $this->shiftId, 'is_unblocked' => 0])
            ->select('block_id')
            ->scalar();
    }
}