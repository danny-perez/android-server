<?php


namespace app\modules\v1\models\worker;

use Yii;

trait FreeTrait
{
    /**
     * @param array $cab
     * @param bool $checkCoords
     * @return bool
     */
    public function isFree($cab, $checkCoords = true)
    {
        if (!in_array($cab['worker']['city_id'], $this->allowCityId)
            || $cab['worker']['status'] != 'FREE'
            || (!empty($this->cityId) && $cab['worker']['city_id'] != $this->cityId || ((empty($cab['geo']['lat']) || empty($cab['geo']['lon'])) && $checkCoords))
            || (!empty($this->positionId) && $cab['position']['position_id'] != $this->positionId)
        ) {
            return false;
        }

        return true;
    }
}