<?php


namespace app\modules\v1\models\worker;


use app\models\Worker as WorkerRecord;
use yii\db\ActiveRecord;

class Worker
{
    /**
     * Getting worker by callsign.
     * @param integer $workerCallsign
     * @param integer $tenant_id
     * @param array $select
     * @return null|WorkerRecord|ActiveRecord
     */
    public function getByCallsign($workerCallsign, $tenant_id, array $select = [])
    {
        return WorkerRecord::find()
            ->where([
                'tenant_id' => $tenant_id,
                'callsign'  => $workerCallsign,
            ])
            ->select($select)
            ->one();
    }
}