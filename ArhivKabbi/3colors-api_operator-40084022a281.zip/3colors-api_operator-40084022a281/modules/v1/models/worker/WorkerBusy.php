<?php


namespace app\modules\v1\models\worker;


use app\models\order\ActiveOrderRepository;

class WorkerBusy extends WorkerBase
{
    use ActiveTrait, CarColorTrait;

    private $_busyWorkers;

    /**
     * @return array
     */
    public function getList()
    {
        if (empty($this->_busyWorkers)) {
            $workers = $this->getAllActiveWorkers();

            $arResult['markers'] = [];
            $arResult['type'] = 'busy_car';
            $arBuzyWorkerStatus = [
                'ON_ORDER',
                'ON_BREAK',
            ];

            foreach ($workers as $cab) {
                $cab = unserialize($cab);

                if (!in_array($cab['worker']['city_id'], $this->allowCityId)
                    || !in_array($cab['worker']['status'], $arBuzyWorkerStatus)
                    || ((!empty($this->cityId) && $cab['worker']['city_id'] != $this->cityId) || empty($cab['geo']['lat']) || empty($cab['geo']['lon']))
                    || (!empty($this->positionId) && $cab['position']['position_id'] != $this->positionId)
                ) {
                    continue;
                }

                $order = isset($cab['worker']['last_order_id']) ? $this->getActiveOrder($cab['worker']['last_order_id']) : null;
                $hasOrder = !empty($order);
                $marker_key_name = 'busy_car_' . $cab['worker']['worker_id'];

                $isPause = $cab['worker']['status'] == 'ON_BREAK';
                $arResult['markers'][] = [
                    'key_name'    => $marker_key_name,
                    'coords'      => [
                        'lat' => $cab['geo']['lat'],
                        'lon' => $cab['geo']['lon'],
                    ],
                    'marker_info' => [
                        'client_id'    => $isPause || !$hasOrder ? null : $order['client_id'],
                        'client_name'  => $isPause || !$hasOrder ? null : trim($order['client']['last_name'] . ' ' . $order['client']['name']),
                        'client_phone' => $isPause || !$hasOrder ? null : $order['phone'],
                        'device'       => $hasOrder ? $order['device'] : null,
                        'device_info'  => $cab['worker']['device_info'],
                        'worker_id'    => $cab['worker']['worker_id'],
                        'worker_name'  => trim($cab['worker']['last_name'] . ' ' . $cab['worker']['name']),
                        'worker_phone' => $cab['worker']['phone'],
                        'callsign'     => $cab['worker']['callsign'],
                        'city_id'      => $cab['worker']['city_id'],
                        'car_id'       => $cab['car']['car_id'],
                        'car_name'     => trim($cab['car']['name'] . ', ' . $cab['car']['gos_number'] . ', ' .
                            $this->getCarColorTextByName($cab['car']['color'])),
                    ],
                    'iconAngle'   => $cab['geo']['degree'],
                ];
            }

            $this->_busyWorkers = $arResult;
        }

        return $this->_busyWorkers;
    }

    /**
     * @return int
     */
    public function getCount()
    {
        $dataList = $this->getList();

        return isset($dataList['markers']) && is_array($dataList['markers']) ? count($dataList['markers']) : 0;
    }

    /**
     * @param int $orderId
     * @return array|null
     */
    private function getActiveOrder($orderId)
    {
        return (new ActiveOrderRepository(['tenantId' => $this->tenantId]))->getOne($orderId);
    }
}