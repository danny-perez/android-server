<?php


namespace app\modules\v1\models\city;


use app\models\City as CityRecord;
use yii\base\Object;
use yii\db\ActiveQuery;

class City extends Object
{
    public $cityId;
    private $_timeOffset = [];

    /**
     * City time offset.
     * @return integer
     */
    public function getTimeOffset()
    {
        if (!isset($this->_timeOffset[$this->cityId])) {
            $city = CityRecord::find()
                ->where(['city_id' => $this->cityId])
                ->with([
                    'republic' => function (ActiveQuery $query) {
                        $query->select([
                            'republic_id',
                            'timezone'
                        ]);
                    }
                ])
                ->one();

            if (empty($city)) {
                return 0;
            }

            $this->_timeOffset[$this->cityId] = !empty($city->republic->timezone) ? $city->republic->timezone * 3600 : 0;
        }

        return $this->_timeOffset[$this->cityId];
    }
}