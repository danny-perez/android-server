## Настройка

### База Данных SQL

Отредактируйте файл `config/db.php`, например:

```php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii2basic',
    'username' => 'root',
    'password' => '1234',
    'charset' => 'utf8',
];
```

### Настройки компонентов

Отредактируйте файл `config/web.php`, внеся настройки в соответствующие компоненты

```php
'components' => [
        'mailer'              => [
            'class'     => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class'      => 'Swift_SmtpTransport',
                'host'       => 'smtp.yandex.ru',
                'port'       => 465,
                'username'   => 'sup1@gootax.pro',
                'password'   => 'D376gr)98hnfd_1',
                'encryption' => 'ssl',
            ],
        ],
        'redis_workers'           => [
            'class'    => 'yii\redis\Connection',
            'hostname' => 'redis.taxi.lcl',
            'port'     => 6379,
            'database' => 0,
        ],
        'redis_active_dispatcher' => [
            'class'    => 'yii\redis\Connection',
            'hostname' => 'redis.taxi.lcl',
            'port'     => 6379,
            'database' => 5,
        ],
        'cache'                   => [
            'class' => 'yii\redis\Cache',
            'redis' => [
                'hostname' => 'redis-cache.taxi.lcl',
                'port'     => 6379,
                'database' => 0,
            ],
        ],
        'autocomplete'            => [
            'class'  => 'app\components\Autocomplete',
            'apiKey' => function () {
                return DefaultSettings::getSetting(DefaultSettings::GEOSERVICE_API_KEY);
            },
            'host'   => 'http://192.168.10.206:3100/v1/',
        ],
        'routeAnalyzer'           => [
            'class'   => 'app\components\TaxiRouteAnalyzer',
            'host'    => 'http://192.168.1.242',
            'port'    => '8087',
            'version' => '1',
        ],
        'workerApi'               => [
            'class'      => 'app\components\WorkerApi',
            'host'       => 'https://da.uatgootax.ru',
            'port'       => 8088,
            'apiKey'     => function () {
                return (new TenantSetting(['tenantId' => user()->tenant_id]))->getValue('WORKER_API_KEY');
            },
            'httpClient' => [
                'class' => 'app\components\http_client\YiiHttpClient',
            ],
        ],
```
