<?php
namespace Codeception\Module;

// here you can define custom actions
// all public methods declared in helper class will be available in $I

use Codeception\Util\HttpCode;

class ApiHelper extends \Codeception\Module
{
    const USER_TOKEN = '$2y$13$YE0nb3J9/VIYgim.Awvvh.3czf1XTzOBIIzHA/eHRwaGKykvZjiZC';

    /** @var  \ApiTester */
    private $tester;

    public function checkRequest($method, $url, $data = [])
    {
        $this->tester->amHttpAuthenticated(self::USER_TOKEN, '');
        $sendMethod = 'send' . $method;
        $this->tester->$sendMethod($url, $data);
        $this->tester->seeResponseCodeIs(HttpCode::OK);
        $this->tester->seeResponseIsJson();
    }

    /**
     * @param \ApiTester $I
     */
    public function setTesterToHelper(\ApiTester $I)
    {
        $this->tester = $I;
    }
}
