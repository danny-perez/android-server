<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$city_id = 26068;
$position_id = 1;
$tariff_id = 2;

$I->wantTo('check tariff list');
$I->checkRequest('GET', '/v1/tariff-client/list', compact('city_id', 'position_id'));

$I->wantTo('check tariff option list');
$I->checkRequest('GET', '/v1/tariff-client/option-list', compact('tariff_id'));