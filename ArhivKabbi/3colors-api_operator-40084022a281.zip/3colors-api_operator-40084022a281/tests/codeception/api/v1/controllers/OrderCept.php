<?php
/* @var $scenario Codeception\Scenario */

$order_id = 623;
$city_id = 26068;
$tenant_id = 66;

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$I->wantTo('check order tracking');
$I->checkRequest('GET', '/v1/order/track', compact('order_id'));

$I->wantTo('check route analyze');
$I->checkRequest('GET', '/v1/order/route-analyze', [
    'city_id'   => $city_id,
    'address'   => 'A%5Bcity%5D=%D0%98%D0%B6%D0%B5%D0%B2%D1%81%D0%BA%2C+%D1%80%D0%B5%D1%81%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0+%D0%A3%D0%B4%D0%BC%D1%83%D1%80%D1%82%D0%B8%D1%8F%2C+%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F%26A%5Bcity_id%5D=26068%26A%5Bstreet%5D=%D1%83%D0%BB.+%D0%9A%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%26A%5Bhouse%5D=127%26A%5Bhousing%5D=%26A%5Bporch%5D=%26A%5Bapt%5D=%26A%5Bparking_id%5D=181%26A%5Blat%5D=56.859826%26A%5Blon%5D=53.215045',
    'tariff_id' => 81,
]);

$I->seeResponseJsonMatchesXpath('//summaryTime');
$I->seeResponseJsonMatchesXpath('//summaryDistance');
$I->seeResponseJsonMatchesXpath('//summaryCost');

$position_id = 1;
/** @var string $type Group of order */
$type = 'new';

$I->wantTo('check a list of orders by "new" group');
$I->checkRequest('GET', '/v1/order/', compact('city_id', 'position_id', 'type'));

$type = 'in_hands';
$I->wantTo('check a list of orders by "in_hands" group');
$I->checkRequest('GET', '/v1/order/', compact('city_id', 'position_id', 'type'));

$type = 'warning';
$I->wantTo('check a list of orders by "warning" group');
$I->checkRequest('GET', '/v1/order/', compact('city_id', 'position_id', 'type'));

$type = 'completed';
$I->wantTo('check a list of orders by "completed" group');
$I->checkRequest('GET', '/v1/order/', compact('city_id', 'position_id', 'type'));

$type = 'rejected';
$I->wantTo('check a list of orders by "rejected" group');
$I->checkRequest('GET', '/v1/order/', compact('city_id', 'position_id', 'type'));

$I->wantTo('check a getting order data by number');
$I->checkRequest('GET', '/v1/order/number/547', compact('tenant_id'));

$I->wantTo('check a getting order data by id');
$I->checkRequest('GET', '/v1/order/' . $order_id);

$I->wantTo('check order count request');
$I->checkRequest('GET', '/v1/order/counters', compact('city_id', 'position_id'));

$I->wantTo('create the order');
$orderData = [
    'phone'             => '11111111111',
    'client_id'         => '',
    'city_id'           => $city_id,
    'comment'           => 'sdfdsfs',
    'position_id'       => $position_id,
    'tariff_id'         => 81,
    'payment'           => 'CASH',
    'bonus_payment'     => 0,
    'additional_option' => [8, 9],
    'predv_price'       => 3,
    'predv_distance'    => 0,
    'predv_time'        => 0,
    'parking_id'        => '',
    'company_id'        => '',
    'device'            => 'DISPATCHER',
    'call_id'           => '',
    'address'           => [
        'A' => [
            'city'       => 'Ижевск',
            'city_id'    => $city_id,
            'street'     => 'улица Кирова',
            'house'      => 117,
            'housing'    => '',
            'porch'      => '',
            'apt'        => '',
            'parking'    => 'Октябрьский',
            'parking_id' => 181,
            'lat'        => '56.860373',
            'lon'        => '53.210334',
        ],
    ],
];
$I->checkRequest('POST', '/v1/order/create', $orderData);
$I->seeResponseContainsJson(['code' => 100]);
$I->seeResponseJsonMatchesJsonPath('$.order_id');

$I->wantTo('check a getting order events');
$I->checkRequest('GET', '/v1/order/events', compact('city_id', 'order_id'));