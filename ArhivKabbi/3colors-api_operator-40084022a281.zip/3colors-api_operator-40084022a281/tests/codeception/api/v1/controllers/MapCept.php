<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$city_id = 26068;
$position_id = 1;

$I->wantTo('check active orders');
$I->checkRequest('GET', '/v1/city', compact('city_id', 'position_id'));

$I->wantTo('check free workers');
$I->checkRequest('GET', '/v1/map/free-workers', compact('city_id', 'position_id'));

$I->wantTo('check busy workers');
$I->checkRequest('GET', '/v1/map/busy-workers', compact('city_id', 'position_id'));

$I->wantTo('check all data');
$I->checkRequest('GET', '/v1/map/data', compact('city_id', 'position_id'));