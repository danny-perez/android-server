<?php
/* @var $scenario Codeception\Scenario */

define('CITY_ID', 26068);

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$I->wantTo('check parking list');
$I->checkRequest('GET', '/v1/parking', ['city_id' => CITY_ID]);