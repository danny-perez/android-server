<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$city_id = 26068;
$position_id = 1;

$I->wantTo('check offline workers');
$I->checkRequest('GET', '/v1/worker/offline', compact('city_id', 'position_id'));

$I->wantTo('check position list');
$I->checkRequest('GET', '/v1/worker/position-list');

$I->wantTo('check counters');
$I->checkRequest('GET', '/v1/worker/counters', compact('city_id', 'position_id'));

$I->wantTo('check getting worker card');
$I->checkRequest('GET', '/v1/worker/21', compact('position_id'));

$callsign = 17777;
$I->wantTo('block the worker');
$I->checkRequest('POST', '/v1/worker/order-block', compact('callsign'));

$I->wantTo('unblock the worker');
$I->checkRequest('POST', '/v1/worker/order-unblock', compact('callsign'));

$I->wantTo('search the worker');
$search = 'Петров';
$I->checkRequest('GET', '/v1/worker/search', compact('position_id', 'city_id', 'search'));

$I->wantTo('end work of the worker');
$I->checkRequest('POST', '/v1/worker/end-work', compact('callsign'));