<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$I->wantTo('check city list');
$I->checkRequest('GET', '/v1/city');