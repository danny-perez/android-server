<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$search = 'Киро';
$city_id = 26068;
$lat = '56.852775';
$lon = '53.211463';

$I->wantTo('check autocomplete');
$I->checkRequest('GET', '/v1/street', compact('search', 'city_id', 'lat', 'lon'));