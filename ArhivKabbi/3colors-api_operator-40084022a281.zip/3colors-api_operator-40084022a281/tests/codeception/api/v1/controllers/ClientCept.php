<?php
/* @var $scenario Codeception\Scenario */

$I = new ApiTester($scenario);
$I->setTesterToHelper($I);

$I->wantTo('search the client');
$I->checkRequest('GET', '/v1/client/search', ['phone' => '11111111111', 'city_id' => 26068]);