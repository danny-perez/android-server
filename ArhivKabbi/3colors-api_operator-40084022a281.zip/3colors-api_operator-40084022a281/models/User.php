<?php

namespace app\models;

use Yii;
use yii\web\IdentityInterface;

/**
 * This is the model class for table "{{%user}}".
 *
 * @property integer $user_id
 * @property integer $tenant_id
 * @property integer $position_id
 * @property string $email
 * @property string $email_confirm
 * @property string $password
 * @property string $last_name
 * @property string $name
 * @property string $second_name
 * @property string $phone
 * @property string $photo
 * @property integer $active
 * @property string $birth
 * @property string $address
 * @property string $create_time
 * @property string $auth_key
 * @property string $password_reset_token
 * @property integer $active_time
 * @property string $ha1
 * @property string $ha1b
 * @property integer $auth_exp
 * @property string $lang
 * @property string $last_session_id
 * @property string $md5_password
 *
 * @property Call[] $calls
 * @property CommunityUser[] $communityUsers
 * @property OrderViews[] $orderViews
 * @property PublicPlaceModeration[] $publicPlaceModerations
 * @property PublicPlaceModerationAdd[] $publicPlaceModerationAdds
 * @property StreetModeration[] $streetModerations
 * @property StreetModerationAdd[] $streetModerationAdds
 * @property Support[] $supports
 * @property Support[] $supports0
 * @property Transaction[] $transactions
 * @property Tenant $tenant
 * @property UserPosition $position
 * @property UserDispetcher[] $userDispetchers
 * @property UserHasCity[] $userHasCities
 */
class User extends \yii\db\ActiveRecord implements IdentityInterface
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'position_id', 'email', 'email_confirm', 'password', 'auth_key', 'active_time'], 'required'],
            [['tenant_id', 'position_id', 'active', 'active_time', 'auth_exp'], 'integer'],
            [['birth', 'create_time'], 'safe'],
            [['email'], 'string', 'max' => 40],
            [['email_confirm', 'last_name', 'name', 'second_name'], 'string', 'max' => 45],
            [
                ['password', 'photo', 'address', 'auth_key', 'password_reset_token', 'last_session_id'],
                'string',
                'max' => 255,
            ],
            [['phone'], 'string', 'max' => 15],
            [['ha1', 'ha1b'], 'string', 'max' => 64],
            [['lang'], 'string', 'max' => 10],
            [['md5_password'], 'string', 'max' => 32],
            [['email'], 'unique'],
            [
                ['tenant_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Tenant::className(),
                'targetAttribute' => ['tenant_id' => 'tenant_id'],
            ],
            [
                ['position_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => UserPosition::className(),
                'targetAttribute' => ['position_id' => 'position_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'user_id'              => 'User ID',
            'tenant_id'            => 'Tenant ID',
            'position_id'          => 'Position ID',
            'email'                => 'Email',
            'email_confirm'        => 'Email Confirm',
            'password'             => 'Password',
            'last_name'            => 'Last Name',
            'name'                 => 'Name',
            'second_name'          => 'Second Name',
            'phone'                => 'Phone',
            'photo'                => 'Photo',
            'active'               => 'Active',
            'birth'                => 'Birth',
            'address'              => 'Address',
            'create_time'          => 'Create Time',
            'auth_key'             => 'Auth Key',
            'password_reset_token' => 'Password Reset Token',
            'active_time'          => 'Active Time',
            'ha1'                  => 'Ha1',
            'ha1b'                 => 'Ha1b',
            'auth_exp'             => 'Auth Exp',
            'lang'                 => 'Lang',
            'last_session_id'      => 'Last Session ID',
            'md5_password'         => 'Md5 Password',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCalls()
    {
        return $this->hasMany(Call::className(), ['user_opertor_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCommunityUsers()
    {
        return $this->hasMany(CommunityUser::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderViews()
    {
        return $this->hasMany(OrderViews::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPublicPlaceModerations()
    {
        return $this->hasMany(PublicPlaceModeration::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPublicPlaceModerationAdds()
    {
        return $this->hasMany(PublicPlaceModerationAdd::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStreetModerations()
    {
        return $this->hasMany(StreetModeration::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStreetModerationAdds()
    {
        return $this->hasMany(StreetModerationAdd::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSupports()
    {
        return $this->hasMany(Support::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSupports0()
    {
        return $this->hasMany(Support::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transaction::className(), ['user_created' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(UserPosition::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserDispetchers()
    {
        return $this->hasMany(UserDispetcher::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserHasCities()
    {
        return $this->hasMany(UserHasCity::className(), ['user_id' => 'user_id']);
    }

    public static function findIdentity($id)
    {
        return self::findOne(['user_id' => $id]);
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findOne(['access_token' => $token, 'active' => 1]);
    }

    /**
     * Returns an ID that can uniquely identify a user identity.
     * @return string|integer an ID that uniquely identifies a user identity.
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }

    public function getAuthKey()
    {
        return $this->auth_key;
    }
}
