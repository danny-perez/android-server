<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%taxi_tariff}}".
 *
 * @property integer $tariff_id
 * @property integer $tenant_id
 * @property integer $class_id
 * @property integer $block
 * @property integer $group_id
 * @property string $name
 * @property string $description
 * @property integer $sort
 * @property integer $enabled_site
 * @property integer $enabled_app
 * @property integer $enabled_operator
 * @property integer $enabled_bordur
 * @property string $logo
 * @property integer $position_id
 * @property integer $position_class_id
 *
 * @property AdditionalOption[] $additionalOptions
 * @property ClientBonusHasTariff[] $clientBonusHasTariffs
 * @property OptionActiveDate[] $optionActiveDates
 * @property OptionTariff[] $optionTariffs
 * @property PhoneLine[] $phoneLines
 * @property TaxiTariffGroup $group
 * @property Position $positionClass
 * @property Position $position
 * @property CarClass $class
 * @property Tenant $tenant
 * @property TaxiTariffHasCity[] $taxiTariffHasCities
 */
class TaxiTariff extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%taxi_tariff}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'position_id'], 'required'],
            [
                [
                    'tenant_id',
                    'class_id',
                    'block',
                    'group_id',
                    'sort',
                    'enabled_site',
                    'enabled_app',
                    'enabled_operator',
                    'enabled_bordur',
                    'position_id',
                    'position_class_id',
                ],
                'integer',
            ],
            [['description'], 'string'],
            [['name', 'logo'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tariff_id'         => Yii::t('app', 'Tariff ID'),
            'tenant_id'         => Yii::t('app', 'Tenant ID'),
            'class_id'          => Yii::t('app', 'Class ID'),
            'block'             => Yii::t('app', 'Block'),
            'group_id'          => Yii::t('app', 'Group ID'),
            'name'              => Yii::t('app', 'Name'),
            'description'       => Yii::t('app', 'Description'),
            'sort'              => Yii::t('app', 'Sort'),
            'enabled_site'      => Yii::t('app', 'Enabled Site'),
            'enabled_app'       => Yii::t('app', 'Enabled App'),
            'enabled_operator'  => Yii::t('app', 'Enabled Operator'),
            'enabled_bordur'    => Yii::t('app', 'Enabled Bordur'),
            'logo'              => Yii::t('app', 'Logo'),
            'position_id'       => Yii::t('app', 'Position ID'),
            'position_class_id' => Yii::t('app', 'Position Class ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAdditionalOptions()
    {
        return $this->hasMany(AdditionalOption::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientBonusHasTariffs()
    {
        return $this->hasMany(ClientBonusHasTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOptionActiveDates()
    {
        return $this->hasMany(OptionActiveDate::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOptionTariffs()
    {
        return $this->hasMany(OptionTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPhoneLines()
    {
        return $this->hasMany(PhoneLine::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(TaxiTariffGroup::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositionClass()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClass()
    {
        return $this->hasOne(CarClass::className(), ['class_id' => 'class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTariffHasCity()
    {
        return $this->hasOne(TaxiTariffHasCity::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCities()
    {
        return $this->hasOne(City::className(),
            ['city_id' => 'city_id'])->viaTable('{{%taxi_tariff_has_city}}', ['tariff_id' => 'tariff_id']);
    }
}
