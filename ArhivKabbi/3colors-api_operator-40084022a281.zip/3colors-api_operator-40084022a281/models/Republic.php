<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%republic}}".
 *
 * @property integer $republic_id
 * @property integer $country_id
 * @property string $name
 * @property string $shortname
 * @property double $timezone
 * @property string $name_en
 * @property string $name_az
 * @property string $name_de
 * @property string $name_sr
 * @property string $shortname_en
 * @property string $shortname_az
 * @property string $shortname_de
 * @property string $shortname_sr
 * @property string $name_ro
 * @property string $shortname_ro
 * @property string $time_zone
 * @property string $name_uz
 * @property string $shortname_uz
 * @property string $name_fi
 * @property string $shortname_fi
 * @property string $name_fa
 * @property string $shortname_fa
 *
 * @property Street[] $streets
 */
class Republic extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%republic}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['country_id', 'name', 'shortname'], 'required'],
            [['country_id'], 'integer'],
            [['timezone'], 'number'],
            [['name', 'name_en', 'name_az', 'name_de', 'name_sr', 'name_fi', 'name_fa'], 'string', 'max' => 100],
            [
                [
                    'shortname',
                    'shortname_en',
                    'shortname_az',
                    'shortname_de',
                    'shortname_sr',
                    'name_ro',
                    'shortname_ro',
                ],
                'string',
                'max' => 50,
            ],
            [['time_zone', 'name_uz', 'shortname_uz', 'shortname_fi', 'shortname_fa'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'republic_id'  => Yii::t('app', 'Republic ID'),
            'country_id'   => Yii::t('app', 'Country ID'),
            'name'         => Yii::t('app', 'Name'),
            'shortname'    => Yii::t('app', 'Shortname'),
            'timezone'     => Yii::t('app', 'Timezone'),
            'name_en'      => Yii::t('app', 'Name En'),
            'name_az'      => Yii::t('app', 'Name Az'),
            'name_de'      => Yii::t('app', 'Name De'),
            'name_sr'      => Yii::t('app', 'Name Sr'),
            'shortname_en' => Yii::t('app', 'Shortname En'),
            'shortname_az' => Yii::t('app', 'Shortname Az'),
            'shortname_de' => Yii::t('app', 'Shortname De'),
            'shortname_sr' => Yii::t('app', 'Shortname Sr'),
            'name_ro'      => Yii::t('app', 'Name Ro'),
            'shortname_ro' => Yii::t('app', 'Shortname Ro'),
            'time_zone'    => Yii::t('app', 'Time Zone'),
            'name_uz'      => Yii::t('app', 'Name Uz'),
            'shortname_uz' => Yii::t('app', 'Shortname Uz'),
            'name_fi'      => Yii::t('app', 'Name Fi'),
            'shortname_fi' => Yii::t('app', 'Shortname Fi'),
            'name_fa'      => Yii::t('app', 'Name Fa'),
            'shortname_fa' => Yii::t('app', 'Shortname Fa'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStreets()
    {
        return $this->hasMany(Street::className(), ['republic_id' => 'republic_id']);
    }
}
