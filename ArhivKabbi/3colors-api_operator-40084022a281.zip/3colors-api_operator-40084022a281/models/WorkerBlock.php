<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%worker_block}}".
 *
 * @property integer $block_id
 * @property integer $shift_id
 * @property string $type_block
 * @property integer $start_block
 * @property integer $end_block
 * @property integer $is_unblocked
 * @property integer $worker_id
 * @property integer $pid
 * @property integer $server_id
 *
 * @property Worker $worker
 */
class WorkerBlock extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_block}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['shift_id', 'type_block', 'worker_id'], 'required'],
            [['shift_id', 'start_block', 'end_block', 'is_unblocked', 'worker_id', 'pid', 'server_id'], 'integer'],
            [['type_block'], 'string'],
            [
                ['worker_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Worker::className(),
                'targetAttribute' => ['worker_id' => 'worker_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'block_id'     => Yii::t('app', 'Block ID'),
            'shift_id'     => Yii::t('app', 'Shift ID'),
            'type_block'   => Yii::t('app', 'Type Block'),
            'start_block'  => Yii::t('app', 'Start Block'),
            'end_block'    => Yii::t('app', 'End Block'),
            'is_unblocked' => Yii::t('app', 'Is Unblocked'),
            'worker_id'    => Yii::t('app', 'Worker ID'),
            'pid'          => Yii::t('app', 'Pid'),
            'server_id'    => Yii::t('app', 'Server ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorker()
    {
        return $this->hasOne(Worker::className(), ['worker_id' => 'worker_id']);
    }
}
