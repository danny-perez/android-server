<?php


namespace app\models;


use yii\base\Object;

class TenantSetting extends Object
{
    const GEOCODER_SETTING = "GEOCODER_TYPE";
    const CURRENCY_SETTING = 'CURRENCY';
    const LANGUAGE_SETTING = 'LANGUAGE';
    const ORDER_PICK_UP_SETTING = 'PICK_UP';

    public $cityId;
    public $tenantId;

    public function getValue($settingName)
    {
        return TenantSettingRecord::find()
            ->where([
                'tenant_id' => $this->tenantId,
                'name'      => $settingName,
            ])
            ->andFilterWhere(['city_id' => $this->cityId])
            ->select('value')
            ->scalar();
    }
}