<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%position}}".
 *
 * @property integer $position_id
 * @property string $name
 * @property integer $parent_id
 * @property integer $module_id
 * @property string $code
 * @property integer $has_car
 * @property integer $transport_type_id
 *
 * @property ClientBonus[] $clientBonuses
 * @property ClientBonus[] $clientBonuses0
 * @property ClientPushNotifications[] $clientPushNotifications
 * @property DefaultClientPushNotifications[] $defaultClientPushNotifications
 * @property DefaultSmsTemplate[] $defaultSmsTemplates
 * @property Module $module
 * @property Position $parent
 * @property Position[] $positions
 * @property TransportType $transportType
 * @property PositionHasDocument[] $positionHasDocuments
 * @property Document[] $documents
 * @property PositionHasField[] $positionHasFields
 * @property PositionField[] $fields
 * @property SmsTemplate[] $smsTemplates
 * @property TaxiTariff[] $taxiTariffs
 * @property TaxiTariff[] $taxiTariffs0
 * @property WorkerGroup[] $workerGroups
 * @property WorkerGroup[] $workerGroups0
 * @property WorkerHasPosition[] $workerHasPositions
 * @property WorkerHasPosition[] $workerHasPositions0
 * @property Worker[] $workers
 * @property WorkerReviewRating[] $workerReviewRatings
 * @property WorkerShift[] $workerShifts
 * @property WorkerTariff[] $workerTariffs
 * @property WorkerTariff[] $workerTariffs0
 */
class Position extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%position}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'module_id', 'code'], 'required'],
            [['parent_id', 'module_id', 'has_car', 'transport_type_id'], 'integer'],
            [['name'], 'string', 'max' => 50],
            [['code'], 'string', 'max' => 45],
            [['code'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'position_id' => 'Position ID',
            'name' => 'Name',
            'parent_id' => 'Parent ID',
            'module_id' => 'Module ID',
            'code' => 'Code',
            'has_car' => 'Has Car',
            'transport_type_id' => 'Transport Type ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientBonuses()
    {
        return $this->hasMany(ClientBonus::className(), ['position_class_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientBonuses0()
    {
        return $this->hasMany(ClientBonus::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientPushNotifications()
    {
        return $this->hasMany(ClientPushNotifications::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDefaultClientPushNotifications()
    {
        return $this->hasMany(DefaultClientPushNotifications::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDefaultSmsTemplates()
    {
        return $this->hasMany(DefaultSmsTemplate::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getModule()
    {
        return $this->hasOne(Module::className(), ['id' => 'module_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParent()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'parent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositions()
    {
        return $this->hasMany(Position::className(), ['parent_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransportType()
    {
        return $this->hasOne(TransportType::className(), ['type_id' => 'transport_type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositionHasDocuments()
    {
        return $this->hasMany(PositionHasDocument::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDocuments()
    {
        return $this->hasMany(Document::className(), ['document_id' => 'document_id'])->viaTable('{{%position_has_document}}', ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositionHasFields()
    {
        return $this->hasMany(PositionHasField::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFields()
    {
        return $this->hasMany(PositionField::className(), ['field_id' => 'field_id'])->viaTable('{{%position_has_field}}', ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSmsTemplates()
    {
        return $this->hasMany(SmsTemplate::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTaxiTariffs()
    {
        return $this->hasMany(TaxiTariff::className(), ['position_class_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTaxiTariffs0()
    {
        return $this->hasMany(TaxiTariff::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerGroups()
    {
        return $this->hasMany(WorkerGroup::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerGroups0()
    {
        return $this->hasMany(WorkerGroup::className(), ['position_class_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerHasPositions()
    {
        return $this->hasMany(WorkerHasPosition::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerHasPositions0()
    {
        return $this->hasMany(WorkerHasPosition::className(), ['position_class_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkers()
    {
        return $this->hasMany(Worker::className(), ['worker_id' => 'worker_id'])->viaTable('{{%worker_has_position}}', ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerReviewRatings()
    {
        return $this->hasMany(WorkerReviewRating::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerShifts()
    {
        return $this->hasMany(WorkerShift::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerTariffs()
    {
        return $this->hasMany(WorkerTariff::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerTariffs0()
    {
        return $this->hasMany(WorkerTariff::className(), ['position_class_id' => 'position_id']);
    }
}
