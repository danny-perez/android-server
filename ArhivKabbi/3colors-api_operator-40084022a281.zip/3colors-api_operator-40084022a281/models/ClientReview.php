<?php

namespace app\models;


/**
 * This is the model class for table "{{%client_review}}".
 *
 * @property string $review_id
 * @property string $client_id
 * @property string $order_id
 * @property string $text
 * @property double $rating
 * @property string $create_time
 *
 * @property Client $client
 * @property Order $order
 */
class ClientReview extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%client_review}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'order_id', 'text'], 'required'],
            [['client_id', 'order_id'], 'integer'],
            [['text'], 'string'],
            [['rating'], 'number'],
            [['create_time'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'review_id'   => 'Review ID',
            'client_id'   => 'Client ID',
            'order_id'    => 'Order ID',
            'text'        => 'Text',
            'rating'      => 'Rating',
            'create_time' => 'Create Time',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['client_id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrder()
    {
        return $this->hasOne(Order::className(), ['order_id' => 'order_id']);
    }
}
