<?php


namespace app\models;


use Yii;

class UserDispatcherRepository
{
    /**
     * @param int $userId
     * @return bool|array
     */
    public function getOne($userId)
    {
        return unserialize($this->getComponent()->executeCommand('get', [$userId]));
    }

    private function getComponent()
    {
        return Yii::$app->redis_active_dispatcher;
    }
}