<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%worker_has_position}}".
 *
 * @property integer $id
 * @property integer $worker_id
 * @property integer $position_id
 * @property integer $active
 * @property integer $position_class_id
 * @property integer $group_id
 * @property double $rating
 *
 * @property WorkerHasCar[] $workerHasCars
 * @property Car[] $cars
 * @property WorkerHasDocument[] $workerHasDocuments
 * @property Position $position
 * @property Worker $worker
 * @property WorkerGroup $group
 * @property Position $positionClass
 */
class WorkerHasPosition extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_has_position}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['worker_id', 'position_id'], 'required'],
            [['worker_id', 'position_id', 'active', 'position_class_id', 'group_id'], 'integer'],
            [['rating'], 'number'],
            [
                ['worker_id', 'position_id'],
                'unique',
                'targetAttribute' => ['worker_id', 'position_id'],
                'message'         => 'The combination of Worker ID and Position ID has already been taken.',
            ],
            [
                ['position_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Position::className(),
                'targetAttribute' => ['position_id' => 'position_id'],
            ],
            [
                ['worker_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Worker::className(),
                'targetAttribute' => ['worker_id' => 'worker_id'],
            ],
            [
                ['group_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => WorkerGroup::className(),
                'targetAttribute' => ['group_id' => 'group_id'],
            ],
            [
                ['position_class_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Position::className(),
                'targetAttribute' => ['position_class_id' => 'position_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id'                => Yii::t('app', 'ID'),
            'worker_id'         => Yii::t('app', 'Worker ID'),
            'position_id'       => Yii::t('app', 'Position ID'),
            'active'            => Yii::t('app', 'Active'),
            'position_class_id' => Yii::t('app', 'Position Class ID'),
            'group_id'          => Yii::t('app', 'Group ID'),
            'rating'            => Yii::t('app', 'Rating'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerHasCars()
    {
        return $this->hasMany(WorkerHasCar::className(), ['has_position_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCars()
    {
        return $this->hasMany(Car::className(), ['car_id' => 'car_id'])->viaTable('{{%worker_has_car}}',
            ['has_position_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerHasDocuments()
    {
        return $this->hasMany(WorkerHasDocument::className(), ['has_position_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorker()
    {
        return $this->hasOne(Worker::className(), ['worker_id' => 'worker_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(WorkerGroup::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositionClass()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_class_id']);
    }
}
