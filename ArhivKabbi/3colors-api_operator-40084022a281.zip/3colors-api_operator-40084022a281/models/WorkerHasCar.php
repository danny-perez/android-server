<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%worker_has_car}}".
 *
 * @property integer $has_position_id
 * @property integer $car_id
 *
 * @property Car $car
 * @property WorkerHasPosition $hasPosition
 */
class WorkerHasCar extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_has_car}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['has_position_id', 'car_id'], 'required'],
            [['has_position_id', 'car_id'], 'integer'],
            [['car_id'], 'exist', 'skipOnError' => true, 'targetClass' => Car::className(), 'targetAttribute' => ['car_id' => 'car_id']],
            [['has_position_id'], 'exist', 'skipOnError' => true, 'targetClass' => WorkerHasPosition::className(), 'targetAttribute' => ['has_position_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'has_position_id' => Yii::t('app', 'Has Position ID'),
            'car_id' => Yii::t('app', 'Car ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCar()
    {
        return $this->hasOne(Car::className(), ['car_id' => 'car_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getHasPosition()
    {
        return $this->hasOne(WorkerHasPosition::className(), ['id' => 'has_position_id']);
    }
}
