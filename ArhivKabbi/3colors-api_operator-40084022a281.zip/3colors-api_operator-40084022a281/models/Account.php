<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%account}}".
 *
 * @property integer $account_id
 * @property integer $acc_kind_id
 * @property integer $acc_type_id
 * @property integer $owner_id
 * @property integer $currency_id
 * @property integer $tenant_id
 * @property double $balance
 *
 * @property AccountKind $accKind
 * @property AccountType $accType
 * @property Currency $currency
 * @property Tenant $tenant
 * @property Operation[] $operations
 * @property Transaction[] $transactions
 * @property Transaction[] $transactions0
 */
class Account extends \yii\db\ActiveRecord
{
    const ACTIVE_TYPE = 1;
    const PASSIVE_TYPE = 2;

    const TENANT_KIND = 1;
    const WORKER_KIND = 2;
    const CLIENT_KIND = 3;
    const COMPANY_KIND = 4;
    const SYSTEM_KIND = 5;
    const CLIENT_BONUS_KIND = 7;
    const SYSTEM_BONUS_KIND = 8;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%account}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['acc_kind_id', 'acc_type_id', 'currency_id'], 'required'],
            [['acc_kind_id', 'acc_type_id', 'owner_id', 'currency_id', 'tenant_id'], 'integer'],
            [['balance'], 'number'],
            [['owner_id', 'acc_kind_id', 'acc_type_id', 'tenant_id', 'currency_id'], 'unique', 'targetAttribute' => ['owner_id', 'acc_kind_id', 'acc_type_id', 'tenant_id', 'currency_id'], 'message' => 'The combination of Acc Kind ID, Acc Type ID, Owner ID, Currency ID and Tenant ID has already been taken.'],
            [['acc_kind_id'], 'exist', 'skipOnError' => true, 'targetClass' => AccountKind::className(), 'targetAttribute' => ['acc_kind_id' => 'kind_id']],
            [['acc_type_id'], 'exist', 'skipOnError' => true, 'targetClass' => AccountType::className(), 'targetAttribute' => ['acc_type_id' => 'type_id']],
            [['currency_id'], 'exist', 'skipOnError' => true, 'targetClass' => Currency::className(), 'targetAttribute' => ['currency_id' => 'currency_id']],
            [['tenant_id'], 'exist', 'skipOnError' => true, 'targetClass' => Tenant::className(), 'targetAttribute' => ['tenant_id' => 'tenant_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'account_id' => Yii::t('app', 'Account ID'),
            'acc_kind_id' => Yii::t('app', 'Acc Kind ID'),
            'acc_type_id' => Yii::t('app', 'Acc Type ID'),
            'owner_id' => Yii::t('app', 'Owner ID'),
            'currency_id' => Yii::t('app', 'Currency ID'),
            'tenant_id' => Yii::t('app', 'Tenant ID'),
            'balance' => Yii::t('app', 'Balance'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAccKind()
    {
        return $this->hasOne(AccountKind::className(), ['kind_id' => 'acc_kind_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAccType()
    {
        return $this->hasOne(AccountType::className(), ['type_id' => 'acc_type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(Currency::className(), ['currency_id' => 'currency_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOperations()
    {
        return $this->hasMany(Operation::className(), ['account_id' => 'account_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transaction::className(), ['receiver_acc_id' => 'account_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions0()
    {
        return $this->hasMany(Transaction::className(), ['sender_acc_id' => 'account_id']);
    }
}
