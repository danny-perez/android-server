<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%worker_shift}}".
 *
 * @property integer $id
 * @property integer $worker_id
 * @property integer $car_id
 * @property integer $start_work
 * @property integer $end_work
 * @property integer $tariff_id
 * @property string $pause_data
 * @property integer $position_id
 *
 * @property Position $position
 */
class WorkerShift extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_shift}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['worker_id', 'car_id', 'start_work', 'end_work', 'tariff_id', 'position_id'], 'integer'],
            [['car_id', 'start_work', 'tariff_id', 'position_id'], 'required'],
            [['pause_data'], 'string'],
            [
                ['position_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Position::className(),
                'targetAttribute' => ['position_id' => 'position_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id'          => Yii::t('app', 'ID'),
            'worker_id'   => Yii::t('app', 'Worker ID'),
            'car_id'      => Yii::t('app', 'Car ID'),
            'start_work'  => Yii::t('app', 'Start Work'),
            'end_work'    => Yii::t('app', 'End Work'),
            'tariff_id'   => Yii::t('app', 'Tariff ID'),
            'pause_data'  => Yii::t('app', 'Pause Data'),
            'position_id' => Yii::t('app', 'Position ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTariff()
    {
        return $this->hasOne(WorkerTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCar()
    {
        return $this->hasOne(Car::className(), ['car_id' => 'car_id']);
    }

    public function afterFind()
    {
        parent::afterFind();
        try {
            $this->pause_data = unserialize($this->pause_data);
        } catch (\Exception $exc) {
            Yii::error('Ошибка десериализации паузы исполнителя. Id записи - ' . $this->id, 'worker_shift');
        }
    }
}
