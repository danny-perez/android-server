<?php

namespace app\models\order;

use Yii;

/**
 * This is the model class for table "{{%order_has_option}}".
 *
 * @property integer $order_id
 * @property integer $option_id
 */
class OrderHasOption extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%order_has_option}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['order_id', 'option_id'], 'required'],
            [['order_id', 'option_id'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'order_id' => 'Order ID',
            'option_id' => 'Option ID',
        ];
    }
}
