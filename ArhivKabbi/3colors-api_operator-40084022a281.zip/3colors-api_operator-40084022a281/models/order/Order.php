<?php

namespace app\models\order;

use app\models\BonusFailLog;
use app\models\CardPayment;
use app\models\CardPaymentLog;
use app\models\ClientOrderFromApp;
use app\models\Currency;
use app\models\RawOrderCalc;
use app\models\Transaction;
use Yii;

/**
 * This is the model class for table "{{%order}}".
 *
 * @property integer $order_id
 * @property integer $tenant_id
 * @property integer $worker_id
 * @property integer $car_id
 * @property integer $city_id
 * @property integer $tariff_id
 * @property integer $user_create
 * @property integer $status_id
 * @property integer $user_modifed
 * @property integer $company_id
 * @property integer $parking_id
 * @property string $address
 * @property string $comment
 * @property string $predv_price
 * @property string $device
 * @property integer $order_number
 * @property string $payment
 * @property integer $show_phone
 * @property integer $create_time
 * @property integer $status_time
 * @property integer $time_to_client
 * @property string $client_device_token
 * @property integer $order_time
 * @property string $predv_distance
 * @property integer $predv_time
 * @property integer $call_warning_id
 * @property string $phone
 * @property integer $client_id
 * @property integer $bonus_payment
 * @property integer $currency_id
 * @property integer $time_offset
 * @property integer $position_id
 *
 * @property BonusFailLog[] $bonusFailLogs
 * @property CardPayment[] $cardPayments
 * @property CardPaymentLog[] $cardPaymentLogs
 * @property ClientOrderFromApp[] $clientOrderFromApps
 * @property RawOrderCalc[] $rawOrderCalcs
 * @property Transaction[] $transactions
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%order}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'tenant_id',
                    'tariff_id',
                    'status_id',
                    'address',
                    'order_number',
                    'status_time',
                    'client_id',
                    'currency_id',
                    'position_id',
                ],
                'required',
            ],
            [
                [
                    'tenant_id',
                    'worker_id',
                    'car_id',
                    'city_id',
                    'tariff_id',
                    'user_create',
                    'status_id',
                    'user_modifed',
                    'company_id',
                    'parking_id',
                    'order_number',
                    'show_phone',
                    'create_time',
                    'status_time',
                    'time_to_client',
                    'order_time',
                    'predv_time',
                    'call_warning_id',
                    'client_id',
                    'bonus_payment',
                    'currency_id',
                    'time_offset',
                    'position_id',
                ],
                'integer',
            ],
            [['address', 'comment', 'device', 'payment', 'client_device_token'], 'string'],
            [['predv_price', 'predv_distance'], 'number'],
            [['phone'], 'string', 'max' => 255],
            [
                ['tenant_id', 'order_number'],
                'unique',
                'targetAttribute' => ['tenant_id', 'order_number'],
                'message'         => 'The combination of Tenant ID and Order Number has already been taken.',
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'order_id'            => Yii::t('order', 'Order ID'),
            'tenant_id'           => Yii::t('order', 'Tenant ID'),
            'worker_id'           => Yii::t('order', 'Worker'),
            'city_id'             => Yii::t('order', 'Branch'),
            'tariff_id'           => Yii::t('order', 'Tariff'),
            'client_id'           => Yii::t('order', 'Client ID'),
            'user_create'         => Yii::t('order', 'User Create'),
            'user_modifed'        => Yii::t('order', 'User modifed'),
            'status_id'           => Yii::t('order', 'Status'),
            'address'             => Yii::t('order', 'Address'),
            'comment'             => Yii::t('order', 'Comment'),
            'predv_price'         => Yii::t('order', 'Price'),
            'predv_distance'      => Yii::t('order', 'Preliminary distance'),
            'predv_time'          => Yii::t('order', 'Preliminary time'),
            'create_time'         => Yii::t('order', 'Create Time'),
            'device'              => Yii::t('order', 'Device'),
            'payment'             => Yii::t('order', 'Payment'),
            'show_phone'          => Yii::t('order', 'Show client phone to worker'),
            'parking_id'          => t('parking', 'Parking'),
            'preliminary_calc'    => t('parking', 'Preliminary calculation'),
            'additional_option'   => t('order', 'Additional options'),
            'order_time'          => t('order', 'Order time'),
            'status_time'         => t('order', 'Status time'),
            'phone'               => t('order', 'Client phone'),
            'bonus_payment'       => t('order', 'Bonus payment'),
            'position_id'         => t('employee', 'Profession'),
            'car_id'              => 'Car ID',
            'company_id'          => 'Company ID',
            'order_number'        => 'Order Number',
            'time_to_client'      => 'Time To Client',
            'client_device_token' => 'Client Device Token',
            'call_warning_id'     => 'Call Warning ID',
            'currency_id'         => 'Currency ID',
            'time_offset'         => 'Time Offset',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBonusFailLogs()
    {
        return $this->hasMany(BonusFailLog::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCardPayments()
    {
        return $this->hasMany(CardPayment::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCardPaymentLogs()
    {
        return $this->hasMany(CardPaymentLog::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClientOrderFromApps()
    {
        return $this->hasMany(ClientOrderFromApp::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRawOrderCalcs()
    {
        return $this->hasMany(RawOrderCalc::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transaction::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(Currency::className(), ['currency_id' => 'currency_id']);
    }

    public function getDetailCost()
    {
        return $this->hasOne(OrderDetailCost::className(), ['order_id' => 'order_id']);
    }
}
