<?php


namespace app\models\order;


use app\models\order\interfaces\OrderRepositoryInterface;

class ActiveOrderRepository extends OrderBaseRepository implements OrderRepositoryInterface
{
    /**
     * @param integer $orderId
     * @return array|null
     */
    public function getOne($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/active/' . $orderId, [
            'tenant_id' => $this->tenantId,
        ]);
    }

    public function getAll()
    {
        return $this->_httpClient->createRequest('GET', 'orders/active', [
            'tenant_id' => $this->tenantId,
        ]);
    }
}