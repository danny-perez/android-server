<?php

namespace app\models\order;

use Yii;

/**
 * This is the model class for table "{{%order_change_data}}".
 *
 * @property integer $change_id
 * @property integer $tenant_id
 * @property integer $order_id
 * @property string $change_field
 * @property string $change_object_id
 * @property string $change_object_type
 * @property string $change_subject
 * @property string $change_val
 * @property integer $change_time
 */
class OrderChangeData extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%order_change_data}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'order_id'], 'required'],
            [['tenant_id', 'order_id', 'change_time'], 'integer'],
            [['change_field', 'change_object_id', 'change_object_type'], 'string', 'max' => 45],
            [['change_subject'], 'string', 'max' => 100],
            [['change_val'], 'string', 'max' => 300],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'change_id' => 'Change ID',
            'tenant_id' => 'Tenant ID',
            'order_id' => 'Order ID',
            'change_field' => 'Change Field',
            'change_object_id' => 'Change Object ID',
            'change_object_type' => 'Change Object Type',
            'change_subject' => 'Change Subject',
            'change_val' => 'Change Val',
            'change_time' => 'Change Time',
        ];
    }
}
