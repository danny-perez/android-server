<?php


namespace app\models\order;


use app\models\order\interfaces\OrderRepositoryInterface;

class OrderRepository extends OrderBaseRepository implements OrderRepositoryInterface
{
    /**
     * @param integer $orderId
     * @return array
     */
    public function getOne($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/' . $orderId);
    }

    /**
     * @param integer $orderNumber
     * @return array
     */
    public function getOneByNumber($orderNumber)
    {
        return $this->_httpClient->createRequest('GET', 'orders/number/' . $orderNumber, [
            'tenant_id' => $this->tenantId,
        ]);
    }

    /**
     * @return array
     */
    public function getCounts()
    {
        return $this->_httpClient->createRequest('GET', 'orders/count',
            ['city_id'     => $this->cityId,
             'position_id' => $this->positionId,
             'tenant_id'   => $this->tenantId,
             'date'        => $this->date,
            ]);
    }

    /**
     * @param integer $orderId
     * @return array
     */
    public function getTracking($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/' . $orderId . '/track');
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function create($data)
    {
        return $this->_httpClient->createRequest('POST', 'orders', $data);
    }

    /**
     * @param integer $orderId
     * @return array
     */
    public function getEvents($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/' . $orderId . '/events');
    }

    /**
     * @param integer $orderId
     * @return array
     */
    public function getDetailCost($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/' . $orderId . '/cost');
    }

    /**
     * @param integer $orderId
     * @return array
     */
    public function getUpdateFieldList($orderId)
    {
        return $this->_httpClient->createRequest('GET', 'orders/' . $orderId . '/fields');
    }
}