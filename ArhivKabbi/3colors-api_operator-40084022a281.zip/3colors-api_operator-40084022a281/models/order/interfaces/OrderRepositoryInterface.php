<?php


namespace app\models\order\interfaces;


interface OrderRepositoryInterface
{
    /**
     * @return array
     */
    public function getList();

    /**
     * @param int $orderId
     * @return array
     */
    public function getOne($orderId);
}