<?php


namespace app\models\order;


use app\components\http_client\YiiHttpClientTrait;
use Yii;
use yii\base\Object;

abstract class OrderBaseRepository extends Object
{
    use YiiHttpClientTrait;

    public $cityId;
    public $allowCityId;
    public $positionId;
    public $tenantId;
    public $statusGroup;
    /** @var string Format: d.m.Y */
    public $date = null;

    public function init()
    {
        parent::init();

        $this->setHttpClient($this->getBaseUrl());
    }

    public function getBaseUrl()
    {
        return Yii::$app->params['orderServiceUrl'];
    }

    /**
     * @return array
     */
    public function getList()
    {
        return $this->_httpClient->createRequest('GET', 'orders', [
            'city_id'     => $this->cityId,
            'position_id' => $this->positionId,
            'tenant_id'   => $this->tenantId,
            'group'       => $this->statusGroup,
            'date'        => $this->date,
        ]);
    }
}