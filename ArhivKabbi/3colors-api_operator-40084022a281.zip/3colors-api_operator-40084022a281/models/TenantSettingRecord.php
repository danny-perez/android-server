<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%tenant_setting}}".
 *
 * @property integer $setting_id
 * @property integer $tenant_id
 * @property string $name
 * @property string $value
 * @property string $type
 * @property integer $city_id
 *
 * @property City $city
 * @property DefaultSettings $name0
 * @property Tenant $tenant
 */
class TenantSettingRecord extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%tenant_setting}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'name', 'value'], 'required'],
            [['tenant_id', 'city_id'], 'integer'],
            [['value', 'type'], 'string'],
            [['name'], 'string', 'max' => 45],
            [
                ['tenant_id', 'name', 'city_id'],
                'unique',
                'targetAttribute' => ['tenant_id', 'name', 'city_id'],
                'message'         => 'The combination of Tenant ID, Name and City ID has already been taken.',
            ],
            [
                ['city_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => City::className(),
                'targetAttribute' => ['city_id' => 'city_id'],
            ],
            [
                ['name'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => DefaultSettings::className(),
                'targetAttribute' => ['name' => 'name'],
            ],
            [
                ['tenant_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Tenant::className(),
                'targetAttribute' => ['tenant_id' => 'tenant_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'setting_id' => Yii::t('app', 'Setting ID'),
            'tenant_id'  => Yii::t('app', 'Tenant ID'),
            'name'       => Yii::t('app', 'Name'),
            'value'      => Yii::t('app', 'Value'),
            'type'       => Yii::t('app', 'Type'),
            'city_id'    => Yii::t('app', 'City ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['city_id' => 'city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getName0()
    {
        return $this->hasOne(DefaultSettings::className(), ['name' => 'name']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }
}
