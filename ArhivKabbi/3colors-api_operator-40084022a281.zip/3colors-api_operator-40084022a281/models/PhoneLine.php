<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%phone_line}}".
 *
 * @property integer $line_id
 * @property integer $tenant_id
 * @property integer $tariff_id
 * @property integer $city_id
 * @property string $phone
 * @property string $incoming_scenario
 * @property integer $block
 *
 * @property Call[] $calls
 * @property City $city
 * @property TaxiTariff $tariff
 * @property Tenant $tenant
 */
class PhoneLine extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%phone_line}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'tariff_id', 'city_id', 'phone'], 'required'],
            [['tenant_id', 'tariff_id', 'city_id', 'block'], 'integer'],
            [['incoming_scenario'], 'string'],
            [['phone'], 'string', 'max' => 20],
            [['phone'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'line_id'           => Yii::t('app', 'Line ID'),
            'tenant_id'         => Yii::t('app', 'Tenant ID'),
            'tariff_id'         => Yii::t('app', 'Tariff ID'),
            'city_id'           => Yii::t('app', 'City ID'),
            'phone'             => Yii::t('app', 'Phone'),
            'incoming_scenario' => Yii::t('app', 'Incoming Scenario'),
            'block'             => Yii::t('app', 'Block'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCalls()
    {
        return $this->hasMany(Call::className(), ['phone_line_id' => 'line_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['city_id' => 'city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTariff()
    {
        return $this->hasOne(TaxiTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }
}
