<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%taxi_tariff_has_city}}".
 *
 * @property integer $tariff_id
 * @property integer $city_id
 *
 * @property TaxiTariff $tariff
 */
class TaxiTariffHasCity extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%taxi_tariff_has_city}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tariff_id', 'city_id'], 'required'],
            [['tariff_id', 'city_id'], 'integer'],
            [
                ['tariff_id'],
                'exist',
                'skipOnError' => true,
                'targetClass' => TaxiTariff::className(),
                'targetAttribute' => ['tariff_id' => 'tariff_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tariff_id' => Yii::t('app', 'Tariff ID'),
            'city_id'   => Yii::t('app', 'City ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTariff()
    {
        return $this->hasOne(TaxiTariff::className(), ['tariff_id' => 'tariff_id']);
    }
}
