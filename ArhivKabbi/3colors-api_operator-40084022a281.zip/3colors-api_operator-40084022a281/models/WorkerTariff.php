<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%worker_tariff}}".
 *
 * @property integer $tariff_id
 * @property integer $tenant_id
 * @property integer $class_id
 * @property string $name
 * @property string $type
 * @property integer $block
 * @property integer $days
 * @property string $description
 * @property integer $position_id
 * @property integer $position_class_id
 *
 * @property CarHasWorkerGroupTariff[] $carHasWorkerGroupTariffs
 * @property Car[] $cars
 * @property WorkerActiveAboniment[] $workerActiveAboniments
 * @property WorkerGroupHasTariff[] $workerGroupHasTariffs
 * @property WorkerOptionTariff[] $workerOptionTariffs
 * @property CarClass $class
 * @property Tenant $tenant
 * @property CarClass $class0
 * @property Position $position
 * @property Position $positionClass
 * @property WorkerTariffHasCity[] $workerTariffHasCities
 * @property City[] $cities
 */
class WorkerTariff extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%worker_tariff}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tenant_id', 'position_id'], 'required'],
            [['tenant_id', 'class_id', 'block', 'days', 'position_id', 'position_class_id'], 'integer'],
            [['type', 'description'], 'string'],
            [['name'], 'string', 'max' => 45],
            [
                ['class_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => CarClass::className(),
                'targetAttribute' => ['class_id' => 'class_id'],
            ],
            [
                ['tenant_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Tenant::className(),
                'targetAttribute' => ['tenant_id' => 'tenant_id'],
            ],
            [
                ['class_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => CarClass::className(),
                'targetAttribute' => ['class_id' => 'class_id'],
            ],
            [
                ['position_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Position::className(),
                'targetAttribute' => ['position_id' => 'position_id'],
            ],
            [
                ['position_class_id'],
                'exist',
                'skipOnError'     => true,
                'targetClass'     => Position::className(),
                'targetAttribute' => ['position_class_id' => 'position_id'],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tariff_id'         => Yii::t('app', 'Tariff ID'),
            'tenant_id'         => Yii::t('app', 'Tenant ID'),
            'class_id'          => Yii::t('app', 'Class ID'),
            'name'              => Yii::t('app', 'Name'),
            'type'              => Yii::t('app', 'Type'),
            'block'             => Yii::t('app', 'Block'),
            'days'              => Yii::t('app', 'Days'),
            'description'       => Yii::t('app', 'Description'),
            'position_id'       => Yii::t('app', 'Position ID'),
            'position_class_id' => Yii::t('app', 'Position Class ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCarHasWorkerGroupTariffs()
    {
        return $this->hasMany(CarHasWorkerGroupTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCars()
    {
        return $this->hasMany(Car::className(), ['car_id' => 'car_id'])->viaTable('{{%car_has_worker_group_tariff}}',
            ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerActiveAboniments()
    {
        return $this->hasMany(WorkerActiveAboniment::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerGroupHasTariffs()
    {
        return $this->hasMany(WorkerGroupHasTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerOptionTariffs()
    {
        return $this->hasMany(WorkerOptionTariff::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClass()
    {
        return $this->hasOne(CarClass::className(), ['class_id' => 'class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTenant()
    {
        return $this->hasOne(Tenant::className(), ['tenant_id' => 'tenant_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClass0()
    {
        return $this->hasOne(CarClass::className(), ['class_id' => 'class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPosition()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPositionClass()
    {
        return $this->hasOne(Position::className(), ['position_id' => 'position_class_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWorkerTariffHasCities()
    {
        return $this->hasMany(WorkerTariffHasCity::className(), ['tariff_id' => 'tariff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCities()
    {
        return $this->hasMany(City::className(), ['city_id' => 'city_id'])->viaTable('{{%worker_tariff_has_city}}',
            ['tariff_id' => 'tariff_id']);
    }
}
