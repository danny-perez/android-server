<?php


namespace app\helpers;


class Language
{
    public static function getLanguagePrefix()
    {
        $prefix = mb_substr(app()->language, 0, 2);

        return $prefix == 'ru' ? '' : '_' . $prefix;
    }
}