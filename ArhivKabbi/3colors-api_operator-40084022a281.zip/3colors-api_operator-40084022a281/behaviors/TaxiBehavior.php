<?php

/**
 * This behavior for common TaxiRouteAnalyzer and TaxiGeocoder classes.
 */

namespace app\behaviors;

use app\models\TenantSetting;

class TaxiBehavior extends \yii\base\Behavior
{
    /**
     * Getting site language
     * @return string
     */
    public function getLangParam()
    {
        $langParts = explode('-', app()->language);
        $curLang = current($langParts);

        return empty($curLang) ? 'ru' : $curLang;
    }

    /**
     * Getting geocoder type param
     * @return string
     */
    public function getGeocoderType()
    {
        $geocoderType = (new TenantSetting(['tenantId' => user()->tenant_id]))->getValue('GEOCODER_TYPE');

        return empty($geocoderType) ? 'ru' : $geocoderType;
    }
}
