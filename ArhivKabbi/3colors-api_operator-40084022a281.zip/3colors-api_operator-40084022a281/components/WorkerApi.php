<?php

namespace app\components;


use app\components\http_client\interfaces\HttpClientInterface;
use Yii;
use yii\base\InvalidConfigException;
use yii\base\Object;
use yii\helpers\ArrayHelper;

/**
 * Class WorkerApi
 * @package frontend\components\workerApi
 */
class WorkerApi extends Object
{
    public $host;
    public $port;
    public $version = 3;

    /** @var  \app\components\http_client\interfaces\HttpClientInterface */
    private $httpClient;
    private $apiKey;

    public function init()
    {
        parent::init();

        if (empty($this->apiKey)) {
            throw new InvalidConfigException('Api key hasn`t been configure');
        }
    }

    /**
     * Getting url
     * @return string
     */
    protected function getUrl()
    {
        return "{$this->host}:{$this->port}/v{$this->version}/api";
    }

    /**
     * Close active worker shift
     * @param int $workerLogin
     * @param string $tenantLogin
     * @return bool|mixed
     */
    public function endWork($workerLogin, $tenantLogin)
    {
        $params = [
            'worker_login' => $workerLogin,
            'tenant_login' => $tenantLogin,
        ];

        return $this->createRequest('post', 'worker_end_work', $params);
    }

    /**
     * @param $workerLogin
     * @param $tenantLogin
     * @return mixed
     */
    public function orderBlock($workerLogin, $tenantLogin)
    {
        $params = [
            'tenant_login' => $tenantLogin,
            'worker_login' => $workerLogin,
        ];

        return $this->createRequest('post', 'worker_order_block', $params);
    }

    /**
     * Remove worker order block
     * @param int $workerLogin
     * @param string $tenantLogin
     * @param int $blockId
     * @return mixed
     */
    public function orderUnblock($workerLogin, $tenantLogin, $blockId)
    {
        $params = [
            'tenant_login' => $tenantLogin,
            'worker_login' => $workerLogin,
            'block_id'     => $blockId,
        ];

        return $this->createRequest('post', 'worker_order_unblock', $params);
    }

    /**
     * Remove worker pre order block
     * @param $workerLogin
     * @param $tenantLogin
     * @param $blockId
     * @return mixed
     */
    public function preOrderUnblock($workerLogin, $tenantLogin, $blockId)
    {
        $params = [
            'tenant_login' => $tenantLogin,
            'worker_login' => $workerLogin,
            'block_id'     => $blockId,
        ];

        return $this->createRequest('post', 'worker_pre_order_unblock', $params);
    }

    /**
     * @param string $method
     * @param string $url
     * @param array $params
     * @return string|array
     */
    private function createRequest($method, $url, $params)
    {
        $signature = $this->getSignature($params);

        return $this->httpClient->createRequest($method, $url, $params, ['signature' => $signature]);
    }

    /**
     * @param array $params
     * @return string
     */
    private function getSignature(array $params)
    {
        ksort($params);

        return md5(http_build_query($params) . $this->getApiKey());
    }

    /**
     * @return string
     */
    public function getApiKey()
    {
        return $this->apiKey;
    }

    /**
     * @param string $apiKey
     */
    public function setApiKey($apiKey)
    {
        if (is_callable($apiKey)) {
            $this->apiKey = call_user_func($apiKey);
        } else {
            $this->apiKey = $apiKey;
        }
    }

    /**
     * Creating a http client object.
     * @param array $value A configuration array: the array must contain a `class` element which is treated as the object class,
     * and the rest of the name-value pairs will be used to initialize the corresponding object properties
     * @throws InvalidConfigException
     */
    public function setHttpClient($value)
    {
        $params = ArrayHelper::merge($value, ['baseUrl' => $this->getUrl()]);
        $this->httpClient = Yii::createObject($params);

        if (!($this->httpClient instanceof HttpClientInterface)) {
            throw new InvalidConfigException('Http client must be implement of "app\components\http_client\interfaces\HttpClientInterface"');
        }
    }
}