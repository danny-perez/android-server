<?php


namespace app\components\http_client;

use app\components\http_client\interfaces\HttpClientInterface;
use Yii;

trait YiiHttpClientTrait
{
    public $parserFormat = 'json';

    /** @var HttpClientInterface */
    protected $_httpClient;

    public function setHttpClient($url)
    {
        $this->_httpClient = Yii::$app->get('httpClient');
        $this->_httpClient->setBaseUrl($url);
        $this->_httpClient->parserFormat = $this->parserFormat;
    }
}