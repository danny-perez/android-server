<?php


namespace app\components\http_client;


use app\components\http_client\interfaces\HttpClientInterface;
use yii\base\Object;
use yii\httpclient\Client;

class YiiHttpClient extends Object implements HttpClientInterface
{
    public $baseUrl;
    public $parserFormat;

    /** @var Client */
    private $httpClient;

    public function init()
    {
        parent::init();

        $this->setClient();

        if (!empty($this->baseUrl)) {
            $this->setBaseUrl($this->baseUrl);
        }
    }

    /**
     * @param string $method
     * @param string $url
     * @param array|string $data
     * @param array $headers
     * @param array $options
     * @return array|string
     */
    public function createRequest($method, $url, $data = [], $headers = [], $options = [])
    {
        $request = $this->httpClient->createRequest()
            ->setUrl($url)
            ->setMethod($method)
            ->addHeaders($headers)
            ->addOptions($options);

        if (is_array($data)) {
            $request->setData($data);
        } else {
            $request->setContent($data);
        }

        $response = $request->send();

        if ($this->parserFormat) {
            return $this->httpClient->getParser($this->parserFormat)->parse($response);
        }

        return $response->content;
    }

    private function setClient()
    {
        $this->httpClient = new Client();
    }

    /**
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->httpClient->baseUrl;
    }

    /**
     * @param string $url
     */
    public function setBaseUrl($url)
    {
        $this->httpClient->baseUrl = $url;
    }
}