<?php


namespace app\components\http_client\interfaces;


interface HttpClientInterface
{
    /**
     * @param string $method
     * @param string $url
     * @param array|string $data
     * @param array $headers
     * @param array $options
     */
    public function createRequest($method, $url, $data = [], $headers = [], $options = []);

    /**
     * @return string
     */
    public function getBaseUrl();

    /**
     * @param string $url
     */
    public function setBaseUrl($url);
}