<?php

namespace app\components;

use app\behaviors\TaxiBehavior;
use Yii;

/**
 * Middleware for taxi-service-api route-analyzer methods
 *
 * @author Sergey K.
 * @mixin TaxiBehavior
 */
class TaxiRouteAnalyzer extends \yii\base\Component
{
    /**
     * Host of taxi-service-api. For default is dev version of api.
     * @var string
     */
    public $host = 'http://192.168.1.242';

    /**
     * Port of taxi-service-api
     * @var string
     */
    public $port = null;

    /**
     * taxi-service-api version
     * @var integer
     */
    public $version = 1;

    /**
     * Timeout of requst to taxi-service-api
     * @var integer
     */
    public $timeout = 30;

    public function behaviors()
    {
        return [
            'common' => [
                'class' => TaxiBehavior::className()
            ]
        ];
    }

    /**
     * Route analyze. Return time, distance, cost and other data of route.
     * @param string $tenantId
     * @param string $cityId
     * @param array $newAddressArray
     * @param string|array $additionalOption format: 1,2,3 | [1,2,3]
     * @param string $tariffId
     * @param string $orderDate format: d-m-Y H:i:s
     * @return array|mixed
     */
    public function analyzeRoute($tenantId, $cityId, $newAddressArray, $additionalOption, $tariffId, $orderDate)
    {
        $newAddressArray = json_encode($newAddressArray);
        $newAddressArray = urlencode($newAddressArray);
        if (is_array($additionalOption)) {
            $additionalOption = implode(',', $additionalOption);
        }
        $params = [
            'tenant_id'     => $tenantId,
            'city_id'       => $cityId,
            'address_array' => $newAddressArray,
            'additional'    => $additionalOption,
            'tariff_id'     => $tariffId,
            'order_time'    => $orderDate,
            'lang'          => $this->getLangParam(),
            'geocoder_type' => $this->getGeocoderType(),
        ];
        $result = $this->sendPostRequest('analyze_route', $params);

        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     *  Method add coords for address if they'a missing
     * @param array $address
     * @param string $lang
     * @param string $geocoder_type
     * @return array|mixed
     */
    public function fixCoords($address)
    {
        $address = json_encode($address);
        $address = urlencode($address);
        $params = [
            'address'       => $address,
            'lang'          => $this->getLangParam(),
            'geocoder_type' => $this->getGeocoderType(),
        ];
        $result = $this->sendGetRequest('fix_coords', $params);
        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     * The method will be defined the point belongs to what parkings
     * @param string $tenantId
     * @param string $cityId
     * @param string $lat
     * @param string $lon
     * @param bool $jsonFormat
     * @return array|mixed
     */
    public function getParkingByCoords($tenantId, $cityId, $lat, $lon, $jsonFormat = false)
    {
        $jsonFormat = ($jsonFormat == true) ? 1 : 0;
        $params = [
            'tenant_id'   => $tenantId,
            'city_id'     => $cityId,
            'lat'         => $lat,
            'lon'         => $lon,
            'json_format' => $jsonFormat,
        ];
        $result = $this->sendGetRequest('get_parking_by_coords', $params);
        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     * Method formatig parking to default type
     * @param array $arParking
     * @param bool $reverse
     */
    public function formatParkings($arParking, $reverse = true)
    {
        $reverse = ($reverse == true) ? 1 : 0;
        $arParking = json_encode($arParking);
        $arParking = urlencode($arParking);
        $params = [
            'parkings' => $arParking,
            'reverse'  => $reverse,
        ];
        $result = $this->sendPostRequest('format_parkings', $params);
        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     * Find at witch parking point is in
     * @param type $lat
     * @param type $lon
     * @param type $arParking
     */
    public function findPointLocationInParking($lat, $lon, $arParking)
    {
        $arParking = json_encode($arParking);
        $arParking = urlencode($arParking);
        $params = [
            'lat'      => $lat,
            'lon'      => $lon,
            'parkings' => $arParking,
        ];
        $result = $this->sendPostRequest('find_point_location_in_parking', $params);
        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     * Определение типа тарифа
     * @param type $tariff_id
     * @param type $date 19.04.2016 11:35:00
     * @return array ["15","22","23"]
     */
    public function addOptions($tariff, $date)
    {
        $params = [
            'tariff_id' => $tariff,
            'date'      => $date,
        ];
        $result = $this->sendPostRequest('add_options', $params);

        if (isset($result['code'])) {
            if ($result['code'] == 0) {
                return $result["result"];
            }
        }
    }

    /**
     * Send GET request to taxi-service-api
     * @param string $method
     * @param array $params
     */
    private function sendGetRequest($method, $params)
    {
        if (is_array($params)) {
            $params = http_build_query($params);
        }

        if (strlen($params) > 0) {
            $url = $this->getUrl($method) . "?" . $params;
        } else {
            $url = $this->getUrl($method);
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        $result = curl_exec($ch);
        $errorCode = curl_errno($ch);
        curl_close($ch);

        return ($errorCode == CURLE_OK) ? json_decode($result, true) : false;
    }

    /**
     * Send POST request  taxi-service-api
     * @param type $method
     * @param type $params
     */
    private function sendPostRequest($method, $params)
    {
        $url = $this->getUrl($method);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $result = curl_exec($ch);
        $errorCode = curl_errno($ch);
        curl_close($ch);

        return ($errorCode == CURLE_OK) ? json_decode($result, true) : false;
    }

    /**
     * Get url of taxi-service-api route-analyzer method
     * @param string $method
     * @return string
     */
    private function getUrl($method)
    {
        return $this->host . ":" . $this->port . "/v" . $this->version . "/route-analyzer/" . $method;
    }
}
