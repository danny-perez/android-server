<?php

namespace app\components;

use Yii;
use yii\base\Object;

class Language extends Object
{
    public $supportedLanguages = [];

    public function setAppLang()
    {
        $user = user();

        if (is_object($user)) {
            $lang = $user->lang;
        } else {
            $lang = app()->request->getPreferredLanguage($this->supportedLanguages);
        };

        app()->language = $lang;
    }

    public function getPreferredLanguage()
    {
        return Yii::$app->request->getPreferredLanguage($this->supportedLanguages);
    }
}
