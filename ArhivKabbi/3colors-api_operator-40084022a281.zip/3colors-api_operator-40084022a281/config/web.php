<?php

use app\models\DefaultSettings;
use app\models\TenantSetting;

$params = require(__DIR__ . '/params.php');

$config = [
    'id'         => 'operator_api',
    'basePath'   => dirname(__DIR__),
    'bootstrap'  => ['log'],
    'components' => [
        'request'                 => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'ecMNFseRgwRI7WvNXeRChdqE4bfVcdJX',
            'parsers'             => [
                'application/json' => 'yii\web\JsonParser',
            ],
        ],
        'response'                => [
            'format'        => yii\web\Response::FORMAT_JSON,
            'charset'       => 'UTF-8',
            'on beforeSend' => function ($event) {
                header('Access-Control-Allow-Headers: Authorization, Content-Type');
            },
        ],
        'user'                    => [
            'identityClass' => 'app\modules\v1\models\user\User',
            'enableSession' => false,
        ],
        'authManager'             => [
            'class' => 'yii\rbac\DbManager',
            'cache' => 'cache',
        ],
        'mailer'                  => [
            'class'     => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class'      => 'Swift_SmtpTransport',
                'host'       => 'smtp.yandex.ru',
                'port'       => 465,
                'username'   => 'sup1@gootax.pro',
                'password'   => 'D376gr)98hnfd_1',
                'encryption' => 'ssl',
            ],
        ],
        'log'                     => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets'    => [
                [
                    'class'  => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
                //                [
                //                    'class'   => 'yii\log\EmailTarget',
                //                    'mailer'  => 'mailer',
                //                    'levels'  => ['error', 'warning'],
                //                    'message' => [
                //                        'from'    => ['sup1@gootax.pro'],
                //                        'to'      => ['sup1@gootax.pro'],
                //                        'subject' => 'OPERATOR SERVICE ERROR',
                //                    ],
                //                ],
            ],
        ],
        'db'                      => require(__DIR__ . '/db.php'),
        'redis_workers'           => [
            'class'    => 'yii\redis\Connection',
            'hostname' => 'redis.taxi.lcl',
            'port'     => 6379,
            'database' => 0,
        ],
        'redis_active_dispatcher' => [
            'class'    => 'yii\redis\Connection',
            'hostname' => 'redis.taxi.lcl',
            'port'     => 6379,
            'database' => 5,
        ],
        'redis_order_event'       => [
            'class'    => 'yii\redis\Connection',
            'hostname' => 'redis.taxi.lcl',
            'port'     => 6379,
            'database' => 12,
        ],
        'urlManager'              => [
            'enablePrettyUrl' => true,
            'showScriptName'  => false,
            'rules'           => require(__DIR__ . '/urlRules.php'),
        ],
        'i18n'                    => [
            'translations' => [
                '*'    => [
                    'class'            => 'yii\i18n\DbMessageSource',
                    'forceTranslation' => true,
                ],
                'app*' => [
                    'class'            => 'yii\i18n\DbMessageSource',
                    'forceTranslation' => true,
                ],
            ],
        ],
        'cache'                   => [
            'class' => 'yii\redis\Cache',
            'redis' => [
                'hostname' => 'redis-cache.taxi.lcl',
                'port'     => 6379,
                'database' => 0,
            ],
        ],
        'bootstrapLanguage'       => [
            'class'              => 'app\components\Language',
            'supportedLanguages' => array_keys($params['supportedLanguages']),
        ],
        'autocomplete'            => [
            'class'  => 'app\components\Autocomplete',
            'apiKey' => function () {
                return DefaultSettings::getSetting(DefaultSettings::GEOSERVICE_API_KEY);
            },
            'host'   => 'http://192.168.10.206:3100/v1/',
        ],
        'routeAnalyzer'           => [
            'class'   => 'app\components\TaxiRouteAnalyzer',
            'host'    => 'http://sa.uat.taxi.lcl',
            'port'    => '80',
            'version' => '1',
        ],
        'formatter'               => [
            'class'                  => 'app\components\Formatter',
            'numberFormatterOptions' => [NumberFormatter::MIN_FRACTION_DIGITS => 0],
        ],
        'workerApi'               => [
            'class'      => 'app\components\WorkerApi',
            'host'       => 'http://da.uat.taxi.lcl',
            'port'       => 80,
            'apiKey'     => function () {
                return (new TenantSetting(['tenantId' => user()->tenant_id]))->getValue('WORKER_API_KEY');
            },
            'httpClient' => [
                'class' => 'app\components\http_client\YiiHttpClient',
            ],
        ],
        'httpClient'              => [
            'class' => 'app\components\http_client\YiiHttpClient',
        ],
        'amqp'                    => [
            'class'    => 'app\components\Amqp',
            'host'     => 'mq.taxi.lcl',
            'port'     => 5672,
            'user'     => 'guest',
            'password' => 'guest',
        ],
    ],
    'modules'    => [
        'v1' => [
            'class' => 'app\modules\v1\Module',
        ],
    ],
    'params'     => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['components'][]     = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['components'][]   = 'gii';
    $config['modules']['gii'] = [
        'class'      => 'yii\gii\Module',
        'allowedIPs' => ['192.168.1.*'],
    ];
}

return $config;
