<?php

return [
    'class'             => 'yii\db\Connection',
    'dsn'               => 'mysql:host=db2.taxi.lcl;dbname=taxi',
    'username'          => 'taxi',
    'password'          => 'JndfkkeiUSh38Zksf',
    'charset'           => 'utf8',
    'tablePrefix'       => 'tbl_',
    'enableSchemaCache' => true,
];
