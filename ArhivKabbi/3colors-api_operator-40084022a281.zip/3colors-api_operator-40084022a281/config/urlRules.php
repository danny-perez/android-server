<?php
return [
    'OPTIONS v1/<controller>/<action>/<id:\d+>'  => 'v1/<controller>/options',
    'OPTIONS v1/<controller>/<action>'           => 'v1/<controller>/options',
    'OPTIONS v1/<controller>/'                   => 'v1/<controller>/options',
    '<module>/order/number/<order_number:\d+>'   => '<module>/order/view-by-number',
    '<module>/order/update/<order_number:\d+>'   => '<module>/order/update',
    '<module>/<controller>/<id:\d+>'             => '<module>/<controller>/view',
    '<module>/order/update-event/<order_id:\d+>' => '<module>/order/update-event',
    '<module>/order/stop-offer/<order_id:\d+>'   => '<module>/order/stop-offer',
];