<?php

return [
    'supportedLanguages' => require(__DIR__ . '/supportedLanguages.php'),
    'photoAction'        => '/file/show?dir=upload&filename=',
    'orderServiceUrl'    => 'http://order.alex.taxi.lcl/v1',
    'phoneApiUrl'        => 'http://va.uat.taxi.lcl',
];
