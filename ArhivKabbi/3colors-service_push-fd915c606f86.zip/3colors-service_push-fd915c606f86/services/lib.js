'use strict';

const fs = require("fs");

exports.getConfig = function () {
    return require('dotenv-safe').load().parsed;
};

exports.getServiceVersion = () => {
    return require('../package.json').version;
};

exports.isString = function (val) {
    return typeof val === 'string' || ((!!val && typeof val === 'object') && Object.prototype.toString.call(val) === '[object String]');
};



