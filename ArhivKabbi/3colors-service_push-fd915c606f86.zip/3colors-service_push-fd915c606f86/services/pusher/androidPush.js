'use strict';

const gcm = require('node-gcm');
const serviceLog = require('../logger').serviceLogger;
const async = require('async');

/**
 * Creates a Push of ANDROID device
 * @constructor
 * @param {Object} senderService
 * @param {Array|String} tokenArr
 * @param {Object} settings
 */
function AndroidPush(senderService, tokenArr, settings) {
    serviceLog('info', "Called service method: androidPush");
    if (typeof tokenArr === "string") {
        tokenArr = [tokenArr];
    }
    this.tokenArr = tokenArr;
    this.title = settings.title;
    this.message = settings.message;
    this.contentAvailable = settings.contentAvailable;
    this.actionLocKey = settings.actionLocKey;
    this.category = settings.category;
    this.sound = settings.sound;
    this.icon = settings.icon;
    this.command = settings.command;
    this.command_params = settings.command_params;
    this.gsmSender = senderService;
    serviceLog('info', `Android push settings: ${JSON.stringify(settings)}`);
    serviceLog('info', `Android push tokenArr: ${JSON.stringify(tokenArr)}`);
}


/**
 * Send Push to one android device
 * @returns {Boolean}
 */
AndroidPush.prototype.sendPush = function (cb) {
    const self = this;
    self.basePushSender((err, res) => {
        if (err) {
            cb(err);
        } else {
            cb(null, res);
        }
    });
};


AndroidPush.prototype.basePushSender = function (cb) {
    const maxConsumers = 999;
    const self = this;
    const message = new gcm.Message({
        priority: 'high',
        timeToLive: 1800
    });
    message.addData('message', self.message);
    message.addData('tickerText', self.title);
    message.addData('sound', self.sound);
    message.addData('icon', self.icon);
    message.addData('command', self.command);
    message.addData('command_params', self.command_params);
    const tokenChunkedArr = chunkArray(self.tokenArr, maxConsumers);
    let deliveryResults = [];
    async.eachSeries(tokenChunkedArr, function iterator(tokenChunk, callback) {
        self.gsmSender.send(message, tokenChunk, (err, result) => {
            if (err) {
                serviceLog('error', `GCM error:${err.message}`);
            } else {
                result.results = result.results.map((resObj) => {
                    resObj.device = tokenChunk.shift();
                    return resObj;
                });
                deliveryResults.push(result);
            }
            callback();
        });
    }, function done() {
        cb(null, {android_sender_report: deliveryResults});
    });


};

function chunkArray(arr, chunk) {
    let i, j, tmp = [];
    for (i = 0, j = arr.length; i < j; i += chunk) {
        tmp.push(arr.slice(i, i + chunk));
    }
    return tmp;
}


module.exports = AndroidPush;