'use strict';

const serviceLogger = require('../../services/logger').serviceLogger;
const pusher = require('../../services/pusher/pushService');
const redisWorkerManager = require('../../dbs/redisWorkerManager');
const async = require('async');
const sqlManager = require('../../dbs/sqlManager');

/**
 * Send push message to update free orders list for workers
 * TYPE REQUEST: GET
 * @param  req
 *  req.body:
 *   tenant_id
 *   order_id
 *   sound_on
 *   workers
 * @param res
 */
module.exports = function controller(req, res) {
    serviceLogger('info', "Called method: send_free_order_for_all");
    serviceLogger('info', req.query);
    const answer = '{"result":1}';
    res.write(answer);
    res.end();
    const tenantId = parseInt(req.query.tenant_id);
    const soundOn = parseInt(req.query.sound_on);
    const forAll = parseInt(req.query.for_all) === 1 ? 1 : 0;
    const workers = req.query.workers.split(',');
    let sound = null;
    if (soundOn === 1) {
        sound = "new_free.aiff";
    }
    const settings = {
        title: '',
        message: '',
        contentAvailable: null,
        actionLocKey: null,
        category: null,
        icon: null,
        sound: sound,
        command: 'update_free_orders',
        command_params: {},

    };
    if (Array.isArray(workers) && workers.length > 0) {
        getWorkerDevices(tenantId, workers, forAll, (err, workerDevices) => {
            if (err) {
                serviceLogger('error', err);
            } else {
                if (workerDevices.ios.length > 0) {
                    pusher.sendPush(tenantId, 'ios', workerDevices.ios, "worker",null, settings).then(result => {
                        serviceLogger('info', `ios push result: ${JSON.stringify(result)}`);
                    }).catch(err => {
                        serviceLogger('error', `ios push error: ${JSON.stringify(err)}`);
                    });
                }
                if (workerDevices.android.length > 0) {
                    pusher.sendPush(tenantId, 'android', workerDevices.android, "worker",null, settings).then(result => {
                        serviceLogger('info', `android push result: ${JSON.stringify(result)}`);
                    }).catch(err => {
                        serviceLogger('error', `android push error: ${JSON.stringify(err)}`);
                    });
                }
            }
        });
    } else {
        serviceLogger('error', `workers: empty array`);
    }
};

function getWorkerDevices(tenantId, workerCallsignArr, isforAllWorkers, callback) {
    if (!isforAllWorkers) {
        getOnlineWorkerDevices(tenantId, workerCallsignArr, (err, workerDevices) => {
            if (err) {
                callback(err);
            } else {
                callback(null, workerDevices)
            }
        })
    } else {
        getAllListedWorkerDevices(tenantId, workerCallsignArr, (err, workerDevices) => {
            if (err) {
                callback(err);
            } else {
                callback(null, workerDevices)
            }
        })
    }
}

function getOnlineWorkerDevices(tenantId, workerCallsignArr, resultCb) {
    const workerDevices = {
        'android': [],
        'ios': []
    };
    async.each(workerCallsignArr, (workerCallsign, callback) => {
        redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
            if (err) {
                serviceLogger('error', `Error of getWorker tenanntId: ${tenantId} workerCallsign: ${workerCallsign}`);
                return callback(err);
            } else {
                if (workerData && workerData.worker && workerData.worker.device && workerData.worker.device_token) {
                    const workerDevice = workerData.worker.device;
                    const workerDeviceToken = workerData.worker.device_token;
                    if (typeof workerDevice === "string" && workerDevice.length > 0 && typeof workerDeviceToken === "string" && workerDeviceToken.length > 0) {
                        if (workerDevice === "IOS") {
                            workerDevices.ios.push(workerDeviceToken)
                        } else if (workerDevice === "ANDROID") {
                            workerDevices.android.push(workerDeviceToken);
                        }
                    } else {
                        serviceLogger('error', `Empty workerDevice or workerDeviceToken`);
                    }
                } else {
                    serviceLogger('error', `Empty workerDevice or workerDeviceToken`);
                }
                callback(null, 1);
            }
        })
    }, (err) => {
        if (err) {
            serviceLogger('error', err);
        }
        return resultCb(null, workerDevices);
    });
}


function getAllListedWorkerDevices(tenantId, workerCallsignArr, resultCb) {
    const workerDevices = {
        'android': [],
        'ios': []
    };
    sqlManager.getListedWorkers(tenantId, workerCallsignArr, (err, workers) => {
        if (err) {
            return resultCb(err);
        }
        if (!Array.isArray(workers)) {
            return resultCb('No workers in db');
        }
        for (let worker of workers) {
            if (worker.device && worker.device_token) {
                let workerDevice = worker.device;
                let workerDeviceToken = worker.device_token;
                if (typeof workerDevice === "string" && workerDevice.length > 0 && typeof workerDeviceToken === "string" && workerDeviceToken.length > 0) {
                    if (workerDevice === "IOS") {
                        workerDevices.ios.push(workerDeviceToken)
                    } else if (workerDevice === "ANDROID") {
                        workerDevices.android.push(workerDeviceToken);
                    }
                }
            }
        }
        return resultCb(null, workerDevices)
    });
}



