'use strict'

const NodeCache = require("node-cache");

module.exports = exports = new NodeCache({stdTTL: 600, checkperiod: 60});


