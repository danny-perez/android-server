<?php


namespace app\modules\v1\controllers;

use yii\rest\Controller;

class BaseController extends Controller
{

}