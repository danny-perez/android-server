<?php

namespace app\modules\v1\models;


use app\components\serviceEngine\ServiceEngine;
use app\components\Card;
use app\models\ActiveOrderRepository;
use app\models\ActiveWorkerRepository;
use app\models\CardPayment;
use app\models\Client;
use app\models\ClientCompany;
use app\models\ClientPhone;
use app\models\DefaultSettings;
use app\models\Order as OrderRecordBase;
use app\models\Parking;
use app\models\TenantSetting;
use app\modules\v1\models\exceptions\BlockedCompanyException;
use app\modules\v1\models\exceptions\ForbiddenChangeOrderTimeException;
use app\modules\v1\models\exceptions\ForbiddenChangeWorkerException;
use app\modules\v1\models\exceptions\InvalidAttributeValueException;
use app\modules\v1\models\exceptions\InvalidClientCard;
use app\modules\v1\models\exceptions\InvalidOrderTimeException;
use app\models\OrderStatusRecord as OrderStatusRecord;
use yii\base\ErrorException;
use app\models\OrderHasOption as OrderHasOptionRecord;
use yii\base\InvalidParamException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "{{%order}}".
 *
 * @property integer $order_id
 * @property integer $tenant_id
 * @property integer $worker_id
 * @property integer $city_id
 * @property integer $tariff_id
 * @property integer $client_id
 * @property string  $phone
 * @property integer $user_create
 * @property integer $status_id
 * @property integer $user_modifed
 * @property integer $company_id
 * @property integer $parking_id
 * @property string  $address
 * @property string  $comment
 * @property string  $predv_price
 * @property string  $predv_distance
 * @property string  $predv_time
 * @property string  $device
 * @property string  $order_number
 * @property string  $payment
 * @property integer $show_phone
 * @property string  $create_time
 * @property string  $updated_time
 * @property string  $order_time
 * @property string  $time_to_client
 * @property integer $time_offset
 * @property integer $position_id
 *
 */
class OrderRecord extends OrderRecordBase
{
    const DEVICE_0 = 'DISPATCHER';
    const DEVICE_WORKER = 'WORKER';
    const DEVICE_WEB = 'WEB';
    const PRE_ODRER_TIME = 1800;
    const PICK_UP_TIME = 300;
    const MAP_DATA_TYPE_ADDRESS = 'address';
    const MAP_DATA_TYPE_WORKER = 'worker';
    const MAP_DATA_TYPE_ROUTE = 'route';

    const PAYMENT_CASH = 'CASH';
    const PAYMENT_CORP = 'CORP_BALANCE';
    const PAYMENT_PERSONAL_ACCOUNT = 'PERSONAL_ACCOUNT';
    const PAYMENT_CARD = 'CARD';

    public $additional_option;
    public $pan;

    /**
     * Who is calling.
     * @var string
     */
    public $caller;
    public $order_now;
    public $order_date;
    public $order_hours;
    public $order_minutes;
    public $status_reject;

    public $subject;

    /**
     * Активный заказ или нет.
     * @var bool
     */
    public $isActive = false;
    public $statusRedis;
    public $clientRedis;
    public $cityRedis;
    public $workerRedis;
    public $carRedis;
    public $userCreatedRedis;

    /**
     * Cost data from redis
     * @var array
     */
    public $costData;
    private $pickUp;
    private $arOldAttributes;

    /**
     * @var string
     */
    public $hash;

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            [
                'class'              => TimestampBehavior::className(),
                'createdAtAttribute' => 'create_time',
                'updatedAtAttribute' => 'update_time',
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        return parent::scenarios();
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tariff_id', 'status_id', 'position_id'], 'required'],
            [
                [
                    'tenant_id',
                    'worker_id',
                    'city_id',
                    'tariff_id',
                    'phone',
                    'user_create',
                    'status_id',
                    'user_modifed',
                    'company_id',
                    'parking_id',
                    'order_number',
                    'show_phone',
                    'create_time',
                    'status_time',
                    'order_time',
                    'time_to_client',
                    'predv_time',
                    'client_id',
                    'bonus_payment',
                    'car_id',
                ],
                'integer',
            ],
            [['address', 'comment', 'payment'], 'string'],
            [
                [
                    'show_phone',
                    'additional_option',
                    'order_now',
                    'order_date',
                    'order_hours',
                    'order_minutes',
                    'status_reject',
                    'pan',
                ],
                'safe',
            ],
            [['predv_price', 'predv_distance'], 'number'],
            [['device'], 'string', 'max' => 10],
            [['is_fix'], 'in', 'range' => [0, 1]],
            ['is_fix', 'default', 'value' => '0'],
            ['deny_refuse_order', 'integer'],
            ['deny_refuse_order', 'default', 'value' => 0],
            ['hash', 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'order_id'          => \Yii::t('order', 'Order ID'),
            'tenant_id'         => \Yii::t('order', 'Tenant ID'),
            'worker_id'         => \Yii::t('order', 'Worker'),
            'city_id'           => \Yii::t('order', 'Branch'),
            'tariff_id'         => \Yii::t('order', 'Tariff'),
            'client_id'         => \Yii::t('order', 'Client ID'),
            'user_create'       => \Yii::t('order', 'User Create'),
            'user_modifed'      => \Yii::t('order', 'User modifed'),
            'status_id'         => \Yii::t('order', 'Status'),
            'address'           => \Yii::t('order', 'Address'),
            'comment'           => \Yii::t('order', 'Comment'),
            'predv_price'       => \Yii::t('order', 'Price'),
            'predv_distance'    => \Yii::t('order', 'Preliminary distance'),
            'predv_time'        => \Yii::t('order', 'Preliminary time'),
            'create_time'       => \Yii::t('order', 'Create Time'),
            'device'            => \Yii::t('order', 'Device'),
            'payment'           => \Yii::t('order', 'Payment'),
            'show_phone'        => \Yii::t('order', 'Show client phone to worker'),
            'parking_id'        => \Yii::t('parking', 'Parking'),
            'preliminary_calc'  => \Yii::t('parking', 'Preliminary calculation'),
            'additional_option' => \Yii::t('order', 'Additional options'),
            'order_time'        => \Yii::t('order', 'Order time'),
            'status_time'       => \Yii::t('order', 'Status time'),
            'phone'             => \Yii::t('order', 'Client phone'),
            'bonus_payment'     => \Yii::t('order', 'Bonus payment'),
            'position_id'       => \Yii::t('order', 'Position Id'),
            'summary_cost'      => \Yii::t('order', 'Summary cost'),
            'update_time'       => \Yii::t('order', 'Update time'),
            'deny_refuse_order' => \Yii::t('order', 'Without the possibility of failure'),
            'car_id'            => \Yii::t('order', 'Car Id'),
            'company_id'        => \Yii::t('order', 'Company ID'),
            'is_fix'            => \Yii::t('order', 'offer my price'),
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributes()
    {
        return ArrayHelper::merge(parent::attributes(), ['additional_option', 'pan', 'subject']);
    }

    /**
     * Getting local time.
     *
     * @param integer $time
     *
     * @return integer
     */
    private function getOrderTimestamp($time = null)
    {
        if (is_null($time)) {
            $time = time();
        }

        $offset = $this->getOrderOffset();

        return $offset + $time;
    }

    /**
     * Getting local time offset.
     * @return integer
     */
    private function getOrderOffset()
    {
        return City::getTimeOffset($this->city_id);
    }

    private function isNeedCheckOrderTime()
    {
        return in_array($this->status->status_group, [
                OrderStatus::STATUS_GROUP_NEW,
                OrderStatus::STATUS_GROUP_PRE_ORDER,
            ], false)
            && $this->status_id != OrderStatus::STATUS_OVERDUE
            && $this->status_id != OrderStatus::STATUS_MANUAL_MODE;
    }

    /**
     * Update order status
     */
    private function updateOrderStatus()
    {
        if ($this->status_id === OrderStatus::STATUS_OVERDUE
            && $this->order_time > $this->getOrderTimestamp()
        ) {
            $this->status_id = OrderStatus::STATUS_FREE;
        }

        if ($this->isPreOrder()) {
            if (in_array($this->status_id, [
                OrderStatus::STATUS_NEW,
                OrderStatus::STATUS_NOPARKING,
                OrderStatus::STATUS_FREE,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD,
            ], false)
            ) {
                switch ($this->status_id) {
                    case OrderStatus::STATUS_NEW:
                    case OrderStatus::STATUS_NOPARKING:
                    case OrderStatus::STATUS_FREE:
                        $this->status_id = empty($this->parking_id)
                            ? OrderStatus::STATUS_PRE_NOPARKING : OrderStatus::STATUS_PRE;
                        break;
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT:
                        $this->status_id = OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT;
                        break;
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD:
                        $this->status_id = OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD;
                        break;
                }
            }
        } else {
            if (in_array($this->status_id, [
                OrderStatus::STATUS_PRE,
                OrderStatus::STATUS_PRE_NOPARKING,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD,
            ], false)
            ) {
                switch ($this->status_id) {
                    case OrderStatus::STATUS_PRE:
                    case OrderStatus::STATUS_PRE_NOPARKING:
                        $this->status_id = empty($this->parking_id)
                            ? OrderStatus::STATUS_NOPARKING : OrderStatus::STATUS_NEW;
                        break;
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT:
                        $this->status_id = OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT;
                        break;
                    case OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD:
                        $this->status_id = OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD;
                        break;
                }
            }
        }
    }

    /**
     * @param int $parkingId
     *
     * @return string
     */
    private function getParkingNameById($parkingId)
    {
        return Parking::find()
            ->where(['parking_id' => $parkingId])
            ->select('name')
            ->scalar();
    }

    /**
     * Determine parking and address coordinates
     *
     * @param array $address
     *
     * @return array
     */
    private function determineParkingAndAddressCoords($address)
    {
        $result = [];
        foreach ($address as $key => $value) {
            if (empty($value['lat']) || empty($value['lon'])) {
                $coords       = app()->geocoder->findCoordsByAddress(implode(', ', [
                    $value['city'],
                    $value['street'],
                    $value['house'],
                ]));
                $value['lat'] = $coords['lat'];
                $value['lon'] = $coords['lon'];
            }

            if (empty($value['parking_id'])) {
                $parkingInfo = app()->routeAnalyzer->getParkingByCoords(
                    $this->tenant_id, $this->city_id, $value['lat'], $value['lon'], false);

                if (empty($parkingInfo['error'])) {
                    $value['parking_id'] = (int)$parkingInfo['inside'];
                    $value['parking']    = $this->getParkingNameById($value['parking_id']);

                    if ($key == 'A') {
                        $this->parking_id = $value['parking_id'];
                    }
                }
            } elseif ($key == 'A') {
                $this->parking_id = $value['parking_id'];
            }
            $result[$key] = $value;
        }

        return $result;
    }

    /**
     * Is active current order in the redis
     * @return bool
     */
    private function isActiveOrder()
    {
        $order           = $this->getActiveOrder();
        $completedStatus = [OrderStatus::STATUS_GROUP_COMPLETED, OrderStatus::STATUS_GROUP_REJECTED];

        return isset($order)
            && isset($order['status']['status_group'])
            && !in_array($order['status']['status_group'], $completedStatus);
    }

    /**
     * Is address was changed
     *
     * @param array $oldAddress
     * @param array $newAddress
     *
     * @return bool
     */
    private function isAddressChanged($oldAddress, $newAddress)
    {
        $addressFields = [
            'city',
            'street',
            'house',
            'housing',
            'parking',
            'parking_id',
            'lat',
            'lon',
        ];

        if (count($oldAddress) != count($newAddress)) {
            return true;
        }

        foreach ($oldAddress as $key => $value) {
            foreach ($addressFields as $field) {
                $oldValue = isset($oldAddress[$key][$field]) ? $oldAddress[$key][$field] : null;
                $newValue = isset($newAddress[$key][$field]) ? $newAddress[$key][$field] : null;

                if ($oldValue != $newValue) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check changed attributes
     * @throws InvalidAttributeValueException
     * @throws \yii\base\InvalidConfigException
     */
    private function checkChangedAttributes()
    {
        $status    = OrderStatusRecord::findOne($this->getOldAttribute('status_id'));
        $newStatus = OrderStatusRecord::findOne($this->getAttribute('status_id'));

        $checkAttributes = [
            'order_number',
            'order_time',
            'city_id',
            'phone',
            'client_id',
            'worker_id',
            'address',
            'parking_id',
            'comment',
            'tariff_id',
            'payment',
            'predv_price',
            'additional_option',
            'pan',
        ];

        if ($status instanceof OrderStatusRecord
            && $newStatus instanceof OrderStatusRecord
            && !empty($checkAttributes)
        ) {
            /* @var $manager OrderChangeRuleManager */
            $manager = \Yii::createObject(OrderChangeRuleManager::class);

            foreach ($checkAttributes as $attribute) {
                switch ($attribute) {
                    case 'address':
                        $error = $this->isAddressChanged(
                                unserialize($this->getOldAttribute('address')),
                                unserialize($this->address))
                            && !$manager->canUpdateAttribute($status, $newStatus, $attribute);
                        break;
                    case 'additional_option':
                        $error = is_array($this->additional_option)
                            && !$manager->canUpdateAttribute($status, $newStatus, $attribute);
                        break;
                    default:
                        $error = $this->getOldAttribute($attribute) != $this->getAttribute($attribute)
                            && !$manager->canUpdateAttribute($status, $newStatus, $attribute);
                }

                if ($error) {
                    throw new InvalidAttributeValueException(
                        t('order', 'It is forbidden to edit the value of "{attribute}"', [
                            'attribute' => $this->getAttributeLabel($attribute),
                        ]));
                }
            }
        }
    }

    /**
     * Check order status
     * @throws InvalidAttributeValueException
     * @throws \yii\base\InvalidConfigException
     */
    private function checkOrderStatus()
    {
        if ($this->getOldAttribute('status_id') != $this->getAttribute('status_id')) {
            $newStatus = OrderStatusRecord::findOne($this->getAttribute('status_id'));
            $oldStatus = OrderStatusRecord::findOne($this->getOldAttribute('status_id'));

            /* @var $manager OrderChangeRuleManager */
            $manager = \Yii::createObject(OrderChangeRuleManager::class);

            if (!$manager->canUpdateStatus($oldStatus, $newStatus)) {
                throw new InvalidAttributeValueException(
                    t('order', 'You can not change the order status to "{status}"', [
                        'status' => t('status_event', t('order', $newStatus->name)),
                    ]));
            }
        }
    }

    /**
     * Check attribute `worker_id`
     * @throws \app\modules\v1\models\exceptions\ForbiddenChangeWorkerException
     */
    private function checkWorker()
    {
        $newWorkerId = $this->getAttribute('worker_id');
        $oldWorkerId = $this->getOldAttribute('worker_id');
        $statusId    = $this->getAttribute('status_id');

        if (empty($newWorkerId) && in_array($statusId, [
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD,
            ], false)
        ) {
            throw new ForbiddenChangeWorkerException(
                t('order', 'You need select the worker'));
        }

        if ($newWorkerId == $oldWorkerId) {
            return;
        }

        if (empty($oldWorkerId) && !empty($newWorkerId)) {
            if (!in_array($statusId, [
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD,
            ], false)
            ) {
                throw new ForbiddenChangeWorkerException(
                    t('order', 'To assign worker to order select action "Assign a worker"'));
            }

            $nodeApi = new ServiceEngine();

            if (!$nodeApi->canOfferOrderToWorker(
                $this->tenant_id, $this->order_id, $this->worker->callsign)
            ) {
                throw new ForbiddenChangeWorkerException(
                    t('order', 'The worker can not accept the order offer'));
            }
        } else {
            throw new ForbiddenChangeWorkerException(
                t('order', 'You need to freeze order to update worker'));
        }
    }

    private function setClientId()
    {
        $client = $this->getClientByPhone(
            $this->phone, $this->tenant_id, $this->city_id);
        if (empty($client)) {
            throw new ErrorException('Не удалось создать клиента с параметрами: phone:' . $this->phone .
                '; tenant_id: ' . $this->tenant_id . '; city_id: ' . $this->city_id);
        }
        $this->client_id = $client->client_id;
    }

    private function getPreparedAddress()
    {
        return serialize($this->determineParkingAndAddressCoords(
            $this->addressFilter($this->address)));
    }

    private function getNextOrderNumber()
    {
        return $this->getLastOrderNumber() + 1;
    }

    private function getTimeOffset()
    {
        return City::getTimeOffset($this->city_id);
    }

    private function getStatusTime()
    {
        return $this->getOldAttribute('status_id') != $this->status_id ? time() : $this->status_time;
    }

    private function isInvalidOrderTime()
    {
        return $this->isNeedCheckOrderTime() && $this->order_time < $this->getOrderTimestamp();
    }


    /**
     * @throws BlockedCompanyException
     */
    private function checkValidCompany()
    {
        $company = ClientCompany::findOne($this->company_id);

        if ($company !== null && (int)$company->block === 1) {
            throw new BlockedCompanyException(t('order', 'Company is blocked.'));
        }
    }

    /**
     * @throws InvalidClientCard
     */
    private function checkValidCard()
    {
        /** @var Card $card */
        $card = app()->get('card');

        if (!$card->isValid($this->tenant_id, $this->client_id, $this->pan)) {
            throw new InvalidClientCard();
        }
    }


    /**
     * @param bool $insert
     *
     * @return bool
     * @throws BlockedCompanyException
     * @throws InvalidAttributeValueException
     * @throws InvalidParamException
     * @throws ForbiddenChangeOrderTimeException
     * @throws \Exception
     */
    public function beforeSave($insert)
    {
        parent::beforeSave($insert);

        if (!$insert && !$this->isActiveOrder()) {
            throw new \Exception(t('order', 'You can not edit the completed order'));
        }

        // search/create client by phone number
        if (empty($this->client_id) || $this->isAttributeChanged('phone')) {
            $this->setClientId();
        }

        if (strpos($this->payment, self::PAYMENT_CORP) !== false) {
            $this->payment = self::PAYMENT_CORP;

            $this->checkValidCompany();
        }

        if (!empty($this->pan)) {
            $this->checkValidCard();
        }

        if (!$this->validate(['tariff_id'])) {
            throw new InvalidAttributeValueException(implode(', ', $this->getFirstErrors()));
        }

        if (is_array($this->address)) {
            $this->address = $this->getPreparedAddress();
        }

        if ($insert) {
            $this->order_number = $this->getNextOrderNumber();

            if (!in_array($this->status_id, [
                OrderStatus::STATUS_NEW,
                OrderStatus::STATUS_FREE,
                OrderStatus::STATUS_MANUAL_MODE,
            ], false)
            ) {
                $this->status_id = OrderStatus::STATUS_NEW;
            }
        }

        $this->order_time = $this->getOrderTime();
        if ($this->isInvalidOrderTime()) {
            $statuses = array_merge(OrderStatus::getStatusWithPickUpTime(), [
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_ORDER_HARD,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_SOFT,
                OrderStatus::STATUS_WORKER_ASSIGNED_AT_PRE_ORDER_HARD,
            ]);
            if (in_array($this->status_id, $statuses, false)) {
                // need for generate current time in method getOrderTime
                $this->order_time = null;
                $this->order_time = $this->getOrderTime();
            } else {
                throw new InvalidOrderTimeException(t('order', 'Order time is incorrect'));
            }
        }

        $this->updateOrderStatus();

        $this->status_time = $this->getStatusTime();

        $this->arOldAttributes = $this->getOldAttributes();

        $this->setCurrencyId();

        $this->time_offset = $this->getTimeOffset();

        $this->checkWorker();

        if (!$insert) {
            $this->checkOrderStatus();
            $this->checkChangedAttributes();
        }

        return true;
    }

    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);

        $isAddOptionsChanged = true;
        if (!$insert) {
            if (is_array($this->additional_option)) {
                OrderHasOptionRecord::deleteAll(['order_id' => $this->order_id]);
            } else {
                $isAddOptionsChanged = false;
            }

            //Формирование лога обновлений
            //Сравниваем старые и новые значения атрибутов, получаеем новые значения
            $newAttributes = $this->getAttributes();
            // через array_diff нельзя сравнивать вложенные массивы идет явное приведение типа к сроке (string)value
            unset($newAttributes['additional_option']);
            $order_diff = array_diff_assoc($newAttributes, $this->arOldAttributes);

            //Проверяем изменения доп.опций
            if ($isAddOptionsChanged) {
                $order_diff['additional_option'] = serialize($this->additional_option);
            }

            //Все изменения логируем
            OrderChangeData::userLog($this->order_id, $this->tenant_id, $this->subject, $order_diff);
            //-----------------------------------
        }

        //Сохранение доп. пожеланий
        if ($isAddOptionsChanged) {
            OrderHasOption::manySave($this->additional_option, $this->order_id);
        }

        if (!empty($this->pan)) {
            CardPayment::deleteAll(['order_id' => $this->order_id]);
            (new CardPayment(['order_id' => $this->order_id, 'pan' => $this->pan]))->save();
        }

        //Сохранение заказа в редис
        if (!array_key_exists('status_id', $changedAttributes)
            || $changedAttributes['status_id'] != OrderStatus::STATUS_COMPLETED_NOT_PAID
        ) {
            $redisSaveResult = $this->saveActiveOrder();
            if (($redisSaveResult != 1 && $insert) || ($redisSaveResult != 0 && !$insert)) {
                throw new ErrorException('Error to save order to redis');
            }
        }

        //Кидаем заказ в распределение
        if ($insert) {
            $nodeApiComponent = new ServiceEngine();
            $resultSendOrder  = $nodeApiComponent->neworderAuto($this->order_id, $this->tenant_id);
            if (!$resultSendOrder) {
                (new ActiveOrderRepository(['tenantId' => $this->tenant_id]))->delete($this->order_id);
                throw new ErrorException('Error to save order to nodejs');
            }
        }
    }

    public function getOrderCostData()
    {
        $orderIds = OrderHasOption::getOptionIds($this->order_id);

        $taxiRouteAnalyzer = app()->routeAnalyzer;
        $routeCostInfo     = $taxiRouteAnalyzer->analyzeRoute($this->tenant_id, $this->city_id,
            unserialize($this->address),
            $orderIds, $this->tariff_id, date('d.m.Y H:i:s', $this->order_time));

        if (empty($routeCostInfo)) {
            throw new ErrorException('No $routeCostInfo in OrderRecord::getOrderCostData()');
        }

        $costData = [];
        $result   = (array)$routeCostInfo;

        if (!isset($result['tariffInfo']) || empty($result['tariffInfo'])) {
            throw new ErrorException('No tariffInfo in OrderRecord::getOrderCostData()');
        }

        $costData['additionals_cost']  = isset($result['additionalCost']) ? (string)$result['additionalCost'] : null;
        $costData['summary_time']      = isset($result['summaryTime']) ? (string)$result['summaryTime'] : null;
        $costData['summary_distance']  = isset($result['summaryDistance']) ? (string)$result['summaryDistance'] : null;
        $costData['city_time']         = isset($result['cityTime']) ? (string)$result['cityTime'] : null;
        $costData['city_distance']     = isset($result['cityDistance']) ? (string)$result['cityDistance'] : null;
        $costData['city_cost']         = isset($result['cityCost']) ? (string)$result['cityCost'] : null;
        $costData['out_city_time']     = isset($result['outCityTime']) ? (string)$result['outCityTime'] : null;
        $costData['out_city_distance'] = isset($result['outCityDistance']) ? (string)$result['outCityDistance'] : null;
        $costData['out_city_cost']     = isset($result['outCityCost']) ? (string)$result['outCityCost'] : null;

        if ($this->is_fix == 1) {
            $costData['summary_cost'] = $this->predv_price;
            $costData['is_fix']       = $this->is_fix;
        } else {
            $costData['is_fix']       = empty($result['isFix']) ? 0 : 1;
            $costData['summary_cost'] = isset($result['summaryCost']) ? (string)$result['summaryCost'] : null;
        }
        $costData['tariffInfo']           = $result['tariffInfo'];
        $costData['start_point_location'] = isset($result['startPointLocation']) ? (string)$result['startPointLocation'] : null;

        return $costData;
    }

    public function afterFind()
    {
        parent::afterFind();

        $this->address = unserialize($this->address);
        if ($this->address === false) {
            $this->address = [
                'A' => [
                    'city'       => '',
                    'city_id'    => '',
                    'street'     => '',
                    'house'      => '',
                    'housing'    => '',
                    'porch'      => '',
                    'apt'        => '',
                    'parking_id' => '',
                    'lat'        => '',
                    'lon'        => '',
                ],
            ];
        }
    }

    /**
     * Find client by phone number and create new client if not found
     *
     * @param string $phone
     * @param int    $tenantId
     * @param int    $cityId
     *
     * @return Client|bool
     */
    private function getClientByPhone($phone, $tenantId, $cityId)
    {
        $client = Client::find()
            ->joinWith('clientPhones', false)
            ->where(['tenant_id' => $tenantId, 'value' => $phone])
            ->one();

        if (empty($client)) {
            $transaction = app()->db->beginTransaction();
            try {
                $client = new Client([
                    'tenant_id' => $tenantId,
                    'city_id'   => $cityId,
                    'phone'     => [$phone],
                ]);

                $client->save();

                $clientPhone = new ClientPhone([
                    'client_id' => $client->client_id,
                    'value'     => $phone,
                ]);

                if ($clientPhone->save()) {
                    $transaction->commit();
                } else {
                    $transaction->rollBack();

                    return false;
                }
            } catch (\Exception $exc) {
                $transaction->rollBack();

                return false;
            }
        }

        return $client;
    }

    public function isPreOrder()
    {
        $pre_order_time = TenantSetting::getSettingValue($this->tenant_id, 'PRE_ORDER', $this->city_id,
            $this->position_id);
        $pre_order_time = $pre_order_time * 60;

        if (empty($pre_order_time)) {
            $pre_order_time = self::PRE_ODRER_TIME;
        }

        $now = $this->getOrderTimestamp();

        return ($this->getOrderTime() - $now) >= $pre_order_time;
    }

    /**
     * Getting last order number.
     * @return false|null|string
     */
    private function getLastOrderNumber()
    {
        return (new Order(['tenantId' => $this->tenant_id]))->getLastOrderNumber();
    }

    private function addressFilter(array $address)
    {
        $index           = 0;
        $filteredAddress = [];
        $currentKey      = 'A';

        $maxNumberOfAddressPoints = DefaultSettings::getSetting(
            DefaultSettings::SETTING_MAX_NUMBER_OF_ADDRESS_POINTS, 0);

        foreach ($address as $key => $value) {
            if ($index >= $maxNumberOfAddressPoints) {
                break;
            }

            if ($value['lat'] && $value['lon']) {
                $filteredAddress[$currentKey] = $address[$key];
                $currentKey++;
                $index++;
            }
        }

        return $filteredAddress;
    }

    /**
     * @return int
     */
    private function getOrderTime()
    {
        if (!empty($this->order_time)) {
            return $this->order_time;
        }

        if (in_array($this->status_id, OrderStatus::getStatusWithPickUpTime())) {
            return $this->getOrderTimestamp() + $this->getPickUp();
        }

        return $this->getOrderTimestamp();
    }

    /**
     * Время подачи авто.
     * @return integer Time in seconds.
     */
    private function getPickUp()
    {
        if (empty($this->pickUp)) {
            $this->pickUp = TenantSetting::getSettingValue($this->tenant_id, 'PICK_UP', $this->city_id,
                $this->position_id);

            if (empty($this->pickUp)) {
                $this->pickUp = self::PICK_UP_TIME;
            }
        }

        return $this->pickUp;
    }

    /**
     * Saving order to Redis
     * @return mixed
     */
    public function saveActiveOrder()
    {
        $costData = $this->getOrderCostData();
        $tariffId = isset($costData["tariffInfo"]["tariffDataCity"]["tariff_id"]) ? $costData["tariffInfo"]["tariffDataCity"]["tariff_id"] : null;
        $order    = self::find()
            ->where([
                'order_id' => $this->order_id,
            ])
            ->with([
                'status',
                'tariff',
                'tariff.class'              => function (ActiveQuery $query) {
                    $query->select(['class_id', 'class']);
                },
                'client'                    => function (ActiveQuery $query) {
                    $query->select(['client_id', 'last_name', 'name', 'second_name', 'lang']);
                },
                'userCreated'               => function (ActiveQuery $query) {
                    $query->select(['user_id', 'last_name', 'name', 'second_name']);
                },
                'options.additionalOptions' => function (ActiveQuery $query) use ($tariffId) {
                    $query->select(['id', 'additional_option_id', 'price'])->where([
                        'tariff_id'   => $tariffId,
                        'tariff_type' => "CURRENT",
                    ]);
                },
                'tenant'                    => function (ActiveQuery $query) {
                    $query->select(['domain']);
                },
                'worker',
            ])
            ->asArray()
            ->one();

        $order['tenant_login'] = $order['tenant']['domain'];
        $order['costData']     = $costData;

        if (!empty($order['worker'])) {
            $workerData = (new ActiveWorkerRepository(['tenantId' => $this->tenant_id]))->getOne($order['worker']['callsign']);
            if (!empty($workerData["worker"])) {
                $order["worker"] = $workerData["worker"];
            }
            if ($workerData["position"] && $workerData["position"]["has_car"]) {
                $order["car_id"] = $workerData["car"]["car_id"];
                $order["car"]    = $workerData["car"];
            }
        }

        if (!$this->isNewRecord) {
            $orderOldData                         = $this->getActiveOrder();
            $order['status']['last_status_id']    = $orderOldData['status']['last_status_id'];
            $order['status']['last_status_group'] = $orderOldData['status']['last_status_group'];
            if (isset($orderOldData['settings'])) {
                $order['settings'] = $orderOldData['settings'];
            }
            if (isset($orderOldData['server_id'])) {
                $order['server_id'] = $orderOldData['server_id'];
            }
            if (isset($orderOldData['process_id'])) {
                $order['process_id'] = $orderOldData['process_id'];
            }
            if (isset($orderOldData['offered_workers_list'])) {
                $order['offered_workers_list'] = $orderOldData['offered_workers_list'];
            }

            if (array_key_exists('originally_preorder', $orderOldData)) {
                $order['originally_preorder'] = $orderOldData['originally_preorder'];
            }
        }

        $orderSerialized = serialize($order);

        return (new ActiveOrderRepository(['tenantId' => $this->tenant_id]))->set($this->order_id, $orderSerialized);
    }

    /**
     * Return waiting time, when worker wait for free.
     * @return integer Time in seconds.
     */
    public function getWorkerWaitingTime()
    {
        $waiting_time = 0;

        if (empty($this->costData)) {
            $order = $this->getActiveOrder();

            if (!empty($order['costData'])) {
                $this->costData = $order['costData'];
            }
        }

        $tariffAreaKey        = isset($this->costData['start_point_location']) && $this->costData['start_point_location'] == 'in' ?
            'tariffDataCity' : 'tariffDataTrack';
        $tariffWaitingTimeKey = isset($this->costData['tariffInfo']['isDay']) && $this->costData['tariffInfo']['isDay'] ?
            'wait_time_day' : 'wait_time_night';

        if (isset($this->costData['tariffInfo'][$tariffAreaKey][$tariffWaitingTimeKey])) {
            $waiting_time = $this->costData['tariffInfo'][$tariffAreaKey][$tariffWaitingTimeKey];
        }

        return $waiting_time * 60;
    }

    /**
     * Return active order from redis.
     * @return array
     */
    public function getActiveOrder()
    {
        return (new ActiveOrdersProvider(['tenantId' => $this->tenant_id]))->getOne($this->order_id);
    }

    public function getDeviceName()
    {
        switch ($this->device) {
            case self::DEVICE_0:
                $name = t('order', 'Dispatcher');
                break;
            case 'IOS':
                $name = 'IOS';
                break;
            case 'ANDROID':
                $name = 'Android';
                break;
            case 'WORKER':
                $name = t('order', 'Border');
                break;
            default :
                $name = '';
        }

        return $name;
    }

    /**
     * Getting order address
     *
     * @param int $orderId
     *
     * @return array
     */
    public static function getOrderAddress($orderId)
    {
        return self::findOne($orderId)->address;
    }

    public function getFormatStreet($point = 'A')
    {
        $street_name = $this->address[$point]['street'] . ' ' . $this->address[$point]['house'];

        if (!empty($this->address[$point]['housing'])) {
            $street_name .= ' ' . t('order', 'b.') . ' ' . $this->address[$point]['housing'];
        }

        return trim($street_name);
    }

    private function setCurrencyId()
    {
        $this->currency_id = TenantSetting::getSettingValue(
            $this->tenant_id, TenantSetting::CURRENCY_TYPE, $this->city_id);
    }
}
