<?php


namespace app\modules\v1\models;


use yii\base\NotSupportedException;

class OrderUpdateEvent
{
    const OPERATOR_SERVICE = 'operator_service';
    const WORKER_SERVICE = 'worker_service';
    const CLIENT_SERVICE = 'client_service';

    /**
     * Update the order
     *
     * @param array $data
     *
     * @return array
     * @throws NotSupportedException
     */
    public function execute(array $data)
    {
        $updaterConfig = [
            'orderId'    => $data['order_id'],
            'updateTime' => $data['last_update_time'],
            'uuid'       => $data['uuid'],
            'tenantId'   => $data['tenant_id'],
            'lang'       => $data['lang'],
        ];

        $service = $data['sender_service'];

        switch ($service) {
            case self::OPERATOR_SERVICE:
                $object = new OrderOperatorUpdater($updaterConfig);
                break;
            case self::WORKER_SERVICE:
                $object = new OrderWorkerUpdater($updaterConfig);
                break;
            case self::CLIENT_SERVICE:
                $object = new OrderClientUpdater($updaterConfig);
                break;
            default:
                throw new NotSupportedException('The service "' . $service . '" is not supported');
        }

        $updateParams = $this->getChangedParams($data);

        return $object->update($updateParams);
    }

    /**
     * @param array $data
     *
     * @return array
     */
    private function getChangedParams(array $data)
    {
        $changedParams = $data['params'];

        switch ($data['sender_service']) {
            case self::OPERATOR_SERVICE:
                $changedParams['user_modifed'] = $data['change_sender_id'];
                $changedParams['subject']      = 'disputcher_' . $data['change_sender_id'];
                break;

            case self::WORKER_SERVICE:
                $changedParams['worker_login'] = $data['change_sender_id'];
                break;

            case self::CLIENT_SERVICE:
                $changedParams['subject'] = 'client_' . $data['change_sender_id'];
                break;
        }

        return $changedParams;
    }
}