<?php

namespace app\modules\v1\models\workers\car;

use Yii;

/**
 * This is the model class for table "tbl_car_has_option".
 *
 * @property integer   $car_id
 * @property integer   $option_id
 *
 * @property Car       $car
 * @property CarOption $option
 */
class CarHasOption extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tbl_car_has_option';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['car_id', 'option_id'], 'required'],
            [['car_id', 'option_id'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'car_id'    => 'Car ID',
            'option_id' => 'Option ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCar()
    {
        return $this->hasOne(Car::className(), ['car_id' => 'car_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOption()
    {
        return $this->hasOne(CarOption::className(), ['option_id' => 'option_id']);
    }
}
