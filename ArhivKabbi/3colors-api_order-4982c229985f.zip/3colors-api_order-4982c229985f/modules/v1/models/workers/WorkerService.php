<?php

namespace app\modules\v1\models\workers;

use app\models\Worker;
use app\modules\v1\models\workers\worker\WorkerShift;
use yii\base\Object;

/**
 * Class WorkerService
 * @package app\modules\v1\models\workers
 */
class WorkerService extends Object
{

    /**
     * Получение исполнителя из редиса
     *
     * @param string $tenantId
     * @param string $workerCallsign
     *
     * @return array|false
     */
    public function getWorkerFromRedis($tenantId, $workerCallsign)
    {
        $workerData = \Yii::$app->redis_workers
            ->executeCommand('hget', [$tenantId, $workerCallsign]);
        $workerData = unserialize($workerData);

        if (!empty($workerData)) {
            return $workerData;
        } else {
            return false;
        }
    }

    /**
     * Save worker to redis
     *
     * @param int   $tenantId
     * @param int   $workerCallsign
     * @param array $worker
     *
     * @return bool
     */
    public function saveWorkerToRedis($tenantId, $workerCallsign, $worker)
    {
        $workerData = serialize($worker);
        $result     = \Yii::$app->redis_workers->executeCommand(
            'hset', [$tenantId, $workerCallsign, $workerData]);

        return $result == 0 || $result == 1;
    }

    /**
     * @param int $tenantId
     * @param int $workerCallsign
     *
     * @return array|null|\yii\db\ActiveRecord
     *
     */
    public function getLastShift($tenantId, $workerCallsign)
    {
        $workerId = Worker::find()
            ->select(['worker_id'])
            ->where([
                'tenant_id' => $tenantId,
                'callsign'  => $workerCallsign,
            ])
            ->scalar();

        return WorkerShift::find()
            ->where([
                'worker_id' => $workerId,
            ])
            ->orderBy(['start_work' => SORT_DESC])
            ->limit(1)
            ->one();
    }

}