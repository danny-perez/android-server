<?php


namespace app\modules\v1\models;


use app\modules\v1\models\workers\WorkerSetOrderStatus;

class OrderWorkerUpdater extends OrderUpdaterBase
{
    public function update($data)
    {
        $result = (new WorkerSetOrderStatus())->update($this->orderId, $this->tenantId, $data, $this->updateTime,
            $this->lang, $this->uuid);

        return $this->getResponse($result['code'], $result['info'],
            isset($result['result']) ? $result['result'] : null);
    }
}