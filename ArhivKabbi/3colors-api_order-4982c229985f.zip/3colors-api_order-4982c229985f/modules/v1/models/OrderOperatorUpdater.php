<?php


namespace app\modules\v1\models;


class OrderOperatorUpdater extends OrderUpdaterBase
{
    public function update($data)
    {
        $result = (new Order())->update($this->orderId, $this->tenantId, $data, $this->updateTime, $this->lang);

        return $this->getResponse($result['code'], $result['info'], 1);
    }
}