<?php


namespace app\modules\v1\models\interfaces;


interface OrderDataProviderInterface
{
    /**
     * @return array
     */
    public function getList();

    /**
     * @return int
     */
    public function getCounts();
}