<?php

namespace app\modules\v1\models\client;

use app\components\ClientErrorCode;
use app\models\ActiveOrderRepository;
use app\models\OrderStatusRecord;
use app\modules\v1\models\exceptions\BlockedCompanyException;
use app\modules\v1\models\exceptions\InvalidClientCard;
use app\modules\v1\models\OrderRecord;
use app\modules\v1\models\OrderStatus;
use yii\base\Object;
use yii\helpers\ArrayHelper;

/**
 * Class ClientUpdateOrder
 * @package app\modules\v1\models\workers
 */
class ClientUpdateOrder extends Object
{
    /**
     * @param       $errorCode
     * @param array $info
     *
     * @return array
     */
    private function getPreparedResponse($errorCode, array $info = [])
    {
        return ArrayHelper::merge(ClientErrorCode::getErrorData($errorCode), [
            'result' => $info,
        ]);
    }

    /**
     * Reject order
     *
     * @param int    $tenantId
     * @param int    $orderId
     * @param array  $data
     * @param int    $updateTime
     * @param string $lang
     *
     * @return array
     */
    private function rejectOrder($tenantId, $orderId, $data, $updateTime, $lang)
    {
        $statusNewId = (int)$data['status_id'];

        // Инфа по заказу из редиса
        $activeOrderRepository = new ActiveOrderRepository(['tenantId' => $tenantId]);
        $orderDataRedis        = $activeOrderRepository->getOne($orderId);

        if (empty($orderDataRedis)) {
            return $this->getPreparedResponse(ClientErrorCode::EMPTY_DATA_IN_DATABASE, ['reject_result' => 0]);
        }

        $statusGroup = (string)$orderDataRedis['status']['status_group'];
        if (in_array($statusGroup, [
            OrderStatus::STATUS_GROUP_NEW,
            OrderStatus::STATUS_GROUP_CAR_ASSIGNED,
            OrderStatus::STATUS_GROUP_PRE_ORDER,
        ])) {
            $orderDataMysql = Order::findOne($orderId);
            if (empty($orderDataMysql)) {
                return $this->getPreparedResponse(ClientErrorCode::EMPTY_DATA_IN_DATABASE, ['reject_result' => 0]);
            }

            $orderDataMysql->status_id = $statusNewId;
            if ($orderDataMysql->save()) {
                $statusData = OrderStatusRecord::findOne($statusNewId);

                $orderDataMysql->status_id   = $statusNewId;
                $orderDataMysql->status_time = time();

                $orderDataRedis['status']['status_id']       = $statusData->status_id;
                $orderDataRedis['status']['name']            = $statusData->name;
                $orderDataRedis['status']['status_group']    = $statusData->status_group;
                $orderDataRedis['status']['dispatcher_sees'] = $statusData->dispatcher_sees;
                $orderDataRedis['status_id']                 = $statusData->status_id;
                $orderDataRedis['status_time']               = time();

                $activeOrderRepository->set($orderId, serialize($orderDataRedis));

                return $this->getPreparedResponse(ClientErrorCode::OK, ['reject_result' => 1]);
            } else {
                return $this->getPreparedResponse(ClientErrorCode::INTERNAL_ERROR, ['reject_result' => 0]);
            }
        }

        switch ($statusGroup) {
            case OrderStatus::STATUS_GROUP_REJECTED :
                return $this->getPreparedResponse(ClientErrorCode::ORDER_IS_REJECTED, ['reject_result' => 0]);
            case OrderStatus::STATUS_GROUP_COMPLETED :
                return $this->getPreparedResponse(ClientErrorCode::ORDER_IS_COMPLETED, ['reject_result' => 0]);
            default:
                return $this->getPreparedResponse(ClientErrorCode::OK, ['reject_result' => 0]);
        }
    }


    /**
     * Update
     *
     * @param int    $orderId
     * @param int    $tenantId
     * @param array  $data
     * @param int    $updateTime
     * @param string $lang
     * @param string $uuid
     *
     * @return array
     */
    public function update($tenantId, $orderId, $data, $updateTime, $lang, $uuid = '')
    {
        if (isset($data['status_id']) && in_array($data['status_id'], OrderStatus::getRejectedStatusIdByClient())) {
            return $this->rejectOrder($tenantId, $orderId, $data, $updateTime, $lang);
        } else {
            return $this->updateOrder($orderId, $tenantId, $data, $updateTime, $lang, $uuid);
        }
    }


    private function updateOrder($orderId, $tenantId, $data, $lastUpdateTime, $lang, $uuid = '')
    {

        if (!empty($lang)) {
            \Yii::$app->language = $lang;
        }

        $order          = $this->getOrder($orderId, $tenantId);
        $updateTime     = $order->update_time;
        $order->subject = $data['subject'];


        if ($lastUpdateTime != $updateTime) {
            return $this->getPreparedResponse(ClientErrorCode::INTERNAL_ERROR);
        }

        if (in_array($order->status_id, OrderStatus::getFinishedStatusId())
            || $order->status_id === OrderStatus::STATUS_WAITING_FOR_PAYMENT
        ) {
            return $this->getPreparedResponse(ClientErrorCode::INTERNAL_ERROR);
        }

        if (isset($data['payment'])) {

            switch ($data['payment']) {

                case OrderRecord::PAYMENT_CORP:
                    if (!isset($data['company_id'])) {
                        return $this->getPreparedResponse(ClientErrorCode::MISSING_INPUT_PARAMETER);
                    }
                    $order->company_id = $data['company_id'];
                    break;

                case OrderRecord::PAYMENT_CARD:
                    if (isset($data['pan'])) {
                        $order->pan = $data['pan'];
                    }
                    break;

                case OrderRecord::PAYMENT_CASH:
                case OrderRecord::PAYMENT_PERSONAL_ACCOUNT:
                    break;

                default:
                    return $this->getPreparedResponse(ClientErrorCode::BAD_PARAM);
            }

            $order->payment = $data['payment'];
        }

        if (isset($data['address'])) {
            if (!is_array($data['address'])) {
                $data['address'] = unserialize($data['address']);
            }
            $data['address']['A'] = $order->address['A'];
            $order->address       = $data['address'];

            if(isset($data['predv_price'])) {
                $order->predv_price = $data['predv_price'];
            }
            if(isset($data['predv_distance'])) {
                $order->predv_distance = $data['predv_distance'];
            }
            if(isset($data['predv_time'])) {
                $order->predv_time = $data['predv_time'];
            }
        }

        $transaction = app()->getDb()->beginTransaction();
        try {
            if (!$order->save(false)) {
                $transaction->rollBack();

                \Yii::error($order->getErrors());
                \Yii::error('Ошибка сохранения заказа', 'order');

                return $this->getPreparedResponse(ClientErrorCode::INTERNAL_ERROR);
            } else {
                $transaction->commit();

                return $this->getPreparedResponse(ClientErrorCode::OK);
            }

        } catch (BlockedCompanyException $ex) {
            $transaction->rollBack();
            return $this->getPreparedResponse(ClientErrorCode::BAD_PARAM);

        } catch (InvalidClientCard $ex) {
            $transaction->rollBack();
            return $this->getPreparedResponse(ClientErrorCode::INVALID_PAN);

        } catch (\Exception $ex) {
            $transaction->rollBack();

            return $this->getPreparedResponse(ClientErrorCode::INTERNAL_ERROR);
        }
    }

    /**
     * @param int $orderId
     * @param int $tenantId
     *
     * @return array|null|\yii\db\ActiveRecord|OrderRecord
     */
    private function getOrder($orderId, $tenantId)
    {
        return OrderRecord::findOne(['order_id' => $orderId, 'tenant_id' => $tenantId]);
    }
}