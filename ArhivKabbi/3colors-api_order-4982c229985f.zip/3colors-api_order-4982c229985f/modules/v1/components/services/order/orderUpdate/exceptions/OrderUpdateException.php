<?php

namespace app\modules\v1\components\services\order\orderUpdate\exceptions;


class OrderUpdateException extends \Exception
{

}