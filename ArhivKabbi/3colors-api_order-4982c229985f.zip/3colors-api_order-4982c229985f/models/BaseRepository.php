<?php


namespace app\models;


use yii\base\Object;

class BaseRepository extends Object
{
    public $tenantId;
}