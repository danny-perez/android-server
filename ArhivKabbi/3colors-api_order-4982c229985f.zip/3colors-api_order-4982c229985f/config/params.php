<?php

return [
    'service.engine.url'   => getenv('SERVICE_ENGINE_URL'),
    'saveOrder.retryCount' => 5,

    'version' => require __DIR__ . '/version.php',
];
