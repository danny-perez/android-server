<?php

$basePath = dirname(__DIR__);
\Yii::setAlias('logger', $basePath . '/components/logger');
\Yii::setAlias('healthCheck', $basePath . '/components/healthCheck');

\logger\ApiLogger::setupStartTimeForStatistic();