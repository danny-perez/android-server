<?php


namespace app\components;


use yii\base\Object;

class OrderError extends Object
{
    const NO_RESULT = 0;
    const SUCCESS = 100;
    const ERROR_SAVING = 101;
    const INVALID_ORDER_TIME = 102;
    const OLD_DATA = 103;
    const FORBIDDEN_CHANGE_ORDER_TIME = 104;
    const INVALID_VALUE = 105;
    const FORBIDDEN_CHANGE_WORKER = 106;
    const INTERNAL_ERROR = 107;
    const COMPLETE_ORDER_ERROR = 108;
    const COMPANY_BLOCKED_ERROR = 109;

    private $errorCode = self::NO_RESULT;
    private $errorMessage;

    /**
     * @return array
     */
    public function getMap()
    {
        return [
            self::NO_RESULT                   => 'The action is not performed',
            self::SUCCESS                     => 'The operation was successfully completed',
            self::ERROR_SAVING                => 'Error saving the order',
            self::INVALID_ORDER_TIME          => 'Order time is incorrect',
            self::OLD_DATA                    => 'Old data for updating',
            self::FORBIDDEN_CHANGE_ORDER_TIME => 'Forbidden to change the order time',
            self::INVALID_VALUE               => 'Invalid attribute value',
            self::FORBIDDEN_CHANGE_WORKER     => 'Forbidden to change the worker',
            self::INTERNAL_ERROR              => 'Internal error',
            self::COMPLETE_ORDER_ERROR        => 'Complete order error',
            self::COMPANY_BLOCKED_ERROR       => 'Company is blocked',
        ];
    }

    /**
     * @return string|null
     */
    public function getErrorMessage()
    {
        if (empty($this->errorMessage)) {
            $errorMap           = $this->getMap();
            $this->errorMessage = isset($errorMap[$this->errorCode]) ? $errorMap[$this->errorCode] : null;
        }

        return $this->errorMessage;
    }

    /**
     * Getting error data by code
     * @return array
     */
    public function getData()
    {
        return [
            'code' => $this->errorCode,
            'info' => $this->getErrorMessage(),
        ];
    }

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setErrorCode($code)
    {
        $this->errorCode    = $code;
        $this->errorMessage = null;

        return $this;
    }

    public function getErrorCode()
    {
        return $this->errorCode;
    }

    /**
     * @param string $message
     *
     * @return $this
     */
    public function setErrorMessage($message)
    {
        $this->errorMessage = $message;

        return $this;
    }
}