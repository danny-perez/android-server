<?php

namespace referralSystem\models;

/**
 * Class Referral
 * @package referralSystem\models
 */
class Referral
{
    /**
     * @var int
     */
    private $id;
    /**
     * @var int
     */
    private $clientId;

    /**
     * @var int
     */
    private $orderCount;

    /**
     * Referral constructor.
     *
     * @param int $id
     * @param int $clientId
     * @param int $orderCount
     */
    public function __construct($id, $clientId, $orderCount)
    {
        $this->id         = $id;
        $this->clientId   = $clientId;
        $this->orderCount = $orderCount;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getClientId()
    {
        return $this->clientId;
    }

    /**
     * @return int
     */
    public function getOrderCount()
    {
        return $this->orderCount;
    }

    /**
     * @param int $orderCount
     */
    public function setOrderCount($orderCount)
    {
        $this->orderCount = $orderCount;
    }

}