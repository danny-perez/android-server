<?php

namespace referralSystem\exceptions;

/**
 * Class OrderWithDetailCostNotFoundException
 * @package referralSystem\exceptions
 */
class OrderWithDetailCostNotFoundException extends \DomainException
{

}