<?php

namespace referralSystem\exceptions;

/**
 * Class ReferralSystemException
 * @package referralSystem\models
 */
class ReferralSystemException extends \DomainException
{

}