<?php

namespace referralSystem\exceptions;

/**
 * Class BonusForOrderNotFoundException
 * @package referralSystem\exceptions
 */
class BonusForOrderNotFoundException extends \DomainException
{

}