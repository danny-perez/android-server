'use strict';
const redisWorkerManager = require('../database/redisDB/redisWorkerManager');
const redisOrderManager = require('../database/redisDB/redisOrderManager');
const redisParkingManager = require('../database/redisDB/redisParkingManager');
const redisWorkerShiftManager = require('../database/redisDB/redisWorkerShiftManager');
const sqlManager = require('../database/sqlDB/sqlManager');
const async = require("async");
const config = require("../services/lib").getConfig();
const nodeId = config.MY_ID;
const logger = require('../services/logger');
const workerShiftLogger = logger.workerShiftLogger;
const amqpWorkerShiftMessageSender = require("../services/amqpWorkerShiftMessageSender");
const uuid = require('uuid/v4');
const rabbitmqHttpService = require('../services/rabbitmqHttpService');
const workerStatusManager = require('../services/workerStatusManager');

/**
 * Close worker shift
 * @param  {Number} tenantId
 * @param  {String} tenantLogin
 * @param  {Number} workerCallsign
 * @param  {Number} shiftId
 * @param  {String} shiftEndReason
 * @param  {String} shiftEndEventSenderType
 * @param  {Number} shiftEndEventSenderId
 * @param  {Function} resultCallback
 */
module.exports = function (tenantId, tenantLogin, workerCallsign, shiftId, shiftEndReason, shiftEndEventSenderType, shiftEndEventSenderId, resultCallback) {
    workerShiftLogger(tenantId, workerCallsign, 'info', "closeWorkerShift called!");
    redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
        if (err) {
            workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->redisWorkerManager.getWorker->Error: ${err.message}`);
            return resultCallback(err);
        }
        if (!workerData) {
            return resultCallback(new Error('No worker at redis Db'));
        }
        if (workerData.worker && workerData.worker.status && workerData.worker.status === workerStatusManager.onOrder) {
            workerShiftLogger(tenantId, workerCallsign, "info", `closeWorkerShift->worker status="${workerData.worker.status}"`);
            const lastOrderId = workerData.worker.last_order_id;
            if (lastOrderId) {
                redisOrderManager.getOrder(tenantId, lastOrderId, (err, orderData) => {
                    if (err) {
                        workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->redisOrderManager.getOrder->Error: ${err.message}`);
                        close();
                    } else {
                        workerData.worker.need_close_shift = 1;
                        redisWorkerManager.saveWorker(workerData, (err, result) => {
                            if (err) {
                                workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->redisOrderManager.saveWorker->Error: ${err.message}`);
                                return resultCallback(err);
                            }
                            return resultCallback(new Error('Can not close shift. Worker at order'));
                        });
                    }
                })
            } else {
                close();
            }
        } else {
            close()
        }

        function close() {
            const workerParkingId = workerData.geo.parking_id;
            const workerShiftId = parseInt(workerData.worker.worker_shift_id);
            if (workerShiftId === parseInt(shiftId)) {
                async.parallel({
                        delWorkerFromParking: callback => {
                            if (workerParkingId) {
                                redisParkingManager.deleteWorkerFromParking(workerParkingId, workerCallsign, (err, result) => {
                                    if (err) {
                                        workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->deleteWorkerFromParking->Error: ${err.message}`);
                                        return callback(err);
                                    } else {
                                        workerShiftLogger(tenantId, workerCallsign, 'info', `closeWorkerShift->deleteWorkerFromParking->Result: ${result}`);
                                    }
                                    return callback(null, 1);
                                });
                            } else {
                                return callback(null, 1);
                            }

                        },
                        delWorkerFromOnline: callback => {
                            redisWorkerManager.deleteWorker(tenantId, workerCallsign, (err, result) => {
                                if (err) {
                                    workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->deleteWorker->Error: ${err.message}`);
                                    return callback(err);
                                } else {
                                    workerShiftLogger(tenantId, workerCallsign, 'info', `closeWorkerShift->deleteWorker->Result: ${result}`);
                                }
                                return callback(null, 1);
                            });
                        },
                        delWorkerShift: callback => {
                            redisWorkerShiftManager.deleteWorkerShift(tenantLogin, workerCallsign, (err, result) => {
                                if (err) {
                                    workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->deleteWorkerShift->Error: ${err.message}`);
                                    return callback(err);
                                } else {
                                    workerShiftLogger(tenantId, workerCallsign, 'info', `closeWorkerShift->deleteWorkerShift->Result: ${result}`);
                                }
                                return callback(null, 1);
                            });
                        },
                        closeShiftInMysql: callback => {
                            sqlManager.logEndOfWorkerShift(workerShiftId, shiftEndReason, shiftEndEventSenderType, shiftEndEventSenderId, (err, result) => {
                                if (err) {
                                    workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->logEndOfWorkerShift->Error: ${err.message}`);
                                    return callback(err);
                                } else {
                                    workerShiftLogger(tenantId, workerCallsign, 'info', `closeWorkerShift->logEndOfWorkerShift->Result: ${result}`);
                                }
                                return callback(null, 1);
                            });

                        }
                    },
                    (err, results) => {
                        if (err) {
                            workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->Error: ${err.message}`);
                            return resultCallback(err);
                        }
                        workerShiftLogger(tenantId, workerCallsign, 'info', `closeWorkerShift->Result: ${results}`);
                        rabbitmqHttpService.getQueueConsumersCount(`${tenantId}_worker_${workerCallsign}_shift`, null, (err, result) => {
                            if (err) {
                                return resultCallback(new Error(`getQueueConsumersCount error: ${err.message}`));
                            } else {
                                if (result >= 1) {
                                    const messageData = JSON.stringify({
                                        uuid: uuid(),
                                        type: 'order_event',
                                        timestamp: Math.floor(Date.now() / 1000),
                                        sender_service: "engine_service",
                                        command: "worker_end_work",
                                        tenant_id: tenantId,
                                        worker_callsign: workerCallsign,
                                        change_sender_id: nodeId,
                                        params: {}
                                    });
                                    amqpWorkerShiftMessageSender.sendMessage(tenantId, workerCallsign, messageData, (err, result) => {
                                        if (err) {
                                            workerShiftLogger(tenantId, workerCallsign, 'error', `closeWorkerShift->amqpWorkerShiftMessageSender.sendMessage->Error: ${err.message}`);
                                        } else {
                                            workerShiftLogger(tenantId, workerCallsign, 'info', 'closeWorkerShift-> Published event at chanell:' + tenantLogin + "_worker_" + workerCallsign + '_shift');
                                            workerShiftLogger(tenantId, workerCallsign, 'info', messageData);
                                        }
                                    });
                                    return resultCallback(null, 1);
                                } else {
                                    return resultCallback(new Error(`there no queue ${tenantId}_worker_${workerCallsign}_shift consumer`));
                                }
                            }
                        });

                    });
            } else {
                return resultCallback(new Error('Worker has other opened shift_id=' + workerShiftId));
            }
        }
    });

};