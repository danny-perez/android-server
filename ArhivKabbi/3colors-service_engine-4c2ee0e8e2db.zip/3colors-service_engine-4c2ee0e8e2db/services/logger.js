module.exports = require('./syslogLogger');





