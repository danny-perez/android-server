'use strict';

/**
 * @class DataProcessingService
 */
class DataProcessingService {
    /**
     * @constructor
     */
    constructor() {
        this.activeOrders = [];
        this.activeWorkerShifts = [];
        this.activeWorkerBlocks = [];
    }

    get activeOrdersList() {
        return this.activeOrders;
    }

    get activeOrdersListLength() {
        return this.activeOrders.length;
    }

    get activeWorkerShiftsList() {
        return this.activeWorkerShifts;
    }

    get activeWorkerShiftsListLength() {
        return this.activeWorkerShifts.length;
    }

    get activeWorkerBlocksList() {
        return this.activeWorkerBlocks;
    }

    get activeWorkerBlocksListLength() {
        return this.activeWorkerBlocks.length;
    }

    addOrder(orderId) {
        this.activeOrders.push(orderId);
    }

    delOrder(orderId) {
        let index = this.activeOrders.indexOf(orderId);
        if (index !== -1) {
            this.activeOrders.splice(index, 1);
        }
    }

    addWorkerShift(shiftId) {
        this.activeWorkerShifts.push(shiftId);
    }

    delWorkerShift(shiftId) {
        let index = this.activeWorkerShifts.indexOf(shiftId);
        if (index !== -1) {
            this.activeWorkerShifts.splice(index, 1);
        }
    }

    addWorkerBlock(blockId) {
        this.activeWorkerBlocks.push(blockId);
    }

    delWorkerBlock(blockId) {
        let index = this.activeWorkerBlocks.indexOf(blockId);
        if (index !== -1) {
            this.activeWorkerBlocks.splice(index, 1);
        }
    }
}

module.exports = exports = new DataProcessingService();