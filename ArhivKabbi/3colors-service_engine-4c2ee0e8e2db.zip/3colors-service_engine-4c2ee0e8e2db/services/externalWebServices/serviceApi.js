const request = require('request');
const config = require("../lib").getConfig();
const apiServiceUrl = config.API_SERVICE_URL;


/**
 * Send request to add orders at statistic
 * @param {Number} orderId
 * @param {Number} tenantId
 * @param {Function} callback
 */
function sendOrderToStatistic(tenantId, orderId, callback) {
    const getString = "order_id=" + orderId + "&tenant_id=" + tenantId;
    const requestOptions = {
        url: apiServiceUrl + 'v1/order/order_statistic?' + getString
    };

    function resultData(error, response, body) {
        if (!error && parseInt(response.statusCode) === 200) {
            try {
                const info = JSON.parse(body);
                if (parseInt(info.result) === 1) {
                    return callback(null, 1);
                } else {
                    return callback(null, null);
                }
            } catch (err) {
                return callback(err);
            }
        } else {
            return callback(null, null);
        }
    }

    request(requestOptions, resultData);
}


/**
 *
 * Send sms notification to client
 * @param  {Object} options
 * @param  {Number} options.orderId
 * @param  {Number} options.tenantId
 * @param  {Number} options.cityId
 * @param  {String} options.clientPhone
 * @param  {Number} options.statusId
 * @param  {Number} options.positionId
 * @param  {Function} callback
 */
function sendSmsNotificationToClient(options, callback) {
    const getString = "city_id=" + options.cityId + "&order_id=" + options.orderId + "&phone=" + options.clientPhone
        + "&status_id=" + options.statusId + "&tenant_id=" + options.tenantId + "&position_id=" + options.positionId;
    const requestOptions = {
        url: apiServiceUrl + 'v1/notification/send_sms_notification_for_client?' + getString
    };

    function resultData(error, response, body) {
        if (!error && parseInt(response.statusCode) === 200) {
            try {
                const info = JSON.parse(body);
                if (parseInt(info.result) === 1) {
                    return callback(null, 1);
                } else {
                    return callback(null, 0);
                }
            } catch (err) {
                return callback(err);
            }
        } else {
            return callback(error);
        }
    }

    request(requestOptions, resultData);
}

/**
 * Update client order counters (count of completed and rejected orders)
 * @param {Number} tenantId
 * @param {Number} clientId
 * @param {Number} statusId
 * @param {Function} callback
 */
function updateClientCounters(tenantId, clientId, statusId, callback) {
    const getString = "client_id=" + clientId + "&status_id=" + statusId + "&tenant_id=" + tenantId;
    const requestOptions = {
        url: apiServiceUrl + 'v1/notification/update_client_order_counters?' + getString
    };

    function sendRequest(error, response, body) {
        if (!error && parseInt(response.statusCode) === 200) {
            try {
                const info = JSON.parse(body);
                if (parseInt(info.result) === 1) {
                    return callback(null, 1);
                } else {
                    return callback(null, 0);
                }
            } catch (err) {
                return callback(err);
            }
        } else {
            return callback(error);
        }
    }

    request(requestOptions, sendRequest);
}

exports.sendOrderToStatistic = sendOrderToStatistic;
exports.sendSmsNotificationToClient = sendSmsNotificationToClient;
exports.updateClientCounters = updateClientCounters;
