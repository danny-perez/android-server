"use strict";

const request = require('request');
const config = require("../lib").getConfig();
const logger = require('../logger');
const mainLogger = logger.mainLogger;

function sendRequest(taskObject, callback) {
    const requestOptions = {
        url: `${config.API_ORDER_URL}v1/orders/${taskObject.command}`,
        method: 'POST',
        headers: {
            "content-type": "application/json",
        },
        json: taskObject
    };

    /**
     *
     * @param error
     * @param response
     * @param body
     * @returns {*}
     */
    function resultData(error, response, body) {
        if (!error && parseInt(response.statusCode) === 200) {
            if (typeof body === "object") {
                return callback(null, body);
            } else if (typeof body === "string") {
                try {
                    let result = JSON.parse(body);
                    callback(null, result)
                } catch (err) {
                    mainLogger('error', 'orderApi PARSING-error:');
                    mainLogger('error', body);
                    mainLogger('error', response);
                    return callback(body);
                }
            } else {
                mainLogger('error', 'orderApi BAD-body:');
                mainLogger('error', body);
                mainLogger('error', response);
                return callback(body);
            }
        } else {
            mainLogger('error', 'orderApi BAD-response:');
            mainLogger('error', body);
            mainLogger('error', response);
            let errInfo = error || body;
            return callback(errInfo);
        }
    }

    request(requestOptions, resultData);
}

exports.sendRequest = sendRequest;