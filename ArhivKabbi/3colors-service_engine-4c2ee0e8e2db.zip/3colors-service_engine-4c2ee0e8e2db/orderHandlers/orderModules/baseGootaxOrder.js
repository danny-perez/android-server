"use strict";

const orderActionManager = require("./common/orderActionManager");
const orderNotificationManager = require("./common/orderNotificationManager");
const redisOrderManager = require('../../database/redisDB/redisOrderManager');
const async = require("async");
const logger = require('../../services/logger');
const orderLogger = logger.orderLogger;
const statusInfo = require('../../services/orderStatusManager').statusInfo;
const OrderTimer = require("../../services/serviceTimer");
const amqpWorkerMessageSender = require("../../services/amqpWorkerMessageSender");
const pushApi = require('../../services/externalWebServices/pushApi');
const serviceApi = require('../../services/externalWebServices/serviceApi');
const sqlManager = require("../../database/sqlDB/sqlManager");
const orderEventWorkerMessage = require('../orderEvent/orderEventWorkerMessage');
const orderEventOrderCommand = require('../orderEvent/orderEventOrderCommand');
const orderEventWorkerCommand = require('../orderEvent/orderEventWorkerCommand');
const orderEventSenderService = require('../orderEvent/orderEventSenderService');
const orderSettingsManager = require('./common/orderSettingsManager');
const redisWorkerReservedOrderListManager = require('../../database/redisDB/redisWorkerReservedOrderListManager');
const redisActiveOrderPhoneManager = require('../../database/redisDB/redisActiveOrderPhoneManager');
const redisWorkerManager = require("../../database/redisDB/redisWorkerManager");
const redisParkingManager = require("../../database/redisDB/redisParkingManager");
const orderStatusRejected = require('./common/statusHandlers/orderStatusRejected');
const orderStatusCompleted = require("./common/statusHandlers/orderStatusCompleted");
const orderStatusExecuting = require("./common/statusHandlers/orderStatusExecuting");
const orderStatusWorkerAtPlace = require("./common/statusHandlers/orderStatusWorkerAtPlace");
const orderStatusWorkerAssigned = require("./common/statusHandlers/orderStatusWorkerAssigned");
const preOrderStatusWorkerAssigned = require("./common/statusHandlers/preOrderStatusWorkerAssigned");
const preOrderStatusWorkerRefusedOrderAssignment = require("./common/statusHandlers/preOrderStatusWorkerRefusedOrderAssignment");
const preOrderStatusNew = require("./common/statusHandlers/preOrderStatusNew");
const orderStatusNewOrder = require("./common/statusHandlers/orderStatusNewOrder");
const orderStatusWorkerRefusedOrderAssignment = require('./common/statusHandlers/orderStatusWorkerRefusedOrderAssignment');
const orderStatusWorkerAssignedAtOrder = require('./common/statusHandlers/orderStatusWorkerAssignedAtOrder');
const orderStatusManualMode = require('./common/statusHandlers/orderStatusManualMode');
const orderStatusFreeOrder = require('./common/statusHandlers/orderStatusFreeOrder');
const orderStatusOfferOrder = require('./common/statusHandlers/orderStatusOfferOrder');
const orderStatusRefuseOfferOrder = require('./common/statusHandlers/orderStatusRefuseOfferOrder');
const preOrderStatusWaitingForConfirmation = require('./common/statusHandlers/preOrderStatusWaitingForConfirmation');
const preOrderStatusRefuseConfirmation = require('./common/statusHandlers/preOrderStatusRefuseConfirmation');
const preOrderStatusAcceptedConfirmation = require('./common/statusHandlers/preOrderStatusAcceptedConfirmation');
const stopOfferOrder = require('./common/actionHandlers/stopOfferOrder');
const refuseOfferOrder = require('./common/actionHandlers/refuseOfferOrder');
const clientLateTimeOut = require('./common/timerHandlers/clientLateTimeOut');
const orderLateTimeOut = require('./common/timerHandlers/orderLateTimeOut');
const orderOfferTimeOut = require('./common/timerHandlers/orderOfferTimeOut');
const orderRejectTimeOut = require('./common/timerHandlers/orderRejectTimeOut');
const workerLateTimeOut = require('./common/timerHandlers/workerLateTimeOut');
const preOrderConfirmTimeOut = require('./common/timerHandlers/preOrderConfirmTimeOut');
const orderDistributionManager = require('./common/orderDistributionManager');


/**
 * Base Gootax order
 * @class BaseGootaxOrder
 */
class BaseGootaxOrder {

    /**
     * @constructor
     * @param {Number} tenantId
     * @param {Number} orderId
     * @param {Number} isFromLoader - (1/0) Was it order add after restart node process(isFromLoader = 1), or from external services
     */
    constructor(tenantId, orderId, isFromLoader) {

        orderLogger(orderId, 'info', `baseGootaxOrder->new BaseGootaxOrder(${tenantId},${orderId},${isFromLoader}) called!`);

        this.orderId = orderId;

        this.tenantId = tenantId;

        this.isFromLoader = isFromLoader;

        this.settings = {};

        // System delay for offer order timer in seconds
        this.offerSecSystemIncrease = 2;

        this.currentDistributionCircle = 1;

        this.currentDistributionCircleRepeat = 1;

        this.maxDistanceDistributionCircle = 1;

        this.offeredInCircleRepeatWorkersList = new Set();

        this.offeredInCircleWorkersList = new Set();

        this.offeredInAllTimeWorkersList = new Set();

        // Service to manage order timers events
        this.orderTimer = new OrderTimer();

        // Array of statuses, that set worker at app
        this.workerSetOfStatus = [
            statusInfo.worker_refused_order.status_id,
            statusInfo.worker_refused_preorder.status_id,
            statusInfo.worker_accepted_order.status_id,
            statusInfo.worker_accepted_preorder.status_id,
            statusInfo.worker_arrived_order.status_id,
            statusInfo.order_execution.status_id,
            statusInfo.pre_order_executing.status_id,
            statusInfo.completed_paid.status_id,
            statusInfo.completed_nopaid.status_id
        ];

        //Array of sequence status ids changes
        this.statusArr = [];

        //Array of sequence status groups changes
        this.statusGroupArr = [];

        //Status changed after update order
        this.statusChanged = false;

        //New order status already was
        this.newStatusAlreadyWas = false;

        //Is this order for all workers or for special one
        this.isForAllWorkers = true;

        this.workerLateTimestamp = null;

        this.startWaitingForPaymentTimestamp = null;

        this._inited = false;

        this._initOrder();
    }

    /**
     * Do order event
     * {orderEventOrderMessage} event
     * @param event
     */
    doEvent(event) {
        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent called!`);
        orderLogger(this.orderId, 'info', event);
        switch (event.command) {
            case orderEventOrderCommand.updateOrderData:
                this._updateOrderData(event.sender_service, typeof event.params === 'object' ? event.params : {});
                break;
            case orderEventOrderCommand.refuseOfferOrder:
                refuseOfferOrder(this, event.change_sender_id)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->refuseOfferOrder->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->refuseOfferOrder->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.stopOffer:
                stopOfferOrder(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->stopOfferOrder->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->stopOfferOrder->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.clientLateTimeout:
                clientLateTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->clientLateTimeOut->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->clientLateTimeOut->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.orderLateTimeout:
                orderLateTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->orderLateTimeOut->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->orderLateTimeOut->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.orderOfferTimeout:
                orderOfferTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->orderOfferTimeout->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->orderOfferTimeout->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.orderRejectTimeout:
                orderRejectTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->orderRejectTimeOut->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->orderRejectTimeOut->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.workerLateTimeout:
                workerLateTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->workerLateTimeOut->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->workerLateTimeOut->Error: ${err.message}`);
                    });
                break;
            case orderEventOrderCommand.preOrderConfirmTimeout:
                preOrderConfirmTimeOut(this)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->doEvent->preOrderConfirmTimeOut->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->doEvent->preOrderConfirmTimeOut->Error: ${err.message}`);
                    });
                break;
            default:
                break;
        }
    };


    /**
     * Modify order event
     * @param {Object} event
     * @return {*}
     */
    modifyEvent(event) {
        //If worker sent refuse offer order and offer order type was 'batch' (sending offer order for many workers)
        //then need change event command to 'refuse_offer_order', because in this case we should not change order status
        if (event.sender_service === orderEventSenderService.workerService && event.command === orderEventOrderCommand.updateOrderData) {
            if (event.params && parseInt(event.params.status_id) === statusInfo.worker_refused_order.status_id) {
                if (this.settings.OFFER_ORDER_TYPE === orderDistributionManager.offerOrderMultipleType) {
                    event.command = orderEventOrderCommand.refuseOfferOrder;
                }
            }
        }
        return event;
    }

    /**
     * Init order
     * @private
     */
    _initOrder() {
        if (!this._inited) {
            orderLogger(this.orderId, 'info', 'baseGootaxOrder->_initOrder called!');
            redisOrderManager.getOrder(this.tenantId, this.orderId, (err, orderData) => {
                if (err) {
                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->Error of getting order from redis: ${err.message}. ${this.tenantId} ${this.orderId}`);
                    return;
                }
                //Order sent from external services
                if (!this.isFromLoader) {
                    async.waterfall([
                        //Persist order setting to to redis and write to object property
                        callback => {
                            orderSettingsManager.persistSettings(this.tenantId, this.orderId)
                                .then(orderSettings => {
                                    orderLogger(this.orderId, 'info', `baseGootaxOrder->_initOrder->orderSettingsManager.persistSettings->Result:`);
                                    orderLogger(this.orderId, 'info', orderSettings);
                                    //Set settings
                                    this.settings = orderSettings;
                                    let circleDistanceSettings = [
                                        orderSettings.CIRCLE_DISTANCE_5,
                                        orderSettings.CIRCLE_DISTANCE_4,
                                        orderSettings.CIRCLE_DISTANCE_3,
                                        orderSettings.CIRCLE_DISTANCE_2,
                                        orderSettings.CIRCLE_DISTANCE_1,
                                    ];
                                    let lastNotEmptyDistanceSetting = circleDistanceSettings.find(element => {
                                        return (!isNaN(parseFloat(element)) && element !== 0);
                                    });
                                    if (!lastNotEmptyDistanceSetting) {
                                        if (orderSettings.CIRCLE_DISTANCE_1) {
                                            this.maxDistanceDistributionCircle = 5
                                        } else {
                                            this.maxDistanceDistributionCircle = 0;
                                        }
                                    } else {
                                        this.maxDistanceDistributionCircle = circleDistanceSettings.reverse().indexOf(lastNotEmptyDistanceSetting) + 1;
                                    }
                                    callback(null, 1);
                                })
                                .catch(err => {
                                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->orderSettingsManager.persistSettings->Error: ${err.message}`);
                                    callback(err);
                                })
                        },
                        //Save last order status to redis
                        (prevResult, callback) => {
                            this._persistLastOrderStatus(this.tenantId, this.orderId)
                                .then(result => {
                                    orderLogger(this.orderId, 'info', `baseGootaxOrder->_initOrder->_persistLastOrderStatus->Result: ${result}`);
                                    callback(null, 1);
                                })
                                .catch(err => {
                                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->_persistLastOrderStatus->Error: ${err.message}`);
                                    callback(err);
                                })
                        },
                        //If pre-order, then set pre-order attribute
                        (prevResult, callback) => {
                            const newPreOrdersStatuses = [statusInfo.new_pre_order.status_id, statusInfo.new_pre_order_no_parking.status_id];
                            const orderStatusId = parseInt(orderData.status.status_id);
                            if (newPreOrdersStatuses.indexOf(orderStatusId) === -1) {
                                return callback(null, 1);
                            }
                            this._setPreOrderAttribute(this.tenantId, this.orderId)
                                .then(result => {
                                    orderLogger(this.orderId, 'info', `baseGootaxOrder->_initOrder->_setPreOrderAttribute->Result: ${result}`);
                                    callback(null, 1);
                                })
                                .catch(err => {
                                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->_setPreOrderAttribute->Error: ${err.message}`);
                                    callback(err);
                                })
                        },
                        //Save client phone to redis
                        (prevResult, callback) => {
                            this._persistOrderPhone(this.tenantId, this.orderId, orderData.phone)
                                .then(result => {
                                    orderLogger(this.orderId, 'info', `baseGootaxOrder->_initOrder->_persistOrderPhone->Result: ${result}`);
                                    callback(null, 1);
                                })
                                .catch(err => {
                                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->_persistOrderPhone->Error: ${err.message}`);
                                    callback(err);
                                })
                        },
                        //Send order to statistic
                        (prevResult, callback) => {
                            serviceApi.sendOrderToStatistic(this.tenantId, this.orderId, (err, result) => {
                                if (err) {
                                    orderLogger(this.orderId, 'error', `baseGootaxOrder->initOrder->sendOrderToStatistic->Error: ${err.message}`);
                                    callback(err);
                                } else {
                                    orderLogger(this.orderId, 'info', `baseGootaxOrder->initOrder->sendOrderToStatistic->Result: ${result}`);
                                    callback(null, 1);
                                }
                            })
                        },
                        //if order from border, init it
                        (prevResult, callback) => {
                            if (orderData.device === "WORKER") {
                                orderLogger(this.orderId, 'info', "baseGootaxOrder->initOrder->order from border. Need init it.");
                                this._initBorderOrder(orderData)
                                    .then(result => {
                                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_initBorderOrder->Result: ${result}`);
                                        callback(null, 1);
                                    })
                                    .catch(err => {
                                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_initBorderOrder->Error: ${err.message}`);
                                        callback(null, 1);
                                    });
                            } else {
                                callback(null, 1);
                            }
                        }
                    ], (err, result) => {
                        if (err) {
                            orderLogger(this.orderId, 'error', `baseGootaxOrder->initOrder->Error: ${err.message}`);
                            return;
                        }
                        this._inited = true;
                        orderSettingsManager.setSystemSettings(this.tenantId, this.orderId)
                            .then(() => {
                                this._updateOrderData(orderEventSenderService.engineService);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->orderSettingsManager.setSystemSettings->Error: ${err.message}`);
                                this._updateOrderData(orderEventSenderService.engineService);
                            });
                    });
                } else {
                    //order is from loader
                    if (!orderData.settings) {
                        orderSettingsManager.persistSettings(this.tenantId, this.orderId)
                            .then(orderSettings => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_initOrder->orderSettingsManager.persistSettings->Result:`);
                                orderLogger(this.orderId, 'info', orderSettings);
                                //Set settings
                                this.settings = orderSettings;
                                let circleDistanceSettings = [
                                    orderSettings.CIRCLE_DISTANCE_5,
                                    orderSettings.CIRCLE_DISTANCE_4,
                                    orderSettings.CIRCLE_DISTANCE_3,
                                    orderSettings.CIRCLE_DISTANCE_2,
                                    orderSettings.CIRCLE_DISTANCE_1,
                                ];
                                let lastNotEmptyDistanceSetting = circleDistanceSettings.find(element => {
                                    return (!isNaN(parseFloat(element)) && element !== 0);
                                });
                                if (!lastNotEmptyDistanceSetting) {
                                    if (orderSettings.CIRCLE_DISTANCE_1) {
                                        this.maxDistanceDistributionCircle = 5
                                    } else {
                                        this.maxDistanceDistributionCircle = 0;
                                    }
                                } else {
                                    this.maxDistanceDistributionCircle = circleDistanceSettings.reverse().indexOf(lastNotEmptyDistanceSetting) + 1;
                                }
                                this._inited = true;
                                orderSettingsManager.setSystemSettings(this.tenantId, this.orderId)
                                    .then(() => {
                                        this._updateOrderData(orderEventSenderService.engineService);
                                    })
                                    .catch(err => {
                                        orderLogger(this.orderId, 'error', `baseGootaxOrder->orderSettingsManager.setSystemSettings->Error: ${err.message}`);
                                        this._updateOrderData(orderEventSenderService.engineService);
                                    });
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_initOrder->orderSettingsManager.persistSettings->Error: ${err.message}`);
                            })
                    } else {
                        //Order sent form loader
                        //Set settings
                        this.settings = orderData.settings;
                        let circleDistanceSettings = [
                            orderData.settings.CIRCLE_DISTANCE_5,
                            orderData.settings.CIRCLE_DISTANCE_4,
                            orderData.settings.CIRCLE_DISTANCE_3,
                            orderData.settings.CIRCLE_DISTANCE_2,
                            orderData.settings.CIRCLE_DISTANCE_1,
                        ];
                        let lastNotEmptyDistanceSetting = circleDistanceSettings.find(element => {
                            return (!isNaN(parseFloat(element)) && element !== 0);
                        });
                        if (!lastNotEmptyDistanceSetting) {
                            if (orderData.settings.CIRCLE_DISTANCE_1) {
                                this.maxDistanceDistributionCircle = 5
                            } else {
                                this.maxDistanceDistributionCircle = 0;
                            }
                        } else {
                            this.maxDistanceDistributionCircle = circleDistanceSettings.reverse().indexOf(lastNotEmptyDistanceSetting) + 1;
                        }
                        this._inited = true;
                        orderSettingsManager.setSystemSettings(this.tenantId, this.orderId)
                            .then(() => {
                                this._updateOrderData(orderEventSenderService.engineService);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->orderSettingsManager.setSystemSettings->Error: ${err.message}`);
                                this._updateOrderData(orderEventSenderService.engineService);
                            });
                    }
                }
            });
        }
    };

    /**
     * Init order from border
     * @param {object} orderData
     * @private
     */
    _initBorderOrder(orderData) {
        return new Promise((resolve, reject) => {
            orderLogger(this.orderId, 'info', 'baseGootaxOrder->_initBorderOrder CALLED!');
            if (orderData && orderData.worker && orderData.worker.callsign) {
                const orderId = this.orderId;
                const tenantId = this.tenantId;
                const workerCallsign = orderData.worker.callsign;
                redisWorkerReservedOrderListManager.addOrder(tenantId, workerCallsign, orderId, (err, result) => {
                    if (err) {
                        orderLogger(orderId, 'error', `baseGootaxOrder->_initBorderOrder->redisWorkerReservedOrderListManager.addOrder->Error: ${err.message}`);
                    } else {
                        orderLogger(orderId, 'info', `baseGootaxOrder->_initBorderOrder->redisWorkerReservedOrderListManager.addOrder->Result: ${result}`);
                    }
                });
                redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
                    if (err) {
                        orderLogger(orderId, 'error', `baseGootaxOrder->_initBorderOrder->redisWorkerManager.getWorker->Error: ${err.message}`);
                        return reject(err);
                    }
                    workerData.worker.last_order_id = orderId;
                    workerData.worker.status = "ON_ORDER";
                    if (typeof workerData.geo.parking_id !== "undefined" && workerData.geo.parking_id !== null) {
                        redisParkingManager.deleteWorkerFromParking(workerData.geo.parking_id, workerCallsign, (err, result) => {
                            if (err) {
                                orderLogger(orderId, 'error', `baseGootaxOrder->_initBorderOrder->redisParkingManager.deleteWorkerFromParking->Error: ${err.message}`);
                            } else {
                                orderLogger(orderId, 'info', `baseGootaxOrder->_initBorderOrder->redisParkingManager.deleteWorkerFromParking->Result: ${result}`);
                            }
                        })
                    }
                    workerData.geo.parking_id = null;
                    orderLogger(orderId, 'info', `baseGootaxOrder->_initBorderOrder->last_order_id:${workerData.worker.last_order_id}`);
                    redisWorkerManager.saveWorker(workerData, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `baseGootaxOrder->_initBorderOrder->redisWorkerManager.saveWorker->Error: ${err.message}`);
                            return reject(err);
                        } else {
                            orderLogger(orderId, 'info', `baseGootaxOrder->_initBorderOrder->redisWorkerManager.saveWorker->Result: ${result}`);
                            return resolve(1);
                        }
                    })
                })
            } else {
                orderLogger(this.orderId, 'error', 'baseGootaxOrder->_initBorderOrder->Error: order have not worker data!');
                return reject(new Error('order have not worker data'));
            }
        });
    }

    /**
     * Handle update_order_data event
     * @param {string} eventSenderService
     * @param {object} messageParams
     * @private
     */
    _updateOrderData(eventSenderService, messageParams = {}) {
        orderLogger(this.orderId, 'info', 'baseGootaxOrder->_updateOrderData called!');
        orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->messageParams: ${messageParams}`);
        redisOrderManager.getOrder(this.tenantId, this.orderId, (err, orderData) => {
            if (err) {
                orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->getOrder->Error: ${err.message}`);
                return;
            }
            orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->getOrder->done!`);
            let orderStatusId = parseInt(orderData.status.status_id);
            let orderStatusGroup = orderData.status.status_group;
            let userModified = orderData.user_modifed;
            this.statusChanged = false;
            let subjectType;
            //Order status id changed
            if (this.statusArr[this.statusArr.length - 1] !== orderStatusId) {
                this.statusArr.push(orderStatusId);
                this.statusChanged = true;
                orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->order status id changed to ${orderStatusId}`);
                subjectType = "system";
                if (this.workerSetOfStatus.indexOf(orderStatusId) > 0) {
                    subjectType = "worker";
                }
                if (!this.isFromLoader) {
                    sqlManager.logOrderChangeData(this.tenantId, this.orderId, "status_id", this.orderId, "order", orderStatusId, subjectType, (err, result) => {
                        if (err) {
                            orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->sqlManager.logOrderChangeData->Error: ${err.message}`);
                        } else {
                            orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->sqlManager.logOrderChangeData->Result: ${result}`);
                        }
                    });
                    orderNotificationManager.sendChangeOrderStatusNotificationToClient(orderData)
                        .then(result => {
                            orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->orderNotificationManager.sendChangeOrderStatusNotificationToClient->Info: ${result}`);
                        })
                        .catch(err => {
                            orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->orderNotificationManager.sendChangeOrderStatusNotificationToClient->Error: ${err.message}`);
                        });
                } else {
                    this.isFromLoader = false;
                }
                //Order status group changed
                if (this.statusGroupArr[this.statusGroupArr.length - 1] !== orderStatusGroup) {
                    this.statusGroupArr.push(orderStatusGroup);
                    orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->order status group changed to ${orderStatusGroup}`);
                }
            }
            async.parallel([
                callback => {
                    if (this.statusChanged) {
                        this._persistLastOrderStatus(this.tenantId, this.orderId)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->_persistLastOrderStatus->Result: ${result}`);
                                callback(null, 1);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->_persistLastOrderStatus->Error: ${err.message}`);
                                callback(err);
                            })
                    } else {
                        callback(null, 1);
                    }
                },
                callback => {
                    // if order has worker
                    // ad order modified by dispatcher
                    // or from client app
                    // or from worker app edited address or  predv_price
                    // then send order update event to worker
                    if (orderData.worker && orderData.worker.callsign && (userModified || eventSenderService === orderEventSenderService.clientService ||
                            (eventSenderService === orderEventSenderService.workerService && (messageParams.hasOwnProperty('predv_price') || messageParams.hasOwnProperty('address'))))) {
                        let messageString = orderEventWorkerMessage({
                            command: orderEventWorkerCommand.updateOrder,
                            tenant_id: orderData.tenant_id,
                            tenant_login: orderData.tenant_login,
                            worker_callsign: orderData.worker.callsign,
                            params: {
                                order_id: this.orderId
                            }
                        });
                        const messageTtl = 60 * 60 * 24 * 10;// 10 days
                        const workerCallsign = orderData.worker.callsign;
                        amqpWorkerMessageSender.sendMessage(orderData.tenant_id, workerCallsign, messageString, messageTtl, (err, result) => {
                            if (err) {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                            } else {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->amqpWorkerMessageSender.sendMessage->sent command: ${orderEventWorkerCommand.updateOrder} to worker ${workerCallsign}. Result: ${result}`);
                            }
                        });
                        pushApi.sendToWorkerUpdateOrder(this.tenantId, this.orderId, workerCallsign, (err, result) => {
                            if (err) {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->pushApi.sendToWorkerUpdateOrder->Error: ${err.message}`);
                            } else {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_updateOrderData->pushApi.sendToWorkerUpdateOrder->Result: ${result}`);
                            }
                            return callback(null, 1);
                        })
                    } else {
                        callback(null, 1);
                    }
                }
            ], (err, result) => {
                if (err) {
                    orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->Error: ${err.message}`);
                } else {
                    if (userModified) {
                        orderData.user_modifed = null;
                        redisOrderManager.saveOrder(orderData, (err, result) => {
                            if (err) {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_updateOrderData->saveOrder->Error: ${err.message}`);
                            }
                            this._statusHandler(orderData, eventSenderService, messageParams);
                        });
                    } else {
                        this._statusHandler(orderData, eventSenderService, messageParams);
                    }
                }

            });
        });
    };

    /**
     * Handle current order status
     * @param {object} orderData
     * @param {string} eventSenderService
     * @param {object} messageParams
     * @private
     */
    _statusHandler(orderData, eventSenderService, messageParams) {
        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler called!`);
        const orderStatusId = parseInt(orderData.status.status_id);
        const orderStatusGroup = orderData.status.status_group;
        switch (orderStatusGroup) {
            case "new": {
                switch (orderStatusId) {
                    case statusInfo.new_order.status_id:
                    case statusInfo.new_order_no_parking.status_id: {
                        orderStatusNewOrder(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusNewOrder->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusNewOrder->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.offer_order.status_id: {
                        orderStatusOfferOrder(this)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusOfferOrder->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusOfferOrder->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.worker_refused_order.status_id:
                    case statusInfo.worker_ignored_offer_order.status_id: {
                        orderStatusRefuseOfferOrder(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusRefuseOfferOrder->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusRefuseOfferOrder->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.free_order.status_id: {
                        orderStatusFreeOrder(this, orderData, messageParams)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusFreeOrder->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusFreeOrder->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.manual_mode.status_id: {
                        orderStatusManualMode(this, orderData, eventSenderService)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusManualMode->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusManualMode->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.worker_assigned_at_order_soft.status_id:
                    case statusInfo.worker_assigned_at_order_hard.status_id: {
                        orderStatusWorkerAssignedAtOrder(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusWorkerAssignedAtOrder->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusWorkerAssignedAtOrder->Error: ${err.message}`);

                            });
                        break;
                    }
                    case statusInfo.worker_refused_order_assign.status_id: {
                        orderStatusWorkerRefusedOrderAssignment(this, orderData, eventSenderService)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusWorkerRefusedOrderAssignment->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusWorkerRefusedOrderAssignment->Error: ${err.message}`);
                            });
                        break;
                    }
                    default: {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->Have't handler for status ${orderStatusId}`);
                        this.orderTimer.clearAll();
                        orderActionManager.rejectOrderByTimeout(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderActionManager.rejectOrderByTimeout->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderActionManager.rejectOrderByTimeout->Error: ${err.message}`);
                            });
                        break;
                    }
                }
                break;

            }
            case "pre_order": {
                switch (orderStatusId) {
                    case statusInfo.new_pre_order.status_id:
                    case statusInfo.new_pre_order_no_parking.status_id: {
                        let orderTimeIsChanged = messageParams && messageParams.order_time;
                        preOrderStatusNew(this, orderData, orderTimeIsChanged)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusNew->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusNew->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.worker_refused_preorder.status_id: {
                        preOrderStatusWorkerRefusedOrderAssignment(this, orderData, eventSenderService)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusWorkerRefusedOrderAssignment->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusWorkerRefusedOrderAssignment->Error: ${err.message}`);

                            });
                        break;
                    }
                    case statusInfo.worker_accepted_preorder.status_id:
                    case statusInfo.worker_assigned_at_preorder_hard.status_id:
                    case statusInfo.worker_assigned_at_preorder_soft.status_id: {
                        let orderTimeIsChanged = messageParams && messageParams.order_time;
                        preOrderStatusWorkerAssigned(this, orderData, orderTimeIsChanged)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusWorkerAssigned->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusWorkerAssigned->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.waiting_for_preorder_confirmation.status_id: {
                        preOrderStatusWaitingForConfirmation(this)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusWaitingForConfirmation->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusWaitingForConfirmation->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.worker_ignored_preorder_confirmation.status_id:
                    case statusInfo.worker_refused_preorder_confirmation.status_id: {
                        preOrderStatusRefuseConfirmation(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusRefuseConfirmation->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusRefuseConfirmation->Error: ${err.message}`);
                            });
                        break;
                    }
                    case statusInfo.worker_accepted_preorder_confirmation.status_id: {
                        preOrderStatusAcceptedConfirmation(this, orderData)
                            .then(result => {
                                orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->preOrderStatusAcceptedConfirmation->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->preOrderStatusAcceptedConfirmation->Error: ${err.message}`);
                            });
                        break;
                    }
                    default: {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->Have't handler for status ${orderStatusId}`);
                        break;
                    }
                }
                break;
            }
            case "car_assigned": {
                orderStatusWorkerAssigned(this, orderData)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusWorkerAssigned->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusWorkerAssigned->Error: ${err.message}`);

                    });
                break;
            }
            case "car_at_place": {
                orderStatusWorkerAtPlace(this, orderData)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusWorkerAtPlace->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusWorkerAtPlace->Error: ${err.message}`);

                    });
                break;
            }
            case "executing": {
                orderStatusExecuting(this, orderData)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusExecuting->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusExecuting->Error: ${err.message}`);

                    });
                break;
            }
            case "completed": {
                orderStatusCompleted(this, orderData, eventSenderService)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusCompleted->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusCompleted->Error: ${err.message}`);

                    });
                break;
            }
            case "rejected": {
                orderStatusRejected(this, orderData)
                    .then(result => {
                        orderLogger(this.orderId, 'info', `baseGootaxOrder->_statusHandler->orderStatusRejected->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(this.orderId, 'error', `baseGootaxOrder->_statusHandler->orderStatusRejected->Error: ${err.message}`);

                    });
                break;
            }
            default: {
                break;
            }
        }

    };

    /**
     * Persist last order status to redis
     * @param {number} tenantId
     * @param {number} orderId
     * @return {Promise}
     * @private
     */
    _persistLastOrderStatus(tenantId, orderId) {
        orderLogger(this.orderId, 'info', `baseGootaxOrder->_persistLastOrderStatus called!`);
        return new Promise((resolve, reject) => {
            redisOrderManager.getOrder(tenantId, orderId, (err, orderItem) => {
                if (err) {
                    return reject(err);
                } else {
                    orderItem.status.last_status_id = orderItem.status.status_id;
                    orderItem.status.last_status_group = orderItem.status.status_group;
                    redisOrderManager.saveOrder(orderItem, (err, result) => {
                        if (err) {
                            return reject(err);
                        }
                        resolve(result);
                    })
                }
            });
        })
    }

    /**
     * Persist order client phone to redis
     * @param {number} tenantId
     * @param {number} orderId
     * @param {string} clientPhone
     * @return {Promise}
     * @private
     */
    _persistOrderPhone(tenantId, orderId, clientPhone) {
        orderLogger(this.orderId, 'info', `baseGootaxOrder->_persistOrderPhone called!`);
        return new Promise((resolve, reject) => {
            try {
                redisActiveOrderPhoneManager.gerOrdersByPhone(tenantId, clientPhone, (err, orders) => {
                    if (err) {
                        return reject(err);
                    }
                    let orderIdsArr = [];
                    if (!orders) {
                        orderIdsArr.push(orderId);
                    } else {
                        if (typeof orders === "object" && orders !== null) {
                            orderIdsArr = Object.keys(orders).map(k => orders[k]);
                            if (!orderIdsArr.find((element, index, array) => parseInt(element) === parseInt(orderId))) {
                                orderIdsArr.push(orderId);
                            }
                        } else {
                            orderIdsArr = [];
                        }
                    }
                    redisActiveOrderPhoneManager.setOrdersByPhone(tenantId, clientPhone, orderIdsArr, (err, result) => {
                        if (err) {
                            return reject(err);
                        }
                        return resolve(result);
                    });
                });
            } catch (err) {
                return reject(err);
            }
        })
    }

    /**
     * Set pre-order attribute
     * @param {number} tenantId
     * @param {number} orderId
     * @return {Promise}
     * @private
     */
    _setPreOrderAttribute(tenantId, orderId) {
        orderLogger(this.orderId, 'info', `baseGootaxOrder->_setPreOrderAttribute called!`);
        return new Promise((resolve, reject) => {
            redisOrderManager.getOrder(tenantId, orderId, (err, orderItem) => {
                if (err) {
                    return reject(err);
                } else {
                    orderItem.originally_preorder = 1;
                    redisOrderManager.saveOrder(orderItem, (err, result) => {
                        if (err) {
                            return reject(err);
                        }
                        resolve(result);
                    })
                }
            });
        })
    }
}

module.exports = BaseGootaxOrder;