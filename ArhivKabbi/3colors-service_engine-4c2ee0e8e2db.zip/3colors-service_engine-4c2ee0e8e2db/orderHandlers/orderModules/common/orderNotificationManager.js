'use strict';

const pushApi = require("../../../services/externalWebServices/pushApi");
const serviceApi = require("../../../services/externalWebServices/serviceApi");
const phoneApi = require("../../../services/externalWebServices/phoneApi");
const sqlManager = require('../../../database/sqlDB/sqlManager');
const logger = require('../../../services/logger');
const orderLogger = logger.orderLogger;
const redisWorkerManager = require("../../../database/redisDB/redisWorkerManager");
const statusInfo = require("../../../services/orderStatusManager").statusInfo;
const positionManager = require("../../../services/workerPositionManager");
const async = require("async");
const orderDistributionManager = require("./orderDistributionManager");

/**
 * @class OrderNotificationManager
 */
class OrderNotificationManager {

    /**
     * @constructor
     */
    constructor() {

    }

    /**
     * Send change order status notification to client
     * @param {object} orderData
     * @returns {Promise}
     */
    sendChangeOrderStatusNotificationToClient(orderData) {
        return new Promise((resolve, reject) => {
            try {
                orderLogger(orderData.order_id, 'info', "orderNotificationManager->sendChangeOrderStatusNotificationToClient called!");
                const orderId = orderData.order_id;
                const tenantId = orderData.tenant_id;
                const positionId = orderData.tariff.position_id;
                const cityId = orderData.city_id;
                let statusId = parseInt(orderData.status_id);
                const statusGroup = orderData.status.status_group;
                const typeDevice = orderData.device;
                const clientPhone = orderData.phone;
                const deviceToken = orderData.client_device_token;
                const lang = orderData.client.lang;
                const appId = orderData.app_id;
                let typeGroup = null;
                switch (typeDevice) {
                    case "IOS":
                        typeGroup = "APP";
                        break;
                    case "ANDROID":
                        typeGroup = "APP";
                        break;
                    case "WINFON":
                        typeGroup = "APP";
                        break;
                    case "DISPATCHER":
                        typeGroup = "CALL";
                        break;
                    case "WEB":
                        typeGroup = "WEB";
                        break;
                    case "CABINET":
                        typeGroup = "WEB";
                        break;
                    default :
                        orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->There are no type notificaton for device: ${typeDevice}`);
                        break;
                }
                if (typeGroup) {
                    statusId = this._getOrderStatusIdForNotificationTemplate(statusId);
                    orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->Type group of order notificaton: ${typeGroup}`);
                    sqlManager.getOrderNoticeType({
                            tenantId: tenantId,
                            positionId: positionId,
                            cityId: cityId,
                            statusId: statusId,
                            typeGroup: typeGroup,
                        }, (err, notice) => {
                            if (err) {
                                orderLogger(orderId, 'error', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->getOrderNoticeType->Error: ${err.message}`);
                                return reject(err);
                            }
                            orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->Type notice of order notificaton: ${notice}`);
                            switch (notice) {
                                case "sms":
                                    serviceApi.sendSmsNotificationToClient({
                                        orderId,
                                        tenantId,
                                        cityId,
                                        clientPhone,
                                        statusId,
                                        positionId
                                    }, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->serviceApi.sendSmsNotificationToClient->Error: ${err.message}`);
                                            return reject(err);
                                        } else {
                                            orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->serviceApi.sendSmsNotificationToClient->Result: ${result}`);
                                            return resolve(1);
                                        }
                                    });
                                    break;
                                case "push":
                                    const visible = true;
                                    pushApi.sendPushNotificationToClient({
                                            tenantId,
                                            orderId,
                                            positionId,
                                            cityId,
                                            deviceToken,
                                            typeDevice,
                                            appId,
                                            statusGroup,
                                            statusId,
                                            lang,
                                            visible
                                        },
                                        (err, result) => {
                                            if (err) {
                                                orderLogger(orderId, 'error', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->pushApi.sendPushNotificationToClient->Error: ${err.message}`);
                                                return reject(err);
                                            } else {
                                                orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->pushApi.sendPushNotificationToClient->Result: ${result}`);
                                                return resolve(1);
                                            }
                                        });
                                    break;
                                case "autocall":
                                    phoneApi.sendCallNotification(orderId, tenantId, clientPhone, statusId, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->sendCallNotification->Error: ${err.message}`);
                                            return reject(err);
                                        } else {
                                            orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->sendCallNotification->Result: ${result}`);
                                            return resolve(1);
                                        }
                                    });
                                    break;
                                default :
                                    orderLogger(orderId, 'info', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->getOrderNoticeType->There are no notice for status_id: ${statusId}`);
                                    return resolve(1);
                            }
                        }
                    )
                }
            } catch (err) {
                orderLogger(orderData.order_id, 'error', `orderNotificationManager->sendChangeOrderStatusNotificationToClient->Error: ${err.message}`);
                return reject(err);
            }
        })
    }

    /**
     * Send push notification about updating free orders list to all relevant worker
     * @param {Object} orderData
     * @param {Number} sendPushFreeOrderForAll  - 1/0
     * @param {Number} distanceToFilterFreeOrders
     */
    sendUpdateFreeOrdersListToWorkers(orderData, sendPushFreeOrderForAll, distanceToFilterFreeOrders) {
        return new Promise((resolve, reject) => {
            try {
                orderLogger(orderData.order_id, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers called!`);
                orderLogger(orderData.order_id, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers-> sendPushFreeOrderForAll: ${sendPushFreeOrderForAll}. distanceToFilterFreeOrders: ${distanceToFilterFreeOrders}`);
                const orderId = parseInt(orderData.order_id);
                const orderCityId = parseInt(orderData.city_id);
                const statusId = parseInt(orderData.status_id);
                const tenantId = parseInt(orderData.tenant_id);
                const orderPositionId = parseInt(orderData.tariff.position_id);
                const orderTariffClassId = parseInt(orderData.tariff.class_id);
                let soundOn = 0;
                if (statusInfo.free_order.status_id === statusId) {
                    soundOn = 1;
                }
                orderLogger(orderId, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers->soundOn: ${soundOn}`);
                let hasCar = positionManager.positionHasCar(orderPositionId);
                orderLogger(orderId, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers->hasCar: ${hasCar}`);
                redisWorkerManager.getAllWorkers(tenantId, (err, workers) => {
                    if (err) {
                        return reject(err);
                    }
                    const goodWorkersCallsignArr = [];
                    const workerOnlineList = [];
                    async.each(workers, (workerItem, workerCb) => {
                        if (workerItem && workerItem.worker && workerItem.worker.callsign) {
                            let workerCallsign = parseInt(workerItem.worker.callsign);
                            workerOnlineList.push(workerCallsign);
                            orderDistributionManager.isGoodWorkerForOrder(
                                orderData,
                                workerItem,
                                {
                                    needCalcDistance: true,
                                    distanceForSearch: distanceToFilterFreeOrders,
                                    needCheckSocket: false,
                                    needCheckStatus: true
                                })
                                .then(result => {
                                    goodWorkersCallsignArr.push(workerCallsign);
                                    return workerCb(null, 1)
                                })
                                .catch(err => {
                                    return workerCb(null, 1)
                                });
                        } else {
                            return workerCb(null, 1)
                        }
                    }, (err) => {
                        orderLogger(orderId, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers->goodWorkersCallsignArr: ${goodWorkersCallsignArr}`);
                        orderLogger(orderId, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers->workerOnlineList: ${workerOnlineList}`);
                        if (err) {
                            return reject(err);
                        } else {
                            if (sendPushFreeOrderForAll === 0) {
                                if (goodWorkersCallsignArr.length > 0) {
                                    const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                    pushApi.sendFreeOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushFreeOrderForAll, (err, result) => {
                                        if (err) {
                                            return reject(err);
                                        } else {
                                            return resolve(1);
                                        }
                                    })
                                } else {
                                    return resolve(1);
                                }
                            } else if (sendPushFreeOrderForAll === 1) {
                                if (soundOn === 1) {
                                    sqlManager.getGoodWorkerArrForOrder(tenantId, orderCityId, orderPositionId, orderTariffClassId, hasCar, (err, workers) => {
                                        if (err) {
                                            return reject(err);
                                        }
                                        if (!Array.isArray(workers)) {
                                            return resolve(1);
                                        }
                                        async.each(workers, (workerItem, workerCb) => {
                                            let workerCallsign = parseInt(workerItem.callsign);
                                            if (workerOnlineList.indexOf(workerCallsign) === -1) {
                                                goodWorkersCallsignArr.push(workerCallsign);
                                            }
                                            return workerCb(null, 1)
                                        }, (err) => {
                                            orderLogger(orderId, 'info', `orderNotificationManager->sendUpdateFreeOrdersListToWorkers->goodWorkersCallsignArr: ${goodWorkersCallsignArr}`);
                                            if (err) {
                                                return reject(err);
                                            }
                                            if (goodWorkersCallsignArr.length > 0) {
                                                const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                                pushApi.sendFreeOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushFreeOrderForAll, (err, result) => {
                                                    if (err) {
                                                        return reject(err);
                                                    } else {
                                                        return resolve(1);
                                                    }
                                                })
                                            } else {
                                                return resolve(1);
                                            }
                                        });
                                    })
                                } else {
                                    if (goodWorkersCallsignArr.length > 0) {
                                        const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                        pushApi.sendFreeOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushFreeOrderForAll, (err, result) => {
                                            if (err) {
                                                return reject(err);
                                            } else {
                                                return resolve(1);
                                            }
                                        })
                                    } else {
                                        return resolve(1);
                                    }
                                }

                            } else {
                                return resolve(1);
                            }

                        }
                    })
                })
            } catch (err) {
                return reject(err);
            }
        })
    }

    /**
     * Send push notification about updating pre orders list to all relevant worker
     * @param {object} orderData
     * @param {number} sendPushPreOrderForAll - 1/0
     * @returns {Promise}
     */
    sendUpdatePreOrdersListToWorkers(orderData, sendPushPreOrderForAll) {
        return new Promise((resolve, reject) => {
            try {
                orderLogger(orderData.order_id, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers called!`);
                orderLogger(orderData.order_id, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers->sendPushPreOrderForAll: ${sendPushPreOrderForAll}`);
                const orderId = parseInt(orderData.order_id);
                const orderCityId = parseInt(orderData.city_id);
                const statusId = parseInt(orderData.status_id);
                const tenantId = parseInt(orderData.tenant_id);
                const orderPositionId = parseInt(orderData.tariff.position_id);
                const orderTariffClassId = parseInt(orderData.tariff.class_id);
                let soundOn = 0;
                if (statusInfo.new_pre_order.status_id === statusId ||
                    statusInfo.new_pre_order_no_parking.status_id === statusId) {
                    soundOn = 1;
                }
                orderLogger(orderId, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers->soundOn: ${soundOn}`);
                let hasCar = positionManager.positionHasCar(orderPositionId);
                orderLogger(orderId, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers->hasCar: ${hasCar}`);
                redisWorkerManager.getAllWorkers(tenantId, (err, workers) => {
                    if (err) {
                        return reject(err);
                    }
                    const goodWorkersCallsignArr = [];
                    const workerOnlineList = [];
                    async.each(workers, (workerItem, workerCb) => {
                        if (workerItem && workerItem.worker && workerItem.worker.callsign) {
                            let workerCallsign = parseInt(workerItem.worker.callsign);
                            workerOnlineList.push(workerCallsign);
                            orderDistributionManager.isGoodWorkerForOrder(
                                orderData,
                                workerItem,
                                {
                                    needCalcDistance: false,
                                    distanceForSearch: null,
                                    needCheckSocket: false,
                                    needCheckStatus: true
                                })
                                .then(result => {
                                    goodWorkersCallsignArr.push(workerCallsign);
                                    return workerCb(null, 1)
                                })
                                .catch(err => {
                                    return workerCb(null, 1)
                                });
                        } else {
                            return workerCb(null, 1)
                        }
                    }, (err) => {
                        orderLogger(orderId, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers->goodWorkersCallsignArr: ${goodWorkersCallsignArr}`);
                        orderLogger(orderId, 'info', `orderNotificationManager->sendUpdatePreOrdersListToWorkers->workerOnlineList: ${workerOnlineList}`);
                        if (err) {
                            return reject(err);
                        } else {
                            if (!sendPushPreOrderForAll) {
                                if (goodWorkersCallsignArr.length > 0) {
                                    const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                    pushApi.sendPreOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushPreOrderForAll, (err, result) => {
                                        if (err) {
                                            return reject(err);
                                        } else {
                                            return resolve(1);
                                        }
                                    })
                                } else {
                                    return resolve(1);
                                }
                            } else {
                                if (soundOn === 1) {
                                    sqlManager.getGoodWorkerArrForOrder(tenantId, orderCityId, orderPositionId, orderTariffClassId, hasCar, (err, workers) => {
                                        if (err) {
                                            return reject(err);
                                        }
                                        if (!Array.isArray(workers)) {
                                            return resolve(1);
                                        }
                                        async.each(workers, (workerItem, workerCb) => {
                                            let workerCallsign = parseInt(workerItem.callsign);
                                            if (workerOnlineList.indexOf(workerCallsign) === -1) {
                                                goodWorkersCallsignArr.push(workerCallsign);
                                            }
                                            return workerCb(null, 1)
                                        }, (err) => {
                                            if (err) {
                                                return reject(err);
                                            }
                                            orderLogger(orderId, 'info', `orderNotificationManager->goodWorkersCallsignArr: ${goodWorkersCallsignArr}`);
                                            if (goodWorkersCallsignArr.length > 0) {
                                                const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                                pushApi.sendPreOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushPreOrderForAll, (err, result) => {
                                                    if (err) {
                                                        return reject(err);
                                                    } else {
                                                        return resolve(1);
                                                    }
                                                })
                                            } else {
                                                return resolve(1);
                                            }
                                        });
                                    })
                                } else {
                                    if (goodWorkersCallsignArr.length > 0) {
                                        const goodWorkersCallsignString = goodWorkersCallsignArr.join(',');
                                        pushApi.sendPreOrderForAll(tenantId, orderId, goodWorkersCallsignString, soundOn, sendPushPreOrderForAll, (err, result) => {
                                            if (err) {
                                                return reject(err);
                                            } else {
                                                return resolve(1);
                                            }
                                        })
                                    } else {
                                        return resolve(1);
                                    }
                                }
                            }
                        }

                    })
                });
            } catch (err) {
                return reject(err);
            }
        })
    }

    /**
     * Get order status id for notification template
     * @param {Number} orderStatusId
     * @returns {Number} ordertStatusIdFixed
     * @private
     */
    _getOrderStatusIdForNotificationTemplate(orderStatusId) {
        let ordertStatusIdFixed;
        switch (orderStatusId) {
            case statusInfo.new_order_no_parking.status_id:
                ordertStatusIdFixed = statusInfo.new_order.status_id;
                break;
            case statusInfo.new_pre_order_no_parking.status_id:
                ordertStatusIdFixed = statusInfo.new_pre_order.status_id;
                break;
            case statusInfo.pre_order_executing.status_id:
                ordertStatusIdFixed = statusInfo.worker_accepted_order.status_id;
                break;
            default:
                ordertStatusIdFixed = orderStatusId;
        }
        return ordertStatusIdFixed;
    }

}

module.exports = exports = new OrderNotificationManager();
