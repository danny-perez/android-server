'use strict';
const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;
const redisWorkerManager = require("../../../../database/redisDB/redisWorkerManager");
const workerStatusManager = require("../../../../services/workerStatusManager");
const sqlManager = require('../../../../database/sqlDB/sqlManager');

/**
 * Refuse offer order event
 * @param orderInstance
 * @param workerCallsign
 */
module.exports = (orderInstance, workerCallsign) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'refuseOfferOrderEvent called!');
            const orderId = parseInt(orderInstance.orderId);
            const tenantId = parseInt(orderInstance.tenantId);
            redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
                if (err) {
                    return reject(err);
                }
                if (workerData.worker.status === workerStatusManager.offerOrder &&
                    parseInt(workerData.worker.last_offered_order_id) === orderId) {
                    workerData.worker.status = workerStatusManager.free;
                    sqlManager.logOrderChangeData(tenantId, orderId, 'status', workerCallsign, 'worker', workerData.worker.status, 'system', (err, result) => {
                        if (err) {
                            orderLogger(orderId, "error", `refuseOfferOrderEvent->sqlManager.logOrderChangeData->Error: ${err.message}`);
                        } else {
                            orderLogger(orderId, "info", `refuseOfferOrderEvent->sqlManager.logOrderChangeData->Result: ${result}`);
                        }
                    });
                    redisWorkerManager.saveWorker(workerData, (err, result) => {
                        if (err) {
                            orderLogger(orderId, "error", `refuseOfferOrderEvent->redisWorkerManager.saveWorker->Error: ${err.message}`);
                            return reject(1);
                        } else {
                            orderLogger(orderId, "info", `refuseOfferOrderEvent->redisWorkerManager.saveWorker->Result: ${result}`);
                        }
                        return resolve(1);
                    });
                } else {
                    return resolve(1);
                }
            })
        } catch (err) {
            return reject(err);
        }
    })
};