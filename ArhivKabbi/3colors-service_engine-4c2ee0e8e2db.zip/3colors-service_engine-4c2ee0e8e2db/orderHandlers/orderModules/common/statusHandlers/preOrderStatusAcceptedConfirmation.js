'use strict';

const orderLogger = require('../../../../services/logger').orderLogger;

/**
 * Order status accepted preorder confirmation
 * @param {BaseGootaxOrder} orderInstance
 * @param {Object} orderData
 * @return {Promise}
 */
module.exports = (orderInstance, orderData) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'preOrderStatusAcceptedConfirmation called!');
            return resolve(1);
        } catch (err) {
            return reject(err);
        }
    })
};