"use strict";

const redisOrderManager = require('../../../../database/redisDB/redisOrderManager');
const workerStatusManager = require('../../../../services/workerStatusManager');
const serviceApi = require("../../../../services/externalWebServices/serviceApi");
const async = require("async");
const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;
const orderActionManager = require("../orderActionManager");
const redisWorkerManager = require("../../../../database/redisDB/redisWorkerManager");
const closeWorkerShift = require("../../../../workerShiftHandlers/closeWorkerShift");
const sqlManager = require("../../../../database/sqlDB/sqlManager");
const amqpOrderMessageSender = require("../../../../services/amqpOrderMessageSender");
const amqpWorkerMessageSender = require("../../../../services/amqpWorkerMessageSender");
const orderEventOrderMessage = require('../../../orderEvent/orderEventOrderMessage');
const orderEventWorkerMessage = require('../../../orderEvent/orderEventWorkerMessage');
const orderEventOrderCommand = require('../../../orderEvent/orderEventOrderCommand');
const orderEventWorkerCommand = require('../../../orderEvent/orderEventWorkerCommand');
const orderEventSenderService = require('../../../orderEvent/orderEventSenderService');
const config = require('../../../../services/lib').getConfig();
const nodeId = config.MY_ID;
const redisWorkerReservedOrderListManager = require('../../../../database/redisDB/redisWorkerReservedOrderListManager');
const statusInfo = require('../../../../services/orderStatusManager').statusInfo;


/**
 * Order completed
 * @param {BaseGootaxOrder} orderInstance
 * @param {Object} orderData
 * @param {String} eventSenderService
 * @return {*}
 */
module.exports = (orderInstance, orderData, eventSenderService) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'orderStatusCompleted called!');
            const tenantId = orderInstance.tenantId;
            const orderId = orderInstance.orderId;
            const clientId = parseInt(orderData.client_id);
            const statusId = parseInt(orderData.status.status_id);
            const tenantLogin = orderData.tenant_login;
            const workerCallsign = (orderData.worker && orderData.worker.callsign) ? parseInt(orderData.worker.callsign) : null;
            const updateTime = Math.floor(Date.now() / 1000);
            if (orderInstance.statusArr[orderInstance.statusArr.length - 2] !== statusInfo.worker_coming_later.status_id) {
                orderInstance.workerLateTimestamp = null;
            }
            if (orderInstance.statusArr[orderInstance.statusArr.length - 2] !== statusInfo.waiting_for_payment.status_id) {
                orderInstance.startWaitingForPaymentTimestamp = null;
            }
            orderLogger(orderId, 'info', 'OrderStatusCompleted CALLED!');
            async.parallel([
                callback => {
                    serviceApi.updateClientCounters(tenantId, clientId, statusId, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `orderStatusCompleted->serviceApi.updateClientCounters->Error: ${err.message}`);
                        }
                        orderLogger(orderId, 'info', `orderStatusCompleted->serviceApi.updateClientCounters->Result: ${result}`);
                        return callback(null, 1);
                    });
                },
                callback => {
                    orderActionManager.deleteOrderPhone(orderData)
                        .then(result => {
                            orderLogger(orderId, 'info', `orderStatusCompleted->orderActionManager.deleteOrderPhone->Result: ${result}`);
                            return callback(null, 1);
                        })
                        .catch(err => {
                            orderLogger(orderId, 'error', `orderStatusCompleted->orderActionManager.deleteOrderPhone->Error: ${err.message}`);
                        });
                },
                callback => {
                    serviceApi.sendOrderToStatistic(tenantId, orderId, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `orderStatusCompleted->serviceApi.sendOrderToStatistic->Error: ${err.message}`);
                        }
                        orderLogger(orderId, 'info', `orderStatusCompleted->serviceApi.sendOrderToStatistic->Result: ${result}`);
                        return callback(null, 1);
                    })
                },
                callback => {
                    if (workerCallsign) {
                        orderLogger(orderId, 'info', `orderStatusCompleted->Order has worker: ${workerCallsign}`);
                        redisWorkerReservedOrderListManager.delOrder(tenantId, workerCallsign, orderId, (err, result) => {
                            if (err) {
                                orderLogger(orderId, 'error', `orderStatusCompleted->redisWorkerReservedOrderListManager.delOrder->Error: ${err.message}`);
                            } else {
                                orderLogger(orderId, 'info', `orderStatusCompleted->redisWorkerReservedOrderListManager.delOrder->Result: ${result}`);
                            }
                        });
                        redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerDataTemp) => {
                            if (err) {
                                orderLogger(orderId, 'error', `orderStatusCompleted->redisWorkerManager.getWorker->Error: ${err.message}`);
                                return callback(null, 1);
                            }
                            try {
                                const workerShiftId = workerDataTemp.worker.worker_shift_id;
                                sqlManager.logWorkerCompletedOrderCounter(workerShiftId, orderId, (err, result) => {
                                    if (err) {
                                        orderLogger(orderId, 'error', `orderStatusCompleted->sqlManager.logWorkerCompletedOrderCounter->Error: ${err.message}`);
                                    } else {
                                        orderLogger(orderId, 'info', `orderStatusCompleted->sqlManager.logWorkerCompletedOrderCounter->Result: ${result}`);
                                    }
                                });
                                if (orderInstance.workerLateTimestamp !== null) {
                                    const lateTimeSec = updateTime - orderInstance.workerLateTimestamp;
                                    sqlManager.logWorkerLateTime(workerShiftId, lateTimeSec, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderStatusCompleted->sqlManager.logWorkerLateTime->Error: ${err.message}`);
                                        } else {
                                            orderLogger(orderId, 'info', `orderStatusCompleted->sqlManager.logWorkerLateTime->Result: ${result}`);
                                        }
                                    });
                                }
                                if (orderInstance.startWaitingForPaymentTimestamp !== null) {
                                    const orderPaymentTimeSec = updateTime - orderInstance.startWaitingForPaymentTimestamp;
                                    sqlManager.logWorkerOrderPaymentTime(workerShiftId, orderPaymentTimeSec, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderStatusCompleted->sqlManager.logWorkerOrderPaymentTime->Error : ${err.message}`);
                                        } else {
                                            orderLogger(orderId, 'info', `orderStatusCompleted->sqlManager.logWorkerOrderPaymentTime->Result: ${result}`);
                                        }
                                    });
                                }
                            } catch (err) {
                                orderLogger(orderId, 'error', `orderStatusCompleted->Error: ${err.message}`);
                            }
                            const lastOrderId = parseInt(workerDataTemp.worker.last_order_id);
                            const needCloseShift = parseInt(workerDataTemp.worker.need_close_shift) === 1;
                            orderLogger(orderId, 'info', `orderStatusCompleted->lastOrderId: ${lastOrderId}`);
                            orderLogger(orderId, 'info', `orderStatusCompleted->worker status: ${workerDataTemp.worker.status}`);
                            orderLogger(orderId, 'info', `orderStatusCompleted->need close shift: ${needCloseShift}`);
                            if (workerDataTemp.worker && workerDataTemp.worker.status
                                && workerDataTemp.worker.status === workerStatusManager.onOrder
                                && lastOrderId === orderId) {
                                orderLogger(orderId, 'info', `orderStatusCompleted->need set worker status=${workerStatusManager.free}: ${true}`);
                                workerDataTemp.worker.status = workerStatusManager.free;
                            } else {
                                orderLogger(orderId, 'info', `orderStatusCompleted->need set worker status=${workerStatusManager.free}: ${false}`);
                            }
                            redisWorkerManager.saveWorker(workerDataTemp, (err, result) => {
                                if (err) {
                                    orderLogger(orderId, 'error', `orderStatusCompleted->redisWorkerManager.saveWorker->Error ${err.message}`);
                                }
                                orderLogger(orderId, 'info', `orderStatusCompleted->saveWorker->Result: ${result}`);
                                sqlManager.logOrderChangeData(tenantId, orderId, 'status', workerDataTemp.worker.callsign, 'worker', workerStatusManager.free, 'system', (err, result) => {
                                    if (err) {
                                        orderLogger(orderId, 'error', `orderStatusCompleted->sqlManager.logOrderChangeData->Error: ${err.message}`);
                                    } else {
                                        orderLogger(orderId, 'info', `orderStatusCompleted->sqlManager.logOrderChangeData->Result: ${result}`);
                                    }
                                });
                                if (eventSenderService === orderEventSenderService.operatorService) {
                                    let messageString = orderEventWorkerMessage({
                                        command: orderEventWorkerCommand.completeOrder,
                                        tenant_id: tenantId,
                                        tenant_login: tenantLogin,
                                        worker_callsign: workerCallsign,
                                        params: {
                                            order_id: orderId
                                        }
                                    });
                                    const messageTtl = 60 * 60 * 24 * 10; // 10 days
                                    amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTtl, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderStatusCompleted->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                                        } else {
                                            orderLogger(orderId, 'info', `orderStatusCompleted->amqpWorkerMessageSender.sendMessage->Published command: ${orderEventWorkerCommand.completeOrder} to worker: ${workerCallsign}.Result: ${result}`);
                                        }
                                    });
                                }
                                if (needCloseShift) {
                                    orderLogger(orderId, 'info', `orderStatusCompleted->Need close shift of worker: ${workerCallsign}`);
                                    const workerShiftId = workerDataTemp.worker.worker_shift_id;
                                    closeWorkerShift(tenantId, tenantLogin, workerCallsign, workerShiftId, 'timer', 'system', nodeId, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, 'error', `orderStatusCompleted->closeWorkerShift->Error: ${err.message}`);
                                        }
                                        orderLogger(orderId, 'info', `orderStatusCompleted->closeWorkerShift->Result: ${result}`);
                                    })
                                }
                                return callback(null, 1);
                            })

                        })
                    } else {
                        return callback(null, 1);
                    }
                },
                callback => {
                    redisOrderManager.deleteOrder(tenantId, orderId, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `orderStatusCompleted->deleteOrder->Error: ${err.message}`);
                        }
                        orderLogger(orderId, 'info', `orderStatusCompleted->deleteOrder->Result: ${result}`);
                        return callback(null, 1);
                    })
                }
            ], (err, result) => {
                if (err) {
                    orderLogger(orderId, 'error', `orderStatusCompleted->Error: ${err.message}`);
                    return reject(err);
                }
                orderLogger(orderId, 'info', `orderStatusCompleted->Results of completing order: ${result}`);
                const messageString = orderEventOrderMessage({
                    command: orderEventOrderCommand.destroyService,
                    tenant_id: tenantId,
                    order_id: orderId,
                    params: {}
                });
                amqpOrderMessageSender.sendMessage(orderId, messageString, (err, result) => {
                    if (err) {
                        orderLogger(orderId, 'error', err.message);
                        return reject(err);
                    } else {
                        orderLogger(orderId, 'info', `orderStatusCompleted->Published command: ${orderEventOrderCommand.destroyService} to order: ${orderId}. Result: ${result}`);
                        orderInstance.orderTimer.clearAll();
                        orderInstance.orderTimer = null;
                        return resolve(1);
                    }
                });
            })
        } catch (err) {
            return reject(err);
        }
    });

};