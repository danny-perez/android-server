'use strict';
const orderWorkerAssignManager = require('../orderWorkerAssignManager');
const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;
const orderEventSenderService = require('../../../orderEvent/orderEventSenderService');
const statusInfo = require('../../../../services/orderStatusManager').statusInfo;

/**
 * Order status worker refused order assigned
 * @param {BaseGootaxOrder} orderInstance
 * @param {Object} orderData
 * @param {String} eventSenderService
 * @return {Promise}
 */
module.exports = (orderInstance, orderData, eventSenderService) => {
    return new Promise((resolve, reject) => {
        try {
            if (orderInstance.statusChanged) {
                const orderId = orderData.order_id;
                orderLogger(orderId, 'info', 'OrderStatusWorkerRefusedOrderAssignment CALLED!');
                orderInstance.orderTimer.clearAll();
                const isWorkerEventOwner = eventSenderService === orderEventSenderService.workerService;
                const newStatusId = statusInfo.manual_mode.status_id;
                orderWorkerAssignManager.processRefusedOrderAssignment(orderData, {
                    isPreOrder: false,
                    isWorkerEventOwner,
                    newStatusId
                });
            }
            return resolve(1);
        } catch (err) {
            return reject(err);
        }
    });
};
