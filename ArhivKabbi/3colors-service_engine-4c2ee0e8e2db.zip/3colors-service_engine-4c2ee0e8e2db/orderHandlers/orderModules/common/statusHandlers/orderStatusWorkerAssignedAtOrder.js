'use strict';
const orderWorkerAssignManager = require('../orderWorkerAssignManager');
const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;

/**
 * Order status worker assigned at order
 * @param {BaseGootaxOrder} orderInstance
 * @param {Object} orderData
 * @return {Promise}
 */
module.exports = (orderInstance, orderData) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'orderStatusWorkerAssignedAtOrder called!');
            if (orderInstance.statusChanged) {
                orderInstance.orderTimer.clearAll();
                orderWorkerAssignManager.processAssignedOrder(orderData, false);
            }
            return resolve(1);
        } catch (err) {
            return reject(err);
        }
    });
};

