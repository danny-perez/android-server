"use strict";

const redisOrderManager = require('../../../database/redisDB/redisOrderManager');
const statusInfo = require('../../../services/orderStatusManager').statusInfo;
const sqlManager = require('../../../database/sqlDB/sqlManager');
const orderActionManager = require('./orderActionManager');
const amqpOrderMessageSender = require("../../../services/amqpOrderMessageSender");
const amqpWorkerMessageSender = require("../../../services/amqpWorkerMessageSender");
const logger = require('../../../services/logger');
const orderLogger = logger.orderLogger;
const orderEventOrderMessage = require('../../orderEvent/orderEventOrderMessage');
const orderEventWorkerMessage = require('../../orderEvent/orderEventWorkerMessage');
const orderEventOrderCommand = require('../../orderEvent/orderEventOrderCommand');
const orderEventWorkerCommand = require('../../orderEvent/orderEventWorkerCommand');
const redisWorkerManager = require('../../../database/redisDB/redisWorkerManager');
const PHPUnserialize = require("php-unserialize");
const pushApi = require("../../../services/externalWebServices/pushApi");
const orderWorkerAssignManager = require("./orderWorkerAssignManager");

/**
 * @class PreOrderWatcher
 */
class PreOrderWatcher {
    /**
     * @constructor
     */
    constructor() {
    }

    /**
     * Run pre order watcher
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     */
    runWatcher(orderInstance, orderData) {
        orderLogger(orderData.order_id, 'info', "preOrderWatcher->runWatcher called!");
        const tenantId = parseInt(orderData.tenant_id);
        const orderId = parseInt(orderData.order_id);
        const cityTimeOffset = !isNaN(parseFloat(orderData.time_offset)) ? parseFloat(orderData.time_offset) : 0;
        const orderTime = parseInt(orderData.order_time);
        let preOrderTimeToWork = orderInstance.settings.PRE_ORDER_WORKING;
        let preOrderTimeForRemind = orderInstance.settings.WORKER_PRE_ORDER_REMINDER;
        if (!preOrderTimeToWork) {
            orderLogger(orderData.order_id, 'error', `preOrderWatcher->runWatcher->bad preOrderTimeToWork value:${preOrderTimeToWork}`);
        } else {
            this._createPreOrderSenderToWork({
                    tenantId,
                    orderId,
                    orderTime,
                    preOrderTimeToWork,
                    cityTimeOffset
                },
                orderInstance.orderTimer)
                .then(result => {
                    orderLogger(orderId, 'info', `preOrderWatcher->runWatcher->_createPreOrderSenderToWork->Result: ${result}`);
                })
                .catch(err => {
                    orderLogger(orderId, 'error', `preOrderWatcher->runWatcher->_createPreOrderSenderToWork->Error: ${err.message}`);
                });
        }
        if (!preOrderTimeForRemind) {
            orderLogger(orderData.order_id, 'error', `preOrderWatcher->runWatcher->bad preOrderTimeForRemind value:${preOrderTimeForRemind}`);
        } else {
            try {
                preOrderTimeForRemind = PHPUnserialize.unserialize(preOrderTimeForRemind);
                if (typeof preOrderTimeForRemind === "object" && preOrderTimeForRemind !== null) {
                    const preOrderTimeForRemindList = Object.keys(preOrderTimeForRemind).map(k => preOrderTimeForRemind[k]);
                    if (preOrderTimeForRemindList.length === 0) {
                        orderLogger(orderId, 'info', "preOrderWatcher->runWatcher->don't need send worker preorder reminder");
                    } else {
                        let reminderCounter = 1;
                        for (let timePreRemind of preOrderTimeForRemindList) {
                            timePreRemind = !isNaN(parseFloat(timePreRemind)) ? parseFloat(timePreRemind) : null;
                            if (timePreRemind) {
                                this._createPreOrderWorkerNotificationReminder({
                                    tenantId,
                                    orderId,
                                    orderTime,
                                    timePreRemind,
                                    cityTimeOffset,
                                    reminderCounter
                                }, orderInstance.orderTimer);
                                reminderCounter++;
                            }
                        }
                    }
                } else {
                    orderLogger(orderData.order_id, 'error', `preOrderWatcher->runWatcher->bad preOrderTimeForRemind type:${preOrderTimeForRemind}`);
                }
            } catch (err) {
                orderLogger(orderData.order_id, 'error', `preOrderWatcher->runWatcher->preOrderTimeForRemind Error: ${err.message}`);
            }
        }
    }

    /**
     * Create pre order sender to work
     * @param {object} options
     * param {number} options.tenantId
     * param {number} options.orderId
     * param {number} options.orderTime
     * param {number} options.preOrderTimeToWork
     * param {number} options.cityTimeOffset
     * @param {object} orderTimer
     * @return {Promise}
     * @private
     */
    _createPreOrderSenderToWork(options, orderTimer) {
        return new Promise((resolve, reject) => {
            try {
                orderLogger(options.orderId, 'info', "preOrderWatcher->_createPreOrderSenderToWork called!");
                const timeOfNotification = options.orderTime - (options.preOrderTimeToWork * 60);
                const tenantNowTime = parseInt((new Date()).getTime() / 1000) + parseInt(options.cityTimeOffset);
                let startTime = timeOfNotification - tenantNowTime;
                startTime = startTime > 0 ? startTime : 0;
                orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->preOrder sender to work will be called after ${startTime / 60} minutes`);
                orderTimer.setServiceTimeout(orderTimer.preOrderSenderToWorkLabel, () => {
                    orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->start sending preOrder to work...`);
                    redisOrderManager.getOrder(options.tenantId, options.orderId, (err, orderData) => {
                        if (err) {
                            orderLogger(options.orderId, 'err', `preOrderWatcher->_createPreOrderSenderToWork->getOrder->Error: ${err.message}`);
                            return;
                        }
                        orderLogger(options.orderId, 'info', `preOrderSenderToWork->_createPreOrderSenderToWork->getOrder->Result: ${orderData}`);
                        const currentStatusId = parseInt(orderData.status_id);
                        if (currentStatusId === statusInfo.new_pre_order.status_id
                            || currentStatusId === statusInfo.new_pre_order_no_parking.status_id
                            || currentStatusId === statusInfo.worker_refused_preorder.status_id) {
                            this.sendPreOrderToWork(orderData)
                                .then(result => {
                                    orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->_sendPreOrderToWork->Result: ${result}`);
                                })
                                .catch(err => {
                                    orderLogger(options.orderId, 'err', `preOrderWatcher->_createPreOrderSenderToWork->_sendPreOrderToWork->Error: ${err.message}`);
                                });
                        } else if (currentStatusId === statusInfo.worker_accepted_preorder.status_id
                            || currentStatusId === statusInfo.worker_assigned_at_preorder_hard.status_id
                            || currentStatusId === statusInfo.worker_assigned_at_preorder_soft.status_id) {
                            orderLogger(options.orderId, 'info', "preOrderSenderToWork->_createPreOrderSenderToWork->getOrder->Order has status: worker_accepted_preorder. Need check state of worker.");
                            if (orderData && orderData.worker && orderData.worker.callsign) {
                                const workerCallsign = orderData.worker.callsign;
                                const workerId = orderData.worker_id;
                                const carId = orderData.car_id;
                                const tenantLogin = orderData.tenant_login;
                                redisWorkerManager.getWorker(options.tenantId, workerCallsign, (err, workerData) => {
                                    if (err || !workerData) {
                                        orderLogger(options.orderId, 'info', "preOrderSenderToWork->_createPreOrderSenderToWork->getOrder->Worker is not on shift, need send preorder to work");
                                        this.sendPreOrderToWork(orderData)
                                            .then(result => {
                                                orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->sendPreOrderToWork->Result: ${result}`);
                                            })
                                            .catch(err => {
                                                orderLogger(options.orderId, 'err', `preOrderWatcher->_createPreOrderSenderToWork->sendPreOrderToWork->Error: ${err.message}`);
                                            });
                                    } else {
                                        orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->Sending preorder confirmation to worker...`);
                                        //set status: waiting_for_preorder_confirmation, add new timer to call after 2 min preorder_confirm_timeout event:
                                        const updateTime = Math.floor(Date.now() / 1000);
                                        orderData.status_id = statusInfo.waiting_for_preorder_confirmation.status_id;
                                        orderData.status.status_id = statusInfo.waiting_for_preorder_confirmation.status_id;
                                        orderData.status.name = statusInfo.waiting_for_preorder_confirmation.name;
                                        orderData.status.status_group = statusInfo.waiting_for_preorder_confirmation.status_group;
                                        orderData.status_time = updateTime;
                                        orderData.update_time = updateTime;
                                        redisOrderManager.saveOrder(orderData, (err, result) => {
                                            if (err) {
                                                orderLogger(options.orderId, "error", `preOrderWatcher->_createPreOrderSenderToWork->redisOrderManager.saveOrder->Error: ${err.message}`);
                                            } else {
                                                orderLogger(options.orderId, "info", `preOrderWatcher->_createPreOrderSenderToWork->redisOrderManager.saveOrder->Result: ${result}`);
                                                sqlManager.updateOrderFromMysql(options.orderId, orderData.status_id, workerId, carId, updateTime, (err, result) => {
                                                    if (err) {
                                                        orderLogger(options.orderId, "error", `preOrderWatcher->sqlManager.updateOrderFromMysql->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(options.orderId, "info", `preOrderWatcher-->sqlManager.updateOrderFromMysql->Result: ${result}`);
                                                    }
                                                });
                                                sqlManager.updateOrderField(options.orderId, 'deny_refuse_order', 0, (err, result) => {
                                                    if (err) {
                                                        orderLogger(options.orderId, 'error', `preOrderWatcher->sqlManager.updateOrderField->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(options.orderId, 'info', `preOrderWatcher->sqlManager.updateOrderField->Result: ${result}`);
                                                    }
                                                });

                                                const messageString = orderEventOrderMessage({
                                                    command: orderEventOrderCommand.updateOrderData,
                                                    tenant_id: options.tenantId,
                                                    order_id: options.orderId,
                                                    params: {}
                                                });
                                                amqpOrderMessageSender.sendMessage(options.orderId, messageString, (err, result) => {
                                                    if (err) {
                                                        orderLogger(options.orderId, 'error', `preOrderWatcher->amqpOrderMessageSender.sendMessage->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(options.orderId, 'info', `preOrderWatcher->amqpOrderMessageSender.sendMessage->Published command: ${orderEventOrderCommand.updateOrderData} to order: ${options.orderId}. Result: ${result}`);
                                                    }
                                                });
                                                const confirmTimeout = 120;
                                                const workerMessageString = orderEventWorkerMessage({
                                                    command: orderEventWorkerCommand.confirmPreOrder,
                                                    tenant_id: options.tenantId,
                                                    tenant_login: tenantLogin,
                                                    worker_callsign: workerCallsign,
                                                    params: {
                                                        confirm_sec: confirmTimeout,
                                                        order_id: options.orderId
                                                    }
                                                });
                                                amqpWorkerMessageSender.sendMessage(options.tenantId, workerCallsign, workerMessageString, confirmTimeout, (err, result) => {
                                                    if (err) {
                                                        orderLogger(options.orderId, "error", `preOrderWatcher->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(options.orderId, 'info', `preOrderWatcher->published command: ${orderEventWorkerCommand.confirmPreOrder} to worker: ${workerCallsign}. Result: ${result} `);
                                                    }
                                                });
                                            }
                                        });
                                    }
                                })
                            } else {
                                this.sendPreOrderToWork(orderData)
                                    .then(result => {
                                        orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork->sendPreOrderToWork->Result: ${result}`);
                                    })
                                    .catch(err => {
                                        orderLogger(options.orderId, 'err', `preOrderWatcher->_createPreOrderSenderToWork->sendPreOrderToWork->Error: ${err.message}`);
                                    });
                            }
                        } else {
                            orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderSenderToWork-> Don't need send preOrder to work. Order status_id: ${currentStatusId}`);
                        }
                    })
                }, startTime * 1000);
                return resolve(1);
            } catch (err) {
                orderLogger(options.orderId, 'error', `preOrderWatcher->_createPreOrderSenderToWork->Error: ${err.message}`);
                return reject(err);
            }
        });
    }

    /**
     * Create pre order worker notification reminder
     * @param {object} options
     * @param {number} options.tenantId
     * @param {number} options.orderId
     * @param {number} options.orderTime
     * @param {number} options.timePreRemind
     * @param {number} options.cityTimeOffset
     * @param {number} options.reminderCounter
     * @param {object} orderTimer
     * @private
     */
    _createPreOrderWorkerNotificationReminder(options, orderTimer) {
        try {
            orderLogger(options.orderId, 'info', "preOrderWatcher->_createPreOrderWorkerNotificationReminder called!");
            const timeOfNotification = parseInt(options.orderTime) - (parseInt(options.timePreRemind) * 60);
            const tenantNowTime = parseInt((new Date()).getTime() / 1000) + parseInt(options.cityTimeOffset);
            let startTime = timeOfNotification - tenantNowTime;
            startTime = startTime > 0 ? startTime : 0;
            let serviceTimoutLabel;
            switch (options.reminderCounter) {
                case 1:
                    serviceTimoutLabel = orderTimer.preOrderFirstReminderLabel;
                    break;
                case 2:
                    serviceTimoutLabel = orderTimer.preOrderSecondReminderLabel;
                    break;
                case 3:
                    serviceTimoutLabel = orderTimer.preOrderThirdReminderLabel;
                    break;
                default:
                    break;
            }
            if (serviceTimoutLabel) {
                orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->preorder reminder will be called after ${startTime / 60} minutes`);
                orderTimer.setServiceTimeout(serviceTimoutLabel, () => {
                    orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->Start sending preorder reminder...`);
                    redisOrderManager.getOrder(options.tenantId, options.orderId, (err, orderData) => {
                        if (err) {
                            orderLogger(options.orderId, 'error', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->getOrder->Error: ${err.message}`);
                            return;
                        }
                        if (orderData.worker && orderData.worker.callsign
                            && (parseInt(orderData.status_id) === statusInfo.worker_accepted_preorder.status_id
                            || parseInt(orderData.status_id) === statusInfo.worker_assigned_at_preorder_soft.status_id
                            || parseInt(orderData.status_id) === statusInfo.worker_assigned_at_preorder_hard.status_id)) {
                            pushApi.sendToWorkerRemindPreOrder(options.tenantId, options.orderId, orderData.worker.callsign, orderData.order_number, options.timePreRemind, (err, result) => {
                                if (err) {
                                    orderLogger(options.orderId, 'error', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->sendToWorkerRemindPreOrder->Error: ${err.message}`);
                                }
                                orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->pushApi.sendToWorkerRemindPreOrder->Result: ${result}`);
                            })
                        } else {
                            orderLogger(options.orderId, 'info', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->Don't need send preorder reminder`);
                        }

                    })
                }, startTime * 1000)
            }
        } catch (err) {
            orderLogger(options.orderId, 'error', `preOrderWatcher->_createPreOrderWorkerNotificationReminder->Error: ${err.message}`);
        }
    }


    /**
     * Send preorder to worker (set new status)
     * @param orderData
     * @return {Promise}
     */
    sendPreOrderToWork(orderData) {
        return new Promise((resolve, reject) => {
            orderLogger(orderData.order_id, 'info', 'preOrderWatcher->sendPreOrderToWork called!');
            const newStatusId = statusInfo.new_order.status_id;
            orderWorkerAssignManager.processRefusedOrderAssignment(orderData, {
                isPreOrder: true,
                isWorkerEventOwner: true,
                newStatusId
            });
            return resolve(1);
        });
    }
}

module.exports = exports = new PreOrderWatcher();