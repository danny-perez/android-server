'use strict';

const redisOrderManager = require('../../../../database/redisDB/redisOrderManager');
const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;
const statusInfo = require('../../../../services/orderStatusManager').statusInfo;
const sqlManager = require("../../../../database/sqlDB/sqlManager");
const orderEventOrderCommand = require('../../../orderEvent/orderEventOrderCommand');
const orderEventOrderMessage = require('../../../orderEvent/orderEventOrderMessage');
const amqpOrderMessageSender = require("../../../../services/amqpOrderMessageSender");


/**
 * Order offering timeout
 * @param {BaseGootaxOrder} orderInstance
 * @return {Promise}
 */
module.exports = (orderInstance) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'OrderOfferTimeOut called!');
            redisOrderManager.getOrder(orderInstance.tenantId, orderInstance.orderId, (err, orderData) => {
                if (err) {
                    orderLogger(orderInstance.orderId, 'error', `orderOfferTimeOut->redisOrderManager.getOrder->Error: ${err.message}`);
                    return reject(err);
                }
                if (parseInt(orderData.status_id) !== statusInfo.offer_order.status_id) {
                    orderLogger(orderInstance.orderId, 'info', "orderOfferTimeOut->Order is not offering now");
                    return resolve(1);
                }
                setWorkerIgnoredOfferOrder(orderInstance, orderData)
                    .then(result => {
                        orderLogger(orderInstance.orderId, 'info', `orderOfferTimeOut->setWorkerIgnoredOfferOrder->result:${result}`);
                        return resolve(1);
                    })
                    .catch(err => {
                        orderLogger(orderInstance.orderId, 'error', `orderOfferTimeOut->setWorkerIgnoredOfferOrder->Error: ${err.message}`);
                        return reject(err);
                    })

            })
        } catch (err) {
            return reject(err);
        }
    })
};


function setWorkerIgnoredOfferOrder(orderInstance, orderData) {
    return new Promise((resolve, reject) => {
        orderData.status_id = statusInfo.worker_ignored_offer_order.status_id;
        orderData.status.status_id = statusInfo.worker_ignored_offer_order.status_id;
        orderData.status.name = statusInfo.worker_ignored_offer_order.name;
        const updateTime = Math.floor(Date.now() / 1000);
        orderData.update_time = updateTime;
        orderData.status_time = updateTime;
        redisOrderManager.saveOrder(orderData, (err, result) => {
            if (err) {
                orderLogger(orderInstance.orderId, 'error', `orderOfferTimeOut->setWorkerIgnoredOfferOrder->redisOrderManager.saveOrder->Error: ${err.message}`);
                return reject(err);
            }
            sqlManager.updateOrderFromMysql(orderInstance.orderId, statusInfo.worker_ignored_offer_order.status_id, orderData.worker_id, orderData.car_id, updateTime, (err, result) => {
                if (err) {
                    orderLogger(orderInstance.orderId, "error", `orderOfferTimeOut->setWorkerIgnoredOfferOrder->sqlManager.updateOrderFromMysql->Error: ${err.message}`);
                } else {
                    orderLogger(orderInstance.orderId, "info", `orderOfferTimeOut->setWorkerIgnoredOfferOrder->sqlManager.updateOrderFromMysql->Result: ${result}`);
                }
            });
            const messageString = orderEventOrderMessage({
                command: orderEventOrderCommand.updateOrderData,
                tenant_id: orderInstance.tenantId,
                order_id: orderInstance.orderId,
                params: {}
            });
            amqpOrderMessageSender.sendMessage(orderInstance.orderId, messageString, (err, result) => {
                if (err) {
                    orderLogger(orderInstance.orderId, "error", `orderOfferTimeOut->setWorkerIgnoredOfferOrder->amqpOrderMessageSender.sendMessage->Error: ${err.message}`);
                    return reject(err);
                }
                orderLogger(orderInstance.orderId, 'info', `orderOfferTimeOut->setWorkerIgnoredOfferOrder->amqpOrderMessageSender.sendMessage->Published message: ${orderEventOrderCommand.updateOrderData} to order: ${orderInstance.orderId}. Result: ${result}`);
                return resolve(1);
            });
        })
    })
}
