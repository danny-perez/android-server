'use strict';

const logger = require('../../../../services/logger');
const orderLogger = logger.orderLogger;
const orderEventOrderMessage = require('../../../orderEvent/orderEventOrderMessage');
const amqpOrderMessageSender = require("../../../../services/amqpOrderMessageSender");
const redisOrderManager = require('../../../../database/redisDB/redisOrderManager');
const orderWorkerAssignManager = require("../orderWorkerAssignManager");
const statusInfo = require('../../../../services/orderStatusManager').statusInfo;

/**
 * PreOrder confirmation timeout
 * @param {BaseGootaxOrder} orderInstance
 * @return {Promise}
 */
module.exports = (orderInstance) => {
    return new Promise((resolve, reject) => {
        try {
            orderLogger(orderInstance.orderId, 'info', 'PreOrderConfirmTimeOut called!');
            redisOrderManager.getOrder(orderInstance.tenantId, orderInstance.orderId, (err, orderData) => {
                if (err) {
                    orderLogger(orderInstance.orderId, 'error', `preOrderConfirmTimeOut->redisOrderManager.getOrder->Error: ${err.message}`);
                    return reject(err);
                }
                if (parseInt(orderData.status_id) === statusInfo.waiting_for_preorder_confirmation.status_id) {
                    orderLogger(orderInstance.orderId, 'info', `preOrderConfirmTimeOut->Need send preorder to work`);
                    orderWorkerAssignManager.processRefusedOrderAssignment(orderData, {
                        isPreOrder: true,
                        isWorkerEventOwner: true,
                        newStatusId: statusInfo.worker_ignored_preorder_confirmation.status_id
                    });
                } else {
                    orderLogger(orderInstance.orderId, 'info', `preOrderConfirmTimeOut->order status: ${orderData.status_id}. Dont need send preorder to work`);
                    return resolve(1);
                }
            });

        } catch (err) {
            return reject(err);
        }
    })
};