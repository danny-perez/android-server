'use strict';

const logger = require('../../../services/logger');
const orderLogger = logger.orderLogger;
const geoLib = require("geolib");
const redisWorkerManager = require('../../../database/redisDB/redisWorkerManager');
const redisParkingManager = require('../../../database/redisDB/redisParkingManager');
const rabbitmqHttpService = require('../../../services/rabbitmqHttpService');
const orderActionManager = require('./orderActionManager');
const sqlManager = require("../../../database/sqlDB/sqlManager");
const async = require("async");
const pushApi = require("../../../services/externalWebServices/pushApi");
const redisOrderManager = require("../../../database/redisDB/redisOrderManager");
const amqpWorkerMessageSender = require("../../../services/amqpWorkerMessageSender");
const amqpOrderMessageSender = require("../../../services/amqpOrderMessageSender");
const orderEventOrderMessage = require('../../orderEvent/orderEventOrderMessage');
const orderEventWorkerMessage = require('../../orderEvent/orderEventWorkerMessage');
const orderEventOrderCommand = require('../../orderEvent/orderEventOrderCommand');
const orderEventWorkerCommand = require('../../orderEvent/orderEventWorkerCommand');
const statusInfo = require('../../../services/orderStatusManager').statusInfo;
const PHPUnserialize = require("php-unserialize");
const workerStatusManager = require("../../../services/workerStatusManager");

/**
 * @class OrderDistributionManager
 */
class OrderDistributionManager {

    /**
     *@constructor
     */
    constructor() {
        this.distanceDistributionType = 1;
        this.parkingDistributionType = 2;
        this.offerOrderInRotationType = 'queue';
        this.offerOrderMultipleType = 'batch';
    }

    /**
     * Run/Continue order distribution process
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     */
    runDistributionProcess(orderInstance, orderData) {
        orderLogger(orderInstance.orderId, 'info', 'orderDistributionManager->runDistributionProcess->Called!');
        if (!orderInstance.isForAllWorkers) {
            orderLogger(orderInstance.orderId, 'info', 'orderDistributionManager->runDistributionProcess->Order is not for all workers!');
            orderInstance.isForAllWorkers = true;
            orderActionManager.sendOrderToFreeStatus(orderData, false)
                .then(result => {
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                })
                .catch(err => {
                    orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runDistributionProcess->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                });
        } else {
            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->currentDistributionCircle: ${orderInstance.currentDistributionCircle}`);
            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->currentDistributionCircleRepeat: ${orderInstance.currentDistributionCircleRepeat}`);
            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->offeredInCircleRepeatWorkersList: ${Array.from(orderInstance.offeredInCircleRepeatWorkersList)}`);
            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->offeredInCircleWorkersList: ${Array.from(orderInstance.offeredInCircleWorkersList)}`);
            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->offeredInAllTimeWorkersList: ${Array.from(orderInstance.offeredInAllTimeWorkersList)}`);
            switch (orderInstance.settings.TYPE_OF_DISTRIBUTION_ORDER) {
                case this.distanceDistributionType:
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->maxDistanceDistributionCircle: ${orderInstance.maxDistanceDistributionCircle}`);
                    this._runDistanceDistributionType(orderInstance, orderData);
                    break;
                case this.parkingDistributionType:
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runDistributionProcess->maxParkingDistributionRepeat: ${orderInstance.settings.CIRCLES_DISTRIBUTION_ORDER}`);
                    this._runParkingDistributionType(orderInstance, orderData);
                    break;
                default:
                    orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runDistributionProcess->Order has unsupported distribution type : ${orderInstance.settings.TYPE_OF_DISTRIBUTION_ORDER}`);
                    break;
            }

        }
    }

    /**
     * Run personal offer order for worker
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @param {Number} workerCallsign
     */
    runPersonalOffer(orderInstance, orderData, workerCallsign) {
        orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->Need send personal offer order№${orderInstance.orderId} for worker ${workerCallsign} `);
        orderInstance.isForAllWorkers = false;
        redisWorkerManager.getWorker(orderInstance.tenantId, workerCallsign, (err, workerData) => {
            if (err) {
                orderLogger(orderInstance.orderId, 'error', 'orderDistributionManager->runPersonalOffer->getWorker-> Error');
                orderLogger(orderInstance.orderId, "error", err);
                return;
            }
            this.isGoodWorkerForOrder(orderData, workerData, {
                distanceForSearch: Number.MAX_SAFE_INTEGER,
                needCalcDistance: false,
                needCheckSocket: false,
                needCheckStatus: false
            }).then(workerInfo => {
                rabbitmqHttpService.getQueueConsumersCount(`${orderInstance.tenantId}_worker_${workerCallsign}`, null, (err, result) => {
                    if (err) {
                        orderLogger(orderInstance.orderId, 'error', `orderDistributionManager-runPersonalOffer->getQueueConsumersCount error`);
                        orderLogger(orderInstance.orderId, 'error', err.message);
                        orderActionManager.sendOrderToFreeStatus(orderData, false)
                            .then(result => {
                                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                            });
                    } else {
                        orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->is socket connected of ${workerCallsign}? result: ${result}`);
                        if (result >= 1) {
                            this._sendOfferOrder({
                                tenantId: orderInstance.tenantId,
                                tenantLogin: orderData.tenant_login,
                                workerInfo,
                                orderId: orderInstance.orderId,
                                orderCurrencyId: orderData.currency_id,
                                offerSec: orderInstance.settings.ORDER_OFFER_SEC
                            })
                                .then(result => {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->Send offer order to worker ${workerCallsign}! `);
                                })
                                .catch(err => {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->sendOfferOrder-> Can't send offer order to  ${workerCallsign}! Reason: ${err.message}`);
                                    orderActionManager.sendOrderToFreeStatus(orderData, false)
                                        .then(result => {
                                            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                                        })
                                        .catch(err => {
                                            orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                                        });
                                });

                        } else {
                            orderActionManager.sendOrderToFreeStatus(orderData, false)
                                .then(result => {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                                })
                                .catch(err => {
                                    orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                                });
                        }
                    }
                });
            }).catch(err => {
                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->runPersonalOffer->isGoodWorkerForOrder-> ${err.message}`);
                orderActionManager.sendOrderToFreeStatus(orderData, false)
                    .then(result => {
                        orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                    })
                    .catch(err => {
                        orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->runPersonalOffer->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                    });
            });

        });

    }

    /**
     * Run/Continue distance distribution process
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @private
     */
    _runDistanceDistributionType(orderInstance, orderData) {
        this._distributeOrderByDistance(orderInstance, orderData)
            .then(result => {
                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->_distributeOrderByDistance->Result ${result}`);
            })
            .catch(err => {
                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->_distributeOrderByDistance-> ${err.message}`);
                let sendToFree = false;
                //Если это последний повтор в круге
                if (orderInstance.currentDistributionCircleRepeat >= orderInstance.settings[`CIRCLE_REPEAT_${orderInstance.currentDistributionCircle}`]) {
                    //Если это не последний круг
                    if (orderInstance.currentDistributionCircle < orderInstance.maxDistanceDistributionCircle) {
                        //Увеличиваем круг
                        orderInstance.currentDistributionCircle++;
                        //Выставляем повтор в новом круге
                        orderInstance.currentDistributionCircleRepeat = 1;
                        //Чистим список водителей, которым предлагался заказ в повторе
                        orderInstance.offeredInCircleRepeatWorkersList.clear();
                        //Копириуем всех водителей, котороым предлагался заказ в круге в глобальный список
                        orderInstance.offeredInCircleWorkersList.forEach(workerCallsign => {
                            orderInstance.offeredInAllTimeWorkersList.add(workerCallsign);
                        });
                        //Чистим список водителей, которым предлагался заказ в круге
                        orderInstance.offeredInCircleWorkersList.clear();
                    } else {
                        sendToFree = true;
                    }
                } else {
                    orderInstance.offeredInCircleRepeatWorkersList.clear();
                    orderInstance.currentDistributionCircleRepeat++;
                }
                if (sendToFree) {
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->_distributeOrderByDistance->Maximum number of order distribution cycles reached. Need send order to free`);
                    orderActionManager.sendOrderToFreeStatus(orderData, false)
                        .then(result => {
                            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                        })
                        .catch(err => {
                            orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runDistanceDistributionType->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                        });
                } else {
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->New order distribution cycle will be call after ${orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER} seconds`);
                    if (orderInstance && orderInstance.orderTimer) {
                        orderInstance.orderTimer.clearAll();
                    }
                    if (orderInstance.settings.FREE_STATUS_BETWEEN_DISTRIBUTION_CYCLES) {
                        orderActionManager.sendOrderToFreeStatus(orderData, true)
                            .then(result => {
                                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runDistanceDistributionType->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                            })
                            .then(() => {
                                if (orderInstance && orderInstance.orderTimer) {
                                    orderInstance.orderTimer.setServiceTimeout(orderInstance.orderTimer.distributionCyclesTimeoutLabel, () => {
                                        orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->New order distribution circle repeat.Value:${orderInstance.currentDistributionCircleRepeat}`);
                                        this.runDistributionProcess(orderInstance, orderData);
                                    }, orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER * 1000);
                                }
                            });
                    } else {
                        orderData.status_id = statusInfo.new_order.status_id;
                        orderData.status.status_id = statusInfo.new_order.status_id;
                        orderData.status.name = statusInfo.new_order.name;
                        orderData.status.status_group = statusInfo.new_order.status_group;
                        orderData.worker_id = null;
                        orderData.car_id = null;
                        orderData.car = null;
                        orderData.worker = null;
                        const updateTime = Math.floor(Date.now() / 1000);
                        orderData.update_time = updateTime;
                        redisOrderManager.saveOrder(orderData, (err, result) => {
                            if (err) {
                                orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runDistanceDistributionType->saveOrder->Error: ${err.message}`);
                            }
                            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->saveOrder->Result: ${result}`);
                            sqlManager.updateOrderFromMysql(orderInstance.orderId, statusInfo.new_order.status_id, null, null, updateTime, (err, result) => {
                                if (err) {
                                    orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runDistanceDistributionType->updateOrderFromMysql->Error: ${err.message}`);
                                } else {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->updateOrderFromMysql->Result: ${result}`);
                                }

                            });
                            if (orderInstance && orderInstance.orderTimer) {
                                orderInstance.orderTimer.setServiceTimeout(orderInstance.orderTimer.distributionCyclesTimeoutLabel, () => {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runDistanceDistributionType->New order distribution circle repeat.Value:${orderInstance.currentDistributionCircleRepeat}`);
                                    this.runDistributionProcess(orderInstance, orderData);
                                }, orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER * 1000);
                            }
                        });
                    }
                }
            });
    }


    /**
     * Run/Continue parking distribution process
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @private
     */
    _runParkingDistributionType(orderInstance, orderData) {
        this._distributeOrderByParking(orderInstance, orderData)
            .then(result => {
                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->_distributeOrderByParking->Result ${result}`);
            })
            .catch(err => {
                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->_distributeOrderByParking-> ${err.message}`);
                let sendToFree = false;
                if (orderInstance.currentDistributionCircleRepeat >= orderInstance.settings.CIRCLES_DISTRIBUTION_ORDER) {
                    sendToFree = true;
                } else {
                    orderInstance.offeredInCircleRepeatWorkersList.clear();
                    orderInstance.currentDistributionCircleRepeat++;
                }
                if (sendToFree) {
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->_distributeOrderByParking->Maximum number of order distribution circle repeat reached. Need send order to free`);
                    orderActionManager.sendOrderToFreeStatus(orderData, false)
                        .then(result => {
                            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                        })
                        .catch(err => {
                            orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runParkingDistributionType->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                        });
                } else {
                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->New order distribution circle repeat will be call after ${orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER} seconds`);
                    if (orderInstance && orderInstance.orderTimer) {
                        orderInstance.orderTimer.clearAll();
                    }
                    if (orderInstance.settings.FREE_STATUS_BETWEEN_DISTRIBUTION_CYCLES) {
                        orderActionManager.sendOrderToFreeStatus(orderData, true)
                            .then(result => {
                                orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->orderActionManager.sendOrderToFreeStatus->Result: ${result}`);
                            })
                            .catch(err => {
                                orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runParkingDistributionType->orderActionManager.sendOrderToFreeStatus->Error: ${err.message}`);
                            })
                            .then(() => {
                                if (orderInstance && orderInstance.orderTimer) {
                                    orderInstance.orderTimer.setServiceTimeout(orderInstance.orderTimer.distributionCyclesTimeoutLabel, () => {
                                        orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->New order distribution circle repeat. Value:${orderInstance.currentDistributionCircleRepeat}`);
                                        this.runDistributionProcess(orderInstance, orderData);
                                    }, orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER * 1000);
                                }
                            });
                    } else {
                        orderData.status_id = statusInfo.new_order.status_id;
                        orderData.status.status_id = statusInfo.new_order.status_id;
                        orderData.status.name = statusInfo.new_order.name;
                        orderData.status.status_group = statusInfo.new_order.status_group;
                        orderData.worker_id = null;
                        orderData.car_id = null;
                        orderData.car = null;
                        orderData.worker = null;
                        const updateTime = Math.floor(Date.now() / 1000);
                        orderData.update_time = updateTime;
                        redisOrderManager.saveOrder(orderData, (err, result) => {
                            if (err) {
                                orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runParkingDistributionType->saveOrder->Error: ${err.message}`);
                            }
                            orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->saveOrder->Result: ${result}`);
                            sqlManager.updateOrderFromMysql(orderInstance.orderId, statusInfo.new_order.status_id, null, null, updateTime, (err, result) => {
                                if (err) {
                                    orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_runParkingDistributionType->updateOrderFromMysql->Error: ${err.message}`);
                                } else {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->updateOrderFromMysql->Result: ${result}`);
                                }

                            });
                            if (orderInstance && orderInstance.orderTimer) {
                                orderInstance.orderTimer.setServiceTimeout(orderInstance.orderTimer.distributionCyclesTimeoutLabel, () => {
                                    orderLogger(orderInstance.orderId, 'info', `orderDistributionManager->_runParkingDistributionType->New order distribution circle repeat. Value:${orderInstance.currentDistributionCircleRepeat}`);
                                    this.runDistributionProcess(orderInstance, orderData);
                                }, orderInstance.settings.DELAY_CIRCLES_DISTRIBUTION_ORDER * 1000);
                            }
                        });
                    }

                }
            });
    }

    /**
     * Find best workers for distance distribution and send offer order
     * @param {BaseGootaxOrder} orderInstance
     * @param {object} orderData
     * @returns {Promise}
     * @private
     */
    _distributeOrderByDistance(orderInstance, orderData) {
        const self = this;
        const offerOrderType = orderInstance.settings.OFFER_ORDER_TYPE ? orderInstance.settings.OFFER_ORDER_TYPE : this.offerOrderInRotationType;
        const offerOrderWorkersCount = offerOrderType === this.offerOrderInRotationType ? 1 : orderInstance.settings.OFFER_ORDER_WORKER_BATCH_COUNT ? orderInstance.settings.OFFER_ORDER_WORKER_BATCH_COUNT : 2;
        return new Promise((resolve, reject) => {
            this._getRelevantWorkersListByDistance(orderInstance, orderData, offerOrderType, offerOrderWorkersCount)
                .then((relevantWorkersList) => {
                    function offerSender(relevantWorkersList) {
                        if (relevantWorkersList.length === 0) {
                            return reject(new Error("No relevant workers"));
                        }
                        redisOrderManager.getOrder(orderInstance.tenantId, orderInstance.orderId, (err, orderData) => {
                            if (err) {
                                orderLogger(orderInstance.orderId, "info", "orderDistributionManager->_distributeOrderByDistance->Don't need distribute order");
                                orderLogger(orderInstance.orderId, "error", `orderDistributionManager->_distributeOrderByDistance->getOrder->Error: ${err.message}`);
                                return resolve(1);
                            }
                            if (self._getRelevantOfferOrderStatuses().indexOf(parseInt(orderData.status.status_id)) === -1) {
                                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_distributeOrderForDistance->Don't need distribute order. Current order status id: ${orderData.status.status_id}`);
                                return resolve(1);
                            }

                            if (!orderInstance.settings.FREE_STATUS_BETWEEN_DISTRIBUTION_CYCLES) {
                                if ([statusInfo.free_order.status_id, statusInfo.outdated_order.status_id].indexOf(parseInt(orderData.status_id)) !== -1) {
                                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_distributeOrderForDistance->Don't need distribute order. Current order status: ${orderData.status_id}`);
                                    return resolve(1);
                                }
                            }
                            if (offerOrderType === self.offerOrderMultipleType) {
                                self._sendBatchOfferOrder({
                                    tenantId: orderInstance.tenantId,
                                    tenantLogin: orderData.tenant_login,
                                    workers: relevantWorkersList,
                                    orderId: orderInstance.orderId,
                                    orderCurrencyId: orderData.currency_id,
                                    offerSec: orderInstance.settings.ORDER_OFFER_SEC
                                })
                                    .then(result => {
                                        for (let worker of relevantWorkersList) {
                                            orderInstance.offeredInCircleRepeatWorkersList.add(worker.worker_callsign);
                                            orderInstance.offeredInCircleWorkersList.add(worker.worker_callsign);
                                        }
                                        return resolve(1);
                                    })
                                    .catch(err => {
                                        for (let worker of relevantWorkersList) {
                                            orderInstance.offeredInCircleRepeatWorkersList.add(worker.worker_callsign);
                                            orderInstance.offeredInCircleWorkersList.add(worker.worker_callsign);
                                        }
                                        offerSender(relevantWorkersList);
                                    });
                            } else {
                                const topWorker = relevantWorkersList.shift();
                                self._sendOfferOrder({
                                    tenantId: orderInstance.tenantId,
                                    tenantLogin: orderData.tenant_login,
                                    workerInfo: topWorker,
                                    orderId: orderInstance.orderId,
                                    orderCurrencyId: orderData.currency_id,
                                    offerSec: orderInstance.settings.ORDER_OFFER_SEC
                                })
                                    .then(result => {
                                        orderInstance.offeredInCircleRepeatWorkersList.add(topWorker.worker_callsign);
                                        orderInstance.offeredInCircleWorkersList.add(topWorker.worker_callsign);
                                        return resolve(1);
                                    })
                                    .catch(err => {
                                        orderInstance.offeredInCircleRepeatWorkersList.add(topWorker.worker_callsign);
                                        orderInstance.offeredInCircleWorkersList.add(topWorker.worker_callsign);
                                        offerSender(relevantWorkersList);
                                    });
                            }
                        });
                    }

                    offerSender(relevantWorkersList);
                })
                .catch(err => {
                    return reject(err);
                })
        });
    }

    /**
     * Find best worker for parking distribution and send offer order
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @returns {Promise}
     * @private
     */
    _distributeOrderByParking(orderInstance, orderData) {
        const self = this;
        const offerOrderType = orderInstance.settings.OFFER_ORDER_TYPE ? orderInstance.settings.OFFER_ORDER_TYPE : this.offerOrderInRotationType;
        const offerOrderWorkersCount = offerOrderType === this.offerOrderInRotationType ? 1 : orderInstance.settings.OFFER_ORDER_WORKER_BATCH_COUNT ? orderInstance.settings.OFFER_ORDER_WORKER_BATCH_COUNT : 2;
        return new Promise((resolve, reject) => {
            this._getRelevantWorkersListByParking(orderInstance, orderData, offerOrderType, offerOrderWorkersCount)
                .then((workersList) => {
                    function offerSender(relevantWorkersList) {
                        if (relevantWorkersList.length === 0) {
                            return reject(new Error("No relevant workers"));
                        }
                        redisOrderManager.getOrder(orderInstance.tenantId, orderInstance.orderId, (err, orderData) => {
                            if (err) {
                                orderLogger(orderInstance.orderId, "info", "orderDistributionManager->_distributeOrderByParking->Don't need distribute order");
                                orderLogger(orderInstance.orderId, "error", `orderDistributionManager->_distributeOrderByParking->Error: ${err.message}`);
                                return resolve(1);
                            }
                            if (self._getRelevantOfferOrderStatuses().indexOf(parseInt(orderData.status.status_id)) === -1) {
                                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_distributeOrderByParking->Don't need distribute order. Current order status id: ${orderData.status.status_id}`);
                                return resolve(1);
                            }
                            if (!orderInstance.settings.FREE_STATUS_BETWEEN_DISTRIBUTION_CYCLES) {
                                if ([statusInfo.free_order.status_id, statusInfo.outdated_order.status_id].indexOf(parseInt(orderData.status_id)) !== -1) {
                                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_distributeOrderByParking->Don't need distribute order. Current order status: ${orderData.status_id}`);
                                    return resolve(1);
                                }
                            }
                            if (offerOrderType === self.offerOrderMultipleType) {
                                self._sendBatchOfferOrder({
                                    tenantId: orderInstance.tenantId,
                                    tenantLogin: orderData.tenant_login,
                                    workers: relevantWorkersList,
                                    orderId: orderInstance.orderId,
                                    orderCurrencyId: orderData.currency_id,
                                    offerSec: orderInstance.settings.ORDER_OFFER_SEC
                                })
                                    .then(result => {
                                        for (let worker of relevantWorkersList) {
                                            orderInstance.offeredInCircleRepeatWorkersList.add(worker.worker_callsign);
                                            orderInstance.offeredInCircleWorkersList.add(worker.worker_callsign);
                                        }
                                        return resolve(1);
                                    })
                                    .catch(err => {
                                        for (let worker of relevantWorkersList) {
                                            orderInstance.offeredInCircleRepeatWorkersList.add(worker.worker_callsign);
                                            orderInstance.offeredInCircleWorkersList.add(worker.worker_callsign);
                                        }
                                        offerSender(relevantWorkersList);
                                    });
                            } else {
                                const topWorker = relevantWorkersList.shift();
                                self._sendOfferOrder({
                                    tenantId: orderInstance.tenantId,
                                    tenantLogin: orderData.tenant_login,
                                    workerInfo: topWorker,
                                    orderId: orderInstance.orderId,
                                    orderCurrencyId: orderData.currency_id,
                                    offerSec: orderInstance.settings.ORDER_OFFER_SEC
                                })
                                    .then(result => {
                                        orderInstance.offeredInCircleRepeatWorkersList.add(topWorker.worker_callsign);
                                        orderInstance.offeredInCircleWorkersList.add(topWorker.worker_callsign);
                                        return resolve(1);
                                    })
                                    .catch(err => {
                                        orderInstance.offeredInCircleRepeatWorkersList.add(topWorker.worker_callsign);
                                        orderInstance.offeredInCircleWorkersList.add(topWorker.worker_callsign);
                                        offerSender(relevantWorkersList);
                                    });
                            }

                        });
                    }

                    offerSender(workersList);
                })
                .catch(err => {
                    return reject(err);
                })
        });
    }

    /**
     * Get relevant workers list by distance
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @param {String} offerOrderType
     * @param {Number} workersCount
     * @return {Promise}
     * @private
     */
    _getRelevantWorkersListByDistance(orderInstance, orderData, offerOrderType, workersCount) {
        return new Promise((resolve, reject) => {
                redisWorkerManager.getAllWorkers(orderInstance.tenantId, (err, workers) => {
                    if (err) {
                        orderLogger(orderInstance.orderId, "error", `orderDistributionManager->_getRelevantWorkersListByDistance->redisWorkerManager.getAllWorkers->Error: ${err.message}`);
                        return reject(err);
                    }
                    let filteredWorkers = [];
                    let lastOfferedWorkerCallsign;
                    orderLogger(orderInstance.orderId, "info", "orderDistributionManager->_getRelevantWorkersListByDistance->Start filtering workers ...");
                    if (offerOrderType === this.offerOrderInRotationType) {
                        lastOfferedWorkerCallsign = Array.from(orderInstance.offeredInCircleRepeatWorkersList).pop();
                    }
                    let distanceForSearch;
                    switch (orderInstance.currentDistributionCircle) {
                        case 1:
                            distanceForSearch = orderInstance.settings.CIRCLE_DISTANCE_1;
                            break;
                        case 2:
                            distanceForSearch = orderInstance.settings.CIRCLE_DISTANCE_2;
                            break;
                        case 3:
                            distanceForSearch = orderInstance.settings.CIRCLE_DISTANCE_3;
                            break;
                        case 4:
                            distanceForSearch = orderInstance.settings.CIRCLE_DISTANCE_4;
                            break;
                        case 5:
                            distanceForSearch = orderInstance.settings.CIRCLE_DISTANCE_5;
                            break;
                        default:
                            return reject(new Error(`Unsupported currentDistributionCircle value: ${orderInstance.currentDistributionCircle}`));
                    }

                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->distance for search worker: ${distanceForSearch} m`);
                    async.each(workers,
                        (workerItem, callback) => {
                            try {
                                const workerCallsign = parseInt(workerItem.worker.callsign);
                                if (offerOrderType === this.offerOrderInRotationType && lastOfferedWorkerCallsign && lastOfferedWorkerCallsign === workerCallsign) {
                                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->Worker ${workerCallsign} was last offered worker at previous distribution circle repeat`);
                                    return callback();
                                }

                                if (orderInstance.offeredInCircleRepeatWorkersList.has(workerCallsign)) {
                                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is already was offered at this distribution circle repeat`);
                                    return callback();
                                }

                                if (orderInstance.offeredInAllTimeWorkersList.has(workerCallsign)) {
                                    orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is already was offered at some of previous distribution circles`);
                                    return callback();
                                }

                                this.isGoodWorkerForOrder(orderData, workerItem, {
                                    distanceForSearch: distanceForSearch,
                                    needCalcDistance: true,
                                    needCheckSocket: true,
                                    needCheckStatus: true
                                })
                                    .then(filteredWorker => {
                                        orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is good for this order!`);
                                        filteredWorkers.push(filteredWorker);
                                        return callback();
                                    })
                                    .catch(err => {
                                        orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is NOT good for this order. Reason: ${err}`);
                                        return callback();
                                    });
                            } catch (err) {
                                orderLogger(orderInstance.orderId, "error", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Bad worker data ${workerItem}. Error: ${err.message}`);
                                return callback();
                            }
                        }, (err) => {
                            if (err) {
                                orderLogger(orderInstance.orderId, "error", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Error: ${err.message}`);
                                return reject(err);
                            }

                            if (filteredWorkers.length === 0) {
                                return reject(new Error("No relevant workers"));
                            }

                            filteredWorkers.sort((prevWorker, nextWorker) => {
                                if (prevWorker.worker_group_priority > nextWorker.worker_group_priority) {
                                    return -1;
                                }
                                if (prevWorker.worker_group_priority < nextWorker.worker_group_priority) {
                                    return 1;
                                }
                                if (prevWorker.worker_group_priority === nextWorker.worker_group_priority) {
                                    if (orderInstance.settings.CHECK_WORKER_RATING_TO_OFFER_ORDER) {
                                        if (prevWorker.worker_personal_rating > nextWorker.worker_personal_rating) {
                                            return -1;
                                        }
                                        if (prevWorker.worker_personal_rating < nextWorker.worker_personal_rating) {
                                            return 1;
                                        }
                                        if (prevWorker.worker_personal_rating === nextWorker.worker_personal_rating) {
                                            if (prevWorker.worker_distance_to_order > nextWorker.worker_distance_to_order) {
                                                return 1;
                                            } else if (prevWorker.worker_distance_to_order < nextWorker.worker_distance_to_order) {
                                                return -1;
                                            } else if (prevWorker.worker_distance_to_order === nextWorker.worker_distance_to_order) {
                                                return 0;
                                            }
                                        }
                                    } else {
                                        if (prevWorker.worker_distance_to_order > nextWorker.worker_distance_to_order) {
                                            return 1;
                                        } else if (prevWorker.worker_distance_to_order < nextWorker.worker_distance_to_order) {
                                            return -1;
                                        } else if (prevWorker.worker_distance_to_order === nextWorker.worker_distance_to_order) {
                                            return 0;
                                        }
                                    }
                                }
                            });
                            if (offerOrderType === this.offerOrderMultipleType) {
                                filteredWorkers.slice(0, workersCount - 1);
                            }
                            orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Filtered workers: ${JSON.stringify(filteredWorkers, (key, value) => {
                                if (key === "worker_worker" || key === "worker_car") {
                                    return '';
                                }
                                return value;
                            }, 4)}`);
                            return resolve(filteredWorkers);
                        });
                });
            }
        )
            ;
    }

    /**
     * Get relevant workers list by parking
     * @param {BaseGootaxOrder} orderInstance
     * @param {Object} orderData
     * @param {String} offerOrderType
     * @param {Number} workersCount
     * @return {Promise}
     * @private
     */
    _getRelevantWorkersListByParking(orderInstance, orderData, offerOrderType, workersCount) {
        return new Promise((resolve, reject) => {
            const parkingId = orderData.parking_id;
            if (!parkingId) {
                return reject(new Error('Order have not parking area'));
            }
            orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByParking->order parking id: ${parkingId}`);
            redisParkingManager.getAllWorkersOnParking(parkingId, (err, workersAtParking) => {
                if (err) {
                    orderLogger(orderInstance.orderId, "error", `orderDistributionManager->_getRelevantWorkersListByParking->redisWorkerManager.getAllWorkersOnParking->Error: ${err.message}`);
                    return reject(err);
                }
                if (Array.isArray(workersAtParking) && workersAtParking.length < 1) {
                    return reject(new Error("No workers at parking"));
                }
                let filteredWorkers = [];
                let lastOfferedWorkerCallsign;
                orderLogger(orderInstance.orderId, "info", "orderDistributionManager->_getRelevantWorkersListByDistance->Start filtering workers ...");
                if (offerOrderType === this.offerOrderInRotationType) {
                    lastOfferedWorkerCallsign = Array.from(orderInstance.offeredInCircleRepeatWorkersList).pop();
                }
                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByParking->last offered worker: ${lastOfferedWorkerCallsign}`);
                async.each(workersAtParking, (workerCallsign, workerCb) => {
                    workerCallsign = parseInt(workerCallsign);
                    redisWorkerManager.getWorker(orderInstance.tenantId, workerCallsign, (err, workerItem) => {
                        if (err) {
                            orderLogger(orderInstance.orderId, 'error', `orderDistributionManager->_getRelevantWorkersListByParking->redisWorkerManager.getWorker->Error: ${err.message}`);
                            return workerCb(null, 1);
                        } else {
                            if (offerOrderType === this.offerOrderInRotationType && lastOfferedWorkerCallsign && lastOfferedWorkerCallsign === workerCallsign) {
                                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->Worker ${workerCallsign} was last offered worker at previous distribution circle repeat`);
                                return workerCb(null, 1);
                            }
                            if (orderInstance.offeredInCircleRepeatWorkersList.has(workerCallsign)) {
                                orderLogger(orderInstance.orderId, "info", `orderDistributionManager->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is already was offered at this distribution circle repeat`);
                                return workerCb(null, 1);
                            }
                            this.isGoodWorkerForOrder(orderData, workerItem, {
                                distanceForSearch: null,
                                needCalcDistance: false,
                                needCheckSocket: true,
                                needCheckStatus: true
                            })
                                .then(filteredWorker => {
                                    orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByDistance->Worker ${workerCallsign} is good for this order!`);
                                    const index = workersAtParking.indexOf(workerItem.worker_callsign);
                                    if (index !== -1) {
                                        workerItem.index = index;
                                        filteredWorker.push(workerItem);
                                    }
                                    filteredWorkers.push(filteredWorker);
                                    return workerCb(null, 1);
                                })
                                .catch(err => {
                                    orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByParking->Worker ${workerCallsign} is NOT good for this order. Reason: ${err}`);
                                    return workerCb(null, 1);
                                });
                        }
                    })
                }, (err) => {
                    if (err) {
                        orderLogger(orderInstance.orderId, "error", `distributeOrderForDistance->_getRelevantWorkersListByParking->Error: ${err.message}`);
                        return reject(err);
                    }

                    if (filteredWorkers.length === 0) {
                        return reject(new Error("No relevant workers"));
                    }

                    if (orderInstance.settings.CHECK_WORKER_RATING_TO_OFFER_ORDER) {
                        filteredWorkers.sort((a, b) => {
                            return b.worker_personal_rating - a.worker_personal_rating;
                        });
                    } else {
                        filteredWorkers.sort((a, b) => {
                            return a.index - b.index;
                        });
                    }

                    if (offerOrderType === this.offerOrderMultipleType) {
                        filteredWorkers.slice(0, workersCount - 1);
                    }
                    orderLogger(orderInstance.orderId, "info", `distributeOrderForDistance->_getRelevantWorkersListByParking->Filtered workers: ${JSON.stringify(filteredWorkers, (key, value) => {
                        if (key === "worker_worker" || key === "worker_car") {
                            return '';
                        }
                        return value;
                    }, 4)}`);
                    return resolve(filteredWorkers);
                })
            })
        })
    }

    /**
     * Send offer order to many workers at the same time
     * @param {Object} options
     * @param {Number} options.tenantId
     * @param {String} options.tenantLogin
     * @param {Object} options.workers
     * @param {Number} options.orderId
     * @param {Number} options.orderCurrencyId
     * @param {Number} options.offerSec
     * @return {Promise}
     * @private
     */
    _sendBatchOfferOrder(options) {
        return new Promise((resolve, reject) => {
            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendBatchOfferOrder->Need send offer order for ${JSON.stringify(options.workers)}`);
            redisOrderManager.getOrder(options.tenantId, options.orderId, (err, orderData) => {
                if (err) {
                    orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeOrderStatus->getOrder->Error: ${err.message}`);
                    return reject(new Error("Error of get order from redis"));
                }
                orderData.status_id = statusInfo.offer_order.status_id;
                orderData.status.status_id = statusInfo.offer_order.status_id;
                orderData.status.name = statusInfo.offer_order.name;
                orderData.status.status_group = statusInfo.offer_order.status_group;
                orderData.offered_workers_list = options.workers.map(worker => {
                    return worker.worker_callsign;
                });
                const updateTime = Math.floor(Date.now() / 1000);
                orderData.update_time = updateTime;
                orderData.status_time = updateTime;
                redisOrderManager.saveOrder(orderData, (err, result) => {
                    if (err) {
                        orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeOrderStatus->saveOrder->Error: ${err.message}`);
                        return reject(new Error("Error of saving order to redis"));
                    }
                    orderLogger(options.orderId, "info", `orderDistributionManager->_sendBatchOfferOrder->changeOrderStatus->saveOrder-> Result: ${result}`);
                    sqlManager.updateOrderFromMysql(options.orderId, statusInfo.offer_order.status_id, null, null, updateTime, (err, result) => {
                        if (err) {
                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeOrderStatus->updateOrderFromMysql->Error: ${err.message}`);
                        } else {
                            orderLogger(options.orderId, "info", `orderDistributionManager->_sendBatchOfferOrder->changeOrderStatus->updateOrderFromMysql->Result: ${result}`);
                        }
                    });
                    const messageString = orderEventOrderMessage({
                        command: orderEventOrderCommand.updateOrderData,
                        tenant_id: options.tenantId,
                        order_id: options.orderId,
                        params: {}
                    });
                    amqpOrderMessageSender.sendMessage(options.orderId, messageString, (err, result) => {
                        if (err) {
                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->amqpOrderMessageSender.sendMessage->Error: ${err.message}`);
                        } else {
                            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendBatchOfferOrder->published command: ${orderEventOrderCommand.updateOrderData} to order: ${options.orderId}. Result: ${result}`);
                        }
                    });
                    async.each(options.workers,
                        (workerInfo, eachCb) => {
                            async.waterfall([
                                //Check money balance
                                wfCb => {
                                    sqlManager.gerWorkerMoneyBalanse(options.tenantId, workerInfo.worker_id, options.orderCurrencyId, (err, result) => {
                                        if (err) {
                                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->Error: ${err.message}`);
                                            return wfCb(new Error("get worker balance error"));
                                        } else {
                                            return wfCb(null, 1);
                                        }
                                    })
                                },
                                //Update worker status
                                (prevResult, wfCb) => {
                                    redisWorkerManager.getWorker(options.tenantId, workerInfo.worker_callsign, (err, workerDataTemp) => {
                                        if (err) {
                                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeWorkerStatus->getWorker->Error: ${err.message}`);
                                            return wfCb(err);
                                        }
                                        if (workerDataTemp && workerDataTemp.worker && workerDataTemp.worker.status) {
                                            workerDataTemp.worker.status = workerStatusManager.offerOrder;
                                            workerDataTemp.worker.last_offered_order_id = options.orderId;
                                            redisWorkerManager.saveWorker(workerDataTemp, (err, result) => {
                                                if (err) {
                                                    orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeWorkerStatus->saveWorker->Error: ${err.message}`);
                                                    return wfCb(err);
                                                }
                                                sqlManager.logOrderChangeData(options.tenantId, options.orderId, 'status', workerDataTemp.worker.callsign, "worker", workerStatusManager.offerOrder, "system", (err, result) => {
                                                    if (err) {
                                                        orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->changeWorkerStatus->logOrderChangeData->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(options.orderId, "info", `orderDistributionManager->_sendBatchOfferOrder->changeWorkerStatus->logOrderChangeData->Result: ${result}`);
                                                    }
                                                });
                                                return wfCb(null, 1);
                                            })
                                        } else {
                                            return wfCb(new Error('Bad worker data'));
                                        }
                                    })
                                },
                                //Send push to offer order
                                (prevResult, wfCb) => {
                                    pushApi.sendNewOrderToWorker(options.tenantId, options.orderId, workerInfo.worker_callsign, (err, result) => {
                                        if (err) {
                                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->pushApi.sendNewOrderToWorker->Error: ${err.message}`);
                                        }
                                        orderLogger(options.orderId, "info", `orderDistributionManager->_sendBatchOfferOrder->pushApi.sendNewOrderToWorker->Result: ${result}`);
                                        return wfCb(null, 1);
                                    })
                                },
                                //Send socket event to offer order
                                (prevResult, wfCb) => {
                                    const workerMessageString = orderEventWorkerMessage({
                                        command: orderEventWorkerCommand.offerOrder,
                                        tenant_id: options.tenantId,
                                        tenant_login: options.tenantLogin,
                                        worker_callsign: workerInfo.worker_callsign,
                                        params: {
                                            offer_sec: options.offerSec,
                                            order_id: options.orderId
                                        }
                                    });
                                    const workerCallsign = workerInfo.worker_callsign;
                                    amqpWorkerMessageSender.sendMessage(options.tenantId, workerCallsign, workerMessageString, options.offerSec, (err, result) => {
                                        if (err) {
                                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                                        } else {
                                            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendBatchOfferOrder->published command: ${orderEventWorkerCommand.offerOrder} to worker: ${workerCallsign}. Result: ${result} `);
                                        }
                                        return wfCb(null, 1);
                                    });
                                },
                            ], (err, result) => {
                                if (err) {
                                    orderLogger(options.orderId, "error", `orderDistributionManager->_sendBatchOfferOrder->error of sending offer order for worker ${workerInfo.worker_callsign} : ${err.message}`);
                                } else {
                                    orderLogger(options.orderId, "info", `orderDistributionManager->_sendBatchOfferOrder->offer order sent to worker ${workerInfo.worker_callsign}`);
                                }
                                return eachCb(null, 1);
                            })
                        }, (err) => {
                            if (err) {
                                orderLogger(options.orderId, 'info', `orderDistributionManager->_sendBatchOfferOrder->Error: ${err.message}`);
                                return reject(err);
                            } else {
                                return resolve();
                            }
                        });
                })

            });
        });
    }

    /**
     * Send offer order to worker
     * @param {Object} options
     * @param {Number} options.tenantId
     * @param {String} options.tenantLogin
     * @param {Object} options.workerInfo
     * @param {Number} options.orderId
     * @param {Number} options.orderCurrencyId
     * @param {Number} options.offerSec
     * @return {Promise}
     * @private
     */
    _sendOfferOrder(options) {
        return new Promise((resolve, reject) => {
            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendOfferOrder->Need send offer order for ${JSON.stringify(options.workerInfo)}`);
            sqlManager.gerWorkerMoneyBalanse(options.tenantId, options.workerInfo.worker_id, options.orderCurrencyId, (err, result) => {
                if (err) {
                    orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->Error: ${err.message}`);
                    return reject(new Error("get worker balance error"));
                }
                async.parallel({
                    sendPushNewOrder: callback => {
                        pushApi.sendNewOrderToWorker(options.tenantId, options.orderId, options.workerInfo.worker_callsign, (err, result) => {
                            if (err) {
                                orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->pushApi.sendNewOrderToWorker->Error: ${err.message}`);
                            }
                            orderLogger(options.orderId, "info", `orderDistributionManager->_sendOfferOrder->pushApi.sendNewOrderToWorker->Result: ${result}`);
                            return callback(null, 1);
                        })
                    },
                    changeOrderStatus: callback => {
                        redisOrderManager.getOrder(options.tenantId, options.orderId, (err, orderData) => {
                            if (err) {
                                orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeOrderStatus->getOrder->Error: ${err.message}`);
                                return callback(new Error("Error of get order from redis"));
                            }
                            orderData.status_id = statusInfo.offer_order.status_id;
                            orderData.status.status_id = statusInfo.offer_order.status_id;
                            orderData.status.name = statusInfo.offer_order.name;
                            orderData.status.status_group = statusInfo.offer_order.status_group;
                            orderData.worker_id = options.workerInfo.worker_id;
                            orderData.worker = options.workerInfo.worker_worker;
                            orderData.offered_workers_list = [options.workerInfo.worker_callsign];
                            let carId = null;
                            if (options.workerInfo.car && options.workerInfo.car.car_id) {
                                orderData.car_id = options.workerInfo.car.car_id;
                                orderData.car = options.workerInfo.car;
                                carId = orderData.car_id
                            }
                            const updateTime = Math.floor(Date.now() / 1000);
                            orderData.update_time = updateTime;
                            orderData.status_time = updateTime;
                            redisOrderManager.saveOrder(orderData, (err, result) => {
                                if (err) {
                                    orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeOrderStatus->saveOrder->Error: ${err.message}`);
                                    return callback(new Error("Error of saving order to redis"));
                                }
                                orderLogger(options.orderId, "info", `orderDistributionManager->_sendOfferOrder->changeOrderStatus->saveOrder-> Result: ${result}`);
                                sqlManager.updateOrderFromMysql(options.orderId, statusInfo.offer_order.status_id, options.workerInfo.worker_id, carId, updateTime, (err, result) => {
                                    if (err) {
                                        orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeOrderStatus->updateOrderFromMysql->Error: ${err.message}`);
                                    } else {
                                        orderLogger(options.orderId, "info", `orderDistributionManager->_sendOfferOrder->changeOrderStatus->updateOrderFromMysql->Result: ${result}`);
                                    }
                                });
                                return callback(null, 1);
                            })

                        })
                    },
                    changeWorkerStatus: callback => {
                        redisWorkerManager.getWorker(options.tenantId, options.workerInfo.worker_callsign, (err, workerDataTemp) => {
                            if (err) {
                                orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeWorkerStatus->getWorker->Error: ${err.message}`);
                                return callback(null, 1);
                            }
                            if (workerDataTemp && workerDataTemp.worker && workerDataTemp.worker.status) {
                                workerDataTemp.worker.status = workerStatusManager.offerOrder;
                                workerDataTemp.worker.last_offered_order_id = options.orderId;
                                redisWorkerManager.saveWorker(workerDataTemp, (err, result) => {
                                    if (err) {
                                        orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeWorkerStatus->saveWorker->Error: ${err.message}`);
                                    }
                                    sqlManager.logOrderChangeData(options.tenantId, options.orderId, 'status', workerDataTemp.worker.callsign, "worker", workerStatusManager.offerOrder, "system", (err, result) => {
                                        if (err) {
                                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->changeWorkerStatus->logOrderChangeData->Error: ${err.message}`);
                                        } else {
                                            orderLogger(options.orderId, "info", `orderDistributionManager->_sendOfferOrder->changeWorkerStatus->logOrderChangeData->Result: ${result}`);
                                        }
                                    });
                                    return callback(null, 1);
                                })
                            } else {
                                orderLogger(options.orderId, "error", "orderDistributionManager->_sendOfferOrder->changeWorkerStatus->getWorker->Bad worker data");
                                orderLogger(options.orderId, "error", workerDataTemp);
                                return callback(null, 1);
                            }
                        })
                    }

                }, (err, result) => {
                    if (err) {
                        orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->Error: ${err.message}`);
                        return reject(err);
                    }
                    const workerMessageString = orderEventWorkerMessage({
                        command: orderEventWorkerCommand.offerOrder,
                        tenant_id: options.tenantId,
                        tenant_login: options.tenantLogin,
                        worker_callsign: options.workerInfo.worker_callsign,
                        params: {
                            offer_sec: options.offerSec,
                            order_id: options.orderId
                        }
                    });
                    const workerCallsign = options.workerInfo.worker_callsign;
                    amqpWorkerMessageSender.sendMessage(options.tenantId, workerCallsign, workerMessageString, options.offerSec, (err, result) => {
                        if (err) {
                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                        } else {
                            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendOfferOrder->published command: ${orderEventWorkerCommand.offerOrder} to worker: ${workerCallsign}. Result: ${result} `);
                        }
                    });
                    const messageString = orderEventOrderMessage({
                        command: orderEventOrderCommand.updateOrderData,
                        tenant_id: options.tenantId,
                        order_id: options.orderId,
                        params: {}
                    });
                    amqpOrderMessageSender.sendMessage(options.orderId, messageString, (err, result) => {
                        if (err) {
                            orderLogger(options.orderId, "error", `orderDistributionManager->_sendOfferOrder->amqpOrderMessageSender.sendMessage->Error: ${err.message}`);
                        } else {
                            orderLogger(options.orderId, 'info', `orderDistributionManager->_sendOfferOrder->published command: ${orderEventOrderCommand.updateOrderData} to order: ${options.orderId}. Result: ${result}`);
                        }
                    });
                    return resolve(1);
                })
            })
        });
    }


    /**
     * Is this worker good for order
     * @param {Object} orderItem
     * @param {Object} workerItem
     * @param {Object} options
     * @param {Boolean} options.needCalcDistance
     * @param {Number}  options.distanceForSearch
     * @param {Boolean} options.needCheckSocket
     * @param {Boolean} options.needCheckStatus
     * @return {Promise<object>}
     */
    isGoodWorkerForOrder(orderItem, workerItem, options) {
        return new Promise((resolve, reject) => {
            try {
                //order data
                const orderId = parseInt(orderItem.order_id);
                orderLogger(orderId, 'info', 'orderDistributionManager->isGoodWorkerForOrder CALLED!');
                const orderCityId = parseInt(orderItem.city_id);
                const orderAddress = PHPUnserialize.unserialize(orderItem.address);
                const orderFromLat = !isNaN(parseFloat(orderAddress.A.lat)) ? parseFloat(orderAddress.A.lat) : null;
                const orderFromLon = !isNaN(parseFloat(orderAddress.A.lon)) ? parseFloat(orderAddress.A.lon) : null;

                const orderPositionId = parseInt(orderItem.tariff.position_id);
                const orderTariffClassId = parseInt(orderItem.tariff.class_id);
                const orderOptionsArr = [];
                const orderOptionsRaw = orderItem.options;
                if (typeof orderOptionsRaw === "object" && orderOptionsRaw !== null) {
                    const orderOptionsRawArr = Object.keys(orderOptionsRaw).map(k => orderOptionsRaw[k]);
                    if (orderOptionsRawArr.length > 0) {
                        for (let optionData of orderOptionsRawArr) {
                            if (optionData.option_id) {
                                orderOptionsArr.push(parseInt(optionData.option_id));
                            }
                        }
                    }
                }
                //worker data
                const workerId = parseInt(workerItem.worker.worker_id);
                const workerCallsign = parseInt(workerItem.worker.callsign);
                const workerTenantId = parseInt(workerItem.worker.tenant_id);
                const workerCityId = parseInt(workerItem.worker.city_id);
                const workerCityArr = workerItem.worker.cities;
                const workerStatus = workerItem.worker.status;
                const workerPositionId = parseInt(workerItem.position.position_id);
                const workerPositionHasCar = parseInt(workerItem.position.has_car);
                const workerLat = !isNaN(parseFloat(workerItem.geo.lat)) ? parseFloat(workerItem.geo.lat) : null;
                const workerLon = !isNaN(parseFloat(workerItem.geo.lon)) ? parseFloat(workerItem.geo.lon) : null;

                //Check worker city
                if (typeof workerCityArr === "object") {
                    let isIn = false;
                    Object.keys(workerCityArr).forEach(key => {
                        let workerCity = workerCityArr[key];
                        if (parseInt(workerCity.city_id) === orderCityId) {
                            isIn = true;
                        }
                    });
                    if (!isIn) {
                        return reject(new Error(`orderCityId not in workerCityArr`));
                    }
                } else {
                    if (orderCityId !== workerCityId) {
                        return reject(new Error(`Bad worker cityId ${workerCityId}`));
                    }
                }
                if (workerPositionHasCar) {
                    //Check worker position
                    if (orderPositionId !== workerPositionId) {
                        return reject(new Error(`Bad worker position id ${workerPositionId}`));
                    }
                    let workerTariffClasses = workerItem.position.classes;
                    if (typeof workerTariffClasses === "object" && workerTariffClasses !== null) {
                        workerTariffClasses = Object.keys(workerTariffClasses).map(k => workerTariffClasses[k]);
                    }
                    if (Array.isArray(workerTariffClasses)) {
                        if (!workerTariffClasses.find((workerTariffClass, index, array) =>
                                parseInt(workerTariffClass) === orderTariffClassId)) {
                            return reject(new Error(`Bad worker tariff classes: ${JSON.stringify(workerTariffClasses)}`));
                        }
                    } else {
                        return reject(new Error(`Bad worker tariff classes: ${JSON.stringify(workerTariffClasses)}`));
                    }
                } else {
                    let workerPositions = workerItem.position.positions;
                    if (typeof workerPositions === "object" && workerPositions !== null) {
                        workerPositions = Object.keys(workerPositions).map(k => workerPositions[k]);
                    }
                    if (Array.isArray(workerPositions)) {
                        if (!workerPositions.find((workerPosition, index, array) =>
                                parseInt(workerPosition) === orderPositionId)) {
                            return reject(new Error(`Bad worker position classes: ${workerPositions}`));
                        }
                    } else {
                        return reject(new Error(`Bad worker position classes: ${workerPositions}`));
                    }

                }

                // Check worker car options
                if (workerPositionHasCar && workerItem.car && Array.isArray(orderOptionsArr) && orderOptionsArr.length > 0) {
                    const carOptions = [];
                    let carOptionsRaw = workerItem.car.carHasOptions;
                    let isGoodCarOption = true;
                    if (typeof carOptionsRaw === "object" && carOptionsRaw !== null) {
                        carOptionsRaw = Object.keys(carOptionsRaw).map(k => carOptionsRaw[k]);
                        if (Array.isArray(carOptionsRaw) && carOptionsRaw.length > 0) {
                            for (let carOptionData of carOptionsRaw) {
                                if (carOptionData.option_id) {
                                    carOptions.push(parseInt(carOptionData.option_id));
                                }
                            }
                        }
                        for (let orderOptionId of orderOptionsArr) {
                            if (!carOptions.find((carOptionId, index, array) => carOptionId === orderOptionId)) {
                                isGoodCarOption = false;
                                break;
                            }
                        }
                    } else {
                        isGoodCarOption = false;
                    }
                    if (!isGoodCarOption) {
                        return reject(new Error(`Bad worker car options: ${carOptions}`));
                    }
                }

                // Check worker status
                if (options.needCheckStatus) {
                    if (workerStatus !== workerStatusManager.free) {
                        return reject(new Error(`Bad worker status: ${workerStatus}`));
                    }
                }

                let workerDistanceToOrder;
                //Check worker distance to order
                if (options.needCalcDistance) {
                    if (!orderFromLat || !orderFromLon) {
                        return reject(new Error(`Bad order coordinates. lat:${orderFromLat};lon:${orderFromLon}`));
                    }
                    if (!workerLat || !workerLon) {
                        return reject(new Error(`Bad worker coordinates. lat:${workerLat};lon:${workerLon}`));
                    }
                    const workerCoords = {
                        'latitude': workerLat,
                        'longitude': workerLon
                    };
                    const orderCoords = {
                        'latitude': orderFromLat,
                        'longitude': orderFromLon
                    };
                    try {
                        workerDistanceToOrder = geoLib.getDistance(
                            workerCoords,
                            orderCoords
                        )
                    } catch (err) {
                        return reject(err);
                    }
                    if (workerDistanceToOrder > options.distanceForSearch) {
                        return reject(new Error(`Bad worker distance to order. Distance: ${workerDistanceToOrder} m.`));
                    }
                }

                //Check worker connection to socket server
                if (options.needCheckSocket) {
                    rabbitmqHttpService.getQueueConsumersCount(`${workerTenantId}_worker_${workerCallsign}`, null, (err, result) => {
                        if (err) {
                            return reject(new Error(`getQueueConsumersCount error:${err.message}`));
                        } else {
                            if (result >= 1) {
                                const workerInfo = {
                                    "worker_id": workerId,
                                    "worker_callsign": workerCallsign,
                                    "worker_distance_to_order": workerDistanceToOrder,
                                    "worker_personal_rating": workerItem.position.rating ? parseFloat(workerItem.position.rating) : 0,
                                    "worker_group_priority": workerItem.position.group_block === 1 ? 0 : workerItem.position.group_priority ? parseFloat(workerItem.position.group_priority) : 0,
                                    "worker_worker": workerItem.worker,
                                    "worker_car": (workerItem.car) ? workerItem.car : null
                                };
                                return resolve(workerInfo)
                            } else {
                                return reject(new Error(`Worker is not connected to socket server`));
                            }
                        }
                    });
                } else {
                    const workerInfo = {
                        "worker_id": workerId,
                        "worker_callsign": workerCallsign,
                        "worker_distance_to_order": workerDistanceToOrder,
                        "worker_personal_rating": workerItem.position.rating ? parseFloat(workerItem.position.rating) : 0,
                        "worker_group_priority": workerItem.position.group_priority ? parseFloat(workerItem.position.group_priority) : 0,
                        "worker_worker": workerItem.worker,
                        "worker_car": (workerItem.car) ? workerItem.car : null
                    };
                    return resolve(workerInfo)
                }
            } catch (err) {
                return reject(err);
            }
        });
    }

    /**
     * Can offer order for worker
     * @param {number} tenantId
     * @param {number} orderId
     * @param {number} workerCallsign
     * @returns {Promise<object>}
     */
    canOfferOrderForWorker(tenantId, orderId, workerCallsign) {
        orderLogger(orderId, 'info', `orderDistributionManager->canOfferOrderForWorker called. tenantId:${tenantId}; orderId:${orderId}; workerCallsign:${workerCallsign}`);
        return new Promise((resolve, reject) => {
            async.parallel({
                orderData: callback => {
                    redisOrderManager.getOrder(tenantId, orderId, (err, orderData) => {
                        if (err) {
                            callback(err);
                        } else {
                            callback(null, orderData);
                        }
                    })
                },
                workerData: callback => {
                    redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
                        if (err) {
                            callback(err);
                        } else {
                            callback(null, workerData);
                        }
                    })
                }
            }, (err, result) => {
                if (err) {
                    orderLogger(orderId, 'error', `orderDistributionManager->canOfferOrderForWorker>Error: ${err.message}`);
                    reject(err);
                } else {
                    let orderData = result.orderData;
                    let workerData = result.workerData;
                    this.isGoodWorkerForOrder(orderData, workerData, {
                        needCalcDistance: false,
                        distanceForSearch: null,
                        needCheckSocket: false,
                        needCheckStatus: false
                    })
                        .then(result => {
                            orderLogger(orderId, 'info', `orderDistributionManager->canOfferOrderForWorker>Result: ${JSON.stringify(result)}`);
                            resolve(result);
                        })
                        .catch(err => {
                            orderLogger(orderId, 'error', `orderDistributionManager->canOfferOrderForWorker>Error: ${err.message}`);
                            reject(err);
                        })
                }
            })
        });
    }

    /**
     * Get order statuses, that relevant for order offering
     * @returns {*[]}
     * @private
     */
    _getRelevantOfferOrderStatuses() {
        return [
            statusInfo.new_order.status_id,
            statusInfo.new_order_no_parking.status_id,
            statusInfo.free_order.status_id,
            statusInfo.worker_refused_order.status_id,
            statusInfo.worker_refused_order_assign.status_id,
            statusInfo.worker_ignored_offer_order.status_id

        ]
    }

    /**
     * Get relevant workers callsign list to offer order
     * @param {Number} tenantId
     * @param {Number} orderId
     * @returns {Promise}
     */
    getRelevantWorkersList(tenantId, orderId) {
        return new Promise((resolve, reject) => {
            let relevantWorkers = [];
            redisOrderManager.getOrder(tenantId, orderId, (err, orderData) => {
                if (err) {
                    orderLogger(orderId, "error", `orderDistributionManager->getRelevantWorkersList->redisOrderManager.getOrder->Error: ${err.message}`);
                    reject(err);
                } else {
                    redisWorkerManager.getAllWorkers(tenantId, (err, workers) => {
                        if (err) {
                            orderLogger(orderId, "error", `orderDistributionManager->getRelevantWorkersList->redisWorkerManager.getAllWorkers->Error: ${err.message}`);
                            return reject(err);
                        }
                        async.each(workers, (workerItem, callback) => {
                            try {
                                const workerCallsign = parseInt(workerItem.worker.callsign);
                                this.isGoodWorkerForOrder(orderData, workerItem, {
                                    distanceForSearch: null,
                                    needCalcDistance: false,
                                    needCheckSocket: true,
                                    needCheckStatus: true
                                })
                                    .then(filteredWorker => {
                                        orderLogger(orderId, "info", `orderDistributionManager->getRelevantWorkersList->Worker ${workerCallsign} is good for this order!`);
                                        relevantWorkers.push(filteredWorker.worker_callsign);
                                        return callback();
                                    })
                                    .catch(err => {
                                        orderLogger(orderId, "info", `orderDistributionManager->getRelevantWorkersList->Worker ${workerCallsign} is NOT good for this order. Reason: ${err.message}`);
                                        return callback();
                                    });
                            } catch (err) {
                                orderLogger(orderId, "error", `orderDistributionManager->getRelevantWorkersList->Bad worker data ${workerItem}. Error: ${err.message}`);
                                return callback();
                            }
                        }, (err) => {
                            if (err) {
                                orderLogger(orderId, "error", `orderDistributionManager->getRelevantWorkersList->Error: ${err.message}`);
                                return reject(err);
                            }
                            return resolve(relevantWorkers);
                        })
                    })
                }
            })
        })
    }
}

module.exports = exports = new OrderDistributionManager();
