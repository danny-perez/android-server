"use strict";

const redisWorkerReservedOrderListManager = require('../../../database/redisDB/redisWorkerReservedOrderListManager');
const redisOrderManager = require('../../../database/redisDB/redisOrderManager');
const redisWorkerManager = require('../../../database/redisDB/redisWorkerManager');
const sqlManager = require('../../../database/sqlDB/sqlManager');
const logger = require('../../../services/logger');
const orderLogger = logger.orderLogger;
const amqpWorkerMessageSender = require("../../../services/amqpWorkerMessageSender");
const amqpOrderMessageSender = require("../../../services/amqpOrderMessageSender");
const blockWorkerPreOrder = require('../../../workerBlockHandlers/blockWorkerPreOrder');
const lib = require('../../../services/lib');
const pushApi = require('../../../services/externalWebServices/pushApi');
const orderEventOrderMessage = require('../../orderEvent/orderEventOrderMessage');
const orderEventWorkerMessage = require('../../orderEvent/orderEventWorkerMessage');
const orderEventOrderCommand = require('../../orderEvent/orderEventOrderCommand');
const orderEventWorkerCommand = require('../../orderEvent/orderEventWorkerCommand');
const getOrderStatusById = require('../../../services/orderStatusManager').getOrderStatusById;

/**
 * Process order assign/refuse order events
 * @class orderWorkerAssignManager
 */
class OrderWorkerAssignManager {

    /**
     *@constructor
     */
    constructor() {
    }

    /**
     * If order assigned to worker, this method:
     * add order_id to worker reserved list at redisDB,
     * send message about this to worker queue,
     * send push notification
     * @param {Object} orderData - order data from redis
     * @param {Boolean} isPreOrder
     */
    processAssignedOrder(orderData, isPreOrder) {
        try {
            orderLogger(orderData.order_id, 'info', `workerOrderAssignManager->processAssignedOrder called!`);
            const tenantId = orderData.tenant_id;
            const orderId = orderData.order_id;
            const workerCallsign = orderData.worker.callsign;
            const tenantLogin = orderData.tenant_login;
            const orderType = isPreOrder ? 'preorder' : 'order';
            redisWorkerReservedOrderListManager.addOrder(tenantId, workerCallsign, orderId, (err, result) => {
                if (err) {
                    orderLogger(orderId, 'error', `workerOrderAssignManager->processAssignedOrder->redisWorkerReservedOrderListManager.addOrder->Error: ${err.message}`);
                } else {
                    orderLogger(orderId, 'info', `workerOrderAssignManager->processAssignedOrder->redisWorkerReservedOrderListManager.addOrder->Result: ${result}`);
                    const messageString = orderEventWorkerMessage({
                        command: orderEventWorkerCommand.orderListAddItem,
                        tenant_id: tenantId,
                        tenant_login: tenantLogin,
                        worker_callsign: workerCallsign,
                        params: {
                            order_id: orderId,
                            type: orderType
                        }
                    });
                    const messageTtl = 60 * 60 * 24 * 3; // 3 days
                    amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTtl, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `workerOrderAssignManager->processAssignedOrder->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                        } else {
                            orderLogger(orderId, 'info', `workerOrderAssignManager->processAssignedOrder->amqpWorkerMessageSender.sendMessage->Result ${result}`);
                        }
                    });
                    pushApi.sendAssignAtOrder(tenantId, orderId, workerCallsign, isPreOrder, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `workerOrderAssignManager->processAssignedOrder->pushApi.sendAssignAtOrder->Error: ${err.message}`);
                            orderLogger(orderId, 'error', err);
                        } else {
                            orderLogger(orderId, 'info', `workerOrderAssignManager->processAssignedOrder->pushApi.sendAssignAtOrder->Result: ${result}`);
                        }
                    })
                }
            });
        } catch (err) {
            orderLogger(orderData.order_id, "error", `workerOrderAssignManager->processAssignedOrder->Error: ${err.message}`);
        }
    }

    /**
     * Worker refused order assignment. This method:
     * delete worker from order,
     * delete order from worker reserved list,
     * send message about this to worker queue,
     * send push notify to worker,
     * set order to new status if need
     * call block worker preorder if need
     * @param {Object} orderData - order data from redis
     * @param {Object} options
     * @param {boolean} options.isPreOrder - is it preorder
     * @param {boolean} options.isWorkerEventOwner -was this event initiates by worker app
     * @param {Number}  [options.newStatusId] - set new status for this order if need
     */
    processRefusedOrderAssignment(orderData, options) {
        try {
            orderLogger(orderData.order_id, 'info', `workerOrderAssignManager->processRefusedOrderAssignment called!`);
            const tenantId = orderData.tenant_id;
            const tenantLogin = orderData.tenant_login;
            const orderId = orderData.order_id;
            const workerCallsign = orderData.worker ? orderData.worker.callsign : null;
            const orderType = options.isPreOrder ? 'preorder' : 'order';
            const cityOffset = !isNaN(parseFloat(orderData.time_offset)) ? parseFloat(orderData.time_offset) : 0;
            const orderTime = orderData.order_time;
            const updateTime = Math.floor(Date.now() / 1000);
            if (options.newStatusId) {
                const statusData = getOrderStatusById(options.newStatusId);
                orderData.status_id = statusData.status_id;
                orderData.status.status_id = statusData.status_id;
                orderData.status.name = statusData.name;
                orderData.status.status_group = statusData.status_group;
                orderData.status_time = updateTime;
            }
            orderData.worker_id = null;
            orderData.car_id = null;
            orderData.worker = null;
            orderData.car = null;
            orderData.update_time = updateTime;
            orderData.deny_refuse_order = 0;
            //Save order and send message to order queue
            redisOrderManager.saveOrder(orderData, (err, result) => {
                if (err) {
                    orderLogger(orderId, "error", `workerOrderAssignManager->processRefusedOrderAssignment->redisOrderManager.saveOrder->Error: ${err.message}`);
                } else {
                    orderLogger(orderId, "info", `workerOrderAssignManager->refuseOrderAssignment->redisOrderManager.saveOrder->Result: ${result}`);
                    sqlManager.updateOrderFromMysql(orderId, orderData.status_id, null, null, updateTime, (err, result) => {
                        if (err) {
                            orderLogger(orderId, "error", `workerOrderAssignManager->processRefusedOrderAssignment->sqlManager.updateOrderFromMysql->Error: ${err.message}`);
                        } else {
                            orderLogger(orderId, "info", `workerOrderAssignManager->processRefusedOrderAssignment->sqlManager.updateOrderFromMysql->Result: ${result}`);
                        }
                    });
                    sqlManager.updateOrderField(orderId, 'deny_refuse_order', 0, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', `workerOrderAssignManager->processRefusedOrderAssignment->sqlManager.updateOrderField->Error: ${err.message}`);
                        } else {
                            orderLogger(orderId, 'info', `workerOrderAssignManager->processRefusedOrderAssignment->sqlManager.updateOrderField->Result: ${result}`);
                        }
                    });

                    const messageString = orderEventOrderMessage({
                        command: orderEventOrderCommand.updateOrderData,
                        tenant_id: tenantId,
                        order_id: orderId,
                        params: {}
                    });

                    amqpOrderMessageSender.sendMessage(orderId, messageString, (err, result) => {
                        if (err) {
                            orderLogger(orderId, 'error', ``);
                        } else {
                            orderLogger(orderId, 'info', `workerOrderAssignManager->processRefusedOrderAssignment->amqpOrderMessageSender.sendMessage->Published command: ${orderEventOrderCommand.updateOrderData} to order: ${orderId}. Result: ${result}`);
                        }
                    });
                }
            });
            if (workerCallsign) {
                if (options.isPreOrder && options.isWorkerEventOwner) {
                    redisWorkerManager.getWorker(tenantId, workerCallsign, (err, workerData) => {
                        if (err) {
                            orderLogger(orderId, "error", `workerOrderAssignManager->processRefusedOrderAssignment->redisWorkerManager.getWorker->Error: ${err.message}`);
                        } else {
                            orderLogger(orderId, "info", `workerOrderAssignManager->processRefusedOrderAssignment->redisWorkerManager.getWorker->Result: ${workerData}`);
                            if (parseFloat(workerData.worker.pre_order_reject_min) > 0 && parseFloat(workerData.worker.pre_order_block_houer) > 0) {
                                const tenantNowTime = parseInt((new Date()).getTime() / 1000) + cityOffset;
                                if ((parseInt(orderTime) - parseInt(tenantNowTime)) < parseFloat(workerData.worker.pre_order_reject_min * 60)) {
                                    blockWorkerPreOrder(tenantId, workerCallsign, (err, result) => {
                                        if (err) {
                                            orderLogger(orderId, "error", `workerOrderAssignManager->processRefusedOrderAssignment->blockWorkerPreOrder->Error: ${err.message}`);
                                        } else {
                                            orderLogger(orderId, "info", `workerOrderAssignManager->processRefusedOrderAssignment->blockWorkerPreOrder->Result: ${result}`);
                                        }

                                    });
                                } else {
                                    orderLogger(orderId, "info", "workerOrderAssignManager->processRefusedOrderAssignment->Don't need block worker pre order. Pre order abort time is good");
                                }
                            } else {
                                orderLogger(orderId, "info", "workerOrderAssignManager->processRefusedOrderAssignment->Don't need block worker pre order. Empty pre order block params");
                            }

                        }
                    })
                }
                redisWorkerReservedOrderListManager.delOrder(tenantId, workerCallsign, orderId, (err, result) => {
                    if (err) {
                        orderLogger(orderId, 'error', `workerOrderAssignManager->processRefusedOrderAssignment->redisWorkerReservedOrderListManager.delOrder->Error: ${err.message}`);
                    } else {
                        orderLogger(orderId, 'info', `workerOrderAssignManager->processRefusedOrderAssignment->redisWorkerReservedOrderListManager.delOrder->Result: ${result}`);
                        const messageString = orderEventWorkerMessage({
                            command: orderEventWorkerCommand.orderListDelItem,
                            tenant_id: tenantId,
                            tenant_login: tenantLogin,
                            worker_callsign: workerCallsign,
                            params: {
                                order_id: orderId,
                                type: orderType
                            }
                        });
                        const messageTtl = 60 * 60 * 24 * 3; // 3 days
                        amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTtl, (err, result) => {
                            if (err) {
                                orderLogger(orderId, 'error', `workerOrderAssignManager->processRefusedOrderAssignment->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                            } else {
                                orderLogger(orderId, 'info', `workerOrderAssignManager->processRefusedOrderAssignment->amqpWorkerMessageSender.sendMessage->Result: ${result}`);
                            }
                        });
                        pushApi.sendRefuseOrderAssignment(tenantId, orderId, workerCallsign, options.isPreOrder, (err, result) => {
                            if (err) {
                                orderLogger(orderId, 'error', `workerOrderAssignManager->processRefusedOrderAssignment->pushApi.sendRefuseOrderAssignment->Error: ${err.message}`);
                            } else {
                                orderLogger(orderId, 'info', `workerOrderAssignManager->processRefusedOrderAssignment->pushApi.sendRefuseOrderAssignment->Result: ${result}`);
                            }
                        })
                    }
                })
            }
        } catch (err) {
            orderLogger(orderData.order_id, "error", `workerOrderAssignManager->processRefusedOrderAssignment->Error: ${err.message}`);
        }
    }
}
module.exports = exports = new OrderWorkerAssignManager();