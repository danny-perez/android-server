'use strict';

const redisOrderManager = require('../database/redisDB/redisOrderManager');
const redisAsyncAnswerManager = require('../database/redisDB/redisAsyncAnswerManager');
const BaseGootaxOrder = require('./orderModules/baseGootaxOrder');
const logger = require('../services/logger');
const orderLogger = logger.orderLogger;
const config = require("../services/lib").getConfig();
const amqp = require('amqplib/callback_api');
const orderApi = require("../services/externalWebServices/orderApi");
const amqpWorkerMessageSender = require("../services/amqpWorkerMessageSender");
const getPositionById = require("../services/workerPositionManager").getPositionById;
const orderEventSenderService = require('./orderEvent/orderEventSenderService');
const orderEventCommand = require('./orderEvent/orderEventOrderCommand');
const DataProcessingService = require("../services/dataProcessingService");

/**
 * Order main handler
 * @param {Number}  tenantId
 * @param {Number}  orderId
 * @param {Number}  isFromLoader - (1/0) Was it order add after restart node process(isFromLoader = 1), or from rest api
 * @param {Function} callback
 */
module.exports = function (tenantId, orderId, isFromLoader, callback) {
    orderLogger(orderId, 'info', "OrderMainHandler CALLED!");
    redisOrderManager.getOrder(tenantId, orderId, (err, orderData) => {
        if (err) {
            orderLogger(orderId, 'error', `orderMainHandler->getOrder->Error: ${err.message}`);
            return callback(new Error('Error of getting order from redis'));
        }
        const orderContainer = {};
        const orderPositionId = parseInt(orderData.tariff.position_id);
        const orderPositionInfo = getPositionById(orderPositionId);
        if (orderPositionInfo) {
            orderLogger(orderId, 'info', `orderMainHandler->order has worker position_id:${orderPositionInfo.position_id}, name:${orderPositionInfo.name}`);
            orderContainer.instance = new BaseGootaxOrder(tenantId, orderId, isFromLoader);
        } else {
            orderLogger(orderId, 'error', `orderMainHandler->unsupported worker position (position_id:${orderPositionInfo.position_id}, name:${orderPositionInfo.name})`);
            return callback(new Error(`Unsupported order position: ${orderPositionId}`));
        }
        orderEventQueueListener(orderId, orderContainer, isFromLoader);
        return callback(null, 1);
    });
};


/**
 * Order event queue listener
 * @param orderId
 * @param orderContainer
 * @param isFromLoader
 */
function orderEventQueueListener(orderId, orderContainer, isFromLoader) {
    // Delay between order messages at order queue in seconds
    const messageWorkTime = 1.5;
    let connSelfClosed = false;
    let chanelSelfClosed = false;
    startListenQueue();

    function startListenQueue() {
        amqp.connect(`amqp://${config.RABBITMQ_MAIN_HOST}:${config.RABBITMQ_MAIN_PORT}`, (err, conn) => {
            if (err) {
                orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->connect->Error: ${err.message}. Need to try reconnect...`);
                return setTimeout(startListenQueue, 2000);
            }
            conn.on("error", err => {
                orderLogger(orderId, 'error', err.message);
                if (err.message !== "Connection closing") {
                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->connection->Error ${err.message}`);
                }
            });
            conn.on("close", () => {
                if (!connSelfClosed) {
                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->connection closed, need to try reconnect...`);
                    return setTimeout(startListenQueue, 2000);
                }
            });
            orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->connected`);
            DataProcessingService.addOrder(orderId);
            conn.createChannel((err, ch) => {
                if (err) {
                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->create channel->Error: ${err.message}`);
                }
                ch.on("error", (err) => {
                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->chanel->Error: ${err.message}`);
                });
                ch.on("close", () => {
                    if (!chanelSelfClosed) {
                        orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->channel closed`);
                    }
                });
                let delayToStartingConsumeQueue = 0;
                if (isFromLoader) {
                    delayToStartingConsumeQueue = 1.5;
                }
                orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->channel created`);
                setTimeout(() => {
                    const q = `order_${orderId}`;
                    ch.assertQueue(q, {
                        durable: true
                    });
                    ch.prefetch(1);
                    orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->waiting for task...`);
                    ch.consume(q, (message) => {
                        if (message) {
                            orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->new task!`);
                            let taskObject;
                            try {
                                taskObject = JSON.parse(message.content.toString());
                                orderLogger(orderId, 'info', taskObject);
                            } catch (err) {
                                orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->task content parsing->Error: ${err.message}`);
                            } finally {
                                if (taskObject) {
                                    taskObject = orderContainer.instance.modifyEvent(taskObject);
                                    orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->modified task:${JSON.stringify(taskObject)}`);
                                    //Если это системное сообещние, то есть от самого движка
                                    if (taskObject.sender_service === orderEventSenderService.engineService) {
                                        // Заказ звершен, нужно убить очередь и сервис
                                        if (taskObject.command === orderEventCommand.destroyService) {
                                            try {
                                                ch.deleteQueue(q, {ifUnused: false, ifEmpty: false}, (err, ok) => {
                                                    if (err) {
                                                        orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->deleteQueue->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(orderId, 'info', "orderMainHandler->rabbitmq->order queue deleted");
                                                        try {
                                                            ch.close();
                                                            chanelSelfClosed = true;
                                                            orderLogger(orderId, 'info', "orderMainHandler->rabbitmq->channel closed");
                                                        } catch (err) {
                                                            orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->channel closing->Error: ${err.message}`);
                                                        }
                                                        try {
                                                            conn.close();
                                                            connSelfClosed = true;
                                                            orderLogger(orderId, 'info', "orderMainHandler->rabbitmq->connection closed");
                                                        } catch (err) {
                                                            orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->connection closing->Error: ${err.message}`);
                                                        }
                                                        delete orderContainer.instance;
                                                        DataProcessingService.delOrder(orderId);
                                                        orderLogger(orderId, 'info', "orderMainHandler->orderContainer deleted");
                                                    }
                                                });
                                            } catch (err) {
                                                orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->deleteQueue->Error: ${err.message}`);
                                            }
                                        } else {
                                            orderContainer.instance.doEvent(taskObject);
                                            setTimeout(() => {
                                                orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->task done`);
                                                try {
                                                    ch.ack(message);
                                                } catch (err) {
                                                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->ch.ack(message)->Error: ${err.message}`);
                                                }
                                            }, messageWorkTime * 1000);
                                        }
                                    } else {
                                        //Кидаем сообщение  в order API, оно выполняет изменение либо возвращает ошибку
                                        if (taskObject.command === orderEventCommand.updateOrderData) {
                                            orderApi.sendRequest(taskObject, (err, result) => {
                                                orderLogger(orderId, 'info', result);
                                                let isGoodOrderAnswer = true;
                                                if (err) {
                                                    orderLogger(orderId, 'error', `orderMainHandler->orderApi.sendRequest->Error: ${err.message}`);
                                                    let errorCode;
                                                    if (taskObject.sender_service === orderEventSenderService.clientService
                                                        || taskObject.sender_service === orderEventSenderService.workerService) {
                                                        errorCode = 1;
                                                    }
                                                    if (taskObject.sender_service === orderEventSenderService.operatorService) {
                                                        errorCode = 107;
                                                    }
                                                    result = {
                                                        uuid: taskObject.uuid,
                                                        order_id: orderId,
                                                        type: 'response',
                                                        code: errorCode,
                                                        info: "INTERNAL_ERROR",
                                                        result: 0
                                                    };
                                                } else {
                                                    orderLogger(orderId, 'info', `orderMainHandler->orderApi.sendRequest->Result: ${JSON.stringify(result)}`);
                                                }
                                                if (taskObject.sender_service === orderEventSenderService.clientService ||
                                                    taskObject.sender_service === orderEventSenderService.workerService) {
                                                    if (result.code !== 0) {
                                                        isGoodOrderAnswer = false;
                                                    }
                                                }
                                                if (taskObject.sender_service === orderEventSenderService.operatorService) {
                                                    if (result.code !== 100) {
                                                        isGoodOrderAnswer = false;
                                                    }
                                                }
                                                let messageTTL = 30;
                                                if (taskObject.sender_service === orderEventSenderService.workerService) {
                                                    messageTTL = 900;
                                                }
                                                // Запишем ответ в редис
                                                redisAsyncAnswerManager.setAsyncAnswer(taskObject.uuid, result, messageTTL, (err, result) => {
                                                    if (err) {
                                                        orderLogger(orderId, 'error', `orderMainHandler->orderApi.setAsyncAnswer->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(orderId, 'info', `orderMainHandler->orderApi.setAsyncAnswer->Result: ${result}`);
                                                    }
                                                });
                                                //Если это было сообщение от водителя, то продублируем ответ в очередь
                                                if (taskObject.sender_service === orderEventSenderService.workerService) {
                                                    let tenantId = taskObject.tenant_id;
                                                    let workerCallsign = taskObject.change_sender_id;
                                                    let messageString = JSON.stringify(result);
                                                    let messageTTL = 60;
                                                    amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTTL, (err, result) => {
                                                        if (err) {
                                                            orderLogger(orderId, 'error', `orderMainHandler->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                                                        } else {
                                                            orderLogger(orderId, 'info', `orderMainHandler->amqpWorkerMessageSender->Result: ${result}`);
                                                        }
                                                    });
                                                }
                                                if (isGoodOrderAnswer) {
                                                    orderContainer.instance.doEvent(taskObject);
                                                }
                                                setTimeout(() => {
                                                    orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->task done`);
                                                    try {
                                                        ch.ack(message);
                                                    } catch (err) {
                                                        orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->ch.ack(message)->Error: ${err.message}`);
                                                    }
                                                }, messageWorkTime * 1000);

                                            });
                                        } else {
                                            if (taskObject.command === orderEventCommand.stopOffer) {
                                                orderContainer.instance.doEvent(taskObject);
                                            }
                                            if (taskObject.command === orderEventCommand.refuseOfferOrder) {
                                                let result = {
                                                    uuid: taskObject.uuid,
                                                    order_id: orderId,
                                                    type: 'response',
                                                    code: 0,
                                                    info: "OK",
                                                    result: {
                                                        "set_result": 1
                                                    }
                                                };
                                                let messageTTL = 900;
                                                // Запишем ответ в редис
                                                redisAsyncAnswerManager.setAsyncAnswer(taskObject.uuid, result, messageTTL, (err, result) => {
                                                    if (err) {
                                                        orderLogger(orderId, 'error', `orderMainHandler->orderApi.setAsyncAnswer->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(orderId, 'info', `orderMainHandler->orderApi.setAsyncAnswer->Result: ${result}`);
                                                    }
                                                });
                                                let tenantId = taskObject.tenant_id;
                                                let workerCallsign = taskObject.change_sender_id;
                                                let messageString = JSON.stringify(result);
                                                messageTTL = 60;
                                                amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTTL, (err, result) => {
                                                    if (err) {
                                                        orderLogger(orderId, 'error', `orderMainHandler->amqpWorkerMessageSender.sendMessage->Error: ${err.message}`);
                                                    } else {
                                                        orderLogger(orderId, 'info', `orderMainHandler->amqpWorkerMessageSender->Result: ${result}`);
                                                    }
                                                });
                                                orderContainer.instance.doEvent(taskObject);
                                            }
                                            setTimeout(() => {
                                                orderLogger(orderId, 'info', `orderMainHandler->rabbitmq->task done`);
                                                try {
                                                    ch.ack(message);
                                                } catch (err) {
                                                    orderLogger(orderId, 'error', `orderMainHandler->rabbitmq->ch.ack(message)->Error: ${err.message}`);
                                                }
                                            }, messageWorkTime * 1000);
                                        }
                                    }
                                }
                            }
                        }
                    }, {noAck: false});
                }, delayToStartingConsumeQueue * 1000);

            });
        });
    }


}