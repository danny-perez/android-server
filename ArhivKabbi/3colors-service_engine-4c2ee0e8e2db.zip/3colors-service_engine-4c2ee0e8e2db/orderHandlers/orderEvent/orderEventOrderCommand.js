'use strict';

const destroyService = "destroy_service";
const updateOrderData = "update_order_data";
const refuseOfferOrder = "refuse_offer_order";
const orderOfferTimeout = "order_offer_timeout";
const preOrderConfirmTimeout = "preorder_confirm_timeout";
const workerLateTimeout = "worker_late_timeout";
const clientLateTimeout = "client_late_timeout";
const orderLateTimeout = "order_late_timeout";
const orderRejectTimeout = "order_reject_timeout";
const stopOffer = "stop_offer";

module.exports = {
    destroyService,
    updateOrderData,
    refuseOfferOrder,
    orderOfferTimeout,
    preOrderConfirmTimeout,
    workerLateTimeout,
    clientLateTimeout,
    orderLateTimeout,
    orderRejectTimeout,
    stopOffer
};
