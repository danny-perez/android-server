'use strict';

const engineService = "engine_service";
const clientService = "client_service";
const workerService = "worker_service";
const operatorService = "operator_service";

module.exports = {
    engineService,
    clientService,
    workerService,
    operatorService
};
