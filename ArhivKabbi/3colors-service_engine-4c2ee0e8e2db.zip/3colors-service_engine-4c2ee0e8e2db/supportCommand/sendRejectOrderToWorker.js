const amqpWorkerMessageSender = require("../services/amqpWorkerMessageSender");
const sqlManager = require('../database/sqlDB/sqlManager');
const logger = require('../services/logger');
const mainLogger = logger.mainLogger;
const orderEventWorkerMessage = require('../orderHandlers/orderEvent/orderEventWorkerMessage');
const orderEventWorkerCommand = require('../orderHandlers/orderEvent/orderEventWorkerCommand');


/**
 * Technical support command:
 *  send socket message to worker to reject him from order
 * @param tenantLogin
 * @param workerCallsign
 * @param orderNumber
 * @param callback
 * @returns {*}
 */
module.exports = function (tenantLogin, workerCallsign, orderNumber, callback) {
    sqlManager.getTenantIdByDomain(tenantLogin, (err, tenantId) => {
        if (err) {
            mainLogger('error', err);
            return callback(err);
        }
        sqlManager.getOrderByNumber(tenantId, orderNumber, (err, orderData) => {
            if (err) {
                mainLogger('error', err);
                return callback(err);
            }
            if (orderData && orderData.order_id) {
                const orderId = orderData.order_id;
                let messageString = orderEventWorkerMessage({
                    command: orderEventWorkerCommand.rejectWorkerFromOrder,
                    tenant_id: tenantId,
                    tenant_login: tenantLogin,
                    worker_callsign: workerCallsign,
                    params: {
                        order_id: orderId
                    }
                });
                const messageTtl = 60 * 60 * 24 * 10; // 10 days
                amqpWorkerMessageSender.sendMessage(tenantId, workerCallsign, messageString, messageTtl, (err, result) => {
                    if (err) {
                        mainLogger('error', err);
                    } else {
                        mainLogger('info', `sendRejectOrderToWorker-> Sended reject_order  to worker ${workerCallsign}`);
                    }
                });
                callback(null, 1);
            } else {
                callback('can not find this order at sqlDB')
            }

        });
    });
};