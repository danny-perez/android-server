const redisOrderManager = require('../database/redisDB/redisOrderManager');
const redisWorkerManager = require('../database/redisDB/redisWorkerManager');
const sqlManager = require('../database/sqlDB/sqlManager');
const logger = require('../services/logger');
const mainLogger = logger.mainLogger;


/**
 *  Force change worker status
 * @param {String} tenantDomain
 * @param {Number} workerCallsign
 * @param {Number} workerStatus
 * @returns {Promise}
 */
module.exports = function (tenantDomain, workerCallsign, workerStatus) {
    return new Promise((resolve, reject)=> {
        workerStatus = workerStatus.toUpperCase();
        const workerStatusArr = ['FREE', 'ON_ORDER', 'BLOCKED', 'ON_BREAK'];
        if (workerStatusArr.indexOf(workerStatus) === -1) {
            reject('INVALID worker_status');
        }
        sqlManager.getTenantIdByDomain(tenantDomain, (err, tenantId)=> {
            if (err) {
                mainLogger('error', err);
                reject(err);
            }
            redisWorkerManager.getWorker(tenantId, workerCallsign, (err, worker)=> {
                if (err) {
                    if (err === "No worker at redisDB") {
                        err = "Сменить статус не удалось: исполнитель не на смене";
                    }
                    reject(err);
                }
                if (worker && worker.worker && worker.worker.status) {
                    worker.worker.status = workerStatus;
                    redisWorkerManager.saveWorker(worker, (err, result)=> {
                        if (err) {
                            mainLogger('error', err);
                            reject(err);
                        } else {
                            resolve(1);
                        }
                    });
                } else {
                    reject("INVALID worker data ar redis DB")
                }
            });
        })
    });
};