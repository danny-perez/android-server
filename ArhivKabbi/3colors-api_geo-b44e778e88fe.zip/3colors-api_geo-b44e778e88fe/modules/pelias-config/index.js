var fs = require('fs'),
    path = require('path'),
    Mergeable = require('mergeable'),
    defaults = new Mergeable(__dirname + '/config/defaults.json'),
    localpath;

// allow the ops guys to override settings on the server
var generate = function (deep) {
    defaults.esclient.hosts[0].host = require('../../helper/lib').getConfig().ELASTICSEARCH_MAIN_HOST;
    defaults.esclient.hosts[0].port = parseInt(require('../../helper/lib').getConfig().ELASTICSEARCH_MAIN_PORT);
    return defaults;
};

var config = {
    defaults: defaults,
    generate: generate.bind(null, true),
    setLocalPath: function (p) {
        localpath = p.replace('~', process.env.HOME);
        return localpath;
    }
};

config.setLocalPath('~/pelias.json');
module.exports = config;