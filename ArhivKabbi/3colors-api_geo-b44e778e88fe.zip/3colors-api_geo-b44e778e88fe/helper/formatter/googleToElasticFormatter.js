'use strict';

var formatDataToElastic = require('./formatDataToElastic');

/**
 * google to elastic formatter
 * @param data
 * @param method
 * @returns {{docs: Array, meta: {scores: Array}}}
 */
function googleToElasticFormatter(data, method) {
    var results = {
        'docs': [],
        'meta': {
            "scores": []
        }
    };
    var rawResultArray = data.results;
    rawResultArray.forEach(function (item, i, raw) {
        var geoItem = item;
        var lat = null;
        var lon = null;
        var number = '';
        var street = '';
        var name = '';
        var admin1 = '';
        var suburb = '';
        var locality = '';
        var alpha3 = '';
        var admin0 = '';
        var category = [];
        var _id = 1;
        var _score = 1;
        var resultString = "";
        if (geoItem.geometry.location) {
            lat = geoItem.geometry.location.lat;
            lon = geoItem.geometry.location.lng;
        }
        if (geoItem.formatted_address) {
            var arrOfGeoData = geoItem.formatted_address.split(', ');
            // get rid of postcode
            if (arrOfGeoData[arrOfGeoData.length - 1].match(/\d+/) !== null) {
                arrOfGeoData.pop();
            }
            resultString = arrOfGeoData.join(', ');
        }
        var _type = 'osmnode';
        //Если дом
        if (geoItem.types && (geoItem.types.indexOf('street_address') !== -1 || geoItem.types.indexOf('premise') !== -1) && geoItem.name) {
            locality = resultString.substr(geoItem.name.length + 1, resultString.length);
            locality = locality.trim();
            name = geoItem.name;
            name = name.trim();
            // Если улица
        } else if (geoItem.types && geoItem.types.indexOf('route') !== -1) {
            name = resultString;
        } else {
            if (geoItem.name) {
                if (geoItem.types && geoItem.types.indexOf('locality') === -1) {
                    name = geoItem.name + ' | ' + resultString;
                } else {
                    name = geoItem.name;
                    var resultArr = resultString.split(', ');
                    if (resultArr.length > 1) {
                        resultArr.shift();
                    }
                    locality = resultArr.join(', ');
                }
            } else {
                name = resultString;
            }
        }
        var formattedItem = formatDataToElastic(lat, lon, number, street, name, suburb, admin1, locality, alpha3, admin0, category, _id, _type, _score);
        results.docs.push(formattedItem);
        results.meta.scores.push(1);
    });
    return results;

}

module.exports = googleToElasticFormatter;
