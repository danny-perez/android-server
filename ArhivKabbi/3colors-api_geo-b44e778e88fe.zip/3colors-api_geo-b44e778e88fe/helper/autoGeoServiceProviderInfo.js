'use strict';

var service = {
    search: require('../service/search')
};
var backend = backend || require('../src/backend');
var check = require('check-types');

function autoGeoServiceProviderInfo(tenantId, tenantDomain, cityId, typeApp, callback) {
    var geoServiceType = "auto_geo_service";
    var autoGeoServiceProviders = {
        1: "yandex",
        2: "herecom",
        3: "google",
        4: "2gis",
        5: "gootax",
        6: "yandex",
        7: "gomap.az",
        8: "geobase.az"
    };

    var response = {
        "auto_geo_service_provider": {
            "provider": null,
            "key_1": null,
            "key_2": null
        }
    };

    if (check.undefined(cityId)) {
        return callback(null, response);
    }
    var query;

    if (typeApp === "driver") {
        if (check.undefined(tenantDomain)) {
            return callback(null, response);
        }
        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "term": {
                                "tenant_domain": tenantDomain
                            }
                        }, {
                            "term": {
                                "city_id": cityId
                            }
                        }, {
                            "term": {
                                "service_type": geoServiceType
                            }
                        }

                    ]
                }
            },
            "size": 1
        };
    } else {
        if (check.undefined(tenantId)) {
            return callback(null, response);
        }
        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "term": {
                                "tenant_id": tenantId
                            }
                        }, {
                            "term": {
                                "city_id": cityId
                            }
                        }, {
                            "term": {
                                "service_type": geoServiceType
                            }
                        }
                    ]
                }
            },
            "size": 1
        };
    }
    var cmd = {
        index: 'service_provider',
        body: query
    };
    // query backend
    service.search(backend, cmd, function (err, docs, meta) {
        if (err) {
            return callback(null, response);
        } else {
            if (check.array(docs)) {
                if (check.object(docs[0])) {
                    var providerData = docs[0];
                    var providerId = parseInt(providerData.service_provider_id, 10);
                    response.auto_geo_service_provider.provider = autoGeoServiceProviders[providerId];
                    response.auto_geo_service_provider.key_1 = providerData.key_1;
                    response.auto_geo_service_provider.key_2 = providerData.key_2;
                    return callback(null, response);
                }
            }
            return callback(null, response);

        }
    });

}

module.exports = autoGeoServiceProviderInfo;
