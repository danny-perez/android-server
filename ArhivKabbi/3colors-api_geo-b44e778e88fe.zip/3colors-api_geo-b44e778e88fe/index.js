var Cluster = require('cluster2'),
    app = require('./app'),
    port = (process.env.PORT || 3100),
    multicore = parseInt(require('./helper/lib').getConfig().MY_MULTICORE),
    logger = require('./helper/logger');

/** cluster webserver across all cores **/
if (multicore) {
    var c = new Cluster({port: port});
    c.listen(function (cb) {
        logger.info('Listenint on port: ' + port);
        cb(app);
    });

}

/** run server on the default setup (single core) **/
else {
    app.listen(port);
    logger.info('Listenint on port: ' + port);
}
