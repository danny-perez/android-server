ALTER TABLE profile ADD COLUMN bonus_state TEXT;
ALTER TABLE profile ADD COLUMN bonus_id TEXT;
ALTER TABLE tariffs ADD COLUMN is_bonus TEXT;