ALTER TABLE profile ADD COLUMN android_url TEXT;
ALTER TABLE profile ADD COLUMN ios_url TEXT;