package com.gootax.client.events.ui;

public class OrderRepeatEvent {
}
