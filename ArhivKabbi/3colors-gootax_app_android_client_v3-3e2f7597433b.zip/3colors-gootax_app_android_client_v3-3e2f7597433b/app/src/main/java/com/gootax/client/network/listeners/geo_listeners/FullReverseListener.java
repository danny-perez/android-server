package com.gootax.client.network.listeners.geo_listeners;

import com.gootax.client.events.api.geo.FullReverseEvent;

public class FullReverseListener extends GeoListener {

    public FullReverseListener() {
        super(new FullReverseEvent());
    }

}