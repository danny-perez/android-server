package com.gootax.client.activities;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;

import com.google.android.gms.maps.model.LatLng;
import com.gootax.client.R;
import com.gootax.client.events.api.geo.CarFreeEvent;
import com.gootax.client.maps.google.PublicTransportMap;
import com.gootax.client.models.Car;
import com.gootax.client.models.City;
import com.gootax.client.models.Profile;
import com.gootax.client.models.Tariff;
import com.gootax.client.network.listeners.CarsListener;
import com.gootax.client.network.requests.GetCarsRequest;
import com.gootax.client.views.adapters.TariffAdapter;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.List;

public class PublicTransportActivity extends BaseSpiceActivity implements TariffAdapter.TariffClickListener {

    public static final String EXTRA_TRANSPORT_CITY_ID = "EXTRA_TRANSPORT_CITY_ID";
    public static final String EXTRA_CURRENT_POSITION = "EXTRA_CURRENT_POSITION";
    public static final String EXTRA_CURRENT_TARIFF_ID = "EXTRA_CURRENT_TARIFF_ID";
    public static final int TARIFF_UPDATE_INTERVAL = 15_000;

    private Profile mProfile;
    private TariffAdapter mTariffAdapter;
    private City mCity;
    private PublicTransportMap mPublicTransportMap;
    private LatLng mCurrentPosition;
    private Handler mUpdateTariffHandler;
    private Runnable mUpdateTariffRunnable;
    private Tariff mTariff;
    private List<Tariff> mTariffList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
        setTheme(Profile.getProfile().getThemeId()); // TODO
        setContentView(R.layout.activity_public_transport);
        setTitle(R.string.activities_PublicTransportActivity_title);
        prepare();
    }


    private void prepare() {
        prepareToolbar();
        prepareVars();
        prepareView();
    }


    private void prepareToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_transport);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar()
                .setDisplayHomeAsUpEnabled(true);
    }


    private void prepareVars() {
        mProfile = Profile.getProfile();

        String cityId = getIntent().getStringExtra(EXTRA_TRANSPORT_CITY_ID); // TODO
        mCurrentPosition = getIntent().getParcelableExtra(EXTRA_CURRENT_POSITION); // TODO

        mCity = City.getCity(cityId);
        mTariffList = Tariff.getTariffs(mCity);
        Log.d("Logos", mTariffList.toString());

        String tariffId = getIntent().getStringExtra(EXTRA_CURRENT_TARIFF_ID);
        mTariff = Tariff.getTariffById(tariffId);

        mTariffAdapter = new TariffAdapter(mTariffList, this, mTariff);
    }


    private void prepareView() {
        RecyclerView mTariffView = (RecyclerView) findViewById(R.id.rv_transport_tariff_list);
        mTariffView.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false)
        );
        mTariffView.setAdapter(mTariffAdapter);
        for (int i = 0; i < mTariffList.size(); i++) {
            if (TextUtils.equals(mTariff.getTariffId(), mTariffList.get(i).getTariffId()))
                mTariffView.scrollToPosition(i);
        }

        LatLng latLng = new LatLng(mCurrentPosition.latitude, mCurrentPosition.longitude);
        mPublicTransportMap = PublicTransportMap.newInstance(latLng);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fl_transport_map_container, mPublicTransportMap, "main_transport")
                .commit();
    }


    @Override
    protected void onResume() {
        super.onResume();
        startUpdateTariffs();
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mUpdateTariffHandler != null && mUpdateTariffRunnable != null) {
            mUpdateTariffHandler.removeCallbacks(mUpdateTariffRunnable);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onTariffClicked(Tariff tariff) {
        mTariff = tariff;
        findCarsByTariff(mTariff);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void startUpdateTariffs() {
        if (mUpdateTariffHandler != null && mUpdateTariffRunnable != null) {
            mUpdateTariffHandler.removeCallbacks(mUpdateTariffRunnable);
        }

        mUpdateTariffHandler = new Handler();
        mUpdateTariffRunnable = new Runnable() {
            @Override
            public void run() {
                if (mTariff != null) {
                    findCarsByTariff(mTariff);
                }
                mUpdateTariffHandler.postDelayed(mUpdateTariffRunnable, TARIFF_UPDATE_INTERVAL);
            }
        };
        mUpdateTariffHandler.post(mUpdateTariffRunnable);
    }


    private void findCarsByTariff(Tariff tariff) {
        mTariff = tariff;
        getSpiceManager().execute(new GetCarsRequest(
                mProfile.getAppId(),
                mProfile.getApiKey(),
                this,
                mCity.getCityId(),
                String.valueOf(mCurrentPosition.latitude),
                String.valueOf(mCurrentPosition.longitude),
                mProfile.getTenantId(),
                true
        ), new CarsListener());
    }


    @Subscribe
    public void onMessage(CarFreeEvent carFreeEvent) {
        List<Car> cars = carFreeEvent.getCarList();
        mPublicTransportMap.showCars(cars);
    }

}
