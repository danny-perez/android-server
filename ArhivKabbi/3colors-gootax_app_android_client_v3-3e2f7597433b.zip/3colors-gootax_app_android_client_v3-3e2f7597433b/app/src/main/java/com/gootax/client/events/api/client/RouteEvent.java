package com.gootax.client.events.api.client;

/**
 * Created by gootax on 10.11.16.
 */

public class RouteEvent {

}
