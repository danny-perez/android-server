package com.gootax.client.network.listeners;

import android.util.Log;

import com.gootax.client.events.api.client.ActivateReferralCodeEvent;
import com.gootax.client.events.api.client.ActivateReferralEvent;
import com.gootax.client.models.Profile;
import com.octo.android.robospice.persistence.exception.SpiceException;
import com.octo.android.robospice.request.listener.RequestListener;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

import retrofit.client.Response;
import retrofit.mime.TypedByteArray;

/**
 * Created by gootax on 12.04.17.
 */

public class ReferralSystemCodeListener implements RequestListener<Response> {

    @Override
    public void onRequestFailure(SpiceException spiceException) {
    }

    @Override
    public void onRequestSuccess(Response response) {
        try {
            Log.d("Logos", new String(((TypedByteArray) response.getBody())
                    .getBytes()));
            JSONObject jsonResult = new JSONObject(new String(((TypedByteArray) response.getBody())
                    .getBytes()));

            int result = jsonResult.optInt("result");

            EventBus.getDefault().post(new ActivateReferralCodeEvent(result));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
