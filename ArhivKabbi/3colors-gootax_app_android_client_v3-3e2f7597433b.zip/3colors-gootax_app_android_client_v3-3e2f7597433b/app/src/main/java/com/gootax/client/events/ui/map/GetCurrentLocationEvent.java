package com.gootax.client.events.ui.map;

public class GetCurrentLocationEvent {

    public GetCurrentLocationEvent() {
    }
}
