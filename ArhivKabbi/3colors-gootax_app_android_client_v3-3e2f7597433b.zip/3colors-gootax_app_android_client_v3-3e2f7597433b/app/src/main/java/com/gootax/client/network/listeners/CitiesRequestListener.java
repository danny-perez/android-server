package com.gootax.client.network.listeners;

import android.util.Log;

import com.gootax.client.R;
import com.gootax.client.events.api.client.AppUpdateEvent;
import com.gootax.client.utils.DataBaseHelper;
import com.octo.android.robospice.persistence.exception.SpiceException;
import com.octo.android.robospice.request.listener.RequestListener;
import com.gootax.client.events.api.client.SaveCitiesEvent;
import com.gootax.client.models.City;
import com.gootax.client.models.Option;
import com.gootax.client.models.Tariff;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import retrofit.client.Response;
import retrofit.mime.TypedByteArray;


public class CitiesRequestListener implements RequestListener<Response> {

    public static final int OLD_CLIENT_VERSION = 104;

    @Override
    public void onRequestFailure(SpiceException spiceException) {
        EventBus.getDefault().post(new SaveCitiesEvent(false,
                R.string.activities_OptionsActivity_progress_conn_error));
    }

    @Override
    public void onRequestSuccess(Response response) {
        Log.d("Logos", "cities req: " + new String(((TypedByteArray)
                response.getBody()).getBytes()));
        boolean isSaved = false;
        try {
            JSONObject json = new JSONObject(new String(((TypedByteArray)
                    response.getBody()).getBytes()));

            int responseCode = json.optInt("code");
            if (responseCode == OLD_CLIENT_VERSION) {
                EventBus.getDefault().post(new AppUpdateEvent());
                return;
            }

            JSONArray jsonResult = json.getJSONObject("result").getJSONArray("city_list");

            if (jsonResult.length() > 0) {
                Option.deleteAllOptions();
                Tariff.deleteAllTariffs();
                City.deleteAllCities();
            }

            List<City> cities = new ArrayList<>();

            for (int i = 0; i < jsonResult.length(); i++) {
                City city = new City(jsonResult.getJSONObject(i).getString("city_id"),
                        jsonResult.getJSONObject(i).getString("city_name"),
                        Double.valueOf(jsonResult.getJSONObject(i).getString("city_lat")),
                        Double.valueOf(jsonResult.getJSONObject(i).getString("city_lon")),
                        jsonResult.getJSONObject(i).getString("currency"),
                        jsonResult.getJSONObject(i).getString("phone"),
                        jsonResult.getJSONObject(i).getString("city_reseption_area"));
                         cities.add(city);
            }

            DataBaseHelper.executeTransactionFromList(cities);

            isSaved = true;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        int infoText = isSaved ?
                R.string.activities_OptionsActivity_progress_success :
                R.string.activities_OptionsActivity_progress_acc_error;
        EventBus.getDefault().post(new SaveCitiesEvent(isSaved, infoText));
    }

}
