package com.gootax.client.events.api.geo;

public class SearchEvent extends GeoEvent {}
