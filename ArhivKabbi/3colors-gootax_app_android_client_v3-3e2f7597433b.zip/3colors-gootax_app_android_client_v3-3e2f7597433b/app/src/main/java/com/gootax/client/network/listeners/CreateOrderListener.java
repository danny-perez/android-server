package com.gootax.client.network.listeners;

import android.util.Log;

import com.gootax.client.app.Constants;
import com.octo.android.robospice.persistence.exception.SpiceException;
import com.octo.android.robospice.request.listener.RequestListener;
import com.gootax.client.events.api.client.CreateOrderEvent;

import org.json.JSONException;
import org.json.JSONObject;

import org.greenrobot.eventbus.EventBus;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;

public class CreateOrderListener implements RequestListener<Response> {

    @Override
    public void onRequestFailure(SpiceException spiceException) {
        EventBus.getDefault().post(new CreateOrderEvent(Constants.REQUEST_FAILURE_CODE));
    }

    @Override
    public void onRequestSuccess(Response response) {
        try {
            Log.d("CREATE_ORDER", new String(((TypedByteArray)
                    response.getBody()).getBytes()));

            JSONObject jsonOrder = new JSONObject(new String(((TypedByteArray)
                    response.getBody()).getBytes()));

            if (jsonOrder.getString("info").equals("OK"))
                EventBus.getDefault().post(new CreateOrderEvent(jsonOrder.getJSONObject("result").getString("order_id"),
                        jsonOrder.getJSONObject("result").getString("order_number"),
                        jsonOrder.getInt("code"), jsonOrder.getJSONObject("result").getString("type")));
            else
                EventBus.getDefault().post(new CreateOrderEvent(jsonOrder.getInt("code")));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
