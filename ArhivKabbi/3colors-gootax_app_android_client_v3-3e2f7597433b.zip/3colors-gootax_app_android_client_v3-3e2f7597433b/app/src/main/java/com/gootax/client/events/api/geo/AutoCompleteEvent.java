package com.gootax.client.events.api.geo;

public class AutoCompleteEvent extends GeoEvent {}
