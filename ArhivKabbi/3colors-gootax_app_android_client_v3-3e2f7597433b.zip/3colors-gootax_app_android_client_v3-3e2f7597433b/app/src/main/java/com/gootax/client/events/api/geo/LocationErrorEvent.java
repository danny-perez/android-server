package com.gootax.client.events.api.geo;

/**
 * Created by gootax on 27.03.17.
 */

public class LocationErrorEvent {
}
