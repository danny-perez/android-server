package com.gootax.client.maps.google;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.gootax.client.R;
import com.gootax.client.models.Car;
import com.gootax.client.views.adapters.map.MapInfoWindowAdapter;

import java.util.List;


public class PublicTransportMap extends SupportMapFragment
        implements OnMapReadyCallback{

    public static final String ARGUMENT_LAT_LON = "ARGUMENT_LAT_LON";

    private GoogleMap mGoogleMap;
    private LatLng mLatLng;

    public static PublicTransportMap newInstance(LatLng latLng) {
        PublicTransportMap transportMap = new PublicTransportMap();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARGUMENT_LAT_LON, latLng);
        transportMap.setArguments(bundle);
        return transportMap;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        mLatLng = getArguments().getParcelable(ARGUMENT_LAT_LON);
        getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;

        MapInfoWindowAdapter sosInfoWindowAdapter = new MapInfoWindowAdapter(getContext());
        if (sosInfoWindowAdapter != null) {
            mGoogleMap.setInfoWindowAdapter(sosInfoWindowAdapter);
        }
        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mLatLng, 17));
    }


    public void showCars(List<Car> cars) {
        mGoogleMap.clear();
        for(Car car: cars) {
            LatLng latLng = new LatLng(car.getLat(), car.getLon());
            MarkerOptions markerOptions = new MarkerOptions()
                    .position(latLng)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.car));
            Marker marker = mGoogleMap.addMarker(markerOptions);
            marker.setTag(car);
        }
    }

}
