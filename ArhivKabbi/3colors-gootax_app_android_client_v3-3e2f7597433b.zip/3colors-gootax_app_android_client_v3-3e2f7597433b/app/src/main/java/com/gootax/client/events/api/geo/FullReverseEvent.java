package com.gootax.client.events.api.geo;

public class FullReverseEvent extends GeoEvent {}
