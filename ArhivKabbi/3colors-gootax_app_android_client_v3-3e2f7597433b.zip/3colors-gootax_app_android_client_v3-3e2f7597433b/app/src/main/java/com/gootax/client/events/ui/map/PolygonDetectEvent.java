package com.gootax.client.events.ui.map;


import com.gootax.client.models.City;

public class PolygonDetectEvent {

    private City city;

    public PolygonDetectEvent(City city) {
        this.city = city;
    }

    public City getCity() {
        return city;
    }
}
