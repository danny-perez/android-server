package com.gootax.client.network.listeners;

import android.util.Log;

import com.gootax.client.events.api.client.ActivateReferralEvent;
import com.gootax.client.models.Profile;
import com.octo.android.robospice.persistence.exception.SpiceException;
import com.octo.android.robospice.request.listener.RequestListener;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

import retrofit.client.Response;
import retrofit.mime.TypedByteArray;

/**
 * Created by gootax on 06.12.16.
 */

public class ReferralSystemListener implements RequestListener<Response> {

    @Override
    public void onRequestFailure(SpiceException spiceException) {
    }

    @Override
    public void onRequestSuccess(Response response) {
        try {
            Log.d("Logos", "REF_SYSTEM: " + new String(((TypedByteArray) response.getBody())
                    .getBytes()));
            JSONObject jsonResult = new JSONObject(new String(((TypedByteArray) response.getBody())
                    .getBytes())).getJSONObject("result");

            String code = null;
            int result = jsonResult.getInt("is_activate");

            if (result == 1) {
                code = jsonResult.getString("code");
            }

            EventBus.getDefault().post(new ActivateReferralEvent(result, code));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
