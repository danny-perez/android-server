package com.gootax.client.events.api.client;

public class AppUpdateEvent {
/*
    private int code;

    public AppUpdateEvent(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
*/
}
