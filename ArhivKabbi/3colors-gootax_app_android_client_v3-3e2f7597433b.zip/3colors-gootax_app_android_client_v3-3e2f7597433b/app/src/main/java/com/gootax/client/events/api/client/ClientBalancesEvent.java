package com.gootax.client.events.api.client;

/**
 * Created by gootax on 13.12.16.
 */

public class ClientBalancesEvent {
}
