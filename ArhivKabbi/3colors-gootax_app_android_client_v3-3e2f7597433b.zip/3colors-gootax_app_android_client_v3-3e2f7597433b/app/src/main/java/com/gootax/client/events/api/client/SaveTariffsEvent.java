package com.gootax.client.events.api.client;


import com.gootax.client.models.Option;
import com.gootax.client.models.Tariff;

import java.util.List;

public class SaveTariffsEvent {

    private List<Tariff> tariffList;

    public SaveTariffsEvent(List<Tariff> tariffList) {
        this.tariffList = tariffList;

    }

    public List<Tariff> getTariffList() {
        return tariffList;
    }

}
